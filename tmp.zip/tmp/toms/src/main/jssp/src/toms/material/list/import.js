/**
 * バインド変数.
 */
var $bind = {};

load("toms/common/mastermaintenance");

// 素材コード
var materialCode = MessageManager.getMessage("TOMS.MASTER.MAINTENANCE.MATERIAL.LABEL.MATERIAL_CODE");
// 親商品形態コード
var parentCommodityShapeCode = MessageManager.getMessage("TOMS.MASTER.MAINTENANCE.COMMODITYSHAPE.LABEL.PARENT_COMMODITY_SHAPE_CODE");
// 商品形態コード
var commodityShapeCode = MessageManager.getMessage("TOMS.MASTER.MAINTENANCE.COMMODITYSHAPE.LABEL.COMMODITY_SHAPE_CODE");
// 原材料名
var materialName = MessageManager.getMessage("TOMS.MASTER.MAINTENANCE.MATERIAL.LABEL.MATERIAL_NAME");
// パーセント
var percent = MessageManager.getMessage("TOMS.MASTER.MAINTENANCE.MATERIAL.LABEL.PARCENT");
// 表示順
var displayOrder = MessageManager.getMessage("TOMS.MASTER.MAINTENANCE.COMMODITYSHAPE.LABEL.DISPLAY_ORDER");
//// JDEコード
//var jdeCode = MessageManager.getMessage("TOMS.MASTER.MAINTENANCE.COMMODITYSHAPE.LABEL.JDE_CODE");
// たたみ袋制御フラグ
var matControlFlg = MessageManager.getMessage("TOMS.MASTER.MAINTENANCE.MATERIAL.LABEL.MAT_CONTROL_FLG");
// たたみ袋SKUコード
var bagSkuCode = MessageManager.getMessage("TOMS.MASTER.MAINTENANCE.MATERIAL.LABEL.BAG_SKU_CODE");
// 運用開始日
var appliedStartDate = MessageManager.getMessage("TOMS.MASTER.MAINTENANCE.COMMODITYSHAPE.LABEL.APPLIED_START_DATE");

/**
 * 初期表示.
 * @param request リクエストパラメータ.
 */
function init(request) {

    load("toms/common/csv/CsvUtil");
    load("toms/common/csv/CsvCheker");
    load("toms/common/cmnUtil");
    
    var response = Web.getHTTPResponse();
    response.setContentType("text/plain; charset=utf-8");
    var csv = []; // csv二次元配列
    var stErr = new java.lang.StringBuilder(); // エラーメッセージ
    var stMsg = new java.lang.StringBuilder(); // 成功メッセージ
    var updateCount = { newCount: 0, updateCount: 0, deleteCount: 0};
    var ret = true;
    
    // ファイルロード csv二次元ファイル化
    if (!CsvUtil.load2Csv(request, csv, stErr)) {
        doError(response, stErr);
        return;
    }
    
    // CSVデータ有無チェック
    if (csv.length < 2) {
        // CSVファイルにデータ行が存在しない場合はエラー
        stErr.append(MessageManager.getMessage("TOMS.MASTER.MAINTENANCE.MATERIAL.LIST.LABEL.MESSAGE.ERROR.CSVNODATA"));
        doError(response, stErr);
        return;
    }

    // CSVデータの行数分繰り返す（先頭行はヘッダ行のため次の行から始める）
    for (var rowPos = 1; rowPos < csv.length; rowPos++) {
        // データチェック
        ret = check(csv[rowPos], rowPos, stErr);
        // DB存在チェック
        if (ret) {
            ret = dbCheck(csv[rowPos], rowPos, stErr);
        }
        // DB更新
        if (ret) {
            ret = dbUpdate(csv[rowPos], rowPos, stErr, updateCount);
        }
    }

    // 正常値の返却
    // 挿入件数
    stMsg.append(MessageManager.getMessage("TOMS.MASTER.MAINTENANCE.MATERIAL.LIST.LABEL.ENTRYNUM", String(updateCount.newCount)));
    // 更新件数
    stMsg.append(MessageManager.getMessage("TOMS.MASTER.MAINTENANCE.MATERIAL.LIST.LABEL.UPDATENUM", String(updateCount.updateCount)));
    // 削除件数
    stMsg.append(MessageManager.getMessage("TOMS.MASTER.MAINTENANCE.MATERIAL.LIST.LABEL.DELETENUM", String(updateCount.deleteCount)));

    var stringErr = stErr.toString();
    var stringMsg = stMsg.toString();
    response.sendMessageBodyString(ImJson.toJSONString([{
        "errorMessage": stringErr,
        "successMessage": stringMsg
    }]));
}

/**
 * チェック
 * @param csvRowData csvの行データ.(IN)
 * @param rowPos 行番号.(IN)
 * @param stErr エラーメッセージパラメータ.(OUT)
 */
function check(csvRowData, rowPos, stErr) {
    var ret = true;
    var ope = csvRowData[0];
    var sRowPos = String(rowPos);
    var cellPos = null;

    // 列数チェック
    var columnCnt = 11;
    if (csvRowData.length != columnCnt) {
        if (csvRowData.length > columnCnt) {
            stErr.append(MessageManager.getMessage("TOMS.MASTER.MAINTENANCE.MATERIAL.LIST.LABEL.MESSAGE.ERROR.COLUMN1",sRowPos));
        } else if (csvRowData.length < columnCnt) {
            stErr.append(MessageManager.getMessage("TOMS.MASTER.MAINTENANCE.MATERIAL.LIST.LABEL.MESSAGE.ERROR.COLUMN2",sRowPos));
        }
        ret = false;
        return ret;
    }

    // --------------------
    //  0 更新区分
    // --------------------
    // データチェック
    if (isBlank(ope)) {
        stErr.append(MessageManager.getMessage("TOMS.MASTER.MAINTENANCE.MATERIAL.LIST.LABEL.MESSAGE.ERROR.UPDATEDIVISION", sRowPos));
        ret = false;
    }
    if (ope != "I" && ope != "U" && ope != "D") {
        stErr.append(MessageManager.getMessage("TOMS.MASTER.MAINTENANCE.MATERIAL.LIST.LABEL.MESSAGE.ERROR.UPDATEDIVISION_FORMAT", sRowPos));
        ret = false;
    }
    // --------------------
    //  1 素材コード
    // --------------------
    cellPos = 1;
    // 必須チェック
    if (!CsvCheker.required(csvRowData[cellPos], rowPos, cellPos, materialCode, stErr)) {
        ret = false;
    } else {
        // 挿入、更新の場合
        if (ope == "I" || ope == "U") {
            // 半角英数字チェック
            if (!CsvCheker.isAlphanumeric(csvRowData[cellPos], rowPos, cellPos, materialCode, stErr)) {
                ret = false;
            }
            // 文字数チェック
            if (!CsvCheker.maxLength(csvRowData[cellPos], 16, rowPos, cellPos, materialCode, stErr)) {
                ret = false;
            }
        }
    }
    // --------------------
    //  2 親商品形態コード
    // --------------------
    cellPos = 2;
    // 必須チェック
    if (!CsvCheker.required(csvRowData[cellPos], rowPos, cellPos, parentCommodityShapeCode, stErr)) {
        ret = false;
    } else {
        // 挿入、更新の場合
        if (ope == "I" || ope == "U") {
            // 半角英数字チェック
            if (!CsvCheker.isAlphanumeric(csvRowData[cellPos], rowPos, cellPos, parentCommodityShapeCode, stErr)) {
                ret = false;
            }
            // 文字数チェック
            if (!CsvCheker.maxLength(csvRowData[cellPos], 16, rowPos, cellPos, parentCommodityShapeCode, stErr)) {
                ret = false;
            }
            // 親商品形態コードチェック
            if (!CsvCheker.isParentCommodityPrefix(csvRowData[cellPos],rowPos, cellPos, parentCommodityShapeCode, stErr)) {
            	
                ret = false;
            }
        }
    }
    // --------------------
    //  3 商品形態コード
    // --------------------
    cellPos = 3;
    // 必須チェック
    if (!CsvCheker.required(csvRowData[cellPos], rowPos, cellPos, commodityShapeCode, stErr)) {
        ret = false;
    } else {
        // 挿入、更新の場合
        if (ope == "I" || ope == "U") {
            // 半角英数字チェック
            if (!CsvCheker.isAlphanumeric(csvRowData[cellPos], rowPos, cellPos, commodityShapeCode, stErr)) {
                ret = false;
            }
            // 文字数チェック
            if (!CsvCheker.maxLength(csvRowData[cellPos], 16, rowPos, cellPos, commodityShapeCode, stErr)) {
                ret = false;
            }
            // 商品形態コードチェック
            if (!CsvCheker.isCommodityPrefix(csvRowData[cellPos], rowPos, cellPos, commodityShapeCode, stErr)) {
                ret = false;
            }
        }
    }
    // --------------------
    //  4 原材料名
    // --------------------
    cellPos = 4;
    // 挿入、更新の場合
    if (ope == "I" || ope == "U") {
        // 必須チェック
        if (!CsvCheker.required(csvRowData[cellPos], rowPos, cellPos, materialName, stErr)) {
            ret = false;
        } else {
            // 文字数チェック
            if (!CsvCheker.maxLength(csvRowData[cellPos], 30, rowPos, cellPos, materialName, stErr)) {
                ret = false;
            }
        }
    }
    // --------------------
    //  5 パーセント
    // --------------------
    cellPos = 5;
    // 挿入、更新の場合
    if (ope == "I" || ope == "U") {
        // 半角数値チェック
        if (!CsvCheker.isNum(csvRowData[cellPos], rowPos, cellPos, percent, stErr)) {
            ret = false;
        }
        // 桁数チェック
        if (!CsvCheker.maxLength(csvRowData[cellPos], 3, rowPos, cellPos, percent, stErr)) {
            ret = false;
        }
    }
    // --------------------
    //  6 表示順
    // --------------------
    cellPos = 6;
    // 挿入、更新の場合
    if (ope == "I" || ope == "U") {
        // 半角数値チェック
        if (!CsvCheker.isNum(csvRowData[cellPos], rowPos, cellPos, displayOrder, stErr)) {
            ret = false;
        }
        // 桁数チェック
        if (!CsvCheker.maxLength(csvRowData[cellPos], 8, rowPos, cellPos, displayOrder, stErr)) {
            ret = false;
        }
    }
//    // --------------------
//    //  7 JDEコード
//    // --------------------
//    cellPos = 7;
//    // 挿入、更新の場合
//    if (ope == "I" || ope == "U") {
//        // 必須チェック
//        if (!CsvCheker.required(csvRowData[cellPos], rowPos, cellPos, jdeCode, stErr)) {
//            ret = false;
//        } else {
//            // 半角英数字チェック
//            if (!CsvCheker.isAlphanumeric(csvRowData[cellPos], rowPos, cellPos, jdeCode, stErr)) {
//                ret = false;
//            }
//            // 文字数チェック
//            if (!CsvCheker.maxLength(csvRowData[cellPos], 8, rowPos, cellPos, jdeCode, stErr)) {
//                ret = false;
//            }
//        }
//    }
    // --------------------
    //  7 たたみ袋制御フラグ
    // --------------------
    cellPos = 7;
    // 挿入、更新の場合
    if (ope == "I" || ope == "U") {
        // 必須チェック
        if (!CsvCheker.required(csvRowData[cellPos], rowPos, cellPos, matControlFlg, stErr)) {
            ret = false;
        } else {
            // 桁数チェック
            if (!CsvCheker.maxLength(csvRowData[cellPos], 1, rowPos, cellPos, matControlFlg, stErr)) {
                ret = false;
            }
            // データチェック
            if (csvRowData[cellPos] != "0" && csvRowData[cellPos] != "1") {
                stErr.append(MessageManager.getMessage("TOMS.MASTER.MAINTENANCE.MATERIAL.LIST.LABEL.MESSAGE.ERROR.NO_MAT_CONTROL_FLG", sRowPos, String(cellPos + 1)));
                ret = false;
            }
        }
    }
    // --------------------
    //  8 たたみ袋SKUコード
    // --------------------
    // 挿入、更新の場合
    cellPos = 8;
    if (ope == "I" || ope == "U") {
        // 半角英数字チェック
        if (!CsvCheker.isAlphanumeric(csvRowData[cellPos], rowPos, cellPos, bagSkuCode, stErr)) {
            ret = false;
        }
        // 文字数チェック
        if (!CsvCheker.maxLength(csvRowData[cellPos], 24, rowPos, cellPos, bagSkuCode, stErr)) {
            ret = false;
        }
        // データチェック
        // たたみ袋SKUコードは「05S01」始まりのコードに限定する
        var skuStartChar = MessageManager.getMessage("TOMS.MASTER.MAINTENANCE.MATERIAL.LABEL.BAG_SKU_CODE.START_WITH");
        if (csvRowData[cellPos]) {
            if (csvRowData[cellPos].lastIndexOf(skuStartChar, 0) == -1) {
                stErr.append(MessageManager.getMessage("TOMS.MASTER.MAINTENANCE.MATERIAL.LIST.LABEL.MESSAGE.ERROR.BAG_SKU_CODE", sRowPos, String(cellPos + 1), csvRowData[cellPos].trim(), skuStartChar));
                ret = false;
            }
        }
    }
    // --------------------
    //  9 適用開始日
    // --------------------
    cellPos = 9;
    // 必須チェック
    if (!CsvCheker.required(csvRowData[cellPos], rowPos, cellPos, appliedStartDate, stErr)) {
        ret = false;
    } else {
        // 挿入、更新の場合
        if (ope == "I" || ope == "U") {
            // 日付チェック
            if (!CsvCheker.isDate(csvRowData[cellPos], rowPos, cellPos, appliedStartDate, stErr)) {
                ret = false;
            }
        }
    }
    // --------------------
    //  10 削除フラグ
    // --------------------
    cellPos = 10;
    // 挿入の場合
    if (ope == "I") {
        // データチェック
        if (csvRowData[cellPos] != "0") {
            stErr.append(MessageManager.getMessage("TOMS.MASTER.MAINTENANCE.MATERIAL.LIST.LABEL.MESSAGE.ERROR.DEL_FLAG", sRowPos));
            ret = false;
        }
    }
    // 挿入、更新の場合
    else if (ope == "I" || ope == "U") {
        // データチェック
        if (csvRowData[cellPos] != "0" && csvRowData[cellPos] != "1") {
            stErr.append(MessageManager.getMessage("TOMS.MASTER.MAINTENANCE.MATERIAL.LIST.LABEL.MESSAGE.ERROR.DEL_FLAG_FORMAT", sRowPos));
            ret = false;
        }
    }

    return ret;
}

/*
 * DBによるデータ有無チェック
 * @param csvRowData csvの行データ.(IN)
 * @param rowPos 行番号.(IN)
 * @param stErr エラーメッセージパラメータ.(OUT)
 */
function dbCheck(csvRowData, rowPos, stErr) {
    var ret = true;
    var ope = csvRowData[0];
    var sRowPos = String(rowPos);
    var cellPos = null;

    // 素材マスタのキー検索（素材コード、商品形態コード、親商品形態コード、適用開始日）
    var resultMaterial = MasterMain.getMaterialByPk(csvRowData[1], csvRowData[2], csvRowData[3], csvRowData[9]);
    // 登録、更新
    if (ope == "I" || ope == "U") {
        // 素材コードの内部コードチェック
        cellPos = 1;
        var resultMaterialCd = MasterMain.checkCodeMaster("03", "01", csvRowData[cellPos]);
        if (resultMaterialCd.countRow == 0) {
            // 存在しない場合
            stErr.append(MessageManager.getMessage("TOMS.MASTER.MAINTENANCE.MATERIAL.LIST.LABEL.MESSAGE.ERROR.CODEMASTER.NOTINLINE", sRowPos, String(cellPos + 1), materialCode));
            ret = false;
        }
//        // JDEコードの内部コードチェック
//        cellPos = 7;
//        var resultJdeCd = MasterMain.checkCodeMaster("03", "02", csvRowData[cellPos]);
//        if (resultJdeCd.countRow == 0) {
//            // 存在しない場合
//            stErr.append(MessageManager.getMessage("TOMS.MASTER.MAINTENANCE.MATERIAL.LIST.LABEL.MESSAGE.ERROR.CODEMASTER.NOTINLINE", sRowPos, String(cellPos + 1), jdeCode));
//            ret = false;
//        }
        // たたみ袋SKUコードの存在チェック
        var resultBagSku = MasterMain.getBagSku(csvRowData[8], "");
        if (resultBagSku.countRow == 0) {
            // 存在しない場合
            cellPos = 9;
            stErr.append(MessageManager.getMessage("TOMS.MASTER.MAINTENANCE.MATERIAL.LIST.LABEL.MESSAGE.ERROR.DATANOTEXIST.BAG_SKU_CODE", sRowPos, String(cellPos + 1), csvRowData[8].trim()));
            ret = false;
        }
    }
    if (ope == "I") {
        // 素材マスタの存在チェック
        if (resultMaterial.countRow > 0) {
            stErr.append(MessageManager.getMessage("TOMS.MASTER.MAINTENANCE.MATERIAL.LIST.LABEL.MESSAGE.ERROR.DATAEXIST", sRowPos, csvRowData[1].trim(), csvRowData[2].trim(), csvRowData[3].trim(), csvRowData[9]));
            ret = false;
        }
        // 親商品形態コード・商品形態コードの存在チェック
        var resultCommodyShape = MasterMain.getCommodyShape(csvRowData[2].trim(), csvRowData[3].trim(), "");
        if (resultCommodyShape.countRow == 0) {
            // 存在しない場合
            stErr.append(MessageManager.getMessage("TOMS.MASTER.MAINTENANCE.MATERIAL.LIST.LABEL.MESSAGE.ERROR.DATANOTEXIST.COMMODITYSHAPE", sRowPos, csvRowData[2].trim(), csvRowData[3].trim()));
            ret = false;
        }
    // 更新、削除の場合
    } else {
        // 存在チェック
        if (resultMaterial.countRow < 1) {
            stErr.append(MessageManager.getMessage("TOMS.MASTER.MAINTENANCE.MATERIAL.LIST.LABEL.MESSAGE.ERROR.DATANOTEXIST", sRowPos, csvRowData[1].trim(), csvRowData[2].trim(), csvRowData[3].trim(), csvRowData[9]));
            ret = false;
        }
        // 複数存在チェック
        if (resultMaterial.countRow > 1) {
            stErr.append(MessageManager.getMessage("TOMS.MASTER.MAINTENANCE.MATERIAL.LIST.LABEL.MESSAGE.ERROR.DUPLICATE", sRowPos, csvRowData[1].trim(), csvRowData[2].trim(), csvRowData[3].trim(), csvRowData[9]));
            ret = false;
        }
    }

    return ret;
}

/**
 * DB更新
 * 
 * @param csvRowData csvの行データ.(IN)
 * @param rowPos 行番号.(IN)
 * @param stErr エラーメッセージパラメータ.(OUT)
 * @param updateCount (OUT)
 */
function dbUpdate(csvRowData, rowPos, stErr, counts) {

    var ret = true;
    var newCount = counts.newCount;
    var updateCount = counts.updateCount;
    var deleteCount = counts.deleteCount;

    var ope = csvRowData[0];
    var sRowPos = String(rowPos);
    var result;

    // CSVの行データからDB更新用データ作成
    var entity = createEntity(csvRowData);
    var condition = "TRIM(mly57amtc) = ?"
                  + " AND TRIM(mly57apcsc) = ? "
                  + " AND TRIM(mly57acsc) = ? "
                  + " AND mleftj = ? ";
    var params = [
            DbParameter.string(entity["mly57amtc"]),
            DbParameter.string(entity["mly57apcsc"]),
            DbParameter.string(entity["mly57acsc"]),
            DbParameter.number(entity["mleftj"])
    ];


    Transaction.begin();
    var masterTable = 'F57A5130'
    if (ope == "I") {           //挿入
        result = MasterMain.insertToMasterTable(masterTable, entity);
        newCount++;
    } else if (ope =="U") {     //更新
        result = MasterMain.updateToMasterTable(masterTable, entity, condition, params);
        updateCount++;
    } else if  (ope =="D") {    //削除
        result = MasterMain.removeFromMasterTable(masterTable, condition, params);
        deleteCount++;
    }
    if (!result.error && result.countRow != 1) {
        Transaction.rollback();
        stErr.append(MessageManager.getMessage("TOMS.MASTER.MAINTENANCE.MATERIAL.LIST.LABEL.MESSAGE.ERROR.ABNORMAL", sRowPos));
        return false;
    }
    if (result.error) {
        Transaction.rollback();
        stErr.append(MessageManager.getMessage("TOMS.MASTER.MAINTENANCE.MATERIAL.LIST.LABEL.MESSAGE.ERROR.DB"));
        stErr.append(MessageManager.getMessage("TOMS.MASTER.MAINTENANCE.MATERIAL.LIST.LABEL.MESSAGE.CSVLINE", sRowPos));
        return false;
    }
    Transaction.commit();

    counts.newCount = newCount;
    counts.updateCount = updateCount;
    counts.deleteCount = deleteCount;

    return true;
}

/**
 * DB更新用データ作成
 * 
 * @param csvRowData csvの行データ.
 */
function createEntity(csvRowData) {

    var userContext = Contexts.getUserContext();
    var now = new Date();

    // 変数初期化
    var mly57amtc = null;    // 素材コード
    var mly57apcsc = null;   // 親商品形態コード
    var mly57acsc = null;    // 商品形態コード
    var mldl01 = null;       // 原材料名
    var mlpct1 = null;       // パーセント
    var mlsnn = null;        // 表示順
    var mly57ajdc = null;    // JDEコード
    var mly57amflg = null;   // たたみ袋制御フラグ
    var mly57absc = null;    // たたみ袋SKUコード
    var mleftj = null;       // 適用開始日
    var mlexdj = cmnUtil.convertDateToJulia(new Date(MessageManager.getMessage("TOMS.COMMON.CONSTANT.ENDDATE")));    // 適用終了日
    var mly57adflg = null;   // 削除フラグ

    var mluser = userContext.userProfile.userCd;     // ユーザID
    var mlpid = MessageManager.getMessage("TOMS.COMMON.CONSTANT.PROGRAM.ID");    // プログラムID
    var mlupmj = cmnUtil.convertDateToJulia(now);    // 更新日付
    var mlupmt = cmnUtil.getTime(now);               // 更新時刻

    // 素材コード
    if (!isBlank(cmnUtil.getData(csvRowData[1], 0))) {
        mly57amtc = cmnUtil.getData(csvRowData[1], 0);
    }
    // 親商品形態コード
    if(!isBlank(cmnUtil.getData(csvRowData[2], 0))){
        mly57apcsc = cmnUtil.getData(csvRowData[2], 0);
    }
    // 商品形態コード
    if (!isBlank(cmnUtil.getData(csvRowData[3], 0))) {
        mly57acsc = cmnUtil.getData(csvRowData[3], 0);
    }
    // 原材料名
    if (!isBlank(cmnUtil.getData(csvRowData[4], 0))) {
        mldl01 = cmnUtil.getData(csvRowData[4], 0);
    }
    // パーセント
    if(!isBlank(cmnUtil.getData(csvRowData[5], 1))){
        mlpct1 = cmnUtil.getData(csvRowData[5], 1);
    }
    // 表示順
    if(!isBlank(cmnUtil.getData(csvRowData[6], 1))){
        mlsnn = cmnUtil.getData(csvRowData[6], 1);
    }
//    // JDEコード
//    if(!isBlank(cmnUtil.getData(csvRowData[7], 0))){
//        mly57ajdc = cmnUtil.getData(csvRowData[7], 0);
//    }
    // たたみ袋制御フラグ
    if(!isBlank(cmnUtil.getData(csvRowData[7], 1))){
        mly57amflg = cmnUtil.getData(csvRowData[7], 1);
    }
    // たたみ袋SKUコード
    if(!isBlank(cmnUtil.getData(csvRowData[8], 0))){
        mly57absc = cmnUtil.getData(csvRowData[8], 0);
    }
    // 適用開始日
    if(!isBlank(csvRowData[9])){
        mleftj = cmnUtil.convertDateToJulia(new Date(csvRowData[9]));
    }
    // 削除フラグ
    if(!isBlank(cmnUtil.getData(csvRowData[10], 1))){
        mly57adflg = cmnUtil.getData(csvRowData[10], 1);
    }
    
    var entity = {
        mly57amtc : mly57amtc,
        mly57apcsc : mly57apcsc,
        mly57acsc : mly57acsc,
        mldl01 : mldl01,
        mlpct1 : mlpct1,
        mlsnn : mlsnn,
//        mly57ajdc : mly57ajdc,　JDEコード廃止に伴い全角スペースを設定
        mly57ajdc : "　",
        mly57amflg : mly57amflg,
        mly57absc : mly57absc,
        mleftj : mleftj,
        mlexdj : mlexdj,
        mly57adflg : mly57adflg,
        mluser : mluser,
        mlpid : mlpid,
        mlupmj : mlupmj,
        mlupmt : mlupmt 
    };
    
    return entity;
}

/**
 * エラー処理
 * 
 * @param response　レスポンス
 * @param stErr エラーメッセージパラメータ.
 */
function doError(response, stErr) {
        stErr.insert(0, MessageManager.getMessage("TOMS.MASTER.MAINTENANCE.MATERIAL.LIST.LABEL.ENTRY.ERROR"));
        var stringErr = stErr.toString();
        response.sendMessageBodyString(ImJson.toJSONString([{
            "errorMessage": stringErr,
            "successMessage": ""
        }]));
}
