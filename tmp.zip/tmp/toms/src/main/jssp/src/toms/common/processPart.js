/**
* staticオブジェクトの作成 
 */ 
load('toms/common/cmnUtil');
 var _SHARED_DB_KEY ="toms-web-dev";
function ProcessPart(){};



ProcessPart.getProcessPartList = function(params, countFlag ,paramStart, paramEnd ){
	var db = new SharedDatabase(_SHARED_DB_KEY);
	var mky57appc1 = isBlank(params.mky57appc1) ? null : DbParameter.string(params.mky57appc1);//加工部位コード
	var mky57appc2 = isBlank(params.mky57appc2) ? null : DbParameter.string(params.mky57appc2);//加工位置コード
	var mky57apcsc = isBlank(params.mky57apcsc) ? null : DbParameter.string(params.mky57apcsc);//親商品形態コード
	var mky57acsc = isBlank(params.mky57acsc) ? null : DbParameter.string(params.mky57acsc);//商品形態コード
	var mky57amtc = isBlank(params.mky57amtc) ? null : DbParameter.string(params.mky57amtc);//素材コード
	var mkdl01 = isBlank(params.mkdl01) ? null : DbParameter.string("%"+params.mkdl01+"%");//加工部位名称
	var mkdl02 = isBlank(params.mkdl02) ? null : DbParameter.string("%"+params.mkdl02+"%");//加工位置名称
	var mky57adop1 = isBlank(params.mky57adop1) ? null : DbParameter.number(Number(params.mky57adop1));//表示順 部位
	var mky57adop2 = isBlank(params.mky57adop2) ? null : DbParameter.number(Number(params.mky57adop2));//表示順 位置
	var mky57ajcp1 = isBlank(params.mky57ajcp1) ? null : DbParameter.string(params.mky57ajcp1);//JDEコード　部位
	var mky57ajcp2 = isBlank(params.mky57ajcp2) ? null : DbParameter.string(params.mky57ajcp2);//JDEコード　位置
	var mky57adflg = isBlank(params.mky57adflg) ? null : DbParameter.number(Number(params.mky57adflg));//削除フラグ
	var mkeftj = isBlank(params.mkeftj) ? null : DbParameter.number(cmnUtil.convertDateToJulia(new Date(params.mkeftj))); //適用開始日
	var mkeftj2 = isBlank(params.mkeftj2) ? null : DbParameter.number(cmnUtil.convertDateToJulia(new Date(params.mkeftj2))); //適用開始日
	var mkexdj = isBlank(params.mkexdj) ? null : DbParameter.number(cmnUtil.convertDateToJulia(new Date(params.mkexdj))); //適用終了日

	var result;
	if(countFlag){
		var objParam = {
		mky57appc1 : mky57appc1,
		mky57appc2 : mky57appc2,
		mky57apcsc : mky57apcsc,
		mky57acsc : mky57acsc,
		mky57amtc : mky57amtc,
		mkdl01 : mkdl01,
		mkdl02 : mkdl02,
		mky57adop1 : mky57adop1,
		mky57adop2 : mky57adop2,
		mky57ajcp1 : mky57ajcp1,
		mky57ajcp2 : mky57ajcp2,
		mkeftj : mkeftj,
		mkeftj2 : mkeftj2,
		mkexdj : mkexdj,
		mky57adflg : mky57adflg
		}

		result = db.executeByTemplate('toms/sql/getProcessPartListCount', objParam);
		
	}else{
		var start = isBlank(paramStart) ? null : DbParameter.number(paramStart);
		var end =  isBlank(paramEnd) ? null : DbParameter.number(paramEnd);
		var objParam = {
		mky57appc1 : mky57appc1,
		mky57appc2 : mky57appc2,
		mky57apcsc : mky57apcsc,
		mky57acsc : mky57acsc,
		mky57amtc : mky57amtc,
		mkdl01 : mkdl01,
		mkdl02 : mkdl02,
		mky57adop1 : mky57adop1,
		mky57adop2 : mky57adop2,
		mky57ajcp1 : mky57ajcp1,
		mky57ajcp2 : mky57ajcp2,
		mkeftj : mkeftj,
		mkeftj2 : mkeftj2,
		mkexdj : mkexdj,
		mky57adflg : mky57adflg,
    		//mkexdj : mkexdj,
    		start : start,
    		end : end
		}
		result = db.executeByTemplate('toms/sql/getProcessPartList', objParam);

	}
	return result;
};
/** 加工部位マスタ検索サブ画面 **/
ProcessPart.searchPartData = function(params, countFlag ,paramStart, paramEnd ){
	var db = new SharedDatabase(_SHARED_DB_KEY);
	var mky57appc1 = isBlank(params.mky57appc1) ? null : DbParameter.string(params.mky57appc1);//加工部位コード
	var mky57appc2 = isBlank(params.mky57appc2) ? null : DbParameter.string(params.mky57appc2);//加工位置コード
	var mky57apcsc = isBlank(params.mky57apcsc) ? null : DbParameter.string(params.mky57apcsc);//親商品形態コード
	var mky57apcscName = isBlank(params.mky57apcscName) ? null : DbParameter.string("%"+params.mky57apcscName+"%");//親商品形態名称
	var mky57acsc = isBlank(params.mky57acsc) ? null : DbParameter.string(params.mky57acsc);//商品形態コード
	var mky57acscName = isBlank(params.mky57acscName) ? null : DbParameter.string("%"+params.mky57acscName+"%");//商品形態名称
	var mky57amtc = isBlank(params.mky57amtc) ? null : DbParameter.string(params.mky57amtc);//素材コード
	var mky57amtcName = isBlank(params.mky57amtcName) ? null : DbParameter.string("%"+params.mky57amtcName+"%");//原材料名
	var mkdl01 = isBlank(params.mkdl01) ? null : DbParameter.string("%"+params.mkdl01+"%");//加工部位名称
	var mkdl02 = isBlank(params.mkdl02) ? null : DbParameter.string("%"+params.mkdl02+"%");//加工位置名称
	
	var result;
	if(countFlag){
		var objParam = {
			mky57appc1 : mky57appc1,
			mky57appc2 : mky57appc2,
			mky57apcsc : mky57apcsc,
			mky57acsc : mky57acsc,
			mky57amtc : mky57amtc,
			mkdl01 : mkdl01,
			mkdl02 : mkdl02,
    		mky57apcscName : mky57apcscName,
    		mky57acscName : mky57acscName,
    		mky57amtcName : mky57amtcName
		};

		result = db.executeByTemplate('toms/sql/searchPartListCount', objParam);
	}else{
		var start = isBlank(paramStart) ? null : DbParameter.number(paramStart);
		var end =  isBlank(paramEnd) ? null : DbParameter.number(paramEnd);
		var objParam = {
			mky57appc1 : mky57appc1,
			mky57appc2 : mky57appc2,
			mky57apcsc : mky57apcsc,
			mky57acsc : mky57acsc,
			mky57amtc : mky57amtc,
			mkdl01 : mkdl01,
			mkdl02 : mkdl02,
    		mky57apcscName : mky57apcscName,
    		mky57acscName : mky57acscName,
    		mky57amtcName : mky57amtcName,
    		start : start,
    		end : end
		};

		result = db.executeByTemplate('toms/sql/searchPartList', objParam);
		
	}
		return result;
}


