SELECT value1 FROM TW_TCMN019001
 WHERE system_id = 'TOMS-WEB'
    AND  key1 = '003'
	AND  key2 = '001'
	AND  key3 = '1'