select *
  from (
    select TRIM(base.MQY57APCSC)  as MQY57APCSC --親商品形態コード
           ,TRIM(base.MQY57ACSC)  as MQY57ACSC  --商品形態コード
           ,TRIM(base.MQY57AMTC)  as MQY57AMTC  --素材コード
           ,TRIM(base.MQY57APPC1) as MQY57APPC1 --加工部位コード
           ,TRIM(base.MQY57APPC2) as MQY57APPC2 --加工位置コード
           ,TRIM(base.MQY57APMT)  as MQY57APMT  --加工方法区分
           ,TRIM(base.MQY57APMDT) as MQY57APMDT --加工方法明細区分
           ,TRIM(base.MQY57APMD1) as MQY57APMD1 --加工方法明細第1階層コード
           ,TRIM(base.MQY57APMD2) as MQY57APMD2 --加工方法明細第2階層コード
           ,TRIM(base.MQY57APMD3) as MQY57APMD3 --加工方法明細第3階層コード
           ,TRIM(base.MQY57AITCD) as MQY57AITCD --商品コード
           ,TRIM(base.MQY57ASC)   as MQY57ASC   --サイズコード
           ,TRIM(base.MQY57ANRT)  as MQY57ANRT  --非推奨区分
           ,TO_CHAR(FC_JDI9902_TO_DATE(base.MQEFTJ), 'YYYY/MM/DD') as MQEFTJ --適用開始日
           ,base.MQY57ADFLG       as MQY57ADFLG --削除フラグ
           ,TRIM(base.MQUSER)     as MQUSER     --ユーザID
           ,TRIM(base.MQPID)      as MQPID      --プログラムID
           ,TO_CHAR(FC_JDI9902_TO_DATE(base.MQUPMJ), 'YYYY/MM/DD') as MQUPMJ --更新日付
           ,base.MQUPMT           as MQUPMT     --最終更新時刻
           ,ROWNUM AS RN
      from (
        select MQ.MQY57APCSC
               ,MQ.MQY57ACSC
               ,MQ.MQY57AMTC
               ,MQ.MQY57APPC1
               ,MQ.MQY57APPC2
               ,MQ.MQY57APMT
               ,MQ.MQY57APMDT
               ,MQ.MQY57APMD1
               ,MQ.MQY57APMD2
               ,MQ.MQY57APMD3
               ,MQ.MQY57AITCD
               ,MQ.MQY57ASC
               ,MQ.MQY57ANRT
               ,MQ.MQEFTJ
               ,MQ.MQY57ADFLG
               ,MQ.MQUSER
               ,MQ.MQPID
               ,MQ.MQUPMJ
               ,MQ.MQUPMT
          from F57A5170 MQ
          ------- 親商品形態名称 --------------------
            inner join (
               select MJY57ACSC
                      ,MJY57APCSC
                 from F57A5110 --商品形態マスタ
              /*IF mqy57apcscName != null*/
                where MJDL01 like /*mqy57apcscName*/'%TEST%'
              /*END*/
                group by MJY57ACSC
                         ,MJY57APCSC
             ) MJ1
               on MQ.MQY57APCSC = MJ1.MJY57ACSC
              and MQ.MQY57APCSC = MJ1.MJY57APCSC
          ------- 商品形態名称 ----------------------
             inner join (
               select MJY57ACSC
                      ,MJY57APCSC
                 from F57A5110 --商品形態マスタ
              /*IF mqy57acscName != null*/
                where MJDL01 like /*mqy57acscName*/'%TEST%'
              /*END*/
                group by MJY57ACSC
                         ,MJY57APCSC
             ) MJ2
               on MQ.MQY57APCSC = MJ2.MJY57APCSC
              and MQ.MQY57ACSC = MJ2.MJY57ACSC
          ------- 原材料名 -------------------------
             inner join (
               select MLY57AMTC
                      ,MLY57APCSC
                      ,MLY57ACSC
                 from F57A5130 --素材マスタ
              /*IF mldl01 != null*/
                where MLDL01 like /*mldl01*/'%TEST%'
              /*END*/
                group by MLY57AMTC
                         ,MLY57APCSC
                         ,MLY57ACSC
             ) ML
               on MQ.MQY57APCSC = ML.MLY57APCSC
              and MQ.MQY57ACSC = ML.MLY57ACSC
              and MQ.MQY57AMTC = ML.MLY57AMTC
          ------- 加工部位名称・加工位置名称 ----------
             inner join (
               select MKY57APPC1
                      ,MKY57APPC2
                      ,MKY57APCSC
                      ,MKY57ACSC
                      ,MKY57AMTC
                 from F57A5120 --部位マスタ
              /*IF mkdl01 != null || mkdl02 != null*/
                where 
              /*END*/
              /*IF mkdl01 != null*/
                      MKDL01 like /*mkdl01*/'%TEST%'
              /*END*/
              /*IF mkdl01 != null && mkdl02 != null*/
                  and MKDL02 like /*mkdl02*/'%TEST%'
              /*END*/
              /*IF mkdl01 == null && mkdl02 != null*/
                      MKDL02 like /*mkdl02*/'%TEST%'
              /*END*/
                group by MKY57APPC1
                         ,MKY57APPC2
                         ,MKY57APCSC
                         ,MKY57ACSC
                         ,MKY57AMTC
             ) MK
               on MQ.MQY57APCSC = MK.MKY57APCSC
              and MQ.MQY57ACSC = MK.MKY57ACSC
              and MQ.MQY57AMTC = MK.MKY57AMTC
              and MQ.MQY57APPC1 = MK.MKY57APPC1
              and MQ.MQY57APPC2 = MK.MKY57APPC2
          ------- 加工方法明細第1～3階層名称 ----------
             inner join (
               select MNY57APCSC
                      ,MNY57ACSC
                      ,MNY57AMTC
                      ,MNY57APPC1
                      ,MNY57APPC2
                      ,MNY57APMT
                      ,MNY57APMDT
                      ,MNY57AJC1
                      ,MNY57AJC2
                      ,MNY57AJC3
                 from F57A5141 --加工方法明細マスタ
              /*IF mny57apmn1 != null || mny57apmn2 != null || mny57apmn3 != null*/
                where
              /*END*/
              /*IF mny57apmn1 != null*/
                      MNY57APMN1 like /*mny57apmn1*/'%TEST%'
              /*END*/
              /*IF mny57apmn1 != null && mny57apmn2 != null*/
                  and MNY57APMN2 like /*mny57apmn2*/'%TEST%'
              /*END*/
              /*IF mny57apmn1 == null && mny57apmn2 != null*/
                      MNY57APMN2 like /*mny57apmn2*/'%TEST%'
              /*END*/
              /*IF mny57apmn1 != null || mny57apmn2 != null*/
                /*IF mny57apmn3 != null*/
                  and MNY57APMN3 like /*mny57apmn3*/'%TEST%'
                /*END*/
              /*END*/
              /*IF mny57apmn1 == null && mny57apmn2 == null && mny57apmn3 != null*/
                      MNY57APMN3 like /*mny57apmn3*/'%TEST%'
              /*END*/
                group by MNY57APCSC
                         ,MNY57ACSC
                         ,MNY57AMTC
                         ,MNY57APPC1
                         ,MNY57APPC2
                         ,MNY57APMT
                         ,MNY57APMDT
                         ,MNY57AJC1
                         ,MNY57AJC2
                         ,MNY57AJC3
             ) MN
               on MQ.MQY57APCSC = MN.MNY57APCSC
              and MQ.MQY57ACSC = MN.MNY57ACSC
              and MQ.MQY57AMTC = MN.MNY57AMTC
              and MQ.MQY57APPC1 = MN.MNY57APPC1
              and MQ.MQY57APPC2 = MN.MNY57APPC2
              and MQ.MQY57APMT = MN.MNY57APMT
              and MQ.MQY57APMDT = MN.MNY57APMDT
              and MQ.MQY57APMD1 = MN.MNY57AJC1
              and MQ.MQY57APMD2 = MN.MNY57AJC2
              and MQ.MQY57APMD3 = MN.MNY57AJC3
          ------- 商品名称 --------------------------
             inner join (
               select IMLITM
                 from F4101 --品目マスタ
              /*IF mqy57aitcdName != null*/
                where IMDSC1 like /*mqy57aitcdName*/'%TEST%'
              /*END*/
                group by IMLITM
             ) IM
               on CONCAT('01', MQ.MQY57AITCD) = IM.IMLITM
          ------- サイズ名称 ------------------------
             inner join (
               select DRSY
                      ,DRRT
                      ,DRKY
                 from F0005 --ユーザ定義マスタ
                where DRSY = RPAD('41F', 4)
                  and DRRT = RPAD('1S', 2)
              /*IF mqy57ascName != null*/
                  and DRDL01 like /*mqy57ascName*/'%ＬＬ%'
              /*END*/
             ) DR
               on MQ.MQY57ASC = RPAD(TRIM(DR.DRKY), 20)
     /*BEGIN*/
         where
       /*IF mqy57apcsc != null*/
               MQ.MQY57APCSC = RPAD(/*mqy57apcsc*/'', 16)
       /*END*/
       /*IF mqy57acsc != null*/
           and MQ.MQY57ACSC = RPAD(/*mqy57acsc*/'', 16)
       /*END*/
       /*IF mqy57amtc != null*/
           and MQ.MQY57AMTC = RPAD(/*mqy57amtc*/'', 16)
       /*END*/
       /*IF mqy57appc1 != null*/
           and MQ.MQY57APPC1 = RPAD(/*mqy57appc1*/'', 16)
       /*END*/
       /*IF mqy57appc2 != null*/
           and MQ.MQY57APPC2 = RPAD(/*mqy57appc2*/'', 16)
       /*END*/
       /*IF mqy57apmt != null*/
           and TRIM(MQ.MQY57APMT) IN /*mqy57apmt*/('1','2','3')
       /*END*/
       /*IF mqy57apmdt != null*/
           and TRIM(MQ.MQY57APMDT) IN /*mqy57apmdt*/('0','1')
       /*END*/
       /*IF mqy57apmd1 != null*/
           and MQ.MQY57APMD1 = RPAD(/*mqy57apmd1*/'', 16)
       /*END*/
       /*IF mqy57apmd2 != null*/
           and MQ.MQY57APMD2 = RPAD(/*mqy57apmd2*/'', 16)
       /*END*/
       /*IF mqy57apmd3 != null*/
           and MQ.MQY57APMD3 = RPAD(/*mqy57apmd3*/'', 16)
       /*END*/
       /*IF mqy57aitcd != null*/
           and MQ.MQY57AITCD = RPAD(/*mqy57aitcd*/'', 16)
       /*END*/
       /*IF mqy57asc != null*/
           and MQ.MQY57ASC = RPAD(/*mqy57asc*/'', 20)
       /*END*/
       /*IF mqy57anrt != null*/
           and MQ.MQY57ANRT = /*mqy57anrt*/'01'
       /*END*/
       /*IF mqy57adflg != null*/
           and MQ.MQY57ADFLG = /*mqy57adflg*/'0'
       /*END*/
       /*IF mqeftj_from != null*/
           and MQ.MQEFTJ >= /*mqeftj_from*/'115060'
       /*END*/
       /*IF mqeftj_to != null*/
           and MQ.MQEFTJ <= /*mqeftj_to*/''
       /*END*/
     /*END*/
         order by MQ.MQY57APCSC
                  ,MQ.MQY57ACSC
                  ,MQ.MQY57AMTC
                  ,MQ.MQY57APPC1
                  ,MQ.MQY57APPC2
                  ,MQ.MQY57APMT
                  ,MQ.MQY57APMDT
                  ,MQ.MQY57APMD1
                  ,MQ.MQY57APMD2
                  ,MQ.MQY57APMD3
                  ,MQ.MQY57AITCD
                  ,MQ.MQY57ASC
                  ,MQ.MQY57ANRT
                  ,MQ.MQEFTJ desc
      ) base
   /*IF end != null*/
       WHERE ROWNUM <= /*end*/'30' 
   /*END*/
  )
/*IF start != null*/
 where RN >= /*start*/'1'
/*END*/
