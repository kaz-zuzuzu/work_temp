/**
 * 加工方法ヘッダマスタ設定更新処理群
 * 
 * toms\src\main\jssp\src\toms\process_part\detail\update_data.js
 * 
 */

load('toms/common/common');
load('toms/common/cmnUtil');
load('toms/common/mastermaintenance');
var _SHARED_DB_KEY = "toms-web-dev";

function init(request){

	var entity = createEntity(request);
	var msg;
	var result;
	
	//更新用SQL
	var condition =" TRIM(mmy57apmc) =?"+
                            " AND TRIM(mmy57apcsc) =? " +
                            " AND TRIM(mmy57acsc) =? " +
                            " AND TRIM(mmy57amtc) =? " +
                            " AND TRIM(mmy57appc1) =? " +
                            " AND TRIM(mmy57appc2) =? " +
                            " AND TRIM(mmy57apmt) =? " +
                            " AND mmy57adflg =0 " +
							" AND mmeftj =? ";
							
	//更新用キー
	var params = [
		   DbParameter.string(entity['mmy57apmc']),
		   DbParameter.string(entity['mmy57apcsc']),
		   DbParameter.string(entity['mmy57acsc']),
		   DbParameter.string(entity['mmy57amtc']),
		   DbParameter.string(entity['mmy57appc1']),
		   DbParameter.string(entity['mmy57appc2']),
		   DbParameter.string(entity['mmy57apmt']),
		   DbParameter.number(entity['mmeftj'])
	];
	
	//------------------------------------
	//新規登録時
	//------------------------------------
	if(request.operateFlag=="0"){
	/*重複チェック*/
		result = _dbCheck(entity['mmy57apcsc'],entity['mmy57acsc'],entity['mmy57amtc'],entity['mmy57appc1'],entity['mmy57appc2'],entity['mmy57apmt'],entity['mmeftj']);
    	if(result.error){
            // SELECTが失敗した場合
        	msg = MessageManager.getMessage('TOMS.COMMON.MAINTENANCE.AJAX.ERROR.INSERT.MESSAGE', MessageManager.getMessage('TOMS.MASTER.MAINTENANCE.PROCESSMETHOD_HEADER.DETAIL.INPUT.TITLE'));
        	common.sendErrorResult(msg, "");
    	}
    	if(result.countRow !=0){
    		// 既に登録済みの場合
        	msg = MessageManager.getMessage('TOMS.COMMON.MAINTENANCE.AJAX.ERROR.INSERT.MESSAGE', MessageManager.getMessage('TOMS.MASTER.MAINTENANCE.PROCESSMETHOD_HEADER.DETAIL.INPUT.TITLE'));
        	common.sendErrorResult(msg, MessageManager.getMessage('TOMS.COMMON.MAINTENANCE.AJAX.ERROR.INSERT.NOTNEWDATA.MESSAGE'));
    	}
    	
	/*内部コードマスタ存在チェック*/
    //親商品形態コード
		result = MasterMain.checkCodeMaster("01","01",entity['mmy57apcsc']);
    	if(result.error){
            // SELECTが失敗した場合
        	msg = MessageManager.getMessage('TOMS.COMMON.MAINTENANCE.AJAX.ERROR.INSERT.MESSAGE', MessageManager.getMessage('TOMS.MASTER.MAINTENANCE.PROCESSMETHOD_HEADER.DETAIL.INPUT.TITLE'));
        	common.sendErrorResult(msg, "");
    	}
    	if(result.countRow ==0){
    		// 存在しない場合
        	msg = MessageManager.getMessage('TOMS.COMMON.MAINTENANCE.AJAX.ERROR.INSERT.MESSAGE', MessageManager.getMessage('TOMS.MASTER.MAINTENANCE.PROCESSMETHOD_HEADER.DETAIL.INPUT.TITLE'));
        	common.sendErrorResult(msg, MessageManager.getMessage('TOMS.COMMON.MAINTENANCE.AJAX.ERROR.CODEMASTER.NOTINLINE.MESSAGE',MessageManager.getMessage('TOMS.MASTER.MAINTENANCE.COMMODITYSHAPE.LABEL.PARENT_COMMODITY_SHAPE_CODE')));
    	}    	
    //商品形態コード
		result = MasterMain.checkCodeMaster("02","01",entity['mmy57acsc']);
    	if(result.error){
            // SELECTが失敗した場合
        	msg = MessageManager.getMessage('TOMS.COMMON.MAINTENANCE.AJAX.ERROR.INSERT.MESSAGE', MessageManager.getMessage('TOMS.MASTER.MAINTENANCE.PROCESSMETHOD_HEADER.DETAIL.INPUT.TITLE'));
        	common.sendErrorResult(msg, "");
    	}
    	if(result.countRow ==0){
    		// 存在しない場合
        	msg = MessageManager.getMessage('TOMS.COMMON.MAINTENANCE.AJAX.ERROR.INSERT.MESSAGE', MessageManager.getMessage('TOMS.MASTER.MAINTENANCE.PROCESSMETHOD_HEADER.DETAIL.INPUT.TITLE'));
        	common.sendErrorResult(msg, MessageManager.getMessage('TOMS.COMMON.MAINTENANCE.AJAX.ERROR.CODEMASTER.NOTINLINE.MESSAGE',MessageManager.getMessage('TOMS.MASTER.MAINTENANCE.COMMODITYSHAPE.LABEL.COMMODITY_SHAPE_CODE')));
    	}    	
    //素材コード
		result = MasterMain.checkCodeMaster("03","01",entity['mmy57amtc']);
    	if(result.error){
            // SELECTが失敗した場合
        	msg = MessageManager.getMessage('TOMS.COMMON.MAINTENANCE.AJAX.ERROR.INSERT.MESSAGE', MessageManager.getMessage('TOMS.MASTER.MAINTENANCE.PROCESSMETHOD_HEADER.DETAIL.INPUT.TITLE'));
        	common.sendErrorResult(msg, "");
    	}
    	if(result.countRow ==0){
    		// 存在しない場合
        	msg = MessageManager.getMessage('TOMS.COMMON.MAINTENANCE.AJAX.ERROR.INSERT.MESSAGE', MessageManager.getMessage('TOMS.MASTER.MAINTENANCE.PROCESSMETHOD_HEADER.DETAIL.INPUT.TITLE'));
        	common.sendErrorResult(msg, MessageManager.getMessage('TOMS.COMMON.MAINTENANCE.AJAX.ERROR.CODEMASTER.NOTINLINE.MESSAGE',MessageManager.getMessage('TOMS.MASTER.MAINTENANCE.MATERIAL.LABEL.MATERIAL_CODE')));
    	}
  	//加工部位コード
		result = MasterMain.checkCodeMaster("04","01",entity['mmy57appc1']);
    	if(result.error){
            // SELECTが失敗した場合
        	msg = MessageManager.getMessage('TOMS.COMMON.MAINTENANCE.AJAX.ERROR.INSERT.MESSAGE', MessageManager.getMessage('TOMS.MASTER.MAINTENANCE.PROCESSMETHOD_HEADER.DETAIL.INPUT.TITLE'));
        	common.sendErrorResult(msg, "");
    	}
    	if(result.countRow ==0){
    		// 存在しない場合
        	msg = MessageManager.getMessage('TOMS.COMMON.MAINTENANCE.AJAX.ERROR.INSERT.MESSAGE', MessageManager.getMessage('TOMS.MASTER.MAINTENANCE.PROCESSMETHOD_HEADER.DETAIL.INPUT.TITLE'));
        	common.sendErrorResult(msg, MessageManager.getMessage('TOMS.COMMON.MAINTENANCE.AJAX.ERROR.CODEMASTER.NOTINLINE.MESSAGE',MessageManager.getMessage('TOMS.MASTER.MAINTENANCE.PROCESSPART.LABEL.PROCESSPART_CODE')));
    	}
	//加工位置コード
		result = MasterMain.checkCodeMaster("05","01",entity['mmy57appc2']);
    	if(result.error){
            // SELECTが失敗した場合
        	msg = MessageManager.getMessage('TOMS.COMMON.MAINTENANCE.AJAX.ERROR.INSERT.MESSAGE', MessageManager.getMessage('TOMS.MASTER.MAINTENANCE.PROCESSMETHOD_HEADER.DETAIL.INPUT.TITLE'));
        	common.sendErrorResult(msg, "");
    	}
    	if(result.countRow ==0){
    		// 存在しない場合
        	msg = MessageManager.getMessage('TOMS.COMMON.MAINTENANCE.AJAX.ERROR.INSERT.MESSAGE', MessageManager.getMessage('TOMS.MASTER.MAINTENANCE.PROCESSMETHOD_HEADER.DETAIL.INPUT.TITLE'));
        	common.sendErrorResult(msg, MessageManager.getMessage('TOMS.COMMON.MAINTENANCE.AJAX.ERROR.CODEMASTER.NOTINLINE.MESSAGE',MessageManager.getMessage('TOMS.MASTER.MAINTENANCE.PROCESSPART.LABEL.PROCESSPART_POSITION_CODE')));
    	}
  	

   	/*DB存在チェック*/
    	//加工部位マスタ
		result = _dbCheckProcessPart(entity['mmy57apcsc'],entity['mmy57acsc'],entity['mmy57amtc'],entity['mmy57appc1'],entity['mmy57appc2']);
    	if(result.error){
            // SELECTが失敗した場合
        	msg = MessageManager.getMessage('TOMS.COMMON.MAINTENANCE.AJAX.ERROR.INSERT.MESSAGE', MessageManager.getMessage('TOMS.MASTER.MAINTENANCE.PROCESSMETHOD_HEADER.DETAIL.INPUT.TITLE'));
        	common.sendErrorResult(msg, "");
    	}
    	if(result.countRow ==0){
    		// 存在しない場合
        	msg = MessageManager.getMessage('TOMS.COMMON.MAINTENANCE.AJAX.ERROR.INSERT.MESSAGE', MessageManager.getMessage('TOMS.MASTER.MAINTENANCE.PROCESSMETHOD_HEADER.DETAIL.INPUT.TITLE'));
        	common.sendErrorResult(msg, MessageManager.getMessage('TOMS.COMMON.MAINTENANCE.AJAX.ERROR.MASTER.NODATA',MessageManager.getMessage('TOMS.MASTER.MAINTENANCE.PROCESSPART.LABEL.INFOMATION')));
    	}
    	//加工方法コード取得
    	result = MasterMain.getSequence();
        if (result.error) {
            // 処理が失敗した場合
        	msg = MessageManager.getMessage('TOMS.COMMON.MAINTENANCE.AJAX.ERROR.INSERT.MESSAGE', MessageManager.getMessage('TOMS.MASTER.MAINTENANCE.PROCESSMETHOD_HEADER.DETAIL.INPUT.TITLE'));
        	common.sendErrorResult(msg, "");
        }
        //加工方法コード設定
    	entity.mmy57apmc = result.data[0].nextval;
    	
    	//登録実行
    	result = insertToF57A5140(entity);
        if (result.error) {
            // 処理が失敗した場合
        	msg = MessageManager.getMessage('TOMS.COMMON.MAINTENANCE.AJAX.ERROR.INSERT.MESSAGE', MessageManager.getMessage('TOMS.MASTER.MAINTENANCE.PROCESSMETHOD_HEADER.DETAIL.INPUT.TITLE'));
        	common.sendErrorResult(msg, "");
        }
        
        // 処理が成功した場合
        msg = MessageManager.getMessage('TOMS.COMMON.MAINTENANCE.AJAX.SUCCESS.INSERT.MESSAGE', MessageManager.getMessage('TOMS.MASTER.MAINTENANCE.PROCESSMETHOD_HEADER.DETAIL.INPUT.TITLE'));
        common.sendResult(msg,"");
        
	//------------------------------------
	//更新時
	//------------------------------------
	}else if(request.operateFlag=="1"){


    	//更新処理
		result = updateToF57A5140(entity, condition, params);
        if (result.error) {
            // 処理が失敗した場合
        	msg = MessageManager.getMessage('TOMS.COMMON.MAINTENANCE.AJAX.ERROR.UPDATE.MESSAGE', MessageManager.getMessage('TOMS.MASTER.MAINTENANCE.PROCESSMETHOD_HEADER.DETAIL.INPUT.TITLE'));
        	common.sendErrorResult(msg, "");
        }
        if (result.countRow != 1) {
            // 対象データが存在しない場合
        	msg = MessageManager.getMessage('TOMS.COMMON.MAINTENANCE.AJAX.ERROR.UPDATE.MESSAGE', MessageManager.getMessage('TOMS.MASTER.MAINTENANCE.PROCESSMETHOD_HEADER.DETAIL.INPUT.TITLE'));
        	common.sendErrorResult(msg, MessageManager.getMessage('TOMS.COMMON.MAINTENANCE.AJAX.ERROR.UPDATE.NODATA.MESSAGE'));
        }
        // 処理が成功した場合
        msg = MessageManager.getMessage('TOMS.COMMON.MAINTENANCE.AJAX.SUCCESS.UPDATE.MESSAGE', MessageManager.getMessage('TOMS.MASTER.MAINTENANCE.PROCESSMETHOD_HEADER.DETAIL.INPUT.TITLE'));
        common.sendResult(msg,"");

//------------------------------------
//削除時
//------------------------------------
	}else if(request.operateFlag=="2"){
    	/*
    	 * DB存在チェック
    	 */
		result = removeFromF57A5140(condition, params);
	    if (result.error) {
	        // 処理が失敗した場合
        	msg = MessageManager.getMessage('TOMS.COMMON.MAINTENANCE.AJAX.ERROR.DELETE.MESSAGE', MessageManager.getMessage('TOMS.MASTER.MAINTENANCE.PROCESSMETHOD_HEADER.DETAIL.INPUT.TITLE'));
        	common.sendErrorResult(msg, "");
	    }
        if(result.countRow != 1){
	    	// 処理件数が１件でない場合
        	msg = MessageManager.getMessage('TOMS.COMMON.MAINTENANCE.AJAX.ERROR.DELETE.MESSAGE', MessageManager.getMessage('TOMS.MASTER.MAINTENANCE.PROCESSMETHOD_HEADER.DETAIL.INPUT.TITLE'));
        	common.sendErrorResult(msg, MessageManager.getMessage('TOMS.COMMON.MAINTENANCE.AJAX.ERROR.DELETE.NODATA.MESSAGE'));
	    }
	    // 処理が成功した場合
        msg = MessageManager.getMessage('TOMS.COMMON.MAINTENANCE.AJAX.SUCCESS.DELETE.MESSAGE', MessageManager.getMessage('TOMS.MASTER.MAINTENANCE.PROCESSMETHOD_HEADER.DETAIL.INPUT.TITLE'));
        common.sendResult(msg,"");	
	}
}


/**
 * DBへの登録オブジェクト生成処理
 */
function createEntity(request){
	
	var userContext = Contexts.getUserContext();
	var now = new Date();
	
	//変数初期化
	var mmy57apmc = null; //加工方法コード
	var mmdl01 = null; //加工方法名称
	var mmy57apcsc =null;//親商品形態コード
	var mmy57acsc = null;//商品形態コード
	var mmy57amtc = null; //素材コード
	var mmy57appc1 = null; //加工部位コード
	var mmy57appc2 = null; //加工位置コード
	var mmy57ada =null;//階層数
	var mmy57asrt =null;//特記事項
	var mmy57apmt =null;//加工方法区分
	var mmy57apmdt =null;//加工方法明細区分
	var mmeftj =null;//適用開始日
	
	var mmuser = userContext.userProfile.userCd; //ユーザID
    var mmpid = "TOMS-WEB"; //プログラムID
	var mmupmj = cmnUtil.convertDateToJulia(now);  //更新日付
	var mmupmt = cmnUtil.getTime(now);  //更新時刻
	
	//加工方法コード
    if(!isBlank(request.mmy57apmc)){
    	mmy57apmc = request.mmy57apmc;
    }
	//加工方法名称
    if(!isBlank(request.mmdl01)){
    	mmdl01 = request.mmdl01;
    }
	//親商品形態コード
    if(!isBlank(request.mmy57apcsc)){
    	mmy57apcsc = request.mmy57apcsc;
    }
	//商品形態コード
    if(!isBlank(request.mmy57acsc)){
    	mmy57acsc = request.mmy57acsc;
    }
    //素材コード
    if(!isBlank(request.mmy57amtc)){
    	mmy57amtc = request.mmy57amtc;
    }
	//加工部位コード
    if(!isBlank(request.mmy57appc1)){
    	mmy57appc1 = request.mmy57appc1;
    }
	//加工位置コード
    if(!isBlank(request.mmy57appc2)){
    	mmy57appc2 = request.mmy57appc2;
    }

	//階層数
    if(!isBlank(request.mmy57ada)){
    	mmy57ada = cmnUtil.getData(request.mmy57ada,1);
    }
	//特記事項
    if(!isBlank(request.mmy57asrt)){
    	mmy57asrt = request.mmy57asrt;
    }
	//加工方法区分
    if(!isBlank(request.mmy57apmt)){
    	mmy57apmt = request.mmy57apmt;
    }
	//加工方法明細区分
    if(!isBlank(request.mmy57apmdt)){
    	mmy57apmdt = request.mmy57apmdt;
    }
	//適用開始日
    if(!isBlank(request.mmeftj)){
    	mmeftj = cmnUtil.convertDateToJulia(new Date(request.mmeftj));
    }
    
    var entity ={
    	mmy57apmc : mmy57apmc,
	    mmy57apcsc : mmy57apcsc,
	    mmy57acsc : mmy57acsc,
	    mmy57amtc : mmy57amtc,
	    mmy57appc1 : mmy57appc1,
	    mmy57appc2 : mmy57appc2,
	    mmy57ada : mmy57ada,
	    mmy57asrt : mmy57asrt,
	    mmy57apmt : mmy57apmt,
	    mmy57apmdt : mmy57apmdt,
	    mmdl01 : mmdl01,
	    //mmy57adflg : mmy57adflg,
	    mmeftj : mmeftj,
    	mmuser : mmuser,
    	mmpid : mmpid,
    	mmupmj : mmupmj,
    	mmupmt : mmupmt 
    };
    return entity;
}

/*データ存在チェック*/

function _dbCheck(mmy57apcsc,mmy57acsc,mmy57amtc,mmy57appc1,mmy57appc2,mmy57apmtt,mmeftj){
	var db = new SharedDatabase(_SHARED_DB_KEY);
	var params = [];

	var sql ="";
	sql += " SELECT * FROM F57A5140 ";
	sql +="     WHERE ";
	sql +="              TRIM(MMY57APCSC) = ? ";
	sql +="          AND TRIM(MMY57ACSC) = ? ";
	sql +="          AND TRIM(MMY57AMTC) = ? ";
	sql +="          AND TRIM(MMY57APPC1) = ? ";
	sql +="          AND TRIM(MMY57APPC2) = ? ";
	sql +="          AND TRIM(MMY57APMT) = ? ";
	sql +="          AND MMEFTJ = ? ";

  params.push(DbParameter.string(mmy57apcsc));
  params.push(DbParameter.string(mmy57acsc));
  params.push(DbParameter.string(mmy57amtc));
  params.push(DbParameter.string(mmy57appc1));
  params.push(DbParameter.string(mmy57appc2));
  params.push(DbParameter.string(mmy57apmtt));
  params.push(DbParameter.number(mmeftj));
	var result = db.execute(sql, params);
	return result;
}


/**
 * 登録処理
 */
function insertToF57A5140(entity){
	var database = new SharedDatabase(_SHARED_DB_KEY);
	var ret = Transaction.begin(function(){
		entity.mmy57adflg=0;//削除フラグ追加
		entity.mmexdj = cmnUtil.convertDateToJulia(new Date(MessageManager.getMessage('TOMS.COMMON.CONSTANT.ENDDATE')));
		var result = database.insert('F57A5140', entity);
		if(result.error || result.countRow !=1){
			Transaction.rollback();
		}
		return result;
	})
	return ret.data;
}
function updateToF57A5140(entity, condition, params) {
	var database = new SharedDatabase(_SHARED_DB_KEY);
	var ret = Transaction.begin(function(){
		var result = database.update('F57A5140', entity, condition, params);
		if(result.error || result.countRow !=1){
			Transaction.rollback();
		}
			return result;
	})
	return ret.data;
}
function removeFromF57A5140(condition, params) {
	var database = new SharedDatabase(_SHARED_DB_KEY);
	var ret = Transaction.begin(function(){
		var entity ={
			mmy57adflg : 1
			};
		var result = database.update('F57A5140',entity,  condition, params);
		if(result.error || result.countRow !=1){
			Transaction.rollback();
		}
		return result;
	})
	return ret.data;
}


/* データチェック　加工部位存在チェック */

function _dbCheckProcessPart(mmy57apcsc,mmy57acsc,mmy57amtc,mmy57appc1,mmy57appc2){
	var db = new SharedDatabase(_SHARED_DB_KEY);
	var params = [];

	var sql ="";
	sql += " SELECT * FROM F57A5120 ";
	sql +="     WHERE ";
	sql +="              TRIM(MKY57APCSC) = ? ";
	sql +="          AND TRIM(MKY57ACSC) = ? ";
	sql +="          AND TRIM(MKY57AMTC) = ? ";
	sql +="          AND TRIM(MKY57APPC1) = ? ";
	sql +="          AND TRIM(MKY57APPC2) = ? ";


  params.push(DbParameter.string(mmy57apcsc));
  params.push(DbParameter.string(mmy57acsc));
  params.push(DbParameter.string(mmy57amtc));
  params.push(DbParameter.string(mmy57appc1));
  params.push(DbParameter.string(mmy57appc2));

	var result = db.execute(sql, params);
	return result;
}

