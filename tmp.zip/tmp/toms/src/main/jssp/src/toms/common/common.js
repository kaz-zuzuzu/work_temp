

var common = function(){};


/**
 * ----------------------------------
 * function sendResult
 * 		処理成功時の結果返却処理
 * 		@param message  成功メッセージ
 * 		@param parameter  次画面引き渡しパラメータ
 * ----------------------------------
 */
common.sendResult = function(message, param){
	var response = Web.getHTTPResponse();
	response.setContentType('application/json; charset=utf-8');
	response.sendMessageBodyString(ImJson.toJSONString({
		error : false,
		successMessage : message,
		parameter:{	organization: param }
		
	}));
}
/**
 * ----------------------------------
 * function sendResultParameter
 * 		処理成功時の結果返却処理
 * 		@param message  成功メッセージ
 * 		@param parameter  次画面引き渡しパラメータ
 * 　　　sendResultと機能は同じ、引き渡しパラメータのプロパティがparam.～で取得可能
 * ----------------------------------
 */
common.sendResultParameter = function(message, param){
	var response = Web.getHTTPResponse();
	response.setContentType('application/json; charset=utf-8');
	response.sendMessageBodyString(ImJson.toJSONString({
		error : false,
		successMessage : message,
		parameter:param
		
	}));
}
	
/**
 * ----------------------------------
 * funtion sendErrorResult
 * 		処理成功時の結果返却処理
 * 		@param message
 * 		@param detailMessage
 * ----------------------------------
 */
common.sendErrorResult=function(message, detailMessage){
		var response = Web.getHTTPResponse();
		response.setContentType('application/json; charset=utf-8');
		response.sendMessageBodyString(ImJson.toJSONString({
			error : true,
			errorMessage : message,
			detailMessages: detailMessage
		}));
}

/**
 * ----------------------------------
 * funtion convertWithSplit
 * 		CSV出力ファイルの各カラムデータ変換処理
 * 		パラメータで渡された区切り文字を項目に設定する
 * 		@param data 項目
 * 		@param split 区切り文字
 * 		@param flag 非改行フラグ
 * ----------------------------------
 */
common.convertWithSplit = function(data, split, flag) {
	if (data != null && data != "") {
		if (flag) {
			return data + split;
		} else {
			return data + getNewLine();
		}
	} else {
		if (flag) {
			return  split;
		} else {
			return  getNewLine();
		}
		
	}
}

/**
 * funtion convert
 * 		CSV出力ファイルの各カラムデータ変換処理
 * 		項目の区切り文字はプロパティから取得する（TAB）
 * 		@param data 項目
 * 		@param flag 非改行フラグ
 * ----------------------------------
 * 
 */
common.convert = function(data, flag){
	if (data != null && data != "") {
		if (flag) {
			return data + getSplit();
		} else {
			return data + getNewLine();
		}
	} else {
		if (flag) {
			return  getSplit();
		} else {
			return  getNewLine();
		}
		
	}
}
/**
 * 項目の区切り文字を取得する処理
 */
function getSplit() {
	return MessageManager.getMessage('TOMS.COMMON.CSV.SPLIT');
}

/**
 * 改行文字を取得する処理
 */
function getNewLine() {
	return MessageManager.getMessage('TOMS.COMMON.NEWLINE');
}