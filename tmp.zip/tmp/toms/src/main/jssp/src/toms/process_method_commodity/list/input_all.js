/**
 * 加工方法商品関連付けマスタメンテナンス一覧（STEP２）
 *
 **/

 var $bind ={};
 
 var $data={};
 load("toms/common/common");
 

/**
 * 初期表示
 * @param request リクエストパラメータ
 */
function init(request){

	$bind.dialogMessages="";

	$data = {
		pageNum : isBlank(request.pageNum) ? '1' : request.pageNum,
		rowNum  : isBlank(request.rowNum) ? '30' : request.rowNum,
		rowList : isBlank(request.rowList) ? '30, 50, 100' : request.rowList
	};
	//加工方法区分生成
	var processMethodData = MessageManager.getMessage('TOMS.MASTER.MAINTENANCE.PROCESS_METHOD_DATA')
	var splitData = processMethodData.split(',');
	var processMethodList =[]; 
	for(var i=0; i<splitData.length;i++){
		var selectFlg = "false";
		var data = splitData[i].split(':');
		if(!isBlank(request.mmy57apmt)){
			if(request.mmy57apmt==data[0]){
				selectFlg = "true";
			}
		}
		var listObj = {
		               label:data[1],
		               value:data[0],
		               selected : selectFlg
		};
		processMethodList.push(listObj);
	}
	$bind.processMethodList = processMethodList;	

	//加工方法明細区分生成
	var processMethodDetailData = MessageManager.getMessage('TOMS.MASTER.MAINTENANCE.PROCESS_METHOD_DETAIL_DATA')
	splitData = processMethodDetailData.split(',');
	var processMethodDetailList =[];
	for(var i=0; i <splitData.length;i++){
		var data = splitData[i].split(':');
		var listObj =null;
		var selectFlg = "false";
//		if(!isBlank(request.mny57apmdt)){
//			if(request.mny57apmdt==data[0]){
//				selectFlg = "true";
//			}
//		}
		listObj = {
		           label : data[1],
		           value:data[0]
//		           selected:selectFlg
		}
			processMethodDetailList.push(listObj);
		
	}
	$bind.processMethodDetailList = processMethodDetailList;
	
	//ダウrンロード用検索条件

	var csvObj;
	if (request.csvFlag == "1") {
		csvObj ={
//			mny57apmc : isBlank(request.mny57apmc) ? "":request.mny57apmc,//加工方法コード,
            mpdl01 : isBlank(request.mpdl01) ? "":request.mpdl01,//加工方法名称,
            mpy57apcsc : isBlank(request.mpy57apcsc) ? "":request.mpy57apcsc,//親商品形態コード,
            mpy57apcscName : isBlank(request.mpy57apcscName) ? "":request.mpy57apcscName,//親商品形態名称,
            mpy57acsc : isBlank(request.mpy57acsc) ? "":request.mpy57acsc,//商品形態コード,
            mpy57acscName : isBlank(request.mpy57acscName) ? "":request.mpy57acscName,//商品形態名称,
            mpy57amtc : isBlank(request.mpy57amtc) ? "":request.mpy57amtc,//素材コード,
            mpy57amtcName : isBlank(request.mpy57amtcName) ? "":request.mpy57amtcName,//原材料名,
            mpy57appc1 : isBlank(request.mpy57appc1) ? "":request.mpy57appc1,//加工部位コード,
            mpy57appc1Name : isBlank(request.mpy57appc1Name) ? "":request.mpy57appc1Name,//加工部位名称コード,
            mpy57appc2 : isBlank(request.mpy57appc2) ? "":request.mpy57appc2,//加工位置コード,
            mpy57appc2Name : isBlank(request.mpy57appc2Name) ? "":request.mpy57appc2Name,//加工位置名称,
            mpy57apmt : isBlank(request.mpy57apmt) ? "":request.mpy57apmt,//加工方法区分,
            mpy57apmdt : isBlank(request.mpy57apmdt) ? "":request.mpy57apmdt,//加工方法明細区分,
			mpy57acc 		: isBlank(request.mpy57acc) ? "":request.mpy57acc, //商品コード
			mpy57adflg 	: isBlank(request.mpy57adflg) ? "" :request.mpy57adflg,//削除フラグ
			mpeftj 		: isBlank(request.mpeftj) ? "":request.mpeftj,//適用開始日
			mpeftj2 	: isBlank(request.mpeftj2) ? "":request.mpeftj2,//適用開始日
			mpexdj 		: isBlank(request.mpexdj) ? "":request.mpexdj//適用終了日		
		};
	
       outputCSV(csvObj);
	}
	
	$bind.checked1 = true; 	
	$bind.checked2 = false;
	$bind.checked3 	=false;
	
	//画面項目
	$bind.select_notdelete=MessageManager.getMessage('TOMS.COMMON.DELETE.SELECT.NOTDELETE');
	$bind.select_delete=MessageManager.getMessage('TOMS.COMMON.DELETE.SELECT.DELETE');
	$bind.select_all=MessageManager.getMessage('TOMS.COMMON.DELETE.SELECT.ALL');

	$bind.message_disp=MessageManager.getMessage('TOMS.COMMON.DISPFLAG.ONLY');
	$bind.message_notdisp=MessageManager.getMessage('TOMS.COMMON.DISPFLAG.NOT_DISP');
	$bind.message_alldisp=MessageManager.getMessage('TOMS.COMMON.DISPFLAG.ALL_DISP');
	
	$bind.control_notcontrol=MessageManager.getMessage('TOMS.COMMON.CONTROL.SELECT.NOTCONTROL');
	$bind.control_control=MessageManager.getMessage('TOMS.COMMON.CONTROL.SELECT.CONTROL');
	$bind.control_all=MessageManager.getMessage('TOMS.COMMON.CONTROL.SELECT.ALL');


  $bind.dialogMessages = ({
    addConfirmTitle: MessageManager.getMessage('TOMS.COMMON.DIALOG.CONFIRM.TITLE'),
    addConfirmMessage: MessageManager.getMessage('TOMS.COMMON.DIALOG.CONFIRM.MESSAGE')
  }).toSource();

}

/**
 * 加工方法商品関連付けマスタメンテナンスのCSV出力処理
 * 
 * @param　リクエストパラメータ
 * 
 */
function outputCSV(param){
    load("toms/common/processMethod");
	var result = ProcessMethod.getProcessMethodCommodityAllList(param, false, null,null);
	var outputContent = "";
	if (!result.error) {
		outputContent = outputCSVHeader();
    	for(var i = 0; i < result.countRow; i++) {
    		outputContent += outputCSVRow(result.data[i]);
    	}
    	var strDate = DateTimeFormatter.format("yyyyMMdd_HHmmss", new Date());
    	var strUserName = Contexts.getUserContext().userProfile.userName;
    	var fileName = MessageManager.getMessage('TOMS.MASTER.MAINTENANCE.PROCESSMETHOD_COMMODITY.DETAIL.INPUT.TITLE') + '_' + strDate + '_' + strUserName + '.csv';
    	Module.download.send(Unicode.to(outputContent, 'MS932'), fileName, MessageManager.getMessage('TOMS.COMMON.MIME.CSV'));
	} else {
		error(result.errorMessage);
	}
}

/**
 * 加工方法商品関連付けマスタメンテナンスのCSVヘッダ部分出力処理。
 */
function outputCSVHeader() {
	var outputHeader = common.convert(MessageManager.getMessage('TOMS.COMMON.CSV.UPDATE.DIVIDE'), true)
	  + common.convert(MessageManager.getMessage('TOMS.MASTER.MAINTENANCE.PROCESSMETHOD_HEADER.LABEL.PROCESS_METHOD_CODE'), true)
	  + common.convert(MessageManager.getMessage('TOMS.MASTER.MAINTENANCE.COMMODITYSHAPE.LABEL.PARENT_COMMODITY_SHAPE_CODE'), true)
	  + common.convert(MessageManager.getMessage('TOMS.MASTER.MAINTENANCE.COMMODITYSHAPE.LABEL.COMMODITY_SHAPE_CODE'), true)
	  + common.convert(MessageManager.getMessage('TOMS.MASTER.MAINTENANCE.MATERIAL.LABEL.MATERIAL_CODE'), true)
	  + common.convert(MessageManager.getMessage('TOMS.MASTER.MAINTENANCE.PROCESSPART.LABEL.PROCESSPART_CODE'), true)
	  + common.convert(MessageManager.getMessage('TOMS.MASTER.MAINTENANCE.PROCESSPART.LABEL.PROCESSPART_POSITION_CODE'), true)
	  + common.convert(MessageManager.getMessage('TOMS.MASTER.MAINTENANCE.PROCESSMETHOD_HEADER.LABEL.PROCESS_METHOD_TPYE'), true)
	  + common.convert(MessageManager.getMessage('TOMS.MASTER.MAINTENANCE.PROCESSMETHOD_HEADER.LABEL.PROCESS_METHOD_DETAIL_TPYE'), true)
	  + common.convert(MessageManager.getMessage('TOMS.MASTER.MAINTENANCE.PROCESSMETHOD_COMMODITY.LABEL.COMMODITY_CODE'), true)
	  + common.convert(MessageManager.getMessage('TOMS.MASTER.MAINTENANCE.COMMODITYSHAPE.LABEL.APPLIED_START_DATE'), true)
	  + common.convert(MessageManager.getMessage('TOMS.MASTER.MAINTENANCE.COMMODITYSHAPE.LABEL.DELETE_FLG'), false)

	  return outputHeader;

}

/**
 * 加工方法商品関連付けマスタメンテナンスのCSVファイルの行を出力する処理
 * 
 * @param record DBから検索した行のデータ
 */
function outputCSVRow(record) {
	var result =  MessageManager.getMessage('TOMS.COMMON.CSV.SPLIT')
		    + common.convert(record["mpy57apmc"], true)
			+ common.convert(record["mpy57apcsc"], true)
			+ common.convert(record["mpy57acsc"], true)
			+ common.convert(record["mpy57amtc"], true)
			+ common.convert(record["mpy57appc1"], true)
			+ common.convert(record["mpy57appc2"], true)
			+ common.convert(record["mpy57apmt"], true)
			+ common.convert(record["mpy57apmdt"], true)
			+ common.convert(record["mpy57acc"], true)
			+ common.convert(record["mpeftj"], true)
			+ common.convert(record["mpy57adflg"]+"", false)
	return result;
	
}

function error(message) {
  Transfer.toErrorPage({
    title: MessageManager.getMessage('TOMS.COMMON.ERROR.PAGE.TITLE'),
    message: MessageManager.getMessage('TOMS.COMMON.ERROR.MESSAGE.SYSTEM'),
    detail: [MessageManager.getMessage('TOMS.MASTER.MAINTENANCE.PROCESSMETHOD_COMMODITY.LIST.LABEL.MESSAGE.ERROR'), message],
    returnUrl: 'toms/process_method_h/list/input', // 戻り先 URL
    returnUrlLabel: MessageManager.getMessage('TOMS.MASTER.MAINTENANCE.PROCESSMETHOD_COMMODITY.LIST.LABEL.RETURN.LINK.NAME'),
    parameter: {
    }
  });
}
