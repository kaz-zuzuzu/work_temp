/**
 * バインド変数.
 */
var $bind = {};

var $data = {};
	

/**
 * 初期表示
 * @param request リクエストパラメータ
 */
function init(request) {

	$bind.mapyrFrom = request.mapyrFrom;
	$bind.mapyrTo = request.mapyrTo;

	$data = {
		rowNum  : 30,
		rowList : [30, 50, 100]
	};
	
  // CSV出力ボタン押下時の確認ダイアログのメッセージを初期化.
  // JavaScriptで利用するためオブジェクトの内容をそのまま渡します.
  $bind.dialogMessages = ({
    addConfirmTitle: MessageManager.getMessage('TOMS.COMMON.DIALOG.CONFIRM.TITLE'),
    addConfirmMessage: MessageManager.getMessage('TOMS.COMMON.DIALOG.CONFIRM.MESSAGE')
  }).toSource();
}

