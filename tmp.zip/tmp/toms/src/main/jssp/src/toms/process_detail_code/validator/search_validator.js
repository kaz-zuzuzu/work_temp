/**
 * 加工明細コード管理マスタメンテナンス検索画面用validation設定
 */

var init = {
    'search_mry57apcsc' : {//親商品形態コード
        caption:'TOMS.MASTER.MAINTENANCE.COMMODITYSHAPE.LABEL.PARENT_COMMODITY_SHAPE_CODE',
        alphanumeric: true,
        maxlength: 16
    },
    'search_mry57apcscName' : {//親商品形態名称
        caption:'TOMS.MASTER.MAINTENANCE.COMMODITYSHAPE.LABEL.PARENT_COMMODITY_SHAPE_NAME',
        maxlength: 30
    },
    'search_mry57acsc' : {//商品形態コード
        caption:'TOMS.MASTER.MAINTENANCE.COMMODITYSHAPE.LABEL.COMMODITY_SHAPE_CODE',
        alphanumeric: true,
        maxlength: 16
    },
    'search_mry57acscName' : {//商品形態名称
        caption:'TOMS.MASTER.MAINTENANCE.COMMODITYSHAPE.LABEL.COMMODITY_SHAPE_NAME',
        maxlength: 30
    },
    'search_mry57amtc' : {//素材コード
        caption:'TOMS.MASTER.MAINTENANCE.MATERIAL.LABEL.MATERIAL_CODE',
        alphanumeric: true,
        maxlength: 16
    },
    'search_mldl01' : {//原材料名
        caption:'TOMS.MASTER.MAINTENANCE.MATERIAL.LABEL.MATERIAL_NAME',
        maxlength: 30
    },
    'search_mry57appc1' : {//加工部位コード
        caption:'TOMS.MASTER.MAINTENANCE.PROCESSPART.LABEL.PROCESSPART_CODE',
        alphanumeric: true,
        maxlength: 16
    },
    'search_mkdl01' : {//加工部位名称
        caption:'TOMS.MASTER.MAINTENANCE.PROCESSPART.LABEL.PROCESSPART_NAME',
        maxlength: 30
    },
    'search_mry57appc2' : {//加工位置コード
        caption:'TOMS.MASTER.MAINTENANCE.PROCESSPART.LABEL.PROCESSPART_POSITION_CODE',
        alphanumeric: true,
        maxlength: 16
    },
    'search_mkdl02' : {//加工位置名称
        caption:'TOMS.MASTER.MAINTENANCE.PROCESSPART.LABEL.PROCESSPART_POSITION_NAME',
        maxlength: 30
    },
    'search_mny57apmn1' : {//第一階層名称
        caption:'TOMS.MASTER.MAINTENANCE.PROCESSMETHOD_DETAIL.LABEL.PROCESS_METHOD_NAME1',
        maxlength: 30
    },
    'search_mry57apmd1' : {//第一階層JDEコード
        caption:'TOMS.MASTER.MAINTENANCE.PROCESSMETHOD_DETAIL.LABEL.PROCESS_METHOD_NAME1',
        alphanumeric: true,
        maxlength: 8
    },
    'search_mny57apmn2' : {//第2階層名称
        caption:'TOMS.MASTER.MAINTENANCE.PROCESSMETHOD_DETAIL.LABEL.PROCESS_METHOD_NAME2',
        maxlength: 30
    },
    'search_mry57apmd2' : {//第2階層JDEコード
        caption:'TOMS.MASTER.MAINTENANCE.PROCESSMETHOD_DETAIL.LABEL.PROCESS_METHOD_NAME2',
        alphanumeric: true,
        maxlength: 8
    },
    'search_mny57apmn3' : {//第3階層名称
        caption:'TOMS.MASTER.MAINTENANCE.PROCESSMETHOD_DETAIL.LABEL.PROCESS_METHOD_NAME3',
        maxlength: 30
    },
    'search_mry57apmd3' : {//第3階層JDEコード
        caption:'TOMS.MASTER.MAINTENANCE.PROCESSMETHOD_DETAIL.LABEL.PROCESS_METHOD_NAME3',
        alphanumeric: true,
        maxlength: 8
    },
    'search_mruorg' : {//数量
        caption:'TOMS.BILL.DETAIL.LABEL.HEADER.PRODUCT.COUNT',
        numeric: true,
        maxlength: 4
    },
    'search_mry57alsku' : {//紐付けSKUコード
        caption:'TOMS.MASTER.MAINTENANCE.PROCESS_DETAIL_CODE.LINK_SKU_CODE',
        alphanumeric: true,
        maxlength: 25
    },
    'search_mry57alskuName' : {//紐付けSKU名称
        caption:'TOMS.MASTER.MAINTENANCE.PROCESS_DETAIL_CODE.LINK_SKU_NAME',
        maxlength: 30
    },
    'search_mry57aoa' : {//注文枚数
        caption:'TOMS.MASTER.MAINTENANCE.PROCESS_DETAIL_CODE.ORDER_COUNT',
        numeric: true,
        maxlength: 4
    },
    'search_mreftj_from' : {//適用開始日From
        caption:'TOMS.MASTER.MAINTENANCE.COMMODITYSHAPE.LABEL.APPLIED_START_DATE',
        date: true,
        maxlength: 10
    },
    'search_mreftj_to' : {//適用開始日To
        caption:'TOMS.MASTER.MAINTENANCE.COMMODITYSHAPE.LABEL.APPLIED_START_DATE',
        date: true,
        maxlength: 10
    }
}