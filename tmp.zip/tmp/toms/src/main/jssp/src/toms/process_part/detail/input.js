/**
 * 加工部位マスタメンテナンス登録・更新画面
 *
 * src /src/toms/process_part/detail/input.js
 * 
 **/
var $bind ={};


function init(request){

	$bind.flag ="0"; //新規、更新フラグ　新規：0　更新：1　
	if(!isBlank(request.updateFlag)){
		$bind.flag = request.updateFlag;
	}
	$bind.inputFlg = "false";
	var endDate=MessageManager.getMessage('TOMS.COMMON.CONSTANT.ENDDATE');

	if($bind.flag=="1"){
		$bind.inputFlg ="true";
		//画面タイトル
		$bind.title = MessageManager.getMessage('TOMS.MASTER.MAINTENANCE.PROCESSPART.DETAIL.INPUT.UPDATE.TITLE');
		//更新時、前画面から設定値を受け取る
        $bind.mky57appc1 = request.mky57appc1;//加工部位コード
        $bind.mky57appc2 = request.mky57appc2;//加工コード
        $bind.mky57apcsc = request.mky57apcsc;//親商品形態コード
        $bind.mky57acsc = request.mky57acsc;//商品形態コード
        $bind.mky57amtc = request.mky57amtc;//素材コード
        $bind.mkdl01 = request.mkdl01;//加工部位名称
        $bind.mkdl02 = request.mkdl02;//加工位置名称
        $bind.mky57adop1 = request.mky57adop1;//表示順 部位
        $bind.mky57adop2 = request.mky57adop2;//表示順 位置
        $bind.mky57ajcp1 = request.mky57ajcp1;//JDEコード 部位
        $bind.mky57ajcp2 = request.mky57ajcp2;//JDEコード 位置
        $bind.mkeftj = request.mkeftj;//適用開始日


	}else{
		//新規登録時
		$bind.title = MessageManager.getMessage('TOMS.MASTER.MAINTENANCE.PROCESSPART.DETAIL.INPUT.ENTRY.TITLE');
	}

	$bind.mkexdj = endDate;//適用終了日


    $bind.dialogMessages = ({
        entryTitle: MessageManager.getMessage('TOMS.COMMON.ENTRY'),
        entryMessage: MessageManager.getMessage('TOMS.MASTER.MAINTENANCE.PROCESSPART.DETAIL.INPUT.ENTRY.MESSAGE'),
        updateTitle: MessageManager.getMessage('TOMS.COMMON.UPDATE'),
        updateMessage: MessageManager.getMessage('TOMS.MASTER.MAINTENANCE.PROCESSPART.DETAIL.INPUT.UPDATE.MESSAGE'),
        deleteTitle: MessageManager.getMessage('TOMS.COMMON.DELETE'),
        deleteMessage: MessageManager.getMessage('TOMS.MASTER.MAINTENANCE.PROCESSPART.DETAIL.INPUT.DELETE.MESSAGE')
      }).toSource();

}