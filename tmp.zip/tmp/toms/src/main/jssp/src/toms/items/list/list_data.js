var $data;

/**
 * 初期表示
 * @param request リクエストパラメータ
 */
function init(request) {
	$data = ImJson.toJSONString(getList(request));
}

function getList(request) {
	// 表示条件を設定（表示ページ、件数など）
	let page = request.page == undefined ? 1 : request.page;
	let rows = request.rowNum == undefined ? 30 : Module.number.toInt(request.rowNum);

	// 検索条件の状況に応じて条件を設定する
	var param = request.extension;
	if (!param || !param.searchCondition) {
    	return  {
                		page  : page,
                		total : rows,
                		data  : []
    				};
    	}
	var mgan8 = param.searchCondition.mgan8;
	
	// 該当する会社情報の件数取得
	let resultCount = getItemsListCount(mgan8);
	// 全体の件数を設定（件数の母数）
	var listCount = 0;
	if (!resultCount.error) {
		listCount = resultCount.data[0]['rowcount'];
	} else {
		Debug.write(resultCount.errorMessage);
	}

	// ページ番号設定:リクエストパラメータのページ番号、最大ページ番号のうち小さい方の番号を設定
	page = Math.min(page, Math.ceil(listCount / rows)); 
	
	// 指定範囲の会社情報を取得
	let start = rows * (page - 1) + 1;
	let end = start + rows - 1;

	var result = getItemsList(mgan8, start, end);
	var rsltData = [];
	if (!result.error) {
		rsltData = result.data;
	} else {
		Debug.write(result.errorMessage);
	}

	var json = {
		page  : page,
		total : listCount,
		data  : rsltData
	};
	return json;
}


function getItemsList(mgan8, start, end) {
    load("toms/common/master");
    var result = TomsMaster.getItemsList(mgan8, start, end, false);
	return result;
}

function getItemsListCount(mgan8) {
    load("toms/common/master");
    var result = TomsMaster.getItemsList(mgan8, null, null, true);
	return result;
}

