/**
 * バインド変数.
 */
var $bind = {};

/**
 * 初期表示.
 * @param request リクエストパラメータ.
 */
function init(request) {
	load("toms/common/master");
	setStockPositionList();
	$bind.manufacturer = "01";
  // 組織のプルダウンに表示されるのトップメッセージを初期化.
  // JavaScriptで利用するためオブジェクトの内容をそのまま渡します.
  $bind.messageLabels = ({
	    selectTopMessage: MessageManager.getMessage('TOMS.COMMON.SELECT.LABEL.STORE.POSITION')
	  }).toSource();
}


/**
 * 在庫場所情報を設定する処理
 * 
 */
function setStockPositionList() {
	var result = TomsMaster.getAllStockPositionList();
	if (!result.error) {
    	// 上位組織	 
    	$bind.stockPositionList = result.data;
	}
}


/**
 * 検索処理.
 * 
 * SSJSでリクエストパラメータの検証を行う場合は、
 * validateアノテーションでバリデーションファイルを指定します。
 * 検証はsearch関数の処理に入る前に実施されます。
 * バリデーションエラーをハンドリングしたい場合は、
 * onerrorアノテーションで関数名を指定することでエラー時の処理を追加することができます。
 * 
 * @param request リクエストパラメータ.
 * @validate toms/stock/search/search_validator#init
 * @onerror handleErrors
 */
function search(request) {
  // なにも処理しない.
}

/**
 * validateアノテーションで指定したバリデーションを実行した結果、
 * エラーだった場合に呼び出される処理.
 * 
 * @param request リクエストパラメータ.
 * @param validationErrors バリデーションエラー.
 */
function handleErrors(request, validationErrors) {
  // なにも処理しない.
}

