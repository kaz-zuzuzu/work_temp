SELECT
    *
FROM
(
    SELECT
        base.*
       ,ROWNUM AS RN
    FROM
    (
         SELECT
         TRIM(IM.IMLITM)                                               AS IMLITM --品目No
        ,TRIM(IM.IMDSC1)                                               AS IMDSC1 --記述１
        ,TRIM(IM.IMDSC2)                                               AS IMDSC2 --記述２
        ,IF_JITU.IFAQTY                                                AS LIPQOH --在庫数量（引当可能数量）
        ,IF_JITU.IFY57AKQTY                                            AS TCY57AKRQT_R --実在庫キープ
        ,IF_NYUKAYOTEI.IFY57AKQTY                                      AS TCY57AKRQT_F --予定在庫キープ
        ,IF_NYUKAYOTEI.IFAQTY                                          AS TQY57BQTYA --入荷予定数（引当可能数量）
        ,MIN(DECODE(SEQ, 1, IF_NYUKAYOTEI_DETAIL.IFY57ANYDB, NULL))    AS TPY57BRDD1_1 --入荷予定日１
        ,MIN(DECODE(SEQ, 1, IF_NYUKAYOTEI_DETAIL.IFAQTY, NULL))        AS TQY57BQTYA_1 --引当可能数１
        ,MIN(DECODE(SEQ, 1, IF_NYUKAYOTEI_DETAIL.IFY57AKQTY, NULL))    AS IFY57AKQTY_1 --キープ数１
        ,MIN(DECODE(SEQ, 2, IF_NYUKAYOTEI_DETAIL.IFY57ANYDB, NULL))    AS TPY57BRDD1_2 --入荷予定日２
        ,MIN(DECODE(SEQ, 2, IF_NYUKAYOTEI_DETAIL.IFAQTY, NULL))        AS TQY57BQTYA_2 --引当可能数２
        ,MIN(DECODE(SEQ, 2, IF_NYUKAYOTEI_DETAIL.IFY57AKQTY, NULL))    AS IFY57AKQTY_2 --キープ数１
        ,MIN(DECODE(SEQ, 3, IF_NYUKAYOTEI_DETAIL.IFY57ANYDB, NULL))    AS TPY57BRDD1_3 --入荷予定日３
        ,MIN(DECODE(SEQ, 3, IF_NYUKAYOTEI_DETAIL.IFAQTY, NULL))        AS TQY57BQTYA_3 --引当可能数３
        ,MIN(DECODE(SEQ, 3, IF_NYUKAYOTEI_DETAIL.IFY57AKQTY, NULL))    AS IFY57AKQTY_3 --キープ数１
        ,MIN(DECODE(SEQ, 4, IF_NYUKAYOTEI_DETAIL.IFY57ANYDB, NULL))    AS TPY57BRDD1_4 --入荷予定日４
        ,MIN(DECODE(SEQ, 4, IF_NYUKAYOTEI_DETAIL.IFAQTY, NULL))        AS TQY57BQTYA_4 --引当可能数４
        ,MIN(DECODE(SEQ, 4, IF_NYUKAYOTEI_DETAIL.IFY57AKQTY, NULL))    AS IFY57AKQTY_4 --キープ数１
        ,MIN(DECODE(SEQ, 5, IF_NYUKAYOTEI_DETAIL.IFY57ANYDB, NULL))    AS TPY57BRDD1_5 --入荷予定日５
        ,MIN(DECODE(SEQ, 5, IF_NYUKAYOTEI_DETAIL.IFAQTY, NULL))        AS TQY57BQTYA_5 --引当可能数５
        ,MIN(DECODE(SEQ, 5, IF_NYUKAYOTEI_DETAIL.IFY57AKQTY, NULL))    AS IFY57AKQTY_5 --キープ数１
        ,MIN(DECODE(SEQ, 6, IF_NYUKAYOTEI_DETAIL.IFY57ANYDB, NULL))    AS TPY57BRDD1_6 --入荷予定日６
        ,MIN(DECODE(SEQ, 6, IF_NYUKAYOTEI_DETAIL.IFAQTY, NULL))        AS TQY57BQTYA_6 --引当可能数６
        ,MIN(DECODE(SEQ, 6, IF_NYUKAYOTEI_DETAIL.IFY57AKQTY, NULL))    AS IFY57AKQTY_6 --キープ数１
        ,MIN(DECODE(SEQ, 7, IF_NYUKAYOTEI_DETAIL.IFY57ANYDB, NULL))    AS TPY57BRDD1_7 --入荷予定日７
        ,MIN(DECODE(SEQ, 7, IF_NYUKAYOTEI_DETAIL.IFAQTY, NULL))        AS TQY57BQTYA_7 --引当可能数７
        ,MIN(DECODE(SEQ, 7, IF_NYUKAYOTEI_DETAIL.IFY57AKQTY, NULL))    AS IFY57AKQTY_7 --キープ数１
        ,MIN(DECODE(SEQ, 8, IF_NYUKAYOTEI_DETAIL.IFY57ANYDB, NULL))    AS TPY57BRDD1_8 --入荷予定日８
        ,MIN(DECODE(SEQ, 8, IF_NYUKAYOTEI_DETAIL.IFAQTY, NULL))        AS TQY57BQTYA_8 --引当可能数８
        ,MIN(DECODE(SEQ, 8, IF_NYUKAYOTEI_DETAIL.IFY57AKQTY, NULL))    AS IFY57AKQTY_8 --キープ数１
        ,MIN(DECODE(SEQ, 9, IF_NYUKAYOTEI_DETAIL.IFY57ANYDB, NULL))    AS TPY57BRDD1_9 --入荷予定日９
        ,MIN(DECODE(SEQ, 9, IF_NYUKAYOTEI_DETAIL.IFAQTY, NULL))        AS TQY57BQTYA_9 --引当可能数９
        ,MIN(DECODE(SEQ, 9, IF_NYUKAYOTEI_DETAIL.IFY57AKQTY, NULL))    AS IFY57AKQTY_9 --キープ数１
        ,MIN(DECODE(SEQ, 10, IF_NYUKAYOTEI_DETAIL.IFY57ANYDB, NULL))   AS TPY57BRDD1_10 --入荷予定日１０
        ,MIN(DECODE(SEQ, 10, IF_NYUKAYOTEI_DETAIL.IFAQTY, NULL))       AS TQY57BQTYA_10 --引当可能数１０
        ,MIN(DECODE(SEQ, 10, IF_NYUKAYOTEI_DETAIL.IFY57AKQTY, NULL))   AS IFY57AKQTY_10 --キープ数１

     FROM F4101 IM
       -- 実在庫---------------------------------------------
       LEFT OUTER JOIN F57A3190 IF_JITU
           ON  IM.IMLITM       = IF_JITU.IFLITM
           AND IM.IMITM        = IF_JITU.IFITM
           AND IF_JITU.IFEV04  = '1'
       -- 入荷予定-------------------------------------------
       LEFT OUTER JOIN 
           (
            SELECT 
                F57A3190.IFLITM          AS IFLITM,
                F57A3190.IFEV04          AS IFEV04,
                SUM(IFY57AKQTY)          AS IFY57AKQTY,
                SUM(IFAQTY)              AS IFAQTY
            FROM F57A3190
            WHERE F57A3190.IFEV04  = '2'
            GROUP BY 
                F57A3190.IFLITM,
                F57A3190.IFEV04
            ) IF_NYUKAYOTEI
           ON IM.IMLITM = IF_NYUKAYOTEI.IFLITM
           AND IF_NYUKAYOTEI.IFEV04  = '2'
       -- 入荷予定明細---------------------------------------
       LEFT OUTER JOIN 
           (
            SELECT 
                IFLITM                              AS IFLITM --品目No
               ,IFEV04                              AS IFEV04
               ,IFAQTY                              AS IFAQTY --引当可能数量
               ,IFY57AKQTY                          AS IFY57AKQTY --キープ数量
               ,DECODE(IFY57ANYDB, NULL, NULL,  TO_CHAR(TO_DATE(IFY57ANYDB, 'FMYYYY/MM/DD'), 'FMYYYY/MM/DD'))   AS IFY57ANYDB --入荷予定日
               ,RANK() OVER(PARTITION BY IFLITM --品目No
                            ORDER BY IFY57ANYDB)    AS SEQ
            FROM F57A3190
            WHERE F57A3190.IFEV04 = '2'
--            AND   F57A3190.IFAQTY > 0
              AND F57A3190.IFAQTY + F57A3190.IFY57AKQTY > 0
           ) IF_NYUKAYOTEI_DETAIL
           ON IM.IMLITM = IF_NYUKAYOTEI_DETAIL.IFLITM
           AND IF_NYUKAYOTEI_DETAIL.IFEV04  = '2'
     WHERE SUBSTR(IM.IMLITM,3,5) in /*productCodes*/('00330')
     AND   LENGTH(TRIM(IM.IMLITM)) >= 12
     GROUP BY 
         IM.IMLITM
        ,IM.IMDSC1
        ,IM.IMDSC2
        ,IF_JITU.IFAQTY
        ,IF_JITU.IFY57AKQTY
        ,IF_NYUKAYOTEI.IFY57AKQTY
        ,IF_NYUKAYOTEI.IFAQTY
     ORDER BY 
         IM.IMLITM
    ) base
    /*IF end != null*/
    WHERE ROWNUM <= /*end*/'15' 
    /*END*/
)
/*IF start != null*/
WHERE RN >= /*start*/'1' 
/*END*/