/**
 * バインド変数.
 */
var $bind = {};

var splitComma = MessageManager.getMessage('TOMS.COMMON.COMMA');

/**
 * 初期表示.
 * @param request リクエストパラメータ.
 */
function init(request) {
    load("toms/common/delivery");
    load('toms/common/common');
    
    var instructNo = "";
    var denpyoType = "";
    
    // CSVファイル出力処理の場合
    if (request.screenId == "outputCSV") {
    	instructNo = request.csv_instructNo;
    	denpyoType = request.csv_denpyoType;
    	
    	outputCSV(instructNo, denpyoType);
    } else {
    	/* 一覧検索条件 */
    	var searchObj ={
    	    stockPositionList : request.search_stockPositionList,
            superOrganization : request.search_superOrganization,
            superOrganizationNm : request.search_superOrganizationNm,
            organization : request.search_organization,
            organizationNm : request.search_organizationNm,
    	    instructNo : request.search_instructNo,
    	    receiveOrderNo : request.search_receiveOrderNo,
    	    orderTypeList : request.search_orderTypeList,
    	    orderTypeListNm : request.search_orderTypeListNm,
    	    destination : request.search_destination,
    	    exchangeTarget : request.search_exchangeTarget,
        	deliveryDateFrom : request.search_deliveryDateFrom,
        	deliveryDateTo : request.search_deliveryDateTo,
        	denpyoType : request.denpyoType
    	};
    	
    	/* 詳細一覧検索条件 */
        instructNo = request.instructNo;
        denpyoType = request.denpyoType;
    	$bind.instructNo = instructNo;
    	$bind.denpyoType = denpyoType;
    	
    	/* ヘッダ情報取得処理 */
    	$bind.deliveryHeaderInfo = getHeaderInfo(instructNo, denpyoType);
    	
    	/* 明細一覧取得処理 */
    	$bind.deliveryDetailList = getDetailList(instructNo, denpyoType);
    	
        // 一覧検索の条件を格納
        $bind.search = searchObj;
        
    	// 出庫明細の「ファイル出力」ボタン押下時の確認ダイアログのメッセージを初期化.
    	// JavaScriptで利用するためオブジェクトの内容をそのまま渡します.
    	$bind.dialogMessages = ({
    		addConfirmTitle: MessageManager.getMessage('TOMS.COMMON.DIALOG.CONFIRM.TITLE'),
    		addConfirmMessage: MessageManager.getMessage('TOMS.COMMON.DIALOG.CONFIRM.MESSAGE.COMMA')
    	}).toSource();
    }
}

/**
 * 明細ヘッダ情報取得.
 * 
 * @param instructNo  出荷予定NO.
 * @param denpyoType 伝票タイプ.
 */
function getHeaderInfo(instructNo, denpyoType){
	load("toms/common/delivery");

	var result = Delivery.getHeaderInfo(instructNo, denpyoType);

	if (result.error) {
		error(result.errorMessage);
	}
	
	var tmpData = result.data[0];

	var resultObj = {
		tdaddj 		: tmpData.tdaddj,
		tdy57ashpn 	: tmpData.tdy57ashpn,
		tddoco 		: tmpData.tddoco,
		tddcto 		: tmpData.tddcto,
		tdy57asdct	: tmpData.tdy57asdct,
		tdy57cpcn	: tmpData.tdy57cpcn,
		abalph		: tmpData.abalph,
		abalp1		: tmpData.abalp1,
		aban8		: tmpData.aban8,
		tel			: tmpData.tel,
		fax			: tmpData.fax,
		tdy57abpsn	: tmpData.tdy57abpsn,
		wwalph		: tmpData.wwalph,
		tdalph		: tmpData.tdalph,
		drdl		: tmpData.drdl,
		tdadd		: tmpData.tdadd,
//		tay57cokj	: isBlank(tmpData.tay57cokj) ? tmpData.tay57cokj : (tmpData.tay57cokj).replace(/\//g,' / '),
		tdy57cyk	: tmpData.tdy57cyk,
		tdy57ahrmk	: tmpData.tdy57ahrmk,
		tdvr01		: tmpData.tdvr01,
		tay57cokj	: tmpData.tay57cokj
	};
	
	return resultObj;
}

/**
 * 明細リスト情報取得.
 * 
 * @param instructNo  出荷予定NO.
 * @param denpyoType 伝票タイプ.
 */
function getDetailList(instructNo, denpyoType){
    load("toms/common/delivery");
    
	var result = Delivery.getDeliveryDetailList(instructNo, denpyoType);

	if (!result.error) {
		return result.data;
	} else {
		Debug.browse(result,instructNo, denpyoType);
		error(result.errorMessage);
	}
	return result;
}

/**
 * 出庫明細CSV出力処理.
 * 
 * @param instructNo  出荷予定NO.
 * @param denpyoType 伝票タイプ.
 */
function outputCSV(instructNo, denpyoType) {
	// 出庫明細のヘッダ部データを抽出
	var resultHeader = Delivery.getHeaderInfo(instructNo, denpyoType);
	if (!resultHeader.error) {
		// 出庫明細の明細部データを抽出
    	var result = Delivery.getDeliveryDetailList(instructNo, denpyoType);
    	
    	var outputContent = "";
    	if (!result.error) {
    		outputContent = outputCSVHeader();
    		for (var i = 0; i < result.countRow; i++) {
    			outputContent += outputCSVRow(resultHeader.data[0], result.data[i]);
    		}
    		var strDateTime = DateTimeFormatter.format("yyyyMMddHHmmss", new Date());
    		var fileName = MessageManager.getMessage('TOMS.DELIVERY.DETAIL.OUTPUT.TITLE') + '_' + strDateTime + '.csv';
    		Module.download.send(Unicode.to(outputContent, 'MS932'), fileName, MessageManager.getMessage('TOMS.COMMON.MIME.CSV'));
    	} else {
    		errorcsv(result.errorMessage);
    	}
	}
}

/**
 * 出庫明細のCSVヘッダ部分出力処理.
 */
function outputCSVHeader() {
    var outputHeader = common.convertWithSplit(MessageManager.getMessage('TOMS.DELIVERY.SEARCH.INPUT.DELIVERY.DATE'), splitComma, true)			// 出庫日付
                       + common.convertWithSplit(MessageManager.getMessage('TOMS.DELIVERY.SEARCH.INPUT.INSTRUCT_NO'), splitComma, true)   		// 出荷予定番号
                       + common.convertWithSplit(MessageManager.getMessage('TOMS.DELIVERY.DETAIL.OUTPUT.SLIPTYPE'), splitComma, true)  			// 伝票タイプ
                       + common.convertWithSplit(MessageManager.getMessage('TOMS.DELIVERY.LIST.OUTPUT.EXCHANGETARGET'), splitComma, true)  			// 取引先
                       + common.convertWithSplit(MessageManager.getMessage('TOMS.DELIVERY.DETAIL.OUTPUT.INVOICE'), splitComma, true)  			// 送り状No
                       + common.convertWithSplit(MessageManager.getMessage('TOMS.DELIVERY.DETAIL.OUTPUT.BRANCHNUMBER'), splitComma, true)  		// 枝番
                       + common.convertWithSplit(MessageManager.getMessage('TOMS.DELIVERY.DETAIL.OUTPUT.PRODUCTCODE'), splitComma, true)  		// 商品コード
                       + common.convertWithSplit(MessageManager.getMessage('TOMS.DELIVERY.DETAIL.OUTPUT.PRODUCTNAME'), splitComma, true)  		// 商品名
                       + common.convertWithSplit(MessageManager.getMessage('TOMS.DELIVERY.DETAIL.OUTPUT.COLOR'), splitComma, true)  			// カラー
                       + common.convertWithSplit(MessageManager.getMessage('TOMS.DELIVERY.DETAIL.OUTPUT.SIZE'), splitComma, true)  				// サイズ
                       + common.convertWithSplit(MessageManager.getMessage('TOMS.DELIVERY.LIST.OUTPUT.NUMBER_OF_PROVEN'), splitComma, true)  	// 実績数
                       + common.convertWithSplit(MessageManager.getMessage('TOMS.DELIVERY.DETAIL.OUTPUT.UNITPRICE'), splitComma, true)  		// 単価
                       + common.convertWithSplit(MessageManager.getMessage('TOMS.DELIVERY.DETAIL.OUTPUT.BLAND.NAME'), splitComma, true)  		// 明細柄名
                       + common.convertWithSplit(MessageManager.getMessage('TOMS.DELIVERY.DETAIL.OUTPUT.CUSTOMER_ORDERNO'), splitComma, false)  // お客様注文No
	return outputHeader;
}

/**
 * 出庫明細のCSVファイルの行を出力する処理.
 * 
 * @param recordHeader DBから検索したヘッダのデータ.
 * @param record DBから検索した行のデータ.
 */
function outputCSVRow(recordHeader, record) {
    var tesoqs = new String(record["tesoqs"]).replace( /,/g, "" );	// ⇒実績数にカンマがある場合は削除
    var teuprc = new String(record["teuprc"]).replace( /,/g, "" );	// ⇒単価にカンマがある場合は削除
    var result = common.convertWithSplit(recordHeader["tdaddj"], splitComma, true)		// 出庫日付
    			+ common.convertWithSplit(recordHeader["tdy57ashpn"], splitComma, true)	// 出荷予定番号
    			+ common.convertWithSplit(recordHeader["tdy57asdct"], splitComma, true)	// 伝票タイプ
    			+ common.convertWithSplit(recordHeader["abalph"], splitComma, true)		// 取引先
    			+ common.convertWithSplit(recordHeader["tay57cokj"], splitComma, true)	// 送り状No
    			+ common.convertWithSplit(record["telnic"], splitComma, true)			// 枝番
    			+ common.convertWithSplit(record["telitm"], splitComma, true)			// 商品コード
    			+ common.convertWithSplit(record["tedsc1"], splitComma, true)			// 商品名
    			+ common.convertWithSplit(record["tedsc2_color"], splitComma, true)		// カラー
    			+ common.convertWithSplit(record["tedsc2_size"], splitComma, true)		// サイズ
    			+ common.convertWithSplit(tesoqs, splitComma, true)						// 実績数
    			+ common.convertWithSplit(teuprc, splitComma, true)						// 単価
    			+ common.convertWithSplit(record["tey57adhrm"], splitComma, true)		// 柄名
    			+ common.convertWithSplit(record["tey57asodn"], splitComma, false)		// 販売先発注番号
    return result;
}

/**
 * エラー画面へ遷移の処理.
 */
function error(message) {
  Transfer.toErrorPage({
    title: MessageManager.getMessage('TOMS.COMMON.ERROR.PAGE.TITLE'),
    message: MessageManager.getMessage('TOMS.COMMON.ERROR.MESSAGE.SYSTEM'),
    detail: [MessageManager.getMessage('TOMS.DELIVERY.LIST.LABEL.MESSAGE.ERROR'), message],
    returnUrl: 'toms/delevery/search/input', // 戻り先 URL
    returnUrlLabel: MessageManager.getMessage('TOMS.DELIVERY.LIST.LABEL.RETURN.LINK.NAME'),
    parameter: {
    }
  });
}
