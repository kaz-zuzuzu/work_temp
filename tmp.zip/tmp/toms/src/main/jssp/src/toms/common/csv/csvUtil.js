/**
* staticオブジェクトの作成 
 */ 
function CsvUtil(){}

/**
 * csvファイルアップロード
 * ファイルを保存しcsv2次元データを作成する
 * @param request リクエストパラメータ.(IN)
 * @param stErr エラーメッセージパラメータ.(OUT)
 * @param fileInfo ファイル情報パラメータ.(OUT)
 * @return 成功時 true
 *         失敗時 false
 */
CsvUtil.Upload = function(request, stErr, fileInfo) {

	try {
        // 保存先の作成
        var dir = 'upload';
        var storedDirectory = new SessionScopeStorage(dir);
        storedDirectory.makeDirectories();
        // ファイルデータの保存
        var upfile = request.getParameter("local_file");
        //var tmpFileName = Identifier.get();
        var tmpFileName = upfile.getFileName();
        upfile.openValueAsBinary(function(reader) {
            var storage = new SessionScopeStorage(dir, tmpFileName);
            storage.createAsBinary(function(writer, err) {
                if (err) {
                	stErr.append(err.message);
                }
                reader.transferTo(writer);
            });
        });
        // 保存したファイルデータの取得
        var storage = new SessionScopeStorage(dir, tmpFileName);
        var storedFileSize = storage.length();
        if (storedFileSize == null) {
//        	stErr.append('Failed to get stored file size.');
        	stErr.append(MessageManager.getMessage('TOMS.COMMON.MAINTENANCE.CSV.ERROR.STOREDFILESIZE.MESSAGE'));
            return false;
        }

        // 正常値の返却
        fileInfo.name = upfile.getFileName();
        fileInfo.size = storedFileSize;
        return true;

    } catch(e) {
        Debug.console(e);
        stErr.append(e.message);
        // エラー情報の返却
        return false;
    }
}

/**
 * csvファイル読み込
 * ファイルを読み込みcsvの2次元データを作成する
 * @param request リクエストパラメータ.(IN)
 * @param csv csv二次元配列.(OUT)
 * @param stErr エラーメッセージパラメータ.(OUT)
 * @return 成功時 true
 *         失敗時 false
 */
CsvUtil.load2Csv = function(request, csv, stErr) {
//CsvUtil.toCsvArrays4Enter = function(request, csv, stErr, fileInfo) {
    try {
    	var dir = 'upload';
    	var tmpFileName = request.fileName;
        // 保存したファイルデータの取得
        var storage = new SessionScopeStorage(dir, tmpFileName);
        var storedFileSize = storage.length();
        if (storedFileSize == null) {
        	//stErr.append('Failed to get stored file size.');
//        	stErr.append('ファイルサイズ取得時にエラーがエラーが起きました。');
        	stErr.append(MessageManager.getMessage('TOMS.COMMON.MAINTENANCE.CSV.ERROR.FILESIZE.MESSAGE'));
            return false;
        }
        storage.openAsText(function(reader, error) {
        	if (error != null) {
        		Debug.print('ファイルのオープン中にエラーが起きました。 ' + error.message);
        		throw error;
        	}
        	var line;
        	while (line = reader.readLine()) { // 1行ずつ読み込む
		     //Debug.print(line);
		     var row = line.split(MessageManager.getMessage('TOMS.COMMON.CSV.SPLIT'));
		     csv.push(row);
		   }
		 }, "MS932");
        // この時点で reader が自動的に閉じられているので、ユーザは close を書く必要がありません

        return true;

    } catch(e) {
        Debug.console(e);
        stErr.append(e.message);
        // エラー情報の返却
        return false;
    }
}