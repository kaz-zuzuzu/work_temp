/**
 * バインド変数.
 */
var $bind = {};


/**
 * 初期表示.
 * @param request リクエストパラメータ.
 */
function init(request) {
	load("toms/common/master");	
	var flag = "";
    $bind.stockPositionName = request.stockPositionName;
    $bind.storePositionName = request.storePositionName;
    $bind.stockCategoryName = request.stockCategoryName;
    $bind.addtionNo = request.addtionNo;
    if (request.stockCategory) {
    	$bind.stockCategory = request.stockCategory;
    } else {
    	$bind.stockCategory = "";
    }

    if (request.screenId == "search") {
    	$bind.stockPositionCode = request.stockPositionSelect;
    	$bind.storePositionCode = request.storePositionSelect;
	
    	flag = request.rdGroup;
    	if (flag == "0") {
    		$bind.manufacturerFlag = "1";
    		$bind.manufacturerProduct = request.manufacturer;
    	} else {
    		$bind.manufacturerFlag = "0";
    		$bind.manufacturerProduct = request.productCode;
    	}
	} else {
		$bind.stockPositionCode = request.stockPositionCode;
    	$bind.storePositionCode = request.storePositionCode;
    	$bind.manufacturerProduct = request.manufacturerProduct;
    	$bind.manufacturerFlag = request.manufacturerFlag;
    	$bind.productCodes = request.productCodes;
    	
    	if (request.manufacturerFlag == "1") {
    		flag = "0";
    	} else {
    		flag = "1";
    	}
	}
	

	if (request.screenId == "outputCSV") {
		var productCodeList = null;
		if (request.productCodes) {
			productCodeList = request.productCodes.split(",");
		}

		if ($bind.manufacturerFlag == "1") {
			outputCSV($bind.stockPositionCode, $bind.storePositionCode, $bind.stockCategory, $bind.manufacturerProduct,  productCodeList, $bind.addtionNo);
		} else {
			outputCSV($bind.stockPositionCode, $bind.storePositionCode, $bind.stockCategory, null, productCodeList, $bind.addtionNo);
		}
	} else {
		if (flag == "0") {
			getProductList($bind.stockPositionCode, $bind.storePositionCode, $bind.stockCategory, $bind.manufacturerProduct, null, $bind.addtionNo);
		} else {
			getProductList($bind.stockPositionCode, $bind.storePositionCode, $bind.stockCategory, null, $bind.manufacturerProduct, $bind.addtionNo);
		}
	}
	
  // CSV出力ボタン押下時の確認ダイアログのメッセージを初期化.
  // JavaScriptで利用するためオブジェクトの内容をそのまま渡します.
  $bind.dialogMessages = ({
    addConfirmTitle: MessageManager.getMessage('TOMS.COMMON.DIALOG.CONFIRM.TITLE'),
    addConfirmMessage: MessageManager.getMessage('TOMS.COMMON.DIALOG.CONFIRM.MESSAGE'),
    productUnselectedMessage: MessageManager.getMessage('TOMS.STOCK.LIST.LABEL.PRODUCT.SELECT.UNCHECKED'),
    productSelectedMessage: MessageManager.getMessage('TOMS.STOCK.LIST.LABEL.PRODUCT.SELECT.CHECKED'),
    alertMessageNoSelect: MessageManager.getMessage('TOMS.STOCK.LIST.LABEL.MESSAGE.PRODUCT.NOSELECT'),
    alertMessageSelectOverMax: MessageManager.getMessage('TOMS.STOCK.LIST.LABEL.MESSAGE.PRODUCT.SELECT.COUNT.OVER'),
    alertTitleCheckError: MessageManager.getMessage('TOMS.COMMON.DIALOG.ERROR.TITLE'),
    maxLength: MessageManager.getMessage('TOMS.STOCK.LIST.LABEL.SELECT.MAXLENGTH')
  }).toSource();
}

/****************************************************************
 * 商品一覧を取得する処理
 *****************************************************************/
function getProductList(stockPositionCode, storePositionCode, stockCategory, manufacturerCode, productCode, addtionNo) {
	var result = TomsMaster.getProductList(stockPositionCode, storePositionCode, stockCategory, manufacturerCode, productCode, addtionNo);
	if (!result.error) {
		$bind.productsData = result.data;
		$bind.productsCount = result.countRow;
	} else {
		error(result.errorMessage);
	}
}

/****************************************************************
 * 在庫一覧のヘッダー情報を取得する処理
 *****************************************************************/
function getStockListHeader(stockPositionCode, storePositionCode, stockCategory, manufacturerCode, productCodes, addtionNo) {
	var result = TomsMaster.getProductSizeList(stockPositionCode, storePositionCode, stockCategory, manufacturerCode, productCodes, addtionNo);
	if (!result.error) {
		$bind.columns = {};
		
		var dynamicCols = "";
		for(var i = 0; i < result.countRow; i++) {
    		$bind.columns[result.data[i]["name"]] = null;
    		dynamicCols += convert(result.data[i]["caption"], true);
    	}

    	var outputHeader = convert(MessageManager.getMessage('TOMS.STOCK.LIST.LABEL.PRODUCT.NAME'), true)
                    	  + convert(MessageManager.getMessage('TOMS.STOCK.LIST.LABEL.PRODUCT.COLOR'), true)
    	
    	outputHeader += dynamicCols;
    	outputHeader += convert(MessageManager.getMessage('TOMS.STOCK.LIST.LABEL.PRODUCT.COUNT'), false);
    		
    	return outputHeader;
	} else {
		error(result.errorMessage);
	}
}
/****************************************************************
 * 在庫一覧のデータ情報を取得し、画面に表示するようにデータを組込む処理
 *****************************************************************/
function getStockList(stockPositionCode, storePositionCode, stockCategory, manufacturerCode, productCodes, addtionNo) {
	var result = TomsMaster.getStockList(stockPositionCode, storePositionCode, stockCategory, manufacturerCode, productCodes, addtionNo);
	if (!result.error) {
		var stockList = [];
		var slIndex = 0;
		stockList[slIndex] = {};
		var columns = {};
		var recordData = {};
		var sumLipqoh = -1;
		for(var i = 0; i < result.countRow; i++) {
			var productItemNo = result.data[i]["imlitm"];
			if (productItemNo && productItemNo.length > 10) {
				var productMpc = productItemNo.substring(0, 10);

				if (i == 0) {
					recordData["imlitm_mpc"] = productMpc;
					recordData["imdsc1"] = result.data[i]["imdsc1"];
					recordData["drdl01_cl"] = result.data[i]["drdl01_cl"];
				} else if (i > 0) {
					var preProductItemNo = result.data[i - 1]["imlitm"];
					if (preProductItemNo && preProductItemNo.length > 10) {
						var preProductMpc = preProductItemNo.substring(0, 10);
						if (productMpc != preProductMpc) {
							columns = {};
							for (var key in $bind.columns) {
								columns[key] = $bind.columns[key];
							}
							recordData = {};	
							recordData["imlitm_mpc"] = productMpc;
							recordData["imdsc1"] = result.data[i]["imdsc1"];
							recordData["drdl01_cl"] = result.data[i]["drdl01_cl"];
						}
						
					}
				} 
				columns['c1' + result.data[i]["imlitm_s"]] = result.data[i]["lipqoh"];
				if (sumLipqoh == -1) {
					sumLipqoh = 0;
				}
				sumLipqoh += result.data[i]["lipqoh"];
				
				if (i == result.countRow - 1){
					for (var key in recordData) {
						stockList[slIndex][key] = recordData[key];
					}
					
					for (var key in columns) {
						stockList[slIndex][key] = columns[key];
					}
					if (sumLipqoh > -1) {
						stockList[slIndex]["sumLipqoh"] = sumLipqoh;
					} else {
						stockList[slIndex]["sumLipqoh"] = "";
					}
					
					recordData = {};
					columns = {};
					sumLipqoh = -1;
					slIndex++;
					stockList[slIndex] = {};
				} else {
					var nextProductItemNo = result.data[i + 1]["imlitm"];
					if (nextProductItemNo && nextProductItemNo.length > 10) {
						var nextProductMpc = nextProductItemNo.substring(0, 10);
						if (productMpc != nextProductMpc) {
							for (var key in recordData) {
								stockList[slIndex][key] = recordData[key];
							}
							
							for (var key in columns) {
								stockList[slIndex][key] = columns[key];
							}
							if (sumLipqoh > -1) {
								stockList[slIndex]["sumLipqoh"] = sumLipqoh;
							} else {
								stockList[slIndex]["sumLipqoh"] = "";
							}
							
							recordData = {};
							columns = {};
							sumLipqoh = -1;
							slIndex++;
							stockList[slIndex] = {};
						}
					}
				}
			}
    	}
		$bind.stockList = stockList;
	} else {
		error(result.errorMessage);
	}
}

	
/**
 * 在庫一覧のCSV出力処理
 */
function outputCSV(stockPositionCode, storePositionCode, stockCategory, manufacturerCode, productCodes, addtionNo) {
	var outputContent = getStockListHeader(stockPositionCode, storePositionCode, stockCategory, manufacturerCode, productCodes);
	getStockList(stockPositionCode, storePositionCode, stockCategory, manufacturerCode, productCodes);
	for(var i = 0; i < $bind.stockList.length; i++) {
		outputContent += outputCSVRow($bind.stockList[i]);
	}
	var header = convert(MessageManager.getMessage('TOMS.STOCK.LIST.LABEL.CSV.HEADER'), false);
	var spliteRow = convert("", false);
	var footer1 = convert(MessageManager.getMessage('TOMS.STOCK.LIST.LABEL.CSV.FOOTER1'), false);
	var footer2 = convert(MessageManager.getMessage('TOMS.STOCK.LIST.LABEL.CSV.FOOTER2'), false);
	var footer3 = convert(MessageManager.getMessage('TOMS.STOCK.LIST.LABEL.CSV.FOOTER3'), false);
	
	outputContent = header + spliteRow + outputContent + footer1 + footer2 + footer3;
	var strDate = DateTimeFormatter.format("yyyyMMdd", new Date());
	var strUserName = Contexts.getUserContext().userProfile.userName;
	var fileName = MessageManager.getMessage('TOMS.STOCK.LIST.LABEL.CSV.FILE.NAME') + '_' + strDate + '_' + strUserName + '.csv';
	Module.download.send(Unicode.to(outputContent, 'MS932'), fileName, MessageManager.getMessage('TOMS.COMMON.MIME.CSV'));

}


/**
 * CSVファイルの行を出力する処理
 * 
 * @param record DBから検索した行のデータ
 */
function outputCSVRow(record) {
	var result = '';
	
	result = convert(record["imdsc1"], true)
			+ convert(record["drdl01_cl"], true);
	for(var key in $bind.columns) {
		result += convert(record[key], true);
	}
	result += convert(record["sumLipqoh"], false);
	return result;
	
}

/**
 * CSV出力ファイルの各カラムデータ変換処理
 * 項目の区切り文字はカーマである
 * 
 * @param data 項目
 * @param flag 非改行フラグ
 */
function convert(data, flag) {
	if (data != null && data != "") {
		if (flag) {
			return transferComma(data) + getComma();
		} else {
			return transferComma(data) + getNewLine();
		}
	} else {
		if (flag) {
			return  getComma();
		} else {
			return  getNewLine();
		}
		
	}
}

/**
 * 項目の区切り文字を取得する処理
 */
function getComma() {
	return MessageManager.getMessage('TOMS.COMMON.COMMA');
}

/**
 * 改行の区切り文字を取得する処理
 */
function getNewLine() {
	return MessageManager.getMessage('TOMS.COMMON.NEWLINE');
}

/**
 * 項目データ中に半角カーマがある場合、全角のカーマに変換する処理
 */
function transferComma(data) {
	if (data != null && data != "") {
		if (data instanceof String) {
			var comma = MessageManager.getMessage('TOMS.COMMON.COMMA');
			return data.replace(/,/g, MessageManager.getMessage('TOMS.COMMON.COMMA.JP'));
		} else {
			return data;
		}
	} else {
		return data;
	}
}

/**
 * エラー画面へ遷移の処理.
 */
function error(message) {
  Transfer.toErrorPage({
    title: MessageManager.getMessage('TOMS.COMMON.ERROR.PAGE.TITLE'),
    message: MessageManager.getMessage('TOMS.COMMON.ERROR.MESSAGE.SYSTEM'),
    detail: [MessageManager.getMessage('TOMS.STOCK.LIST.LABEL.MESSAGE.ERROR'), message],
    returnUrl: 'toms/stock/search/input', // 戻り先 URL
    returnUrlLabel: MessageManager.getMessage('TOMS.STOCK.SEARCH.LABEL.RETURN.LINK.NAME'),
    parameter: {
    }
  });
}
