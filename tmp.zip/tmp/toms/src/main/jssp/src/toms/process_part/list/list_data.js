var $data;

/**
 * 初期表示
 * @param request リクエストパラメータ
 */
	
function init(request) {
	$data = ImJson.toJSONString(getList(request)); 
}

function getList(request) {

	// 表示条件を設定（表示ページ、件数など）
	let page = request.page == undefined ? 1 : request.page;
	let rows = request.rowNum == undefined ? 15 : Module.number.toInt(request.rowNum);
	
	// 検索条件の状況に応じて条件を設定する
	var param = request.extension;
	if (!param || !param.searchCondition) {
    	return  {
                		page  : page,
                		total : rows,
                		data  : []
    				};
	}
	
	//検索条件の設定
	var mky57appc1 = isBlank(param.searchCondition.mky57appc1) ? null : param.searchCondition.mky57appc1;//加工部位コード
	var mky57appc2 = isBlank(param.searchCondition.mky57appc2) ? null : param.searchCondition.mky57appc2;//加工位置コード
	var mky57apcsc = isBlank(param.searchCondition.mky57apcsc) ? null : param.searchCondition.mky57apcsc;//親商品形態コード
	var mky57acsc = isBlank(param.searchCondition.mky57acsc) ? null : param.searchCondition.mky57acsc;//商品形態コード
	var mky57amtc = isBlank(param.searchCondition.mky57amtc) ? null : param.searchCondition.mky57amtc;//素材コード
	var mkdl01 = isBlank(param.searchCondition.mkdl01) ? null : param.searchCondition.mkdl01 ;//加工部位名称
	var mkdl02 = isBlank(param.searchCondition.mkdl02) ? null : param.searchCondition.mkdl02;//加工位置名称
	var mky57adop1 = isBlank(param.searchCondition.mky57adop1) ? null : param.searchCondition.mky57adop1;//表示順 部位
	var mky57adop2 = isBlank(param.searchCondition.mky57adop2) ? null : param.searchCondition.mky57adop2;//表示順 位置
	var mky57ajcp1 = isBlank(param.searchCondition.mky57ajcp1) ? null : param.searchCondition.mky57ajcp1;//JDEコード　部位
	var mky57ajcp2 = isBlank(param.searchCondition.mky57ajcp2) ? null : param.searchCondition.mky57ajcp2;//JDEコード 位置
	var mkeftj = isBlank(param.searchCondition.mkeftj) ? null :param.searchCondition.mkeftj ;//適用開始日
	var mkeftj2 = isBlank(param.searchCondition.mkeftj2) ? null :param.searchCondition.mkeftj2 ;//適用開始日
	var mkexdj = isBlank(param.searchCondition.mkexdj) ? null : param.searchCondition.mkexdj;//適用終了日
	var mky57adflg = isBlank(param.searchCondition.mky57adflg) ? null : param.searchCondition.mky57adflg ;//削除フラグ
	

	var objParams = {
		mky57appc1 : mky57appc1,
		mky57appc2 : mky57appc2,
		mky57apcsc : mky57apcsc,
		mky57acsc : mky57acsc,
		mky57amtc : mky57amtc,
		mkdl01 : mkdl01,
		mkdl02 : mkdl02,
		mky57adop1 : mky57adop1,
		mky57adop2 : mky57adop2,
		mky57ajcp1 : mky57ajcp1,
		mky57ajcp2 : mky57ajcp2,
		mkeftj : mkeftj,
		mkeftj2 : mkeftj2,
		mkexdj : mkexdj,
		mky57adflg : mky57adflg
	}
	//加工部位マスタの件数取得
	var resultCount = getProcessPartListCount(objParams);
	// 全体の件数を設定（件数の母数）
	var listCount = 0;
	if (!resultCount.error) {
		listCount = resultCount.data[0]['rowcount'];
	} else {
		Debug.write(resultCount.errorMessage);
	}
	
	// ページ番号設定:リクエストパラメータのページ番号、最大ページ番号のうち小さい方の番号を設定
	page = Math.min(page, Math.ceil(listCount / rows)); 
	
	// 指定範囲の加工部位情報を取得
	var start = rows * (page - 1) + 1;
	var end = start + rows - 1;

	//加工部位マスタの一覧取得
	var result = getProcessPartList(objParams, start, end);
	var resultData =[];
	if(!result.error){
		resultData = result.data;
	}else{
		Debug.write(result.errorMessage);
	}

	var json = {
		page  : page,
		total : listCount,
		data  : resultData
	};
	return json;

	
	}

/**
 * 加工部位一覧件数取得
 */	
function getProcessPartListCount(objParams){
    load("toms/common/processPart");
    var result = ProcessPart.getProcessPartList(objParams, true,"","");
    return result;
}

/**
 * 加工部位一覧データ取得
 */
function getProcessPartList(objParams, start , end){
    load("toms/common/processPart");
    var result = ProcessPart.getProcessPartList(objParams, false,start,end);
    return result;
	
}

function createResult(page, total, data){
	return {
		page : page == null ? 1 : page,
		total : total == null ? 0 : total,
		data : data == null ? [] : data
	};
}


/**
 * エラーオブジェクト生成
 */
function createErrorResult(message, details){
	return {
		error : true,
		errorMessage : message,
		detailMessages : details

	}
}
