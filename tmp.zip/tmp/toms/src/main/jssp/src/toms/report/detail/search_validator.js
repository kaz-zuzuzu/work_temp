/**
 * 検索画面validation設定
 */
var init = {
  'mfpid1': { // 帳票ID.
    caption: 'TOMS.MASTER.MAINTENANCE.REPORT.LIST.INPUT.MFP1D1', // キャプションのメッセージキーを指定する. 
    required: true, // 必須チェック
    alphanumeric: true,
    maxlength: 10
  },
  'mfuser1': { // ユーザID.
    caption: 'TOMS.MASTER.MAINTENANCE.REPORT.LIST.INPUT.MFUSER1', // キャプションのメッセージキーを指定する. 
    required: true, // 必須チェック
    maxlength: 10
  },
  'mfev01': { // オプションコード.
    caption: 'TOMS.MASTER.MAINTENANCE.REPORT.LIST.INPUT.MFEV01', // キャプションのメッセージキーを指定する. 
    numeric: true,
    maxlength: 1
  },
  'mfactntyp': { // 処理タイプ.
    caption: 'TOMS.MASTER.MAINTENANCE.REPORT.LIST.INPUT.MFACTNTYP', // キャプションのメッセージキーを指定する. 
    alphanumeric: true,
    maxlength: 4
  },
  'mfpdes': { // 出力プリンタ名.
    caption: 'TOMS.MASTER.MAINTENANCE.REPORT.LIST.INPUT.MFPDES', // キャプションのメッセージキーを指定する. 
//    alphanumeric: true,
    maxlength: 255
  },
  'mfsrc': { // バリデーション対象のformのname属性を指定する.
    caption: 'TOMS.MASTER.MAINTENANCE.REPORT.LIST.INPUT.MFSRC', // キャプションのメッセージキーを指定する. 
    alphanumeric: true,
    maxlength: 80
  },
  'mfy57cura1': { // バリデーション対象のformのname属性を指定する.
    caption: 'TOMS.MASTER.MAINTENANCE.REPORT.LIST.INPUT.MFY57CURA1', // キャプションのメッセージキーを指定する. 
    numeric: true, // 数字チェック
    maxlength: 38
  },
  'mfy57cdl01': { // バリデーション対象のformのname属性を指定する.
      caption: 'TOMS.MASTER.MAINTENANCE.REPORT.LIST.INPUT.MFY57CDL01', // キャプションのメッセージキーを指定する. 
      maxlength: 30
   },
  'mfy57cdl02': { // バリデーション対象のformのname属性を指定する.
      caption: 'TOMS.MASTER.MAINTENANCE.REPORT.LIST.INPUT.MFY57CDL02', // キャプションのメッセージキーを指定する. 
      alphanumeric: true,
      maxlength: 30
   },
  'mfy57cdl03': { // 改ページ項目.
	  caption: 'TOMS.MASTER.MAINTENANCE.REPORT.LIST.INPUT.MFY57CDL03', // キャプションのメッセージキーを指定する. 
      regex: /^[0-9,]+$/,
	  maxlength: 30
   }
};
