/**
 * 素材マスタメンテナンス検索画面用validation設定
 */

 var init ={
		 'search_mly57amtc':{//素材コード
	 	caption:'TOMS.MASTER.MAINTENANCE.MATERIAL.LABEL.MATERIAL_CODE',
	 	alphanumeric: true,
		maxlength: 16
 		},
 		'search_mldl01':{//原材料名
	 	caption:'TOMS.MASTER.MAINTENANCE.MATERIAL.LABEL.MATERIAL_NAME',
		maxlength: 30
 		},	
		 'search_mly57acsc':{//商品形態コード
	 	caption:'TOMS.MASTER.MAINTENANCE.COMMODITYSHAPE.LABEL.COMMODITY_SHAPE_CODE',
	 	alphanumeric: true,
		maxlength: 16
 		},	
		 'search_mly57apcsc':{//親商品形態コード
	 	caption:'TOMS.MASTER.MAINTENANCE.COMMODITYSHAPE.LABEL.PARENT_COMMODITY_SHAPE_CODE',
	 	alphanumeric: true,
		maxlength: 16
 		},
		 'search_mlpct1':{//パーセント
	 	caption:'TOMS.MASTER.MAINTENANCE.MATERIAL.LABEL.PARCENT',
	 	numeric: true,
		maxlength: 3
 		},	 		
		 //JDEコード
		 'search_mly57ajdc':{
	 	caption:'TOMS.MASTER.MAINTENANCE.COMMODITYSHAPE.LABEL.JDE_CODE',
		 alphanumeric: true,
		 maxlength: 8
 		},	 		
		 //たたみ袋SKUコード
		 'search_mly57absc':{
	 	caption:'TOMS.MASTER.MAINTENANCE.MATERIAL.LABEL.BAG_SKU_CODE',
	 	alphanumeric: true,
		maxlength: 24
 		},
 		//有効開始日 
	 	'search_mleftj':{
	 	caption:'TOMS.MASTER.MAINTENANCE.COMMODITYSHAPE.LABEL.APPLIED_START_DATE',
		date: true,
	    maxlength: 10
	 	}, 
 		//有効開始日2 
	 	'search_mleftj2':{
	 	caption:'TOMS.MASTER.MAINTENANCE.COMMODITYSHAPE.LABEL.APPLIED_START_DATE',
		date: true,
	    maxlength: 10
	 	}, 
	 	//有効終了日 
	 	'search_mlexdj':{
	 	caption:'TOMS.MASTER.MAINTENANCE.COMMODITYSHAPE.LABEL.APPLIED_END_DATE',
		date: true,
	    maxlength: 10
	 	}
 }