	SELECT 
	 *
	FROM
	 (
	
		SELECT
	    TRIM(MPY57APMC) AS MPY57APMC
	  , TRIM(MPY57ACC) AS MPY57ACC
	  , TO_CHAR(FC_JDI9902_TO_DATE(MPEFTJ), 'YYYY/MM/DD') AS MPEFTJ
	  , TO_CHAR(FC_JDI9902_TO_DATE(MPEXDJ), 'YYYY/MM/DD') AS MPEXDJ
	  , MPY57ADFLG
	  , MPURCD
	  , MPURDT
	  , MPURAT
	  , MPURAB
	  , MPURRF
	  , TRIM(MPUSER) AS MPUSER
	  , TRIM(MPPID) AS MPPID
	  , MPJOBN
	  , TO_CHAR(FC_JDI9902_TO_DATE(MPUPMJ), 'YYYY/MM/DD') AS MPUPMJ
	  , MPUPMT
	  , TRIM(MPY57APCSC) AS MPY57APCSC
	  , TRIM(MPY57ACSC) AS MPY57ACSC
	  , TRIM(MPY57AMTC) AS MPY57AMTC
	  , TRIM(MPY57APPC1) AS MPY57APPC1
	  , TRIM(MPY57APPC2) AS MPY57APPC2
	  , TRIM(MPY57APMT) AS MPY57APMT
	  , TRIM(MPY57APMDT) AS MPY57APMDT
	  , ROWNUM AS RN 
		FROM
	(
	SELECT
	  MPY57APMC
	  , MPY57ACC
	  , MPEFTJ
	  , MPEXDJ
	  , MPY57ADFLG
	  , MPURCD
	  , MPURDT
	  , MPURAT
	  , MPURAB
	  , MPURRF
	  , MPUSER
	  , MPPID
	  , MPJOBN
	  , MPUPMJ
	  , MPUPMT
	  , MPY57APCSC
	  , MPY57ACSC
	  , MPY57AMTC
	  , MPY57APPC1
	  , MPY57APPC2
	  , MPY57APMT
	  , MPY57APMDT 
	FROM
	  F57A5160 MP
 INNER JOIN 
    (
    SELECT

    MMY57APMC,
    MMY57APCSC,
    MMY57ACSC,
    MMY57AMTC,
    MMY57APPC1,
    MMY57APPC2,
    MMY57APMT,
    MMY57APMDT

    FROM 
     F57A5140
/*IF mpdl01 != null*/
    WHERE 
            TRIM(MMDL01) LIKE /*mpdl01*/'%%'
/*END*/
    GROUP BY 
        MMY57APMC,
        MMY57APCSC,
        MMY57ACSC,
        MMY57AMTC,
        MMY57APPC1,
        MMY57APPC2,
        MMY57APMT,
        MMY57APMDT
    ) h
  ON MP.MPY57APMC = h.MMY57APMC
 and MP.MPY57APCSC = h.MMY57APCSC
 and MP.MPY57ACSC = h.MMY57ACSC
 and MP.MPY57AMTC = h.MMY57AMTC
 and MP.MPY57APPC1 = h.MMY57APPC1
 and MP.MPY57APPC2 = h.MMY57APPC2
 and MP.MPY57APMT = h.MMY57APMT
 and MP.MPY57APMDT = h.MMY57APMDT

 INNER JOIN 
    (
    SELECT
        MKY57APPC1,
        MKY57APPC2,
        MKY57APCSC,
        MKY57ACSC,
        MKY57AMTC
    FROM 
        F57A5120
        /*IF mpy57appc1Name!=null || mpy57appc2Name !=null*/
    WHERE 
        /*END*/
        /*IF mpy57appc1Name!=null*/    
          TRIM(MKDL01) LIKE /*mpy57appc1Name*/'%%'
        /*END*/
        /*IF mpy57appc1Name !=null && mpy57appc2Name!=null*/
          AND TRIM(MKDL02) LIKE /*mpy57appc2Name*/'%%'
        /*END*/
        /*IF mpy57appc1Name ==null && mpy57appc2Name!=null*/
          TRIM(MKDL02) LIKE /*mpy57appc2Name*/'%%'
        /*END*/
          
          GROUP BY 
         MKY57APPC1,
        MKY57APPC2,
        MKY57APCSC,
        MKY57ACSC,
        MKY57AMTC       
    ) bui
  ON MP.MPY57AMTC = bui.MKY57AMTC
 and MP.MPY57APCSC = bui.MKY57APCSC
 and MP.MPY57ACSC = bui.MKY57ACSC
 and MP.MPY57APPC1 = bui.MKY57APPC1
 and MP.MPY57APPC2 = bui.MKY57APPC2

 INNER JOIN 
    (
    SELECT
        MLY57AMTC,
        MLY57APCSC,
        MLY57ACSC
    FROM 
        F57A5130
/*IF mpy57amtcName!=null*/
        WHERE         
          TRIM(MLDL01) LIKE /*mpy57amtcName*/'%%'
          /*END*/
    GROUP BY 
        MLY57AMTC,
        MLY57APCSC,
        MLY57ACSC
      ) sozai
  ON MP.MPY57AMTC = sozai.MLY57AMTC
 and MP.MPY57APCSC = sozai.MLY57APCSC
 and MP.MPY57ACSC = sozai.MLY57ACSC
 
 INNER JOIN
     (
    SELECT 
        MJY57ACSC
      , MJY57APCSC
     FROM
        F57A5110 
     WHERE
        MJY57ACSC = MJY57APCSC
     /*IF mpy57apcscName!= null*/
     AND TRIM(MJDL01) LIKE /*mpy57apcscName*/'%%'
     /*END*/
     GROUP BY 
        MJY57ACSC
      , MJY57APCSC
    ) oya
    ON MP.MPY57APCSC = oya.MJY57ACSC
    
 INNER JOIN
     (
    SELECT 
        MJY57ACSC
      , MJY57APCSC
     FROM
        F57A5110 
     WHERE 
        MJY57ACSC <> MJY57APCSC
     /*IF mpy57acscName!= null*/
     AND TRIM(MJDL01) LIKE /*mpy57acscName*/'%%'
     /*END*/
     GROUP BY 
        MJY57ACSC
      , MJY57APCSC
    ) ko
    ON MP.MPY57ACSC = ko.MJY57ACSC
    and MP.MPY57APCSC = ko.MJY57APCSC

   /*BEGIN*/
      WHERE
      /*IF mpy57apmc !=null */
      TRIM(MP.MPY57APMC) =/*mpy57apmc*/''
      /*END*/
        /*IF mpy57acc !=null */
          AND TRIM(MP.MPY57ACC) =/*mpy57acc*/''
        /*END*/
            /*IF mpeftj !=null */
              AND MP.MPEFTJ >= /*mpeftj*/''
            /*END*/
            /*IF mpeftj2 !=null */
              AND MP.MPEFTJ <= /*mpeftj2*/''
            /*END*/
            /*IF mpy57adflg !=null */
              AND MP.MPY57ADFLG = /*mpy57adflg*/'0'
            /*END*/
            /*IF mpy57apcsc !=null */
              AND TRIM(MP.MPY57APCSC) = /*mpy57apcsc*/''
            /*END*/
            /*IF mpy57acsc !=null */
              AND TRIM(MP.MPY57ACSC) = /*mpy57acsc*/'0'
            /*END*/
            /*IF mpy57amtc !=null */
              AND TRIM(MP.MPY57AMTC) = /*mpy57amtc*/'0'
            /*END*/
            /*IF mpy57appc1 !=null */
              AND TRIM(MP.MPY57APPC1) = /*mpy57appc1*/'0'
            /*END*/
            /*IF mpy57appc2 !=null */
              AND TRIM(MP.MPY57APPC2) = /*mpy57appc2*/'0'
            /*END*/ 
            /*IF mpy57apmt !=null */
              AND TRIM(MP.MPY57APMT) IN /*mpy57apmt*/('1','2','3')
            /*END*/
            /*IF mpy57apmdt !=null */
              AND TRIM(MP.MPY57APMDT) IN /*mpy57apmdt*/('1','0')
            /*END*/
        /*END*/
		ORDER BY
			  MPY57APMC  
			, MPY57ACC 
			, MPEFTJ DESC 
	) base 
	     /*IF end != null*/
	        WHERE ROWNUM <= /*end*/'30' 
	     /*END*/
	)
	/*IF start != null*/
	WHERE RN >= /*start*/'1' 
	/*END*/