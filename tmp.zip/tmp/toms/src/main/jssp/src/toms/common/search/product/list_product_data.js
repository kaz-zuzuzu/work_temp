var $data;

/**
 * 初期表示
 * @param request リクエストパラメータ
 */
function init(request) {
	$data = ImJson.toJSONString(getList(request));
}

function getList(request) {
	// 表示条件を設定（表示ページ、件数など）
	let page = request.page == undefined ? 1 : request.page;
	let rows = request.rowNum == undefined ? 10 : Module.number.toInt(request.rowNum);
	var searchCondition = request.extension;
	if (!searchCondition || !searchCondition.searchConditionParam) {
		return  {
                		page  : page,
                		total : rows,
                		data  : []
    				};
    }
	
    if (searchCondition.searchConditionParam.popupFlag == "search") {
    	page = 1;
    }
    
	var productCode = searchCondition.searchConditionParam.productCode;
	var description1 = searchCondition.searchConditionParam.description1;
	var description2 = searchCondition.searchConditionParam.description2;
	

	// 該当する会社情報の件数取得
	let resultCount = searchProductCount(productCode, description1, description2);
	// 全体の件数を設定（件数の母数）
	var listCount = 0;
	if (!resultCount.error) {
		listCount = resultCount.data[0]['rowcount'];
	} else {
		Debug.write(resultCount.errorMessage);
	}
	// ページ番号設定:リクエストパラメータのページ番号、最大ページ番号のうち小さい方の番号を設定
	page = Math.min(page, Math.ceil(listCount / rows)); 
	
	// 指定範囲の会社情報を取得
	let start = rows * (page - 1) + 1;
	let end = start + rows - 1;
	
	var result = searchProduct(productCode, description1, description2, start, end);
	var rsltData = [];
	if (!result.error) {
		rsltData = result.data;
	} else {
		Debug.write(result.error);
	}
	
	var json = {
		page  : page,
		total : listCount,
		data  : rsltData
	};
	return json;
}

function searchProductCount(productCode, description1, description2) {
	load("toms/common/master");
	var result = TomsMaster.searchProduct(productCode, description1, description2, true);
	return result;
}

function searchProduct(productCode, description1, description2, start, end) {
	load("toms/common/master");
	var result = TomsMaster.searchProduct(productCode, description1, description2, false, start, end);
	return result;
}

