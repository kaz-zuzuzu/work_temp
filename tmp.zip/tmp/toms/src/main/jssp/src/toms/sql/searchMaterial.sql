SELECT
    *
FROM
(
    SELECT
        base.*
      , ROWNUM AS RN
    FROM
    (
select
  TRIM(SOZAI.MLY57AMTC) AS MLY57AMTC
  ,TRIM(SOZAI.MLDL01) AS MLDL01  
  ,TRIM(KO.MJY57ACSC) AS MJY57ACSC
  ,TRIM(KO.MJDL01) AS MJDL01
  ,TRIM(OYA.MJY57ACSC) AS MJY57APCSC
  ,TRIM(OYA.MJDL01) AS MJDL01P 
from  				
  ( 
    select
      MLY57AMTC 
      , MLY57APCSC
      , MLY57ACSC
      , MLDL01
      , dense_rank() over ( partition by MLY57AMTC ,MLY57APCSC, MLY57ACSC order by MLEFTJ desc ) rnk 
    from
      F57A5130 a
    where
      mly57adflg = 0 
      and MLEFTJ <= FC_JDI9902_TO_JULIAN(sysdate)
  ) sozai,

  ( 
    select
      MJY57ACSC
      , MJY57APCSC
      , MJDL01
      , dense_rank() over ( partition by MJY57ACSC ,MJY57APCSC order by MJEFTJ desc ) rnk 
    from
      F57A5110 
    where
      mjy57adflg = 0 
      and MJEFTJ <= FC_JDI9902_TO_JULIAN(sysdate)
  ) ko,

  ( 
    select
      MJY57ACSC
      , MJY57APCSC
      , MJDL01
      , dense_rank() over ( partition by MJY57ACSC ,MJY57APCSC order by MJEFTJ desc ) rnk 
    from
      F57A5110 
    where
      mjy57adflg = 0 
      and MJEFTJ <= FC_JDI9902_TO_JULIAN(sysdate)
  ) oya

where
	sozai.rnk=1
  and ko.rnk = 1
  and oya.rnk = 1
  and sozai.MLY57APCSC = ko.MJY57APCSC
  and sozai.MLY57APCSC = oya.MJY57ACSC
  and sozai.MLY57ACSC = ko.MJY57ACSC
  and ko.MJY57APCSC = oya.MJY57ACSC
           /*IF mjy57acsc !=null*/
           AND TRIM(ko.MJY57ACSC) =/*mjy57acsc*/
           /*END*/
            /*IF mjdl01 != null*/
           AND ko.MJDL01 like /*mjdl01*/
           /*END*/
           /*IF mjy57apcsc != null*/
            AND TRIM(oya.MJY57ACSC) = /*mjy57apcsc*/
           /*END*/
            /*IF mjdl01p != null*/
           AND oyaMJDL01 like /*mjdl01p*/
           /*END*/
           /*IF mly57amtc != null*/
            AND TRIM(sozai.MLY57AMTC) = /*mly57amtc*/
           /*END*/
            /*IF mldl01 != null*/
           AND sozai.MLDL01 like /*mldl01*/
           /*END*/
           order by sozai.MLY57AMTC,oya.MJY57ACSC,ko.MJY57ACSC
    ) base
     /*IF end != null*/
        WHERE ROWNUM <= /*end*/'10' 
     /*END*/

)
/*IF start != null*/
WHERE RN >= /*start*/'1' 
/*END*/
