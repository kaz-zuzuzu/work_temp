/**
 * バインド変数.
 */
var $bind = {};


/**
 * 初期表示.
 * @param request リクエストパラメータ.
 */
function init(request) {
    
    load("toms/common/master");
    
    request.setAttribute("imui-theme-builder-module", "headwithcontainer");
    
    var exchangeTargetId = request.exchangeTargetId
    
    // 取引先明細を取得する
    getExchangeTargetDetail(exchangeTargetId);

    // 口座名義人取得
    $bind.kouzameiginin = getHanyouMasterKouzanin();

}

function getExchangeTargetDetail(exchangeTargetId) {
    var result = TomsMaster.getExchangeTargetDetail(exchangeTargetId);
   if (!result.error) {
        $bind.DetailData = result.data[0];
    } else {
        error(result.errorMessage);
    }
}


function getHanyouMasterKouzanin(){
    var result = TomsMaster.getHanyouMasterKouzanin();
    if (!result.error) {
         return result.data[0].value1;
     } else {
         error(result.errorMessage);
     }
}
	 

/**
 * エラー画面へ遷移の処理.
 */
function error(message) {
  Transfer.toErrorPage({
    title: MessageManager.getMessage('TOMS.COMMON.ERROR.PAGE.TITLE'),
    message: MessageManager.getMessage('TOMS.COMMON.ERROR.MESSAGE.SYSTEM'),
    detail: [MessageManager.getMessage('TOMS.EXCHANGE.DETAIL.LABEL.MESSAGE.ERROR'), message],
    parameter: {
    }
  });
}