/**
 * バインド変数.
 */
var $bind = {};

var $data = {};
	
load("toms/common/common");

/**
 * 初期表示
 * @param request リクエストパラメータ
 */
function init(request) {
	load("toms/common/master");
	$data = {
		rowNum  : 30,
		rowList : [30, 50, 100]
	};
	
	$bind.mfpid1 = request.mfpid1;
    $bind.mfuser1 = request.mfuser1;
    
	if (request.csvFlag == "1") {
        outputCSV($bind.mfpid1, $bind.mfuser1);
	}

  // CSV出力ボタン押下時の確認ダイアログのメッセージを初期化.
  // JavaScriptで利用するためオブジェクトの内容をそのまま渡します.
  $bind.dialogMessages = ({
    addConfirmTitle: MessageManager.getMessage('TOMS.COMMON.DIALOG.CONFIRM.TITLE'),
    addConfirmMessage: MessageManager.getMessage('TOMS.COMMON.DIALOG.CONFIRM.MESSAGE')
  }).toSource();
}


/**
 * 帳票設定マスタメンテナンスのCSV出力処理
 * 
 * @param mfpid1 帳票ID
 * @param mfuser1 ユーザーID
 */
function outputCSV(mfpid1, mfuser1) {
	var result = TomsMaster.getReportList(mfpid1, mfuser1, null, null, false);
	var outputContent = "";
	if (!result.error) {
		outputContent = outputCSVHeader();
    	for(var i = 0; i < result.countRow; i++) {
    		outputContent += outputCSVRow(result.data[i]);
    	}
    	var strDate = DateTimeFormatter.format("yyyyMMdd", new Date());
    	var strUserName = Contexts.getUserContext().userProfile.userName;
    	var fileName = MessageManager.getMessage('TOMS.MASTER.MAINTENANCE.REPORT.LIST.INPUT.FILENAME') + '_' + strDate + '_' + strUserName + '.csv';
    	Module.download.send(Unicode.to(outputContent, 'MS932'), fileName, MessageManager.getMessage('TOMS.COMMON.MIME.CSV'));
	} else {
		error(result.errorMessage);
	}
}


/**
 * 帳票設定マスタメンテナンスのCSVヘッダ部分出力処理。
 */
function outputCSVHeader() {
	var outputHeader = common.convert(MessageManager.getMessage('TOMS.COMMON.CSV.UPDATE.DIVIDE'), true)
				  + common.convert(MessageManager.getMessage('TOMS.MASTER.MAINTENANCE.REPORT.LIST.INPUT.MFP1D1'), true)
				  + common.convert(MessageManager.getMessage('TOMS.MASTER.MAINTENANCE.REPORT.LIST.INPUT.MFUSER1'), true)
				  + common.convert(MessageManager.getMessage('TOMS.MASTER.MAINTENANCE.REPORT.LIST.INPUT.MFEV01'), true)
				  + common.convert(MessageManager.getMessage('TOMS.MASTER.MAINTENANCE.REPORT.LIST.INPUT.MFACTNTYP'), true)
				  + common.convert(MessageManager.getMessage('TOMS.MASTER.MAINTENANCE.REPORT.LIST.INPUT.MFPDES'), true)
				  + common.convert(MessageManager.getMessage('TOMS.MASTER.MAINTENANCE.REPORT.LIST.INPUT.MFSRC'), true)
				  + common.convert(MessageManager.getMessage('TOMS.MASTER.MAINTENANCE.REPORT.LIST.INPUT.MFY57CURA1'), true)
				  + common.convert(MessageManager.getMessage('TOMS.MASTER.MAINTENANCE.REPORT.LIST.INPUT.MFY57CDL01'), true)
				  + common.convert(MessageManager.getMessage('TOMS.MASTER.MAINTENANCE.REPORT.LIST.INPUT.MFY57CDL02'), true)
				  + common.convert(MessageManager.getMessage('TOMS.MASTER.MAINTENANCE.REPORT.LIST.INPUT.MFY57CDL03'), false);
	return outputHeader;
}

/**
 * 帳票設定マスタメンテナンスのCSVファイルの行を出力する処理
 * 
 * @param record DBから検索した行のデータ
 */
function outputCSVRow(record) {
	var result =  MessageManager.getMessage('TOMS.COMMON.CSV.SPLIT')
		    + common.convert(record["mfpid1"], true)
			+ common.convert(record["mfuser1"], true)
			+ common.convert(record["mfev01"], true)
			+ common.convert(record["mfactntyp"], true)
			+ common.convert(record["mfpdes"], true)
			+ common.convert(record["mfsrc"], true)
			+ common.convert(record["mfy57cura1"], true)
			+ common.convert(record["mfy57cdl01"], true)
			+ common.convert(record["mfy57cdl02"], true)
			+ common.convert(record["mfy57cdl03"], false);
	return result;
	
}

function error(message) {
  Transfer.toErrorPage({
    title: MessageManager.getMessage('TOMS.COMMON.ERROR.PAGE.TITLE'),
    message: MessageManager.getMessage('TOMS.COMMON.ERROR.MESSAGE.SYSTEM'),
    detail: [MessageManager.getMessage('TOMS.MASTER.MAINTENANCE.REPORT.LIST.LABEL.MESSAGE.ERROR'), message],
    returnUrl: 'toms/report/list/input', // 戻り先 URL
    returnUrlLabel: MessageManager.getMessage('TOMS.MASTER.MAINTENANCE.REPORT.LIST.LABEL.RETURN.LINK.NAME'),
    parameter: {
    }
  });
}

