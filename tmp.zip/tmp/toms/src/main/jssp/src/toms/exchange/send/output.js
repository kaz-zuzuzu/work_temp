/**
 * バインド変数.
 */
var $bind = {};

load("toms/common/master");
load('toms/common/common');

// 区切り文字（カンマ）
var splitComma = MessageManager.getMessage('TOMS.COMMON.COMMA');


/**
 * 初期表示.
 * @param request リクエストパラメータ.
 */
function init(request) {
    

    
    request.setAttribute("imui-theme-builder-module", "headwithcontainer");    

    var exchangeTargetId = request.exchangeTargetId
    
    $bind.exchangeTargetId = exchangeTargetId;
    $bind.exchangeTargetName = request.exchangeTargetName;
    
    	// 送付先一覧を取得する
        getSendList(exchangeTargetId);
        
        // CSV出力ボタン押下時の確認ダイアログのメッセージを初期化.
        // JavaScriptで利用するためオブジェクトの内容をそのまま渡します.
        $bind.dialogMessages = ({
          addConfirmTitle: MessageManager.getMessage('TOMS.COMMON.DIALOG.CONFIRM.TITLE'),
          addConfirmMessage: MessageManager.getMessage('TOMS.COMMON.DIALOG.CONFIRM.MESSAGE.COMMA')
        }).toSource();
        
    // 呼び出し元が特記事項一覧の場合（CSV出力の場合）
    if (request.screenId == "outputCSV") {
    	outputCSV($bind.exchangeTargetId, $bind.exchangeTargetName);
    }
}

function getSendList(exchangeTargetId) {
    var result = TomsMaster.getSendList(exchangeTargetId);
    if (!result.error) {
        $bind.listData = result.data;
    } else {
        error(result.errorMessage);
    }
}

/**
 * 特記事項一覧のCSV出力処理.
 * 
 * @param exchangeTargetId 取引先コード.
 * @param exchangeTargetName 取引先名.
 */
function outputCSV(exchangeTargetId, exchangeTargetName) {
    var result = TomsMaster.getSendList(exchangeTargetId);
    var outputContent = "";
    if (!result.error) {
        outputContent = outputCSVHeader();
        for (var i = 0; i < result.countRow; i++) {
            outputContent += outputCSVRow(result.data[i]);
        }
        var strDateTime = DateTimeFormatter.format("yyyyMMddHHmmss", new Date());
//        var fileName = MessageManager.getMessage('TOMS.EXCHANGE.LIST.LABEL.NOTICE.TITTLE') + '_' + exchangeTargetId + '_' + exchangeTargetName + '_' + strDate + '_' + strUserName + '.csv';
        var fileName = MessageManager.getMessage('TOMS.EXCHANGE.LIST.LABEL.SEND.TITTLE') + '_' + strDateTime + '.csv';
        Module.download.send(Unicode.to(outputContent, 'MS932'), fileName, MessageManager.getMessage('TOMS.COMMON.MIME.CSV'));
    } else {
        errorcsv(result.errorMessage);
    }
}

/**
 * 特記事項一覧のCSVヘッダ部分出力処理.
 */
function outputCSVHeader() {
    var outputHeader = common.convertWithSplit(MessageManager.getMessage('TOMS.EXCHANGE.LIST.LABEL.SEND.EXCHANGETARGET.CODE'), splitComma, true)		// 取引先コード
    				   + common.convertWithSplit(MessageManager.getMessage('TOMS.EXCHANGE.LIST.LABEL.SEND.EXCHANGETARGET'), splitComma, true)   // 送付先番号
                       + common.convertWithSplit(MessageManager.getMessage('TOMS.EXCHANGE.LIST.LABEL.SEND.SENDINGNO'), splitComma, true)		// 送付先番号
                       + common.convertWithSplit(MessageManager.getMessage('TOMS.EXCHANGE.LIST.LABEL.SEND.SENDINGNAME'), splitComma, true)      // 送付先名称
                       + common.convertWithSplit(MessageManager.getMessage('TOMS.EXCHANGE.LIST.LABEL.SEND.SENDINGKANA'), splitComma, true)		// 送付先カナ
                       + common.convertWithSplit(MessageManager.getMessage('TOMS.EXCHANGE.LIST.LABEL.SEND.SENDINGADD1'), splitComma, true)  	// 送付先住所１
                       + common.convertWithSplit(MessageManager.getMessage('TOMS.EXCHANGE.LIST.LABEL.SEND.SENDINGADD2'), splitComma, true)		// 送付先住所２
                       + common.convertWithSplit(MessageManager.getMessage('TOMS.EXCHANGE.LIST.LABEL.SEND.SENDINGADD3'), splitComma, true)		// 送付先住所３
                       + common.convertWithSplit(MessageManager.getMessage('TOMS.EXCHANGE.LIST.LABEL.SEND.SENDINGADD4'), splitComma, true)		// 送付先住所４
                       + common.convertWithSplit(MessageManager.getMessage('TOMS.EXCHANGE.LIST.LABEL.SEND.ZIPCODE'), splitComma, true)			// 郵便番号
                       + common.convertWithSplit(MessageManager.getMessage('TOMS.EXCHANGE.LIST.LABEL.SEND.FARECHARGEFLG'), splitComma, true)	// 運賃請求フラグ
                       + common.convertWithSplit(MessageManager.getMessage('TOMS.EXCHANGE.LIST.LABEL.SEND.SAVETIME'), splitComma, true)			// 貯め打時間
                       + common.convertWithSplit(MessageManager.getMessage('TOMS.EXCHANGE.LIST.LABEL.SEND.ASSERTINGSET'), splitComma, true)		// アソート設定
                       + common.convertWithSplit(MessageManager.getMessage('TOMS.EXCHANGE.LIST.LABEL.SEND.DELIVERY'), splitComma, true)			// 運送便
                       + common.convertWithSplit(MessageManager.getMessage('TOMS.EXCHANGE.LIST.LABEL.SEND.CHARGEPERSON'), splitComma, true)		// 担当者
                       + common.convertWithSplit(MessageManager.getMessage('TOMS.EXCHANGE.LIST.LABEL.SEND.REPRESENTATIVETEL'), splitComma, true)// 代表電話番号
                       + common.convertWithSplit(MessageManager.getMessage('TOMS.EXCHANGE.LIST.LABEL.SEND.REPRESENTATIVEFAX'), splitComma, true)// 代表FAX番号
                       + common.convertWithSplit(MessageManager.getMessage('TOMS.EXCHANGE.LIST.LABEL.SEND.DIRECTTEL'), splitComma, true)		// 直通電話番号
                       + common.convertWithSplit(MessageManager.getMessage('TOMS.EXCHANGE.LIST.LABEL.SEND.DIRECTFAX'), splitComma, false)      	// 直通FAX番号 
	return outputHeader;
}

	/**
 * 特記事項一覧のCSVファイルの行を出力する処理.
 * 
 * @param record DBから検索した行のデータ.
 */
function outputCSVRow(record) {
    var result = common.convertWithSplit(record["torihikisakicd"], splitComma, true)	// 取引先コード
    			+ common.convertWithSplit(record["torihikisakimei"], splitComma, true)	// 取引先
    			+ common.convertWithSplit(record["soufusakibangou"], splitComma, true)	// 送付先番号
    			+ common.convertWithSplit(record["soufusakimei"], splitComma, true)		// 送付先名称
    			+ common.convertWithSplit(record["soufusakikana"], splitComma, true)	// 送付先カナ名
    			+ common.convertWithSplit(record["soufusakijyusyo1"], splitComma, true)	// 送付先住所１
    			+ common.convertWithSplit(record["soufusakijyusyo2"], splitComma, true)	// 送付先住所２
    			+ common.convertWithSplit(record["soufusakijyusyo3"], splitComma, true)	// 送付先住所３
    			+ common.convertWithSplit(record["soufusakijyusyo4"], splitComma, true)	// 送付先住所４
    			+ common.convertWithSplit(record["zipcode"], splitComma, true)			// 郵便番号
    			+ common.convertWithSplit(record["untinseikyuuflg"], splitComma, true)	// 運賃請求フラグ
    			+ common.convertWithSplit(record["tameutitime"], splitComma, true)		// 貯め打時間
    			+ common.convertWithSplit(record["asootoset"], splitComma, true)		// アソート設定
    			+ common.convertWithSplit(record["unsoubin"], splitComma, true)			// 運送便
    			+ common.convertWithSplit(record["tantousya"], splitComma, true)		// 担当者
    			+ common.convertWithSplit(record["daihyoutel"], splitComma, true)		// 代表電話番号
    			+ common.convertWithSplit(record["daihyoufax"], splitComma, true)		// 代表FAX番号
    			+ common.convertWithSplit(record["tyokutuutel"], splitComma, true)		// 直通電話番号
    			+ common.convertWithSplit(record["tyokutuufax"], splitComma, false)		// 直通FAX番号
    return result;
}

/**
 * エラー画面へ遷移の処理.
 */
// エラーページ
function error(message) {
  Transfer.toErrorPage({
    title: MessageManager.getMessage('TOMS.COMMON.ERROR.PAGE.TITLE'),
    message: MessageManager.getMessage('TOMS.COMMON.ERROR.MESSAGE.SYSTEM'),
    detail: [MessageManager.getMessage('TOMS.EXCHANGE.LIST.LABEL.SEND.MESSAGE.ERROR'), message],
    returnUrl: 'toms/exchange/send/output', // 戻り先 URL
    returnUrlLabel: MessageManager.getMessage('TOMS.EXCHANGE.LIST.LABEL.SEND.RETURN.LINK.NAME'),
    parameter: {
    }
  });
}

// エラーページ
function errorcsv(message) {
  Transfer.toErrorPage({
    title: MessageManager.getMessage('TOMS.COMMON.ERROR.PAGE.TITLE'),
    message: MessageManager.getMessage('TOMS.COMMON.ERROR.MESSAGE.SYSTEM'),
    detail: [MessageManager.getMessage('TOMS.EXCHANGE.SEND.LABEL.CSV.MESSAGE.ERROR'), message],
    returnUrl: 'toms/exchange/send/output', // 戻り先 URL
    returnUrlLabel: MessageManager.getMessage('TOMS.EXCHANGE.SEND.LABEL.CSV.RETURN.LINK.NAME'),
    parameter: {
    }
  });
}