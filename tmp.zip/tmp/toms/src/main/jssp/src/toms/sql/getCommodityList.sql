SELECT
    *
FROM
(
    SELECT
         TRIM(MJY57ACSC) AS MJY57ACSC
        ,TRIM(MJY57APCSC) AS MJY57APCSC
        ,TRIM(MJDL01) AS MJDL01
        ,MJSNN
        ,TRIM(MJY57AJDT) AS MJY57AJDT
        ,TRIM(MJY57AJDC) AS MJY57AJDC
        ,TO_CHAR(FC_JDI9902_TO_DATE(MJEFTJ), 'YYYY/MM/DD') AS MJEFTJ
        ,TO_CHAR(FC_JDI9902_TO_DATE(MJEXDJ), 'YYYY/MM/DD') AS MJEXDJ
        ,MJY57ADFLG
        ,MJURCD
        ,MJURDT
        ,MJURAT
        ,MJURAB
        ,MJURRF
          ,TRIM(MJUSER) AS MJUSER
          ,TRIM(MJPID) AS MJPID
          ,TRIM(MJJOBN) AS MJJOBN
          ,TO_CHAR(FC_JDI9902_TO_DATE(MJUPMJ), 'YYYY/MM/DD') AS MJUPMJ
        ,MJUPMT
        ,ROWNUM AS RN
    FROM
    (
    SELECT 
        MJY57ACSC
        ,MJY57APCSC
        ,MJDL01
        ,MJSNN
        ,MJY57AJDT
        ,MJY57AJDC
        ,MJEFTJ
        ,MJEXDJ
        ,MJY57ADFLG
        ,MJURCD
        ,MJURDT
        ,MJURAT
        ,MJURAB
        ,MJURRF
        ,MJUSER
        ,MJPID
        ,MJJOBN
        ,MJUPMJ
        ,MJUPMT
    FROM
        F57A5110
/*BEGIN*/
    WHERE
        /*IF mjy57acsc != null*/
        AND  TRIM(MJY57ACSC) = /*mjy57acsc*/'%TEST%'
        /*END*/
        /*IF mjy57apcsc != null*/
        AND  TRIM(MJY57APCSC) = /*mjy57apcsc*/'2'
        /*END*/
        /*IF mjdl01 != null*/
        AND  TRIM(MJDL01) LIKE  /*mjdl01*/'%3%'
        /*END*/
         /*IF mjy57ajdc != null*/
        AND  TRIM(MJY57AJDC) = /*mjy57ajdc*/'5'
        /*END*/
        /*IF mjy57adflg != null*/
        AND  TRIM(MJY57ADFLG) = /*mjy57adflg*/'0'
        /*END*/
        /*IF mjeftj != null*/
        AND  MJEFTJ >= /*mjeftj*/'116032'
        /*END*/
        /*IF mjeftj2 != null*/
        AND  MJEFTJ <= /*mjeftj2*/'116033'
        /*END*/
    /*END*/
        ORDER BY MJY57ACSC, MJY57APCSC, MJSNN, MJEFTJ DESC
    ) base
     /*IF end != null*/
        WHERE ROWNUM <= /*end*/'30' 
     /*END*/
)
/*IF start != null*/
WHERE RN >= /*start*/'1' 
/*END*/