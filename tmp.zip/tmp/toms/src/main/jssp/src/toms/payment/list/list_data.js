var $data;

/**
 * 初期表示
 * @param request リクエストパラメータ
 */
function init(request) {
	$data = ImJson.toJSONString(getList(request));
}

function getList(request) {
	// 表示条件を設定（表示ページ、件数など）
	let page = request.page == undefined ? 1 : request.page;
	let rows = request.rowNum == undefined ? 30 : Module.number.toInt(request.rowNum);

	// 検索条件の状況に応じて条件を設定する
	var param = request.extension;
	if (!param || !param.searchCondition) {
    	return  {
                		page  : page,
                		total : rows,
                		data  : []
    				};
    	}

	var mapyrFrom =  param.searchCondition.mapyrFrom;
	var mapyrTo =  param.searchCondition.mapyrTo;
	
	// 該当する入金パターン情報の件数取得
	let resultCount = getPaymentListCount(mapyrFrom, mapyrTo);

	// 全体の件数を設定（件数の母数）
	var listCount = 0;
	if (!resultCount.error) {
		listCount = resultCount.data[0]['rowcount'];
	} else {
		Debug.write(resultCount.errorMessage);
	}

	// ページ番号設定:リクエストパラメータのページ番号、最大ページ番号のうち小さい方の番号を設定
	page = Math.min(page, Math.ceil(listCount / rows)); 
	
	// 取得データの開始行と終了行を設定
	let start = rows * (page - 1) + 1;
	let end = start + rows - 1;
	
	var result = getPaymentList(mapyrFrom, mapyrTo, start, rows);
	var rsltData = [];
	if (!result.error) {
		rsltData = result.data;
	} else {
		Debug.write(result.errorMessage);
	}

	var json = {
		page  : page,
		total : listCount,
		data  : rsltData
	};
	return json;
}

function getPaymentList(mapyrFrom, mapyrTo, start, end) {

    load("toms/common/master");
    var result = TomsMaster.getPaymentPtnList(mapyrFrom, mapyrTo, start, end);
	return result;
}

function getPaymentListCount(mapyrFrom, mapyrTo) {
    load("toms/common/master");//getPaymentPtnListCount
    var result = TomsMaster.getPaymentPtnListCount(mapyrFrom, mapyrTo);
	return result;
}
