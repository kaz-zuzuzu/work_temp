/**
 * バインド変数.
 */
var $bind = {};

/**
 * 初期表示
 * @param request リクエストパラメータ
 */
function init(request) {
	load("toms/common/master");
	// 組織コード
	var organizationCode = request.organization;
	// 全期間のフラグ（１ヵ月分を表示）
	var checkFlag = request.allFlag;
	// 支払日のデータを設定した場合、CSV出力ボタンの処理が行われる
	if (checkFlag == '1'
		|| request.paymentDateFrom != null
		|| request.paymentDateTo != null
		) {
		if (organizationCode == ' ') {
			organizationCode = null;
		}
		// 全期間のフラグをチェックした場合、 支払日を設定しないようにする
    	if (checkFlag == "1") {
    		// 全期間
    		outputCSV(organizationCode, null, null);
    	} else {
    		// 支払日の開始日と終了日を検索条件に設定し、ファイルを出力する
    		outputCSV(organizationCode, request.paymentDateFrom, request.paymentDateTo);
    	}
	}

    // 上位組織のセレクトボックスの値を初期化.
    setSuperOrganizationData();
    // 組織のセレクトボックスの値を初期化.
    setOrganizationData();
  
	// 支払日のFrom Toの初期値設定
	var dateTimeObject = new DateTime();

	//$bind.paymentDateFrom = dateTimeObject.dayOfMonth;
   if (dateTimeObject.dayOfMonth >= 11 && dateTimeObject.dayOfMonth <= 20) {
	// システム日付から9日後を取得
		$bind.paymentDateFrom = 11;
		$bind.paymentDateTo = 20;
	//  仕様の確認　今はシステム日付から9日後をToとして設定
	//	運用で10日区切りだった場合には以下とする
	//		 システム日付 <= 10 ：10
	//		10 < システム日付 <= 20 ：20
	//		20 < システム日付 ： 月末
	} else if (dateTimeObject.dayOfMonth >= 1 && dateTimeObject.dayOfMonth <= 10) {
		$bind.paymentDateFrom = 1;
		$bind.paymentDateTo = 10;
	} else {
		$bind.paymentDateFrom = 21;
		$bind.paymentDateTo = dateTimeObject.lastDayOfMonth;
	}
   
	//支払日のFrom Toの指定をプルダウンで生成
   	$bind.paymentDateFromList = [
   	                             { 	 label:"1",
   	                            	 value:"1"
   	                             },
   	                             {	 label:"11",
	                            	 value:"11"
   	                             },
   	                             {	 label:"21",
   	                            	 value:"21"
	                             }
   	                            ];

   	$bind.paymentDateToList = [
   	                             { 	 label:"10",
   	                            	 value:"10"
   	                             },
   	                             {	 label:"20",
	                            	 value:"20"
   	                             },
   	                             {	 label:dateTimeObject.lastDayOfMonth,
   	                            	 // 当月末日のvalueに固定値を設定
//   	                            	 value:dateTimeObject.lastDayOfMonth
   	                            	 value:MessageManager.getMessage('TOMS.COMMON.DATE.CUTOFF.DATE')
	                             }
   	                             ]; 
   	// CSV出力ボタン押下時の確認ダイアログのメッセージを初期化.
  // JavaScriptで利用するためオブジェクトの内容をそのまま渡します.
  $bind.dialogMessages = ({
    addConfirmTitle: MessageManager.getMessage('TOMS.COMMON.DIALOG.CONFIRM.TITLE'),
    addConfirmMessage: MessageManager.getMessage('TOMS.COMMON.DIALOG.CONFIRM.MESSAGE'),
    addCheckTitle: MessageManager.getMessage('TOMS.COMMON.DIALOG.CHECK.TITLE'),
    addCheckMessage: MessageManager.getMessage('TOMS.COMMON.DIALOG.CHECK.MESSAGE')
  }).toSource();
  
    // 組織のプルダウンに表示されるのトップメッセージを初期化.
  // JavaScriptで利用するためオブジェクトの内容をそのまま渡します.
  $bind.organizationLabel = ({
	    selectTopMessage: MessageManager.getMessage('TOMS.COMMON.SELECT.LABEL.ORGANIZATION')
	  }).toSource();

}

/**
 * 上位組織情報を設定する処理
 * 
 */
function setSuperOrganizationData() {
	var result = TomsMaster.getSuperOrganizationList();
	if (!result.error) {
    	// 上位組織	 
    	$bind.superOrganizationSelectList = result.data;
	}
}

/**
 * 組織情報を設定する処理
 * 
 */
function setOrganizationData() {
	var result = TomsMaster.getOrganizationListByCode(' ');
	if (!result.error) {
    	// 組織	 
    	$bind.organizationSelectList = result.data;
	}
}

/**
 * 売掛金回収残高管理表のCSV出力処理
 * 
 * SSJSでリクエストパラメータの検証を行う場合は、
 * validateアノテーションでバリデーションファイルを指定します。
 * 検証はoutputCSV関数の処理に入る前に実施されます。
 * バリデーションエラーをハンドリングしたい場合は、
 * onerrorアノテーションで関数名を指定することでエラー時の処理を追加することができます。
 * 
 * @param organizationCode 組織コード
 * @param paymentDayFrom 支払日（FROM）
 * @param paymentDayTo 支払日（TO）
 * @validate toms/account/search/outputcsv_validator#init
 * @onerror handleErrors
 */
function outputCSV(organizationCode, paymentDayFrom, paymentDayTo) {
	var result = TomsMaster.getAccountData(organizationCode, paymentDayFrom, paymentDayTo);
	var outputContent = "";
	if (!result.error) {
		outputContent = outputCSVHeader();
    	for(var i = 0; i < result.countRow; i++) {
    		outputContent += outputCSVRow(result.data[i]);
    	}
    	var strDate = DateTimeFormatter.format("yyyyMMdd", new Date());
    	var strUserName = Contexts.getUserContext().userProfile.userName;
    	var fileName = MessageManager.getMessage('TOMS.ACCOUNT.SEARCH.LABEL.FILENAME') + '_' + strDate + '_' + strUserName + '.csv';
    	Module.download.send(Unicode.to(outputContent, 'MS932'), fileName, MessageManager.getMessage('TOMS.COMMON.MIME.CSV'));
	} else {
		error(result.errorMessage);
	}
}

/**
 * 売掛金回収残高管理表のCSVヘッダ部分出力処理。
 */
function outputCSVHeader() {
	var outputHeader = convert(MessageManager.getMessage('TOMS.ACCOUNT.SEARCH.LABEL.CSV.TITLE.ORGANIZATION.NAME'), true)
				  + convert(MessageManager.getMessage('TOMS.ACCOUNT.SEARCH.LABEL.CSV.TITLE.CHARGEPERSON'), true)
				  + convert(MessageManager.getMessage('TOMS.ACCOUNT.SEARCH.LABEL.CSV.TITLE.EXCHANGETARGET.CODE'), true)
				  + convert(MessageManager.getMessage('TOMS.ACCOUNT.SEARCH.LABEL.CSV.TITLE.EXCHANGETARGET.NAME'), true)
				  + convert(MessageManager.getMessage('TOMS.ACCOUNT.SEARCH.LABEL.CSV.TITLE.PAYMENT.ENDDATE'), true)
				  + convert(MessageManager.getMessage('TOMS.ACCOUNT.SEARCH.LABEL.CSV.TITLE.PAYMENT.COMMENT'), true)
				  + convert(MessageManager.getMessage('TOMS.ACCOUNT.SEARCH.LABEL.CSV.TITLE.ACCOUNT.0'), true)
				  + convert(MessageManager.getMessage('TOMS.ACCOUNT.SEARCH.LABEL.CSV.TITLE.ACCOUNT.1'), true)
				  + convert(MessageManager.getMessage('TOMS.ACCOUNT.SEARCH.LABEL.CSV.TITLE.ACCOUNT.2'), true)
				  + convert(MessageManager.getMessage('TOMS.ACCOUNT.SEARCH.LABEL.CSV.TITLE.ACCOUNT.3'), true)
				  + convert(MessageManager.getMessage('TOMS.ACCOUNT.SEARCH.LABEL.CSV.TITLE.ACCOUNT.4'), true)
				  + convert(MessageManager.getMessage('TOMS.ACCOUNT.SEARCH.LABEL.CSV.TITLE.ACCOUNT.5'), true)
				  + convert(MessageManager.getMessage('TOMS.ACCOUNT.SEARCH.LABEL.CSV.TITLE.ACCOUNT.6'), true)
				  + convert(MessageManager.getMessage('TOMS.ACCOUNT.SEARCH.LABEL.CSV.TITLE.ACCOUNT.7'), true)
				  + convert(MessageManager.getMessage('TOMS.ACCOUNT.SEARCH.LABEL.CSV.TITLE.ACCOUNT.8'), true)
				  + convert(MessageManager.getMessage('TOMS.ACCOUNT.SEARCH.LABEL.CSV.TITLE.CURRENTLY.STATUS'), true)
				  + convert(MessageManager.getMessage('TOMS.ACCOUNT.SEARCH.LABEL.CSV.TITLE.REASON'), true)
				  + convert(MessageManager.getMessage('TOMS.ACCOUNT.SEARCH.LABEL.CSV.TITLE.DEAL'), true)
				  + convert(MessageManager.getMessage('TOMS.ACCOUNT.SEARCH.LABEL.CSV.TITLE.CHARGE.DATE'), true)
				  + convert(MessageManager.getMessage('TOMS.ACCOUNT.SEARCH.LABEL.CSV.TITLE.COMMENT'), false);
	return outputHeader;
}

/**
 * 売掛金回収残高管理表のCSVファイルの行を出力する処理
 * 
 * @param record DBから検索した行のデータ
 */
function outputCSVRow(record) {
	var result = '';
	var responseAccount = record["rpaap_0"]
	                    + record["rpaap_1"]
	                    + record["rpaap_2"]
	                    + record["rpaap_3"]
	                    + record["rpaap_4"]
	                    + record["rpaap_5"];
	var allAccount = responseAccount + record["rpaap_99"];
	result = convert(record["mcdc"], true)
			+ convert(record["aban84_nm"], true)
			+ convert(record["rpan8"], true)
			+ convert(record["rpan8_nm"], true)
			+ convert(record["abac10"], true)
			+ convert(record["l3ptd"], true)
			+ convert(record["rpaap_0"], true)
			+ convert(record["rpaap_1"], true)
			+ convert(record["rpaap_2"], true)
			+ convert(record["rpaap_3"], true)
			+ convert(record["rpaap_4"], true)
			+ convert(record["rpaap_5"], true)
			+ convert(responseAccount, true)
			+ convert(record["rpaap_99"], true)
			+ convert(allAccount, true)
			+ convert("", true)
			+ convert("", true)
			+ convert("", true)
			+ convert("", true)
			+ convert("", false);
	return result;
	
}

/**
 * CSV出力ファイルの各カラムデータ変換処理
 * 項目の区切り文字はカーマである
 * 
 * @param data 項目
 * @param flag 非改行フラグ
 */
function convert(data, flag) {
	if (data != null && data != "") {
		if (flag) {
			return transferComma(data) + getComma();
		} else {
			return transferComma(data) + getNewLine();
		}
	} else {
		if (flag) {
			return  getComma();
		} else {
			return  getNewLine();
		}
		
	}
}

/**
 * 項目の区切り文字を取得する処理
 */
function getComma() {
	return MessageManager.getMessage('TOMS.COMMON.COMMA');
}

/**
 * 改行の区切り文字を取得する処理
 */
function getNewLine() {
	return MessageManager.getMessage('TOMS.COMMON.NEWLINE');
}

/**
 * 項目データ中に半角カーマがある場合、全角のカーマに変換する処理
 */
function transferComma(data) {
	if (data != null && data != "") {
		if (data instanceof String) {
			var comma = MessageManager.getMessage('TOMS.COMMON.COMMA');
			return data.replace(/,/g, MessageManager.getMessage('TOMS.COMMON.COMMA.JP'));
		} else {
			return data;
		}
	} else {
		return data;
	}
}


function error(message) {
  Transfer.toErrorPage({
    title: MessageManager.getMessage('TOMS.COMMON.ERROR.PAGE.TITLE'),
    message: MessageManager.getMessage('TOMS.COMMON.ERROR.MESSAGE.SYSTEM'),
    detail: [MessageManager.getMessage('TOMS.ACCOUNT.SEARCH.LABEL.MESSAGE.ERROR'), message],
    returnUrl: 'toms/account/search/input', // 戻り先 URL
    returnUrlLabel: MessageManager.getMessage('TOMS.ACCOUNT.SEARCH.LABEL.RETURN.LINK.NAME'),
    parameter: {
    }
  });
}


///**
// * validateアノテーションで指定したバリデーションを実行した結果、
// * エラーだった場合に呼び出される処理.
// * 
// * @param request リクエストパラメータ.
// * @param validationErrors バリデーションエラー.
// */
//function handleErrors(request, validationErrors) {
//  // なにも処理しない.
//}

