/**
* staticオブジェクトの作成 
 */ 
load('toms/common/cmnUtil');
 var _SHARED_DB_KEY ="toms-web-dev";
function ProcessDetailCode(){};

/**
 * 加工明細コード管理マスタメンテナンスの一覧データ取得処理
 */
ProcessDetailCode.getList= function(params, countFlag ,paramStart, paramEnd ) {

    var db = new SharedDatabase(_SHARED_DB_KEY);
    
    // 検索条件設定
    var mry57apcsc = isBlank(params.mry57apcsc) ? null : DbParameter.string(params.mry57apcsc);                                          // 親商品形態コード
    var mry57apcscName = isBlank(params.mry57apcscName) ? null : DbParameter.string("%" + params.mry57apcscName + "%");                  // 親商品形態名称
    var mry57acsc = isBlank(params.mry57acsc) ? null : DbParameter.string(params.mry57acsc);                                             // 商品形態コード
    var mry57acscName = isBlank(params.mry57acscName) ? null : DbParameter.string("%" + params.mry57acscName + "%");                     // 商品形態名称
    var mry57amtc = isBlank(params.mry57amtc) ? null : DbParameter.string(params.mry57amtc);                                             // 素材コード
    var mldl01 = isBlank(params.mldl01) ? null : DbParameter.string("%" + params.mldl01 + "%");                                          // 原材料名称
    var mry57appc1 = isBlank(params.mry57appc1) ? null : DbParameter.string(params.mry57appc1);                                          // 加工部位コード
    var mkdl01 = isBlank(params.mkdl01) ? null : DbParameter.string("%" + params.mkdl01 + "%");                                          // 加工部位名称
    var mry57appc2 = isBlank(params.mry57appc2) ? null : DbParameter.string(params.mry57appc2);                                          // 加工位置コード
    var mkdl02 = isBlank(params.mkdl02) ? null : DbParameter.string("%" + params.mkdl02 + "%");                                          // 加工位置名称
    // 加工方法区分
    var mry57apmt = null;
    if (!isBlank(params.mry57apmt)) {
        var aryData = params.mry57apmt.split(',');
        mry57apmt = [];
        for (var i = 0; i < aryData.length; i++) {
            mry57apmt.push(DbParameter.string(aryData[i]));
        }
    }
    // 加工方法明細区分
    var mry57apmdt = null;
    if (!isBlank(params.mry57apmdt)) {
        var aryData = params.mry57apmdt.split(',');
        mry57apmdt = [];
        for (var i = 0; i < aryData.length; i++) {
            mry57apmdt.push(DbParameter.string(aryData[i]));
        }
    }
    var mry57apmd1 = isBlank(params.mry57apmd1) ? null : DbParameter.string(params.mry57apmd1);                                          // 加工方法明細第1階層コード
    var mny57apmn1 = isBlank(params.mny57apmn1) ? null : DbParameter.string("%" + params.mny57apmn1 + "%");                              // 加工方法明細第1階層名称
    var mry57apmd2 = isBlank(params.mry57apmd2) ? null : DbParameter.string(params.mry57apmd2);                                          // 加工方法明細第2階層コード
    var mny57apmn2 = isBlank(params.mny57apmn2) ? null : DbParameter.string("%" + params.mny57apmn2 + "%");                              // 加工方法明細第2階層名称
    var mry57apmd3 = isBlank(params.mry57apmd3) ? null : DbParameter.string(params.mry57apmd3);                                          // 加工方法明細第3階層コード
    var mny57apmn3 = isBlank(params.mny57apmn3) ? null : DbParameter.string("%" + params.mny57apmn3 + "%");                              // 加工方法明細第3階層名称
    // 加工明細判定区分
    var mry57apdjt = null;
    if (!isBlank(params.mry57apdjt)) {
        var aryData = params.mry57apdjt.split(',');
        mry57apdjt = [];
        for (var i = 0; i < aryData.length; i++) {
            mry57apdjt.push(DbParameter.string(aryData[i]));
        }
    }
    var mruorg = isBlank(params.mruorg) ? null : DbParameter.string(params.mruorg);                                                      // 数量
    var mry57alsku = isBlank(params.mry57alsku) ? null : DbParameter.string(params.mry57alsku);                                          // 紐づけSKUコード
    var mry57alskuName = isBlank(params.mry57alskuName) ? null : DbParameter.string("%" + params.mry57alskuName + "%");                  // 紐づけSKU名称
    var mry57aoa = isBlank(params.mry57aoa) ? null : DbParameter.string(params.mry57aoa);                                                // 注文枚数
    var mry57adflg = isBlank(params.mry57adflg) ? null : DbParameter.number(Number(params.mry57adflg));                                  // 削除フラグ
    var mreftj_from = isBlank(params.mreftj_from) ? null : DbParameter.number(cmnUtil.convertDateToJulia(new Date(params.mreftj_from))); // 適用開始日From
    var mreftj_to = isBlank(params.mreftj_to) ? null : DbParameter.number(cmnUtil.convertDateToJulia(new Date(params.mreftj_to)));       // 適用開始日To
    
    var result;
    if (countFlag) {
        var objParam = {
            mry57apcsc : mry57apcsc,
            mry57apcscName : mry57apcscName,
            mry57acsc : mry57acsc,
            mry57acscName : mry57acscName,
            mry57amtc : mry57amtc,
            mldl01 : mldl01,
            mry57appc1 : mry57appc1,
            mkdl01 : mkdl01,
            mry57appc2 : mry57appc2,
            mkdl02 : mkdl02,
            mry57apmt : mry57apmt,
            mry57apmdt : mry57apmdt,
            mry57apmd1 : mry57apmd1,
            mny57apmn1 : mny57apmn1,
            mry57apmd2 : mry57apmd2,
            mny57apmn2 : mny57apmn2,
            mry57apmd3 : mry57apmd3,
            mny57apmn3 : mny57apmn3,
            mry57apdjt : mry57apdjt,
            mruorg : mruorg,
            mry57alsku : mry57alsku,
            mry57alskuName : mry57alskuName,
            mry57aoa : mry57aoa,
            mry57adflg : mry57adflg,
            mreftj_from : mreftj_from,
            mreftj_to : mreftj_to
        }
        
        result = db.executeByTemplate('toms/sql/getProcessDetailCodeListCount', objParam);
        
    } else {
        var start = isBlank(paramStart) ? null : DbParameter.number(paramStart);
        var end =  isBlank(paramEnd) ? null : DbParameter.number(paramEnd);
        var objParam = {
            mry57apcsc : mry57apcsc,
            mry57apcscName : mry57apcscName,
            mry57acsc : mry57acsc,
            mry57acscName : mry57acscName,
            mry57amtc : mry57amtc,
            mldl01 : mldl01,
            mry57appc1 : mry57appc1,
            mkdl01 : mkdl01,
            mry57appc2 : mry57appc2,
            mkdl02 : mkdl02,
            mry57apmt : mry57apmt,
            mry57apmdt : mry57apmdt,
            mry57apmd1 : mry57apmd1,
            mny57apmn1 : mny57apmn1,
            mry57apmd2 : mry57apmd2,
            mny57apmn2 : mny57apmn2,
            mry57apmd3 : mry57apmd3,
            mny57apmn3 : mny57apmn3,
            mry57apdjt : mry57apdjt,
            mruorg : mruorg,
            mry57alsku : mry57alsku,
            mry57alskuName : mry57alskuName,
            mry57aoa : mry57aoa,
            mry57adflg : mry57adflg,
            mreftj_from : mreftj_from,
            mreftj_to : mreftj_to,
            start : start,
            end : end
        }
        result = db.executeByTemplate('toms/sql/getProcessDetailCodeList', objParam);

    }
    return result;
}


