/**
 * 加工方法ヘッダ情報
 */
var $bind ={};
 var _SHARED_DB_KEY ="toms-web-dev";
 
 load("toms/common/cmnUtil");
 
 
function init(request){

	//加工方法コード
	var mmy57apmc = isBlank(request.mmy57apmc) ? "":DbParameter.string(request.mmy57apmc);
	var mmeftj = isBlank(request.mmeftj) ? "": DbParameter.number(cmnUtil.convertDateToJulia(new Date(request.mmeftj)))
	var result =null;
	if(!isBlank(mmy57apmc)){
		//加工方法ヘッダ情報取得
		var db = new SharedDatabase(_SHARED_DB_KEY);
		var objParam = {
			mmy57apmc : mmy57apmc,
// 適用開始日は考慮しない
//				mmy57apmc : mmy57apmc,
				mmeftj :mmeftj
		};

		result = db.executeByTemplate('toms/sql/getProcessMethodInfo', objParam);
		if(!result.error && result.countRow > 0){
			var ret = result.data[0];
			$bind.mmy57apmc = ret.mmy57apmc;// 加工方法コード
			$bind.mmy57apcsc = ret.mmy57apcsc;// 親商品形態コード
			$bind.mmy57apcscName = ret.mmy57apcscname;//親商品形態名称
			$bind.mmy57acsc = ret.mmy57acsc;//商品形態コード
			$bind.mmy57acscName = ret.mmy57acscname;//商品形態名称
			$bind.mmy57amtc = ret.mmy57amtc;//素材コード
			$bind.mmy57amtcName = ret.mmy57amtcname;//原材料名
			$bind.mmy57appc1 = ret.mmy57appc1;//加工部位コード
			$bind.mmy57appc1Name = ret.mmy57appc1name;//加工部位名称
			$bind.mmy57appc2 = ret.mmy57appc2;//加工位置コード
			$bind.mmy57appc2Name = ret.mmy57appc2name;//加工位置名称
			$bind.mmdl01 = ret.mmdl01;//加工方法名称
			$bind.mmy57apmt = ret.mmy57apmt;//加工方法区分
			$bind.mmy57apmdt = ret.mmy57apmdt;//加工方法明細区分
		}
	}
}