select
 a.pnptc,
 a.pnptd,
 a.rn,
 rownum
 from (
    select
     pnptc,
     pnptd,
     rownum as rn
    from
     f0014
    where
     1=1
    /*IF pnptc != null*/
     and pnptc like /*pnptc*/'%085%'
    /*END*/
    /*IF pnptd != null*/
     and pnptd like /*pnptd*/'%手形%'
    /*END*/
    order by
     pnptc ASC NULLS FIRST
) a
where
 rn  >=/*start*/0
 and rn <=/*end*/10