SELECT
    COUNT(*) AS ROWCOUNT
FROM
(
SELECT
  MKY57APPC1
  , MKY57APPC2
  , MKY57APCSC
  , MKY57ACSC
  , MKY57AMTC
  , MKDL01
  , MKDL02
  , MKY57ADOP1
  , MKY57ADOP2
  , MKY57AJCP1
  , MKY57AJCP2
  , MKEFTJ
  , MKEXDJ
  , MKY57ADFLG
  , MKURCD
  , MKURDT
  , MKURAT
  , MKURAB
  , MKURRF
  , MKUSER
  , MKPID
  , MKJOBN
  , MKUPMJ
  , MKUPMT 
FROM
  F57A5120 
/*BEGIN*/
WHERE
	/*IF mky57appc1 !=null */
  AND TRIM(MKY57APPC1) = /*mky57appc1*/''
	/*END*/
	/*IF mky57appc2 !=null */
  AND TRIM(MKY57APPC2) = /*mky57appc2*/''
	/*END*/
	/*IF mky57apcsc !=null */
  AND TRIM(MKY57APCSC) = /*mky57apcsc*/''
	/*END*/
	/*IF mky57acsc !=null */
  AND TRIM(MKY57ACSC) = /*mky57acsc*/''
	/*END*/
	/*IF mky57amtc !=null */
  AND TRIM(MKY57AMTC) = /*mky57amtc*/''
	/*END*/
	/*IF mkdl01 !=null */
  AND MKDL01 LIKE /*mkdl01*/''
	/*END*/
	/*IF mkdl02 !=null */
  AND MKDL02 LIKE /*mkdl02*/''
	/*END*/
	/*IF mky57adop1 !=null */
  AND TRIM(MKY57ADOP1) = /*mky57adop1*/''
	/*END*/
	/*IF mky57adop2 !=null */
  AND TRIM(MKY57ADOP2) = /*mky57adop2*/''
	/*END*/
	/*IF mky57ajcp1 !=null */
  AND TRIM(MKY57AJCP1) = /*mky57ajcp1*/''
	/*END*/
	/*IF mky57ajcp2 !=null */
  AND TRIM(MKY57AJCP2) = /*mky57ajcp2*/''
	/*END*/

	/*IF mkeftj !=null */
  AND MKEFTJ >= /*mkeftj*/''
	/*END*/
	/*IF mkeftj2 !=null */
  AND MKEFTJ <= /*mkeftj2*/''
	/*END*/
	/*IF mky57adflg !=null */
  AND MKY57ADFLG = /*mky57adflg*/''
	/*END*/
/*END*/
ORDER BY
  MKY57APPC1
  , MKY57APPC2
  , MKY57APCSC
  , MKY57ACSC
  , MKY57AMTC
  , MKEFTJ DESC
)
