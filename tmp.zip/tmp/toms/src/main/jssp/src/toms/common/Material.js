/**
* staticオブジェクトの作成 
 */ 
load('toms/common/cmnUtil');
 var _SHARED_DB_KEY ="toms-web-dev";
function Material(){};

/**
 * 親商品形態の一覧取得処理
 * 
 * @code 商品形態コード
 * @name 商品形態名称
 * @contFlag 件数取得フラグ　true：条件に紐づく件数を返却、false：条件に紐づく一覧を返却
 * @start  取得のレコード開始
 * @end  取得のレコード終了
 * 
 * 
 */
Material.searchCommodityData= function(code, name, countFlag ,start, end ){

	var database = new SharedDatabase(_SHARED_DB_KEY);
	var paramCode = null;
	var paramName = null;
	var paramStart = null;
	var paramEnd = null;

	if (!isBlank(code)) {
		paramCode = DbParameter.string(code);
	}
	if (!isBlank(name)) {
		paramName = DbParameter.string("%" + name + "%");
	}

	var result;
	if(countFlag){
		//件数取得
		var params = {
		              paramCode : paramCode,
		              paramName : paramName
		}
		result = database.executeByTemplate('toms/sql/searchMaterialCount', params);
	}else{
		//データ取得
		if (!isBlank(start)) {
			paramStart = DbParameter.number(start);
		}
		if (!isBlank(end)) {
			paramEnd = DbParameter.number(end);
		}
		
		var params = {
		              paramCode : paramCode,
		              paramName : paramName,
		              start : paramStart,
		              end : paramEnd
		}	
		result = database.executeByTemplate('toms/sql/searchMaterial', params);
	}
	return result;
};
/**
 * 素材マスタメンテナンスの一覧データ取得処理
 */
Material.getMaterialList= function(params, countFlag ,paramStart, paramEnd ){

	var db = new SharedDatabase(_SHARED_DB_KEY);
	var mly57amtc = isBlank(params.mly57amtc) ? null : DbParameter.string(params.mly57amtc);//素材コード
	var mldl01 = isBlank(params.mldl01) ? null : DbParameter.string("%"+params.mldl01+"%");//原材料名
	var mly57acsc = isBlank(params.mly57acsc) ? null : DbParameter.string(params.mly57acsc);//商品形態コード
	var mly57apcsc = isBlank(params.mly57apcsc) ? null : DbParameter.string(params.mly57apcsc) ;//親商品形態コード
	var mlpct1 = isBlank(params.mlpct1) ? null : DbParameter.number(Number(params.mlpct1));//パーセント
	var mly57ajdc = isBlank(params.mly57ajdc) ? null : DbParameter.string(params.mly57ajdc);//JDEコード
	var mly57adflg = isBlank(params.mly57adflg) ? null : DbParameter.number(Number(params.mly57adflg));//削除フラグ
	var mly57amflg = isBlank(params.mly57amflg) ? null : DbParameter.number(Number(params.mly57amflg));//たたみ袋制御フラグ
	var mly57absc = isBlank(params.mly57absc) ? null : DbParameter.string(params.mly57absc) ;//たたみ袋SKUコード
	var mleftj = isBlank(params.mleftj) ? null : DbParameter.number(cmnUtil.convertDateToJulia(new Date(params.mleftj))); //提供開始日
	var mleftj2 = isBlank(params.mleftj2) ? null : DbParameter.number(cmnUtil.convertDateToJulia(new Date(params.mleftj2))); //提供開始日
//	var mlexdj = isBlank(params.mlexdj) ? null : DbParameter.number(cmnUtil.convertDateToJulia(new Date(params.mlexdj))); //適用終了日
	
	var result;
	if(countFlag){
		var objParam = {
			mly57amtc : mly57amtc,
        	mldl01 : mldl01,
        	mly57acsc : mly57acsc,
        	mly57apcsc : mly57apcsc,
        	mlpct1 : mlpct1,
        	mly57ajdc : mly57ajdc,
        	mly57adflg : mly57adflg,
        	mly57amflg : mly57amflg,
        	mly57absc : mly57absc,
        	mleftj : mleftj,
        	mleftj2 : mleftj2
        	//mlexdj : mlexdj
		}

		result = db.executeByTemplate('toms/sql/getMaterialListCount', objParam);
		
	}else{
		var start = isBlank(paramStart) ? null : DbParameter.number(paramStart);
		var end =  isBlank(paramEnd) ? null : DbParameter.number(paramEnd);
		var objParam = {
			mly57amtc : mly57amtc,
        	mldl01 : mldl01,
        	mly57acsc : mly57acsc,
        	mly57apcsc : mly57apcsc,
        	mlpct1 : mlpct1,
        	mly57ajdc : mly57ajdc,
        	mly57adflg : mly57adflg,
        	mly57amflg : mly57amflg,
        	mly57absc : mly57absc,
    		mleftj : mleftj,
    		mleftj2 : mleftj2,
    		//mlexdj : mlexdj,
    		start : start,
    		end : end
		}
		result = db.executeByTemplate('toms/sql/getMaterialList', objParam);

	}
	return result;
}

/**
 * 品目検索の一覧取得処理
 * 
 * @code 品目コード
 * @name1 記述
 * @name2 記述2
 * @contFlag 件数取得フラグ　true：条件に紐づく件数を返却、false：条件に紐づく一覧を返却
 * @start  取得のレコード開始
 * @end  取得のレコード終了
 * 
 * 
 */
Material.searchSkuData= function(code, name1, name2,countFlag ,start, end ){

	var database = new SharedDatabase(_SHARED_DB_KEY);
	var paramCode = null;
	var paramName1 = null;
	var paramName2 = null;
	var paramStart = null;
	var paramEnd = null;

	if (!isBlank(code)) {
		paramCode = DbParameter.string(code);
	}
	if (!isBlank(name1)) {
		paramName1 = DbParameter.string("%" + name1 + "%");
	}
	if (!isBlank(name2)) {
		paramName2 = DbParameter.string("%" + name2 + "%");
	}

	var result;
	if(countFlag){
		//件数取得
		var params = {
		              imlitm : paramCode,
		              imdsc1 : paramName1,
		              imdsc2 : paramName2
		}
		result = database.executeByTemplate('toms/sql/searchSkuCount', params);
	}else{
		//データ取得
		if (!isBlank(start)) {
			paramStart = DbParameter.number(start);
		}
		if (!isBlank(end)) {
			paramEnd = DbParameter.number(end);
		}
		
		var params = {
		              imlitm : paramCode,
		              imdsc1 : paramName1,
		              imdsc2 : paramName2,
		              start : paramStart,
		              end : paramEnd
		}	
		result = database.executeByTemplate('toms/sql/searchSku', params);
	}
	return result;
};

/* 素材検索ポップアップ */

Material.searchMaterialData = function(materialCode,materialName, commodityCode, commodityName,parentCode, parentName, countFlag ,start, end ){
	
	var db = new SharedDatabase(_SHARED_DB_KEY);
	var mCode = null;
	var mName = null;
	var cCode = null;
	var cName = null;
	var pCode = null;
	var pName = null;
	var paramStart = null;
	var paramEnd = null;	

	if (!isBlank(materialCode)) {
		mCode = DbParameter.string(materialCode);
	}
	if (!isBlank(materialName)) {
		mName = DbParameter.string("%" + materialName + "%");
	}

	if (!isBlank(commodityCode)) {
		cCode = DbParameter.string(commodityCode);
	}
	if (!isBlank(commodityName)) {
		cName = DbParameter.string("%" + commodityName + "%");
	}

	if (!isBlank(parentCode)) {
		pCode = DbParameter.string(parentCode);
	}
	if (!isBlank(parentName)) {
		pName = DbParameter.string("%" + parentName + "%");
	}
	
	var result;
	if(countFlag){
		//件数取得
		var params = {
			mly57amtc : mCode,
			mldl01 : mName,
			mjy57acsc : cCode,
			mjdl01 : cName,
			mjy57apcsc : pCode,
			mjdl01p : pName
		}
		result = db.executeByTemplate('toms/sql/searchMaterialCount', params);
	}else{
		//データ取得
		if (!isBlank(start)) {
			paramStart = DbParameter.number(start);
		}
		if (!isBlank(end)) {
			paramEnd = DbParameter.number(end);
		}
		
		var params = {
			mly57amtc : mCode,
			mldl01 : mName,
			mjy57acsc : cCode,
			mjdl01 : cName,
			mjy57apcsc : pCode,
			mjdl01p : pName,
			start : paramStart,
		    end : paramEnd
		}	
		result = db.executeByTemplate('toms/sql/searchMaterial', params);
	}
	return result;
};

