SELECT
    COUNT(*) AS ROWCOUNT
FROM
(
SELECT
  MMY57APMC
  , MMY57APCSC
  , MMY57ACSC
  , MMY57AMTC
  , MMY57APPC1
  , MMY57APPC2
  , MMY57ADA
  , MMY57ASRT
  , MMY57APMT
  , MMY57APMDT
  , MMEFTJ
  , MMEXDJ
  , MMY57ADFLG
  , MMURCD
  , MMURDT
  , MMURAT
  , MMURAB
  , MMURRF
  , MMUSER
  , MMPID
  , MMJOBN
  , MMUPMJ
  , MMUPMT
  , MMDL01 
FROM
  F57A5140 
	/*BEGIN*/
		WHERE
		/*IF mmy57apmc !=null */
		  AND TRIM(MMY57APMC) = /*mmy57apmc*/
		/*END*/
		/*IF mmy57apcsc !=null */
		  AND TRIM(MMY57APCSC) = /*mmy57apcsc*/
		/*END*/
		/*IF mmy57acsc !=null */
		  AND TRIM(MMY57ACSC) = /*mmy57acsc*/
		/*END*/
		/*IF mmy57amtc !=null */
		  AND TRIM(MMY57AMTC) = /*mmy57amtc*/
		/*END*/
		/*IF mmy57appc1 !=null */
		  AND TRIM(MMY57APPC1) = /*mmy57appc1*/
		/*END*/
		/*IF mmy57appc2 !=null */
		  AND TRIM(MMY57APPC2) = /*mmy57appc2*/
		/*END*/
		/*IF mmy57ada !=null */
		  AND MMY57ADA = /*mmy57ada*/
		/*END*/
		/*IF mmy57asrt !=null */
		  AND TRIM(MMY57ASRT) = /*mmy57asrt*/
		/*END*/
	    /*IF mmy57apmt != null */
	    AND TRIM(MMY57APMT) IN /*mmy57apmt*/('101', '102')
	    /*END*/
		/*IF mmy57apmdt !=null */
		  AND TRIM(MMY57APMDT) = /*mmy57apmdt*/
		/*END*/
		/*IF mmeftj !=null */
		  AND MMEFTJ >= /*mmeftj*/
		/*END*/
		/*IF mmeftj2 !=null */
		  AND MMEFTJ <= /*mmeftj2*/
		/*END*/
		/*IF mmdl01 !=null */
		  AND TRIM(MMDL01) LIKE /*mmdl01*/
		/*END*/
		/*IF mmy57adflg !=null */
		  AND MMY57ADFLG = /*mmy57adflg*/
		/*END*/
	/*END*/
	ORDER BY
	  MMY57APCSC
	  , MMY57ACSC
	  , MMY57AMTC
	  , MMY57APPC1
	  , MMY57APPC2
	  , MMY57APMT
	  , MMY57APMDT
	  , MMEFTJ DESC

)
