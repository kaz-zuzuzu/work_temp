
function init(request) {
	load("toms/common/master");
	
	var response = Web.getHTTPResponse();
	response.setContentType('application/json; charset=utf-8');
	
    var resultObject = getStockStorePositionList(request.stockPositionCode);
    if (resultObject.error) {
        // 処理が失敗した場合
        response.sendMessageBodyString(
            ImJson.toJSONString({
                error: resultObject.error,
                errorMessage: resultObject.message,
                detailMessages: ['管理者にお問い合わせください', '連絡先：admin@xxx.xxx.xxx']
            })
        );
    }

    // 処理が成功した場合
    response.sendMessageBodyString(
        ImJson.toJSONString({
            error: false,
            parameter:{
            	stockPosition: resultObject.data
            }
        })
    );	
	
}



function getStockStorePositionList(stockPositionCode) {
	return TomsMaster.getStockStorePositionList(stockPositionCode);
}