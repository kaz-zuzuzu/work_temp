var $data;

/**
 * 初期表示
 * @param request リクエストパラメータ
 */
    
function init(request) {
    $data = ImJson.toJSONString(getList(request)); 
}

function getList(request) {
    // 表示条件を設定（表示ページ、件数など）
    let page = request.page == undefined ? 1 : request.page;
    let rows = request.rowNum == undefined ? 30 : Module.number.toInt(request.rowNum);
    
    // 検索条件の状況に応じて条件を設定する
    var param = request.extension;
    if (!param || !param.searchCondition) {
        return  {
                        page  : page,
                        total : rows,
                        data  : []
                    };
    }
    
    // 検索条件の設定
    var mqy57apcsc = isBlank(param.searchCondition.mqy57apcsc) ? null : param.searchCondition.mqy57apcsc;             // 親商品形態コード
    var mqy57apcscName = isBlank(param.searchCondition.mqy57apcscName) ? null : param.searchCondition.mqy57apcscName; // 親商品形態名称
    var mqy57acsc = isBlank(param.searchCondition.mqy57acsc) ? null : param.searchCondition.mqy57acsc;                // 商品形態コード
    var mqy57acscName = isBlank(param.searchCondition.mqy57acscName) ? null : param.searchCondition.mqy57acscName;    // 商品形態名称
    var mqy57amtc = isBlank(param.searchCondition.mqy57amtc) ? null : param.searchCondition.mqy57amtc;                // 素材コード
    var mldl01 = isBlank(param.searchCondition.mldl01) ? null : param.searchCondition.mldl01;                         // 原材料名称
    var mqy57appc1 = isBlank(param.searchCondition.mqy57appc1) ? null : param.searchCondition.mqy57appc1;             // 加工部位コード
    var mkdl01 = isBlank(param.searchCondition.mkdl01) ? null : param.searchCondition.mkdl01;                         // 加工部位名称
    var mqy57appc2 = isBlank(param.searchCondition.mqy57appc2) ? null : param.searchCondition.mqy57appc2;             // 加工位置コード
    var mkdl02 = isBlank(param.searchCondition.mkdl02) ? null : param.searchCondition.mkdl02;                         // 加工位置名称
    var mqy57apmt = isBlank(param.searchCondition.mqy57apmt) ? null : param.searchCondition.mqy57apmt;                // 加工方法区分
    var mqy57apmdt = isBlank(param.searchCondition.mqy57apmdt) ? null : param.searchCondition.mqy57apmdt;             // 加工方法明細区分
    var mqy57apmd1 = isBlank(param.searchCondition.mqy57apmd1) ? null : param.searchCondition.mqy57apmd1;             // 加工方法明細第1階層コード
    var mny57apmn1 = isBlank(param.searchCondition.mny57apmn1) ? null : param.searchCondition.mny57apmn1;             // 加工方法明細第1階層名称
    var mqy57apmd2 = isBlank(param.searchCondition.mqy57apmd2) ? null : param.searchCondition.mqy57apmd2;             // 加工方法明細第2階層コード
    var mny57apmn2 = isBlank(param.searchCondition.mny57apmn2) ? null : param.searchCondition.mny57apmn2;             // 加工方法明細第2階層名称
    var mqy57apmd3 = isBlank(param.searchCondition.mqy57apmd3) ? null : param.searchCondition.mqy57apmd3;             // 加工方法明細第3階層コード
    var mny57apmn3 = isBlank(param.searchCondition.mny57apmn3) ? null : param.searchCondition.mny57apmn3;             // 加工方法明細第3階層名称
    var mqy57aitcd = isBlank(param.searchCondition.mqy57aitcd) ? null : param.searchCondition.mqy57aitcd;             // 商品コード
    var mqy57aitcdName = isBlank(param.searchCondition.mqy57aitcdName) ? null : param.searchCondition.mqy57aitcdName; // 商品名称
    var mqy57asc = isBlank(param.searchCondition.mqy57asc) ? null : param.searchCondition.mqy57asc;                   // サイズコード
    var mqy57ascName = isBlank(param.searchCondition.mqy57ascName) ? null : param.searchCondition.mqy57ascName;       // サイズ名称
    var mqy57anrt = isBlank(param.searchCondition.mqy57anrt) ? null : param.searchCondition.mqy57anrt;                // 非推奨区分
    var mqy57adflg = isBlank(param.searchCondition.mqy57adflg) ? null : param.searchCondition.mqy57adflg;             // 削除フラグ
    var mqeftj_from = isBlank(param.searchCondition.mqeftj_from) ? null : param.searchCondition.mqeftj_from;          // 適用開始日From
    var mqeftj_to = isBlank(param.searchCondition.mqeftj_to) ? null : param.searchCondition.mqeftj_to;                // 適用開始日To
    
    var objParams = {
        mqy57apcsc : mqy57apcsc,
        mqy57apcscName : mqy57apcscName,
        mqy57acsc : mqy57acsc,
        mqy57acscName : mqy57acscName,
        mqy57amtc : mqy57amtc,
        mldl01 : mldl01,
        mqy57appc1 : mqy57appc1,
        mkdl01 : mkdl01,
        mqy57appc2 : mqy57appc2,
        mkdl02 : mkdl02,
        mqy57apmt : mqy57apmt,
        mqy57apmdt : mqy57apmdt,
        mqy57apmd1 : mqy57apmd1,
        mny57apmn1 : mny57apmn1,
        mqy57apmd2 : mqy57apmd2,
        mny57apmn2 : mny57apmn2,
        mqy57apmd3 : mqy57apmd3,
        mny57apmn3 : mny57apmn3,
        mqy57aitcd : mqy57aitcd,
        mqy57aitcdName : mqy57aitcdName,
        mqy57asc : mqy57asc,
        mqy57ascName : mqy57ascName,
        mqy57anrt : mqy57anrt,
        mqy57adflg : mqy57adflg,
        mqeftj_from : mqeftj_from,
        mqeftj_to : mqeftj_to
    }
    // ボディ非推奨管理マスタの件数取得
    var resultCount = getBodyNotRecommendedListCount(objParams);
    // 全体の件数を設定（件数の母数）
    var listCount = 0;
    if (!resultCount.error) {
        listCount = resultCount.data[0]['rowcount'];
    } else {
        Debug.write(resultCount.errorMessage);
    }
    
    // ページ番号設定:リクエストパラメータのページ番号、最大ページ番号のうち小さい方の番号を設定
    page = Math.min(page, Math.ceil(listCount / rows)); 
    
    // 指定範囲の会社情報を取得
    var start = rows * (page - 1) + 1;
    var end = start + rows - 1;
    
    // ボディ非推奨管理マスタの一覧取得
    var result = getBodyNotRecommendedList(objParams, start, end);
    var resultData = [];
    if (!result.error) {
        resultData = result.data;
    } else {
        Debug.write(result.errorMessage);
    }
    
    var json = {
        page  : page,
        total : listCount,
        data  : resultData
    };
    
    return json;
}

/**
 * ボディ非推奨管理マスタ一覧件数取得
 */    
function getBodyNotRecommendedListCount(objParams) {
    load("toms/common/bodyNotRecommended");
    var result = BodyNotRecommended.getBodyNotRecommendedList(objParams, true, null, null);
    
    return result;
}

/**
 * ボディ非推奨管理マスタ一覧データ取得
 */
function getBodyNotRecommendedList(objParams, start , end) {
    load("toms/common/bodyNotRecommended");
    var result = BodyNotRecommended.getBodyNotRecommendedList(objParams, false, start, end);
    
    return result;
}

/**
 * 検索結果一覧のページオブジェクト生成
 */
function createResult(page, total, data) {
    return {
        page : page == null ? 1 : page,
        total : total == null ? 0 : total,
        data : data == null ? [] : data
    };
}

/**
 * エラーオブジェクト生成
 */
function createErrorResult(message, details){
    return {
        error : true,
        errorMessage : message,
        detailMessages : details
    };
}
