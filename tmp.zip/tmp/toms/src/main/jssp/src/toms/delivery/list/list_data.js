var $data;

/**
 * 初期表示
 * @param request リクエストパラメータ
 */
function init(request) {
	$data = ImJson.toJSONString(getList(request));
}

function getList(request) {

	// 表示条件を設定（表示ページ、件数など）
	let page = request.page == undefined ? 1 : request.page;
	let rows = request.rowNum == undefined ? 15 : Module.number.toInt(request.rowNum);

	var searchObj = request.extension.searchCondition;

    var superOrganization = searchObj.superOrganization;
	var organization = searchObj.organization;
	var stockPositionList = searchObj.stockPositionList;
	var instructNo = searchObj.instructNo;
	var receiveOrderNo = searchObj.receiveOrderNo;
	var orderTypeList = searchObj.orderTypeList;
	var destination = searchObj.destination;
	var exchangeTarget = searchObj.exchangeTarget;
	var deliveryDateFrom = searchObj.deliveryDateFrom;
	var deliveryDateTo = searchObj.deliveryDateTo;

    load("toms/common/delivery");
    
    // 件数取得
    var result = Delivery.getDeliveryItemListCount(stockPositionList, organization, 
                                          receiveOrderNo, orderTypeList, instructNo, destination, exchangeTarget,
                                          deliveryDateFrom, deliveryDateTo);
                                          // 全体の件数を設定（件数の母数）
    if(result.error){
    	return createErrorResult(MessageManager.getMessage('TOMS.DELIVERY.LIST.LABEL.MESSAGE.ERROR'),'');
    }
    let total = result.data[0].rowcount;
    if(total == 0){
    	return createResult(1, 0 ,null);
    }
    page = Math.min(page, Math.ceil(total / rows));
    let start = (rows * (page -1) + 1);
    let end = start + rows - 1;

	result = null;
	result = Delivery.getDeliveryItemList(stockPositionList, organization, 
                                 receiveOrderNo, orderTypeList, instructNo, destination, exchangeTarget,
                                 deliveryDateFrom, deliveryDateTo, start, end);

	if (result.error) {
		return createErrorResult(MessageManager.getMessage('TOMS.DELIVERY.LIST.LABEL.MESSAGE.ERROR'),'');
	}
	var json = {
		page  : page,
		total : total,
		data  : result.data
	};
	
	return json;
}

function createResult(page, total, data){
	return {
		page : page == null ? 1 : page,
		total : total == null ? 0 : total,
		data : data == null ? [] : data
	}
}


/**
 * エラーオブジェクト生成
 */
function createErrorResult(message, details){
	return {
		error : true,
		errorMessage : message,
		detailMessages : details

	}
}
