var $data;

/**
 * 初期表示
 * @param request リクエストパラメータ
 */
function init(request) {
	$data = ImJson.toJSONString(getList(request));
}

function getList(request) {
	// 表示条件を設定（表示ページ、件数など）
	let page = request.page == undefined ? 1 : request.page;
	let rows = request.rowNum == undefined ? 30 : Module.number.toInt(request.rowNum);

	// 検索条件の状況に応じて条件を設定する
	var param = request.extension;
	if (!param || !param.searchCondition) {
    	return  {
                		page  : page,
                		total : rows,
                		data  : []
    				};
    	}
	var malitm = param.searchCondition.malitm;
	var maan8 = param.searchCondition.maan8;
	var macpgp = param.searchCondition.macpgp;
	var maeftj = param.searchCondition.maeftj;
	
	// 該当する会社情報の件数取得
	let resultCount = getSalesListCount(malitm, maan8, macpgp, maeftj);
	// 全体の件数を設定（件数の母数）
	var listCount = 0;
	if (!resultCount.error) {
		listCount = resultCount.data[0]['rowcount'];
	} else {
		Debug.write(resultCount.errorMessage);
	}

	// ページ番号設定:リクエストパラメータのページ番号、最大ページ番号のうち小さい方の番号を設定
	page = Math.min(page, Math.ceil(listCount / rows)); 
	
	// 指定範囲の会社情報を取得
	let start = rows * (page - 1) + 1;
	let end = start + rows - 1;

	var result = getSalesList(malitm, maan8, macpgp, maeftj, start, end);
	var rsltData = [];
	if (!result.error) {
		rsltData = result.data;
	} else {
		Debug.write(result.errorMessage);
	}

	var json = {
		page  : page,
		total : listCount,
		data  : rsltData
	};
	return json;
}


function getSalesList(malitm, maan8, macpgp, maeftj, start, end) {
    load("toms/common/master");
    var result = TomsMaster.getSalesList(malitm, maan8, macpgp, maeftj, start, end, false);
	return result;
}

function getSalesListCount(malitm, maan8, macpgp, maeftj) {
    load("toms/common/master");
    var result = TomsMaster.getSalesList(malitm, maan8, macpgp, maeftj, null, null, true);
	return result;
}

