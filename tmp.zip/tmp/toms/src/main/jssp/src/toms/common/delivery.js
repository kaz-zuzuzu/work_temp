/**
* staticオブジェクトの作成 
 */ 

function Delivery(){}

	
/**
 * 出庫一覧件数取得
 */

Delivery.getDeliveryItemListCount = function(stockPositionList,  organization, 
	                                          receiveOrderNo, orderTypeList, instructNo, destination, exchangeTarget,
	                                          deliveryDateFrom, deliveryDateTo) {
	var database = new SharedDatabase("toms-web-dev");
	var paraStockPositionList = null;
	var paraSuperOrganization = null;
	var paraOrganization = null;
	var paraReceiveOrderNo = null;
	var paraOrderTypeList = null;
	var paraInstructNo = null;
	var paraDestination = null;
	var paraExchangeTarget = null;
	var paradeliveryDateFrom = null;
	var paradeliveryDateTo = null;

	if (stockPositionList != null && stockPositionList != ""){
		paraStockPositionList = DbParameter.string(stockPositionList);
	}
	if (organization != null && organization != "" && organization != " "){
		var paramTemporganization = organization.split(',');

		paraOrganization = [paramTemporganization.length];
		for (var i = 0; i < paramTemporganization.length; i++) {
			paraOrganization[i] = DbParameter.string(paramTemporganization[i]);
		}

	}
	if (receiveOrderNo != null && receiveOrderNo != ""){
		paraReceiveOrderNo = DbParameter.string(receiveOrderNo);
	}
	if (orderTypeList != null && orderTypeList != ""){
		var aryOrderType = orderTypeList.split(',');
		paraOrderTypeList = [aryOrderType.length];
		for(i=0; i<aryOrderType.length; i++){
			paraOrderTypeList[i] = DbParameter.string(aryOrderType[i]);
		}
	}
	if (instructNo != null && instructNo != ""){
		paraInstructNo = DbParameter.string(instructNo);
	}
	if (destination != null && destination != ""){
		paraDestination = DbParameter.string("%" + destination + "%");
	}
	if (exchangeTarget != null && exchangeTarget != ""){
		paraExchangeTarget = DbParameter.string("%" + exchangeTarget + "%");
	}
	if (deliveryDateFrom != null && deliveryDateFrom != ""){
		paradeliveryDateFrom = DbParameter.string(deliveryDateFrom);
	}
	if (deliveryDateTo != null && deliveryDateTo != ""){
		paradeliveryDateTo = DbParameter.string(deliveryDateTo);
	}
	
	var params = {stockPositionList : paraStockPositionList, 
                  organization : paraOrganization,
	              receiveOrderNo : paraReceiveOrderNo,
	              orderTypeList : paraOrderTypeList,
	              instructNo : paraInstructNo,
	              destination : paraDestination,
	              exchangeTarget : paraExchangeTarget,
	              deliveryDateFrom : paradeliveryDateFrom,
	              deliveryDateTo : paradeliveryDateTo
	             };
	
	var result = database.executeByTemplate('resources/toms/delivery/search/getDeliveryItemListCount', params);
	return result;
}

/**
 * 出庫一覧取得
 */
Delivery.getDeliveryItemList = function(stockPositionList, organization, 
	                                          receiveOrderNo, orderTypeList, instructNo, destination, exchangeTarget,
	                                          deliveryDateFrom, deliveryDateTo, start, end) {

	var database = new SharedDatabase("toms-web-dev");
	var paraStockPositionList = null;
	var paraSuperOrganization = null;
	var paraOrganization = null;
	var paraReceiveOrderNo = null;
	var paraOrderTypeList = null;
	var paraInstructNo = null;
	var paraDestination = null;
	var paraExchangeTarget = null;
	var paradeliveryDateFrom = null;
	var paradeliveryDateTo = null;
	var paraStart = null;
	var paraEnd = null;
	
	if (stockPositionList != null && stockPositionList != ""){
		paraStockPositionList = DbParameter.string(stockPositionList);
	}
	if (organization != null && organization != "" && organization != " "){
		var paramTemporganization = organization.split(',');
		paraOrganization = [paramTemporganization.length];
		for (var i = 0; i < paramTemporganization.length; i++) {
			paraOrganization[i] = DbParameter.string(paramTemporganization[i]);
		}
	}
	if (receiveOrderNo != null && receiveOrderNo != ""){
		paraReceiveOrderNo = DbParameter.string(receiveOrderNo);
	}
	if (orderTypeList != null && orderTypeList != ""){
		var aryOrderType = orderTypeList.split(',');
		paraOrderTypeList = [aryOrderType.length];
		for(var i=0; i<aryOrderType.length; i++){
			paraOrderTypeList[i] = DbParameter.string(aryOrderType[i]);
		}
	}
	if (instructNo != null && instructNo != ""){
		paraInstructNo = DbParameter.string(instructNo);
	}
	if (destination != null && destination != ""){
		paraDestination = DbParameter.string("%" + destination + "%");
	}
	if (exchangeTarget != null && exchangeTarget != ""){
		paraExchangeTarget = DbParameter.string("%" + exchangeTarget + "%");
	}
	if (deliveryDateFrom != null && deliveryDateFrom != ""){
		paradeliveryDateFrom = DbParameter.string(deliveryDateFrom);
	}
	if (deliveryDateTo != null && deliveryDateTo != ""){
		paradeliveryDateTo = DbParameter.string(deliveryDateTo);
	}
	
	if (start != null && start != "") {
		paraStart = DbParameter.number(start);
	}
	if (end != null && end != "") {
		paraEnd = DbParameter.number(end);
	}

	var params = {stockPositionList : paraStockPositionList,
                  organization : paraOrganization,
	              receiveOrderNo : paraReceiveOrderNo,
	              orderTypeList : paraOrderTypeList,
	              instructNo : paraInstructNo,
	              destination : paraDestination,
	              exchangeTarget : paraExchangeTarget,
	              deliveryDateFrom : paradeliveryDateFrom,
	              deliveryDateTo : paradeliveryDateTo,
	              start : paraStart,
	              end :paraEnd
	             };
	             
	var result = database.executeByTemplate('resources/toms/delivery/search/getDeliveryItemList', params);
	return result;
}

/**
 * 出庫詳細ヘッダ情報取得処理
 * @param instructNo 出荷予定No
 * @param denpyoType 伝票タイプ
 * 
 */
Delivery.getHeaderInfo = function(instructNo, denpyoType){
	var db = new SharedDatabase("toms-web-dev");
	var paramInstructNo = isBlank(instructNo) ? null: DbParameter.number(parseInt(instructNo));
	var paramDenpyoType = isBlank(denpyoType) ? null: DbParameter.string(denpyoType);
	var params ={
	             instructNo : paramInstructNo,
	             denpyoType : paramDenpyoType
	};
	var path ="toms/sql/delivery/getDeliveryDetailHeaderInfo";
	var result = db.executeByTemplate(path, params);
	return result;
	
}

/**
 * 出庫詳細リスト取得処理
 */

Delivery.getDeliveryDetailList =function(instructNo, denpyoType){

	var db = new SharedDatabase("toms-web-dev");
	var paramInstructNo = isBlank(instructNo) ? null: DbParameter.number(parseInt(instructNo));
	var paramDenpyoType = isBlank(denpyoType) ? null: DbParameter.string(denpyoType);
	var params ={
	             instructNo : paramInstructNo,
	             denpyoType : paramDenpyoType
	};

	var path ="toms/sql/delivery/getDeliveryDetailListInfo";
	var result = db.executeByTemplate(path, params);
	return result;
}


/**
 * 出庫照会詳細画面用
 */ 
Delivery.getDeliveryItemData = function(instructNo) {
	
//	var database = new SharedDatabase("toms-web-dev");
//	var paramInstructNo= DbParameter.string(instructNo);
//	
//	var params =  {
//					instructNo   : paramInstructNo
//                  }
//
//    var result = database.executeByTemplate('resources/toms/delivery/search/getDeriveryItemList', params);
//	
//	return result;
}






/**
 * 在庫場所取得
 */
Delivery.getStockPositionList = function(){
	var database = new SharedDatabase("toms-web-dev");
	var result = database.executeByTemplate('resources/toms/common/search/delivery/getStockPosition');
	return result;
}

/**
 * オーダータイプの取得
 */

Delivery.getOrderTypeList = function(){
	var database = new SharedDatabase("toms-web-dev");
	var result = database.executeByTemplate('resources/toms/delivery/search/getOrderType');
	return result;
}