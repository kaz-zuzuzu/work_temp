/**
 * 特記事項更新処理群
 * 
 * toms\src\main\jssp\src\toms\items\detail\update_data.js
 * 
 */
load('toms/common/common');
load('toms/common/cmnUtil');

function init(request) {
	load("toms/common/master");
	
	var entity = createEntity(request);
	var msg;
	
	var condition = "MGAN8 = ? " +
					" AND TRIM(MGY57ASPCD) = ? " +
                	" AND MGRNO = ? ";
    //検索キーの特記事項メモ行をセット
    //　新規の場合はrequest.mgrno,更新・削除時はrequest.old_mgrno
    
    var key_mgrno = isBlank(request.old_mgrno) ? entity['mgrno'] : request.old_mgrno;
	var params = [
				   DbParameter.number(entity['mgan8']),
				   DbParameter.string(entity['mgy57aspcd']),
				   DbParameter.number(Number(key_mgrno))
	             ];
	//------------------------------------
	//新規登録時
	//  重複チェック
	//    SELECTエラー
	//    count != 0
	//  insertエラー
	//
	//------------------------------------
	if (request.oprateFlag == "1") {
		//登録時に登録済みか確認する
		var result = dbCheck(condition, params);
		if(result.error){
            // SELECTが失敗した場合
        	msg = MessageManager.getMessage('TOMS.COMMON.MAINTENANCE.AJAX.ERROR.INSERT.MESSAGE', MessageManager.getMessage('TOMS.MASTER.MAINTENANCE.ITEMS.LIST.INPUT.FILENAME'));
        	common.sendErrorResult(msg, "");
		}
		if(result.data[0].cnt !=0){
			// 既に登録済みの場合
        	msg = MessageManager.getMessage('TOMS.COMMON.MAINTENANCE.AJAX.ERROR.INSERT.MESSAGE', MessageManager.getMessage('TOMS.MASTER.MAINTENANCE.ITEMS.LIST.INPUT.FILENAME'));
        	common.sendErrorResult(msg, MessageManager.getMessage('TOMS.COMMON.MAINTENANCE.AJAX.ERROR.INSERT.NOTNEWDATA.MESSAGE'));
		}
		//登録実行
        result = entry(entity);
         var msg;
        if (result.error) {
            // 処理が失敗した場合
        	msg = MessageManager.getMessage('TOMS.COMMON.MAINTENANCE.AJAX.ERROR.INSERT.MESSAGE', MessageManager.getMessage('TOMS.MASTER.MAINTENANCE.ITEMS.LIST.INPUT.FILENAME'));
        	common.sendErrorResult(msg, "");
        }
        // 処理が成功した場合
        msg = MessageManager.getMessage('TOMS.COMMON.MAINTENANCE.AJAX.SUCCESS.INSERT.MESSAGE', MessageManager.getMessage('TOMS.MASTER.MAINTENANCE.ITEMS.LIST.INPUT.FILENAME'));
        common.sendResult(msg,{organization: result.data});
	//------------------------------------
	//更新時
	//------------------------------------
	} else if (request.oprateFlag == "2") {
		var result = update(entity, condition, params);
        var msg;
        if (result.error) {
            // 処理が失敗した場合
        	msg = MessageManager.getMessage('TOMS.COMMON.MAINTENANCE.AJAX.ERROR.UPDATE.MESSAGE', MessageManager.getMessage('TOMS.MASTER.MAINTENANCE.ITEMS.LIST.INPUT.FILENAME'));
        	common.sendErrorResult(msg, "");
        }
        if (result.countRow != 1) {
            // 対象データが存在しない場合
        	msg = MessageManager.getMessage('TOMS.COMMON.MAINTENANCE.AJAX.ERROR.UPDATE.MESSAGE', MessageManager.getMessage('TOMS.MASTER.MAINTENANCE.ITEMS.LIST.INPUT.FILENAME'));
        	common.sendErrorResult(msg, MessageManager.getMessage('TOMS.COMMON.MAINTENANCE.AJAX.ERROR.UPDATE.NODATA.MESSAGE'));
        }
        // 処理が成功した場合
        msg = MessageManager.getMessage('TOMS.COMMON.MAINTENANCE.AJAX.SUCCESS.UPDATE.MESSAGE', MessageManager.getMessage('TOMS.MASTER.MAINTENANCE.ITEMS.LIST.INPUT.FILENAME'));
        common.sendResult(msg,{organization: result.data});
	//------------------------------------
	//削除時
	//------------------------------------
	} else if (request.oprateFlag == "3") {
		var result = remove(condition, params);
        var msg;
        if (result.error) {
            // 処理が失敗した場合
        	msg = MessageManager.getMessage('TOMS.COMMON.MAINTENANCE.AJAX.ERROR.DELETE.MESSAGE', MessageManager.getMessage('TOMS.MASTER.MAINTENANCE.ITEMS.LIST.INPUT.FILENAME'));
        	common.sendErrorResult(msg, "");
        }
        if(result.countRow != 1){
	    	// 処理件数が１件でない場合
        	msg = MessageManager.getMessage('TOMS.COMMON.MAINTENANCE.AJAX.ERROR.DELETE.MESSAGE', MessageManager.getMessage('TOMS.MASTER.MAINTENANCE.ITEMS.LIST.INPUT.FILENAME'));
        	common.sendErrorResult(msg, MessageManager.getMessage('TOMS.COMMON.MAINTENANCE.AJAX.ERROR.UPDATE.NODATA.MESSAGE'));
	    }
        // 処理が成功した場合
        msg = MessageManager.getMessage('TOMS.COMMON.MAINTENANCE.AJAX.SUCCESS.DELETE.MESSAGE', MessageManager.getMessage('TOMS.MASTER.MAINTENANCE.ITEMS.LIST.INPUT.FILENAME'));
        common.sendResult(msg,{organization: result.data});

	}
}

function dbCheck(condition, params){
	return TomsMaster.selectFromF57A5070(condition,params);
}

function entry(entity) {
	return TomsMaster.insertToF57A5070(entity);
}

function update(entity, condition, params) {
	return TomsMaster.updateToF57A5070(entity, condition, params);
}
function remove(condition, params) {
	return TomsMaster.removeFromF57A5070(condition, params);
}
/**
 * 更新データのオブジェクト生成
 */
function createEntity(request) {
	var userContext = Contexts.getUserContext();
	var now = new Date();
	
    // 数字のデータ型
	var mgan8 = null;
	var mgrno = null;
	var mgupmj = cmnUtil.convertDateToJulia(now);
	var mgupmt = cmnUtil.getTime(now);

	// 文字列のデータ型
	var mgy57aspcd = null;
    var mgds01 = null;
    var mguser = userContext.userProfile.userCd;
    var mgpid = MessageManager.getMessage('TOMS.COMMON.CONSTANT.PROGRAM.ID');
    
    // 数字設定
    if (cmnUtil.getData(request.mgan8, 1) != "")  {
    	mgan8 = cmnUtil.getData(request.mgan8, 1);
    }
    if (cmnUtil.getData(request.mgrno, 1) != "")  {
    	mgrno = cmnUtil.getData(request.mgrno, 1);
    }

	if (cmnUtil.getData(request.mgy57aspcd, 0) != "")  {
		mgy57aspcd = cmnUtil.getData(request.mgy57aspcd, 0);
    }
	if (cmnUtil.getData(request.mgds01, 0) != "")  {
		mgds01 = cmnUtil.getData(request.mgds01, 0);
    }
    var entity = {
            		mgan8 : mgan8,
                    mgy57aspcd : mgy57aspcd,
                    mgrno : mgrno,
                    mgds01 : mgds01,
                    mguser : mguser,
                    mgpid : mgpid,
                    mgupmj : mgupmj,
                    mgupmt : mgupmt
            };
    return entity;
}

