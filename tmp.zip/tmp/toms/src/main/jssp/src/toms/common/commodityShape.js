/**
* staticオブジェクトの作成 
 */ 
load('toms/common/cmnUtil');
 var _SHARED_DB_KEY ="toms-web-dev";
function CommodityShape(){};

/**
 * 商品形態の検索一覧取得処理
 * 
 * @param code1 商品形態コード
 * @param name1 商品形態名称
 * @param code2 親商品形態コード
 * @parem name2  親商品形態名称
 * @param contFlag 件数取得フラグ　true：条件に紐づく件数を返却、false：条件に紐づく一覧を返却
 * @param start  取得のレコード開始
 * @param end  取得のレコード終了
 * 
 * 
 */
CommodityShape.searchCommodityData= function(code1, name1,code2,name2, countFlag ,start, end ){

	var database = new SharedDatabase(_SHARED_DB_KEY);
	var pCode1 = isBlank(code1) ? null :DbParameter.string(code1);
	var pName1 = isBlank(name1) ? null :DbParameter.string("%"+name1+"%");
	var pCode2 = isBlank(code2) ? null :DbParameter.string(code2);
	var pName2 = isBlank(name2) ? null :DbParameter.string("%"+name2+"%");

	var paramStart = isBlank(start) ? null :DbParameter.number(start);
	var paramEnd = isBlank(end) ? null :DbParameter.number(end);
	var sql=";"
	var paramArray =[];
	var result;
	if(countFlag){
		//件数取得
		var params = {
			pCode1 : pCode1,
			pName1 : pName1,
			pCode2 : pCode2,
			pName2 : pName2 
		};
		
//		//件数取得SQL
//        sql = " SELECT ";
//        sql +="	    COUNT(*) AS ROWCOUNT ";
//        sql +="  FROM  ( ";
//        sql +="    select MJ.KO_MJY57ACSC AS KO_MJY57ACSC ";
//        sql +="      ,MJ.KO_MJDL01 AS MJDL01 ";
//        sql +="      ,MJ.OYA_MJY57ACSC AS MJY57APCSC ";
//        sql +="      ,MJ.OYA_MJDL01 AS MJDL01P ";
//        sql +="      from ( ";
//        sql +="        select oya.MJY57ACSC as oya_MJY57ACSC ";
//        sql +="              ,oya.MJDL01    as oya_MJDL01 ";
//        sql +="              ,ko.MJY57ACSC  as ko_MJY57ACSC ";
//        sql +="              ,ko.MJDL01     as ko_MJDL01 ";
//        sql +="              ,FC_JDI9902_TO_DATE(oya.MJEFTJ) as oya_MJEFTJ ";
//        sql +="              ,FC_JDI9902_TO_DATE(ko.MJEFTJ)  as ko_MJEFTJ ";
//        sql +="              ,dense_rank() over (partition by oya.MJY57ACSC order by oya.MJEFTJ desc) oya_rnk ";
//        sql +="              ,dense_rank() over (partition by ko.MJY57ACSC order by ko.MJEFTJ desc) ko_rnk ";
//        sql +="	          from F57A5110 oya ";
//        sql +="	               left outer join F57A5110 ko ";
//        sql +="	                  on oya.MJY57ACSC = ko.MJY57APCSC ";
//        sql +="	                 and ko.MJEFTJ    <= FC_JDI9902_TO_JULIAN(sysdate) ";
//        sql +="	         where oya.MJY57ACSC = oya.MJY57APCSC ";
//        sql +="	           and oya.MJEFTJ <= FC_JDI9902_TO_JULIAN(sysdate) ";
//        sql +="               ) MJ ";
//        sql +="         where MJ.OYA_RNK = 1 ";
//        sql +="           and MJ.KO_RNK  = 1 ";
//        sql +="           and MJ.KO_MJY57ACSC <> MJ.OYA_MJY57ACSC ";
//        if(!isBlank(pCode1)){
//            sql +="           AND TRIM(MJ.KO_MJY57ACSC) = ? ";
//            paramArray.push(pCode1);
//        }
//        if(!isBlank(pName1)){
//            sql +="           AND MJ.KO_MJDL01 like ? ";
//            paramArray.push(pName1);
//        }
//        if(!isBlank(pCode2)){
//            sql +="            AND TRIM(MJ.OYA_MJY57ACSC) = ? ";
//            paramArray.push(pCode2);
//        }
//        if(!isBlank(pName2)){
//            sql +="           AND MJ.OYA_MJDL01 like ? ";
//            paramArray.push(pName2);
//        }
//        sql +="  ) ";
//
//        result = database.execute(sql, paramArray);
		result = database.executeByTemplate('toms/sql/searchCommodityShapeCount', params);

	}else{
		//データ取得
		var params = {
			pCode1 : pCode1,
			pName1 : pName1,
			pCode2 : pCode2,
			pName2 : pName2 ,
    		start : paramStart,
    		end : paramEnd
		};
		
//		//データ取得SQL
//        sql = " SELECT ";
//        sql +="	    COUNT(*) AS ROWCOUNT ";
//        sql +="  FROM  ( ";
//        sql +="    select MJ.KO_MJY57ACSC AS KO_MJY57ACSC ";
//        sql +="      ,MJ.KO_MJDL01 AS MJDL01 ";
//        sql +="      ,MJ.OYA_MJY57ACSC AS MJY57APCSC ";
//        sql +="      ,MJ.OYA_MJDL01 AS MJDL01P ";
//        sql +="      from ( ";
//        sql +="        select oya.MJY57ACSC as oya_MJY57ACSC ";
//        sql +="              ,oya.MJDL01    as oya_MJDL01 ";
//        sql +="              ,ko.MJY57ACSC  as ko_MJY57ACSC ";
//        sql +="              ,ko.MJDL01     as ko_MJDL01 ";
//        sql +="              ,FC_JDI9902_TO_DATE(oya.MJEFTJ) as oya_MJEFTJ ";
//        sql +="              ,FC_JDI9902_TO_DATE(ko.MJEFTJ)  as ko_MJEFTJ ";
//        sql +="              ,dense_rank() over (partition by oya.MJY57ACSC order by oya.MJEFTJ desc) oya_rnk ";
//        sql +="              ,dense_rank() over (partition by ko.MJY57ACSC order by ko.MJEFTJ desc) ko_rnk ";
//        sql +="	          from F57A5110 oya ";
//        sql +="	               left outer join F57A5110 ko ";
//        sql +="	                  on oya.MJY57ACSC = ko.MJY57APCSC ";
//        sql +="	                 and ko.MJEFTJ    <= FC_JDI9902_TO_JULIAN(sysdate) ";
//        sql +="	         where oya.MJY57ACSC = oya.MJY57APCSC ";
//        sql +="	           and oya.MJEFTJ <= FC_JDI9902_TO_JULIAN(sysdate) ";
//        sql +="               ) MJ ";
//        sql +="         where MJ.OYA_RNK = 1 ";
//        sql +="           and MJ.KO_RNK  = 1 ";
//        sql +="           and MJ.KO_MJY57ACSC <> MJ.OYA_MJY57ACSC ";
//        if(!isBlank(pCode1)){
//            sql +="           AND TRIM(MJ.KO_MJY57ACSC) = ? ";
//            paramArray.push(pCode1);
//        }
//        if(!isBlank(pName1)){
//            sql +="           AND MJ.KO_MJDL01 like ? ";
//            paramArray.push(pName1);
//        }
//        if(!isBlank(pCode2)){
//            sql +="            AND TRIM(MJ.OYA_MJY57ACSC) = ? ";
//            paramArray.push(pCode2);
//        }
//        if(!isBlank(pName2)){
//            sql +="           AND MJ.OYA_MJDL01 like ? ";
//            paramArray.push(pName2);
//        }
//        sql +="  ) ";
//
//        //result = database.execute(sql, paramArray);		


		result = database.executeByTemplate('toms/sql/searchCommodityShape', params);

	}
	return result;
};

	/**
 * 親商品形態の一覧取得処理
 * 
 * @param code 商品形態コード
 * @param name 商品形態名称
 * @param contFlag 件数取得フラグ　true：条件に紐づく件数を返却、false：条件に紐づく一覧を返却
 * @param start  取得のレコード開始
 * @param end  取得のレコード終了
 * 
 * 
 */
CommodityShape.searchParentCommodityData= function(code, name, countFlag ,start, end ){

	var database = new SharedDatabase(_SHARED_DB_KEY);
	var paramCode = null;
	var paramName = null;
	var paramStart = null;
	var paramEnd = null;

	if (!isBlank(code)) {
		paramCode = DbParameter.string(code);
	}
	if (!isBlank(name)) {
		paramName = DbParameter.string("%" + name + "%");
	}

	var result;
	if(countFlag){
		//件数取得
		var params = {
		              paramCode : paramCode,
		              paramName : paramName
		}
		result = database.executeByTemplate('toms/sql/searchParentCommodityShapeCount', params);
	}else{
		//データ取得
		if (!isBlank(start)) {
			paramStart = DbParameter.number(start);
		}
		if (!isBlank(end)) {
			paramEnd = DbParameter.number(end);
		}
		
		var params = {
		              paramCode : paramCode,
		              paramName : paramName,
		              start : paramStart,
		              end : paramEnd
		}	
		result = database.executeByTemplate('toms/sql/searchParentCommodityShape', params);
	}
	return result;
};
/**
 * 商品形態マスタメンテナンスの一覧データ取得処理
 */
CommodityShape.getCommodityList= function(params, countFlag ,paramStart, paramEnd ){

	var db = new SharedDatabase(_SHARED_DB_KEY);

	var mjy57acsc = isBlank(params.mjy57acsc) ? null :DbParameter.string(params.mjy57acsc) ;
	var mjy57apcsc = isBlank(params.mjy57apcsc) ? null : DbParameter.string(params.mjy57apcsc);
	var mjdl01 = isBlank(params.mjdl01) ? null : DbParameter.string("%"+params.mjdl01+"%");
	var mjy57ajdc = isBlank(params.mjy57ajdc) ? null : DbParameter.string(params.mjy57ajdc);
	var mjy57adflg = isBlank(params.mjy57adflg) ? null :DbParameter.number(Number(params.mjy57adflg)) ;
	var mjeftj = isBlank(params.mjeftj) ? null : DbParameter.string(cmnUtil.convertDateToJulia(new Date(params.mjeftj))+"");
	var mjeftj2 = isBlank(params.mjeftj2) ? null : DbParameter.string(cmnUtil.convertDateToJulia(new Date(params.mjeftj2))+"");
//	var mjexdj = isBlank(params.mjexdj) ? null : DbParameter.string(cmnUtil.convertDateToJulia(new Date(params.mjexdj))+"");
	
	var result;
	if(countFlag){
		var objParam = {
			mjy57acsc : mjy57acsc,
    		mjy57apcsc : mjy57apcsc,
    		mjdl01 : mjdl01,
    		mjy57ajdc : mjy57ajdc,
    		mjy57adflg : mjy57adflg,
    		mjeftj : mjeftj,
    		mjeftj2 : mjeftj2
//    		mjexdj : mjexdj
		}
		result = db.executeByTemplate('toms/sql/getCommodityListCount', objParam);
		
	}else{
		var start = isBlank(paramStart) ? null : DbParameter.number(paramStart);
		var end =  isBlank(paramEnd) ? null : DbParameter.number(paramEnd);
		var objParam = {
			mjy57acsc : mjy57acsc,
    		mjy57apcsc : mjy57apcsc,
    		mjdl01 : mjdl01,
    		mjy57ajdc : mjy57ajdc,
    		mjy57adflg : mjy57adflg,
    		mjeftj : mjeftj,
    		mjeftj2 : mjeftj2,
//    		mjexdj : mjexdj,
    		start : start,
    		end : end
		}
		result = db.executeByTemplate('toms/sql/getCommodityList', objParam);
	}
	return result;
}

