/**
 * 商品形態マスタメンテナンス一覧
 *
 **/

 var $bind ={};
 
 var $data={};
 load("toms/common/common");
 

/**
 * 初期表示
 * @param request リクエストパラメータ
 */
function init(request){
	
	$bind.dialogMessages="";

	$data = {
		pageNum : isBlank(request.pageNum) ? '1' : request.pageNum,
		rowNum  : isBlank(request.rowNum) ? '30' : request.rowNum,
		rowList : isBlank(request.rowList) ? '30, 50, 100' : request.rowList
	};

	$bind.mjy57acsc = isBlank(request.search_mjy57acsc) ? "":request.search_mjy57acsc;
	$bind.mjy57apcsc = isBlank(request.search_mjy57apcsc) ? "":request.search_mjy57apcsc;
	$bind.mjdl01 = isBlank(request.search_mjdl01) ? "":request.search_mjdl01;
	$bind.mjy57ajdc = isBlank(request.search_mjy57ajdc) ? "":request.search_mjy57ajdc;
	$bind.mjy57adflg = isBlank(request.search_mjy57adflg) ? "" :request.search_mjy57adflg;
	
	$bind.checked1=true;

	$bind.mjeftj = isBlank(request.search_mjeftj) ? "":request.search_mjeftj;
	$bind.mjeftj2 = isBlank(request.search_mjeftj2) ? "":request.search_mjeftj2;
	$bind.mjexdj = isBlank(request.search_mjexdj) ? "":request.search_mjexdj;
	
	
	//ダウンロード用検索条件
	var csvObj;
	if (request.csvFlag == "1") {
		csvObj ={
//			mjy57acsc: isBlank(request.hidden-csvMjy57acsc) ? "":request.hidden-csvMjy57acsc,
//			mjy57apcsc: isBlank(request.hidden-csvMjy57apcsc) ? "":request.hidden-csvMjy57apcsc,
//			mjdl01: isBlank(request.hidden-csvMjdl01) ? "":request.hidden-csvMjdl01,
//			mjy57ajdc: isBlank(request.hidden-csvMjy57ajdc) ? "":request.hidden-csvMjy57ajdc,
//			mjy57adflg: isBlank(request.hidden-csvMjy57adflg) ? "":request.hidden-csvMjy57adflg,
//			mjeftj: isBlank(request.hidden-csvMjeftj) ? "":request.hidden-csvMjeftj,
//			mjexdj: isBlank(request.hidden-csvMjexdj) ? "":request.hidden-csvMjexdj
			mjy57acsc: isBlank(request.mjy57acsc) ? "":request.mjy57acsc,
			mjy57apcsc: isBlank(request.mjy57apcsc) ? "":request.mjy57apcsc,
			mjdl01: isBlank(request.mjdl01) ? "":request.mjdl01,
			mjy57ajdc: isBlank(request.mjy57ajdc) ? "":request.mjy57ajdc,
			mjy57adflg: isBlank(request.mjy57adflg) ? "":request.mjy57adflg,
			mjeftj: isBlank(request.mjeftj) ? "":request.mjeftj,
			mjeftj2: isBlank(request.mjeftj2) ? "":request.mjeftj2,
			mjexdj: isBlank(request.mjexdj) ? "":request.mjexdj
		};
		//ダウンロード出力処理呼び出し
		outputCSV(csvObj);
	}
	
	//画面項目
	$bind.select_notdelete=MessageManager.getMessage('TOMS.COMMON.DELETE.SELECT.NOTDELETE');
	$bind.select_delete=MessageManager.getMessage('TOMS.COMMON.DELETE.SELECT.DELETE');
	$bind.select_all=MessageManager.getMessage('TOMS.COMMON.DELETE.SELECT.ALL');


  $bind.dialogMessages = ({
    addConfirmTitle: MessageManager.getMessage('TOMS.COMMON.DIALOG.CONFIRM.TITLE'),
    addConfirmMessage: MessageManager.getMessage('TOMS.COMMON.DIALOG.CONFIRM.MESSAGE')
  }).toSource();

}

/**
 * 商品形態マスタメンテナンスのCSV出力処理
 * 
 * @param　リクエストパラメータ
 * 
 */
function outputCSV(param){
    load("toms/common/commodityShape");
	var result = CommodityShape.getCommodityList(param, false, null,null);

	var outputContent = "";
	if (!result.error) {
		outputContent = outputCSVHeader();
    	for(var i = 0; i < result.countRow; i++) {
    		outputContent += outputCSVRow(result.data[i]);
    	}
    	var strDate = DateTimeFormatter.format("yyyyMMdd_HHmmss", new Date());
    	var strUserName = Contexts.getUserContext().userProfile.userName;
    	var fileName = MessageManager.getMessage('TOMS.MASTER.MAINTENANCE.COMMODITYSHAPE.DETAIL.INPUT.TITLE') + '_' + strDate + '_' + strUserName + '.csv';
    	Module.download.send(Unicode.to(outputContent, 'MS932'), fileName, MessageManager.getMessage('TOMS.COMMON.MIME.CSV'));
	} else {
		error(result.errorMessage);
	}
}

/**
 * 商品形態マスタメンテナンスのCSVヘッダ部分出力処理。
 */
function outputCSVHeader() {
	var outputHeader = common.convert(MessageManager.getMessage('TOMS.COMMON.CSV.UPDATE.DIVIDE'), true)
	  + common.convert(MessageManager.getMessage('TOMS.MASTER.MAINTENANCE.COMMODITYSHAPE.LABEL.COMMODITY_SHAPE_CODE'), true)
	  + common.convert(MessageManager.getMessage('TOMS.MASTER.MAINTENANCE.COMMODITYSHAPE.LABEL.PARENT_COMMODITY_SHAPE_CODE'), true)
	  + common.convert(MessageManager.getMessage('TOMS.MASTER.MAINTENANCE.COMMODITYSHAPE.LABEL.COMMODITY_SHAPE_NAME'), true)
	  + common.convert(MessageManager.getMessage('TOMS.MASTER.MAINTENANCE.COMMODITYSHAPE.LABEL.DISPLAY_ORDER'), true)
//	  + common.convert(MessageManager.getMessage('TOMS.MASTER.MAINTENANCE.COMMODITYSHAPE.LABEL.JDE_TYPE'), true)
//	  + common.convert(MessageManager.getMessage('TOMS.MASTER.MAINTENANCE.COMMODITYSHAPE.LABEL.JDE_CODE'), true)
	  + common.convert(MessageManager.getMessage('TOMS.MASTER.MAINTENANCE.COMMODITYSHAPE.LABEL.APPLIED_START_DATE'), true)
//	  + common.convert(MessageManager.getMessage('TOMS.MASTER.MAINTENANCE.COMMODITYSHAPE.LABEL.APPLIED_END_DATE'), true)
	  + common.convert(MessageManager.getMessage('TOMS.MASTER.MAINTENANCE.COMMODITYSHAPE.LABEL.DELETE_FLG'), false);
//	  + common.convert(MessageManager.getMessage('TOMS.MASTER.MAINTENANCE.LIST.INPUT.USER'), true)
//	  + common.convert(MessageManager.getMessage('TOMS.MASTER.MAINTENANCE.LIST.INPUT.PID'), true)
//	  + common.convert(MessageManager.getMessage('TOMS.MASTER.MAINTENANCE.LIST.INPUT.UPMJ'), true)
//	  + common.convert(MessageManager.getMessage('TOMS.MASTER.MAINTENANCE.LIST.INPUT.UPMT'), false);
return outputHeader;

}

/**
 * 商品形態マスタメンテナンスのCSVファイルの行を出力する処理
 * 
 * @param record DBから検索した行のデータ
 */
function outputCSVRow(record) {
	var result =  MessageManager.getMessage('TOMS.COMMON.CSV.SPLIT')
		    + common.convert(record["mjy57acsc"], true)
			+ common.convert(record["mjy57apcsc"], true)
			+ common.convert(record["mjdl01"], true)
			+ common.convert(record["mjsnn"], true)
//			+ common.convert(record["mjy57ajdt"], true)
//			+ common.convert(record["mjy57ajdc"], true)
			+ common.convert(record["mjeftj"], true)
//			+ common.convert(record["mjexdj"], true)
			+ common.convert(record["mjy57adflg"]+"", false);
//			+ common.convert(record["mjuser"], true)
//			+ common.convert(record["mjpid"], true)
//			+ common.convert(record["mjupmj"], true)
//			+ common.convert(record["mjupmt"], false);

	return result;
	
}

function error(message) {
  Transfer.toErrorPage({
    title: MessageManager.getMessage('TOMS.COMMON.ERROR.PAGE.TITLE'),
    message: MessageManager.getMessage('TOMS.COMMON.ERROR.MESSAGE.SYSTEM'),
    detail: [MessageManager.getMessage('TOMS.MASTER.MAINTENANCE.COMMODITYSHAPE.LIST.LABEL.MESSAGE.ERROR'), message],
    returnUrl: 'toms/commodity_shape/list/input', // 戻り先 URL
    returnUrlLabel: MessageManager.getMessage('TOMS.MASTER.MAINTENANCE.COMMODITYSHAPE.LIST.LABEL.RETURN.LINK.NAME'),
    parameter: {
    }
  });
}