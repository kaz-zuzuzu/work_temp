/**
 * 素材マスタメンテナンスvalidation設定
 */

 var init={
	 'mky57appc1':{//加工部位コード
	 	caption:'TOMS.MASTER.MAINTENANCE.PROCESSPART.LABEL.PROCESSPART_CODE',
	 	required: true, //必須チェック
	 	alphanumeric: true,
		maxlength: 16
		},
		 'mky57appc2':{//加工位置コード
		 	caption:'TOMS.MASTER.MAINTENANCE.PROCESSPART.LABEL.PROCESSPART_POSITION_CODE',
		 	required: true, //必須チェック
		 	alphanumeric: true,
			maxlength: 16
	 		},
		 'mky57apcsc':{//親商品形態コード
		 	caption:'TOMS.MASTER.MAINTENANCE.COMMODITYSHAPE.LABEL.PARENT_COMMODITY_SHAPE_CODE',
		 	required: true, //必須チェック
		 	alphanumeric: true,
			maxlength: 16
	 		},
		 'mky57acsc':{//商品形態コード
		 	caption:'TOMS.MASTER.MAINTENANCE.COMMODITYSHAPE.LABEL.COMMODITY_SHAPE_CODE',
		 	required: true, //必須チェック
		 	alphanumeric: true,
			maxlength: 16
	 		},	
		 'mky57amtc':{//素材コード
		 	caption:'TOMS.MASTER.MAINTENANCE.MATERIAL.LABEL.MATERIAL_CODE',
		 	required: true, //必須チェック
		 	alphanumeric: true,
			maxlength: 16
	 		},
		'mkdl01':{//加工部位名称
	 	caption:'TOMS.MASTER.MAINTENANCE.PROCESSPART.LABEL.PROCESSPART_NAME',
	 	required: true, //必須チェック
		maxlength: 30
		},	
		'mkdl02':{//加工位置名称
	 	caption:'TOMS.MASTER.MAINTENANCE.PROCESSPART.LABEL.PROCESSPART_POSITION_NAME',
	 	//required: true, //必須チェック
		maxlength: 30
		},	
		 'mky57adop1':{//表示順_部位
	 	caption:'TOMS.MASTER.MAINTENANCE.PROCESSPART.LABEL.PROCESSPART_DISPLAY_PART',
	 	numeric: true,
		maxlength: 8
		},	 		
		 'mky57adop2':{//表示順_位置
	 	caption:'TOMS.MASTER.MAINTENANCE.PROCESSPART.LABEL.PROCESSPART_DISPLAY_POSITION',
	 	numeric: true,
		maxlength: 8
		},	 		
//		 //JDEコード_部位
//		 'mky57ajcp1':{
//	 	caption:'TOMS.MASTER.MAINTENANCE.PROCESSPART.LABEL.PROCESSPART_JDECODE_PART',
//	 	required: true, //必須チェック
//	 	alphanumeric: true,
//		maxlength: 8
//		},	 		
//		 //JDEコード_位置
//		 'mky57ajcp2':{
//	 	caption:'TOMS.MASTER.MAINTENANCE.PROCESSPART.LABEL.PROCESSPART_JDECODE_POSITION',
//		 required: true, //必須チェック
//		 alphanumeric: true,
//		 maxlength: 8
//		},	 		
		//有効開始日 
	 	'mkeftj':{
	 	caption:'TOMS.MASTER.MAINTENANCE.COMMODITYSHAPE.LABEL.APPLIED_START_DATE',
	 	required: true, //必須チェック
		date: true,
	    maxlength: 10
	 	}
 	}