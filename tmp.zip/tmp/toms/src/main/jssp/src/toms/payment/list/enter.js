/**
 * バインド変数.
 */
var $bind = {};

/**
 * 初期表示.
 * @param request リクエストパラメータ.
 */
function init(request) {

	load("toms/common/csv/CsvUtil");
	load("toms/common/csv/CsvCheker");
	load("toms/common/cmnUtil");
	
    var response = Web.getHTTPResponse();
    response.setContentType('text/plain; charset=utf-8');
    var csv = []; // csv二次元配列
    var stErr = new java.lang.StringBuilder(); // エラー文言
    var updateCount = { newCount:0, updateCount:0, deleteCount:0};

    // ファイルロード csv二次元ファイル化
    if(!CsvUtil.load2Csv(request, csv, stErr)) {
    	doError(response, stErr);
	    return;
	}

	// チェック
	if(!check(csv, stErr)) {
		doError(response, stErr);
		return;
	}

	// DBによるチェック
	if(!dbCheck(csv, stErr)) {
		doError(response, stErr);
		return;
	}

	// DB更新
	if(!dbUpdate(csv, stErr, updateCount)) {
		doError(response, stErr);
		return;
	}

	// 正常値の返却
	stErr.append(MessageManager.getMessage('TOMS.PAYMENT.LIST.LABEL.MESSAGE.ENTRY.SUCCESS2'));
	stErr.append(MessageManager.getMessage('TOMS.PAYMENT.LIST.LABEL.MESSAGE.NUMBEROFINSERT', String(updateCount.newCount)));
	stErr.append(MessageManager.getMessage('TOMS.PAYMENT.LIST.LABEL.MESSAGE.NUMBEROFEDIT', String(updateCount.updateCount)));
	stErr.append(MessageManager.getMessage('TOMS.PAYMENT.LIST.LABEL.MESSAGE.NUMBEROFDELETE', String(updateCount.deleteCount)));
	var st = stErr.toString();
    response.sendMessageBodyString(ImJson.toJSONString([{
        "message": st,
        "isError": "false"
    }]));
}

/**
 * チェック
 * @param csv csv二次元配列.(IN)
 * @param stErr エラーメッセージパラメータ.(OUT)
 */
function check(csv, stErr) {

	var rowLength = csv.length;	//行数	
	var ret = true;

	// CSVデータ無し
	if(rowLength < 2) {
	//		stErr.append("<p>" + MessageManager.getMessage('TOMS.PAYMENT.DETAIL.LIST.MESSAGE.CSV.DATANOTEXIST') + "</p>");
	//"<p>" + csvファイルにデータがありません。</p>
		stErr.append(MessageManager.getMessage('TOMS.PAYMENT.DETAIL.LIST.MESSAGE.CSV.DATANOTEXIST'));//OK
		return false;
	}

	for(var rowPos=1; rowPos<rowLength; rowPos++) {
		var row = csv[rowPos];
		var sRowPos = String(rowPos);

		// 列数チェック
//		if(row.length != 16) {
//			stErr.append("<p>" + rowPos + "行目は" + row.length + MessageManager.getMessage('TOMS.PAYMENT.LIST.LABEL.MESSAGE.ROWNUMBER') + "</p>");
			//"<p>" + {0}行目は{1}列になっています。</p>
//			stErr.append(MessageManager.getMessage('TOMS.PAYMENT.LIST.LABEL.MESSAGE.ROWNUMBER',sRowPos, String(row.length)));//OK
//			ret = false;
//			continue;
//		}
		// 列数チェック
		var colCnt = 17;    // 列数
		if(row.length != colCnt) {
			if(row.length > colCnt){
				stErr.append(MessageManager.getMessage('TOMS.MASTER.MAINTENANCE.PAYMENT.LIST.LABEL.MESSAGE.ERROR.COLUMN1',sRowPos));//OK
			} else if(row.length < colCnt){
				stErr.append(MessageManager.getMessage('TOMS.MASTER.MAINTENANCE.PAYMENT.LIST.LABEL.MESSAGE.ERROR.COLUMN2',sRowPos));//OK
			}
//			stErr.append("<p>" + rowPos + "行目は" + row.length + MessageManager.getMessage('TOMS.PAYMENT.LIST.LABEL.MESSAGE.ROWNUMBER') + "</p>");
			//"<p>" + {0}行目は{1}列になっています。</p>
//			stErr.append(MessageManager.getMessage('TOMS.PAYMENT.LIST.LABEL.MESSAGE.ROWNUMBER',sRowPos, String(row.length)));//OK
			ret = false;
			continue;
		}

		// 登録区分　0
		if(row[0] != "I" && row[0] != "U" && row[0] != "D" ) {
//			stErr.append("<p>" + rowPos + MessageManager.getMessage('TOMS.PAYMENT.LIST.LABEL.MESSAGE.ENTRYDIVISION') + "</p>");
			//"<p>" + "{0}行目 1列　登録区分にはIかUかDを設定して下さい。</p>
//			stErr.append(MessageManager.getMessage('TOMS.PAYMENT.LIST.LABEL.MESSAGE.ENTRYDIVISION', sRowPos)); //OK
			stErr.append(MessageManager.getMessage('TOMS.PAYMENT.LIST.LABEL.MESSAGE.ENTRYDIVISION', sRowPos)); //OK
			ret = false;
		}

		// 支払人No 1
			// 必須
			//CsvCheker
			if(!CsvCheker.required(row[1], rowPos, 1, MessageManager.getMessage('TOMS.PAYMENT.LIST.LABEL.MAPYR'), stErr)) {
				ret = false;
			}
			// 文字数
			if(!CsvCheker.maxLength(row[1], 8, rowPos, 1, MessageManager.getMessage('TOMS.PAYMENT.LIST.LABEL.MAPYR'), stErr)) {
				ret = false;
			}
			// 数値
			if(!CsvCheker.isNum(row[1], rowPos, 1, MessageManager.getMessage('TOMS.PAYMENT.LIST.LABEL.MAPYR'), stErr)) {
				ret = false;
			}

		// 削除の場合 支払人No(keyのみ必要)
		if(row[0] == "D") {
			continue;
		}

		// 通貨コード 2
			// 必須
			if(!CsvCheker.required(row[2], rowPos, 2, MessageManager.getMessage('TOMS.PAYMENT.LIST.LABEL.MACRCD'), stErr)) {
				ret = false;
			}
			// 文字数
			if(!CsvCheker.maxLength(row[2], 3, rowPos, 2, MessageManager.getMessage('TOMS.PAYMENT.LIST.LABEL.MACRCD'), stErr)) {
				ret = false;
			}

		// 閾値（円） 3
			// 必須
			if(!CsvCheker.required(row[3], rowPos, 3, MessageManager.getMessage('TOMS.PAYMENT.LIST.LABEL.MAY56CATHR'), stErr)) {
				ret = false;
			}
			// 数値長さ
			if(!CsvCheker.isDigits(row[3], 15, 2, rowPos, 3, MessageManager.getMessage('TOMS.PAYMENT.LIST.LABEL.MAY56CATHR'), stErr)) {
				ret = false;
			}
			// 数値
			if(!CsvCheker.isNum(row[3], rowPos, 3, MessageManager.getMessage('TOMS.PAYMENT.LIST.LABEL.MAY56CATHR'), stErr)) {
				ret = false;
			}

		// 受取 割合（％） と受取 金額の相関チェック ///////////////////////////////
		// 受取 割合（％） と受取 金額はどちらか一方だけ設定されている事
		// 必須のみ
		// 超過受取 割合（％）超過受取 金額 はチェックしない
		var tmp1 = row[4];	// 受取 割合（％）
		var tmp2 = row[5];	// 受取 金額
		// 両設定チェック
		if(!(tmp1 == null || tmp1 == "")
			&& !(tmp2 == null || tmp2 == "")) {
//			stErr.append("<p>" + rowPos + "行目 " 
//				+ "5列" + MessageManager.getMessage('TOMS.PAYMENT.LIST.MESSAGE.CSVCHECK.MAY56CRPER') + "</p>");
			stErr.append(MessageManager.getMessage('TOMS.PAYMENT.LIST.MESSAGE.CSVCHECK.MAY56CRPER1', sRowPos));
			ret = false;
			
		}
		// 両なし
		if((tmp1 == null || tmp1 == "")
			&& (tmp2 == null || tmp2 == "")) {
//			stErr.append("<p>" + rowPos + "行目 " 
//				+ "5列" + MessageManager.getMessage('TOMS.PAYMENT.DETAIL.LABEL.MAY56CRPER') + "と　6列" + MessageManager.getMessage('TOMS.PAYMENT.DETAIL.LABEL.MAY56CAREC') + "</p>");
			stErr.append(MessageManager.getMessage('TOMS.PAYMENT.LIST.MESSAGE.CSVCHECK.MAY56CRPER2', sRowPos));
			ret = false;
		}
		//////////////////////////////////////////////////////////////

		// 受取 割合（％） 4
			// 数値長さ
			if(!CsvCheker.isDigits(row[4], 9, 3, rowPos, 4, MessageManager.getMessage('TOMS.PAYMENT.LIST.LABEL.MAY56CRPER'), stErr)) {
				ret = false;
			}
			// 数値
			if(!CsvCheker.isNum(row[4], rowPos, 4, MessageManager.getMessage('TOMS.PAYMENT.LIST.LABEL.MAY56CRPER'), stErr)) {
				ret = false;
			}


		// 受取 金額 5
			// 数値長さ
			if(!CsvCheker.isDigits(row[5], 15, 2, rowPos, 5, MessageManager.getMessage('TOMS.PAYMENT.LIST.LABEL.MAY56CAREC'), stErr)) {
				ret = false;
			}
			if(!CsvCheker.isNum(row[5], rowPos, 5, MessageManager.getMessage('TOMS.PAYMENT.LIST.LABEL.MAY56CAREC'), stErr)) {
				ret = false;
			}

		// 取引 区分1 6
			// 必須
			if(!CsvCheker.required(row[6], rowPos, 6, MessageManager.getMessage('TOMS.PAYMENT.LIST.LABEL.MAY56CRYI1'), stErr)) {
				ret = false;
			}
			// 文字数
			if(!CsvCheker.maxLength(row[6], 1, rowPos, 6, MessageManager.getMessage('TOMS.PAYMENT.LIST.LABEL.MAY56CRYI1'), stErr)) {
				ret = false;
			}
			// E　or R
			if(row[6] != null && row[6] != "") {
				if(row[6] != "E" && row[6] != "R") {
//					stErr.append("<p>" + rowPos + "行目 " 
//						+ "7列　取引 区分1にはEかRを設定して下さい。</p>");
					stErr.append( MessageManager.getMessage('TOMS.PAYMENT.LIST.MESSAGE.CSVCHECK.E_OR_R', sRowPos));
					ret = false;
				}
			}

		// 取引 条件1 7 
			// 必須
			if(!CsvCheker.required(row[7], rowPos, 7, MessageManager.getMessage('TOMS.PAYMENT.LIST.LABEL.MAY56CTRA1'), stErr)) {
				ret = false;
			}
			// 文字数
			if(!CsvCheker.maxLength(row[7], 3, rowPos, 7, MessageManager.getMessage('TOMS.PAYMENT.LIST.LABEL.MAY56CTRA1'), stErr)) {
				ret = false;
			}

		//  ここまで必須 //////////////////////////////

		// 取引 区分2 8
			// 文字数
			if(!CsvCheker.maxLength(row[8], 1, rowPos, 8, MessageManager.getMessage('TOMS.PAYMENT.LIST.LABEL.MAY56CRYI2'), stErr)) {
				ret = false;
			}
			// E　or R
			if(row[8] != null && row[8] != "") {
				if(row[8] != "E" && row[8] != "R") {
					//stErr.append("<p>" + rowPos + "行目 " 
					//	+ "9列　取引 区分2にはEかRを設定して下さい。</p>");
					stErr.append(MessageManager.getMessage('TOMS.PAYMENT.LIST.MESSAGE.CSVCHECK.E_OR_R2', sRowPos));
					ret = false;
				}
			}

		// 取引 条件2 9
			// 文字数
			if(!CsvCheker.maxLength(row[9], 3, rowPos, 9, MessageManager.getMessage('TOMS.PAYMENT.LIST.LABEL.MAY56CRYI2'), stErr)) {
				ret = false;
			}
			// 条件1と同じ
			if(row[9] != null && row[9] !="") {
				if(row[7] != row[9]) {
//					stErr.append("<p>" + rowPos + "行目 " 
//						+ "10列　取引 条件2は取引 条件1と同じ値にして下さい。</p>");
					stErr.append(MessageManager.getMessage('TOMS.PAYMENT.LIST.MESSAGE.CSVCHECK.MAY56CRYI2.SAME', sRowPos));
					ret = false;
				}
			}

//       ↓　必須の項目のみ相関チェックのため削除
//		// 超過受取 割合（％） と超過受取 金額 の相関チェック ///////////////////////////////
//		// 超過受取 割合（％） と超過受取 金額 はどちらか一方だけ設定されている事

//		//////////////////////////////////////////////////////////////

		// 超過受取 割合（％） 10
			// 数値
			if(!CsvCheker.isNum(row[10], rowPos, 10, MessageManager.getMessage('TOMS.PAYMENT.LIST.LABEL.MAY56CERPE'), stErr)) {
				ret = false;
			}
			// 数値長さ
			if(!CsvCheker.isDigits(row[10], 9, 3, rowPos, 10, MessageManager.getMessage('TOMS.PAYMENT.LIST.LABEL.MAY56CERPE'), stErr)) {
				ret = false;
			}

		// 超過受取 金額 11
			// 数値
			if(!CsvCheker.isNum(row[11], rowPos, 11, MessageManager.getMessage('TOMS.PAYMENT.LIST.LABEL.MAY56CEARE'), stErr)) {
				ret = false;
			}
			// 数値長さ
			if(!CsvCheker.isDigits(row[11], 15, 2, rowPos, 11, MessageManager.getMessage('TOMS.PAYMENT.LIST.LABEL.MAY56CEARE'), stErr)) {
				ret = false;
			}

		// 超過取引 区分1 12
			// 文字数
			if(!CsvCheker.maxLength(row[12], 1, rowPos, 12, MessageManager.getMessage('TOMS.PAYMENT.LIST.LABEL.MAY56CERY1'), stErr)) {
				ret = false;
			}
			// E or R
			if(row[12] != null && row[12] != "") {
				if(row[12] != "E" && row[12] != "R") {
//					stErr.append("<p>" + rowPos + "行目 " 
//						+ "13列　超過取引 区分にはEかRを設定して下さい。</p>");
					stErr.append(MessageManager.getMessage('TOMS.PAYMENT.LIST.MESSAGE.CSVCHECK.E_OR_R3', sRowPos ))
					ret = false;
				}
			}

		// 超過取引 条件1 13
			// 文字数
			if(!CsvCheker.maxLength(row[13], 3, rowPos, 13, MessageManager.getMessage('TOMS.PAYMENT.LIST.LABEL.MAY56CETR1'), stErr)) {
				ret = false;
			}
			// 条件1と同じ
			if(row[13] != null && row[13] !="") {
				if(row[7] != row[13]) {
//					stErr.append("<p>" + rowPos + "行目 " 
//						+ "14列　超過取引 条件1は取引 条件1と同じ値にして下さい。</p>");
					stErr.append(MessageManager.getMessage('TOMS.PAYMENT.LIST.MESSAGE.CSVCHECK.MAY56CETR1.SAME', sRowPos))
					ret = false;
				}
			}

		// 超過取引 区分2 14
			// 文字数
			if(!CsvCheker.maxLength(row[14], 1, rowPos, 14, MessageManager.getMessage('TOMS.PAYMENT.LIST.LABEL.MAY56CERY2'), stErr)) {
				ret = false;
			}
			// E or R
			if(row[14] != null && row[14] != "") {
				if(row[14] != "E" && row[14] != "R") {
//					stErr.append("<p>" + rowPos + "行目 " 
//						+ "15列　超過取引 区分2にはEかRを設定して下さい。</p>");
					stErr.append(MessageManager.getMessage('TOMS.PAYMENT.LIST.MESSAGE.CSVCHECK.E_OR_R4', sRowPos));
					ret = false;
				}
			}

		// 超過取引 条件2 15
			// 文字数
			if(!CsvCheker.maxLength(row[15], 3, rowPos, 15, MessageManager.getMessage('TOMS.PAYMENT.LIST.LABEL.MAY56CETR2'), stErr)) {
				ret = false;
			}
			// 条件1と同じ
			if(row[15] != null && row[15] !="") {
				if(row[7] != row[15]) {
//					stErr.append("<p>" + rowPos + "行目 " 
//						+ "16列　超過取引 条件2は取引 条件1と同じ値にして下さい。</p>");
					stErr.append(MessageManager.getMessage('TOMS.PAYMENT.LIST.MESSAGE.CSVCHECK.MAY56CETR2.SAME', sRowPos));
					ret = false;
				}
			}
		// 支払条件 16
			// 文字数
			if(!CsvCheker.maxLength(row[16], 15, rowPos, 16, MessageManager.getMessage('TOMS.PAYMENT.LIST.LABEL.PAYMENTCONDITION'), stErr)) {
				ret = false;
			}
	}

	return ret;
}

/*
 * DBによるデータ有無チェック
 * @param csv　csv二次元配列
 * @param stErr エラーメッセージパラメータ.(OUT)
 */
function dbCheck(csv, stErr) {
	
	var rowLength = csv.length;
	var result;
	var dbPram = [1];
	var ret = true;
	var db = new SharedDatabase("toms-web-dev");
	
	for(var rowPos=1; rowPos<rowLength; rowPos++) {
		var sRowPos = String(rowPos);

		var row = csv[rowPos];
		var ope = row[0];
		var pram =  row[1];
		dbPram[0] = DbParameter.string(pram);
		result = db.select('select mapyr from F56C1030 where mapyr = ?', dbPram, 0);

		// 入金パターンマスタ
		// 挿入の場合
		if(ope == "I") {			
			if(result.countRow > 0 ) {
//				stErr.append("<p>" + rowPos + MessageManager.getMessage('TOMS.PAYMENT.LIST.MESSAGE.DBCHECK.DUPLICATED') + pram + "</p>");
				stErr.append(MessageManager.getMessage('TOMS.PAYMENT.LIST.MESSAGE.DBCHECK.DUPLICATED', sRowPos, pram));
				ret = false;
			}
		// 更新、削除の場合
		} else {
			if(result.countRow < 1 ) {
//				p>{0}行目は入金パターンマスタにデータが存在しません。 支払人No={1}</p>
				stErr.append(MessageManager.getMessage('TOMS.PAYMENT.LIST.MESSAGE.DBCHECK.DATANOTEXIST', sRowPos, pram));
				ret = false;
			}
		}

		// 通貨コード  2 f0013
		pram = row[2];
		if( pram != null && pram != "" ) {
			dbPram[0] = DbParameter.string(pram);
			result = db.select('select cvcrcd from f0013 where cvcrcd = ?', dbPram, 0);
			if(result.countRow < 1 ) {
				// p>{0}行目 3列 通貨コードは通貨コードマスタにデータが存在しません。 通貨コード={1}</p>
				stErr.append(MessageManager.getMessage('TOMS.PAYMENT.LIST.MESSAGE.DBCHECK.MACRCD', sRowPos, pram));
				ret = false;
			}
		}

		// 支払 条件 //////////////////////////////////////////////////////////////////////
		// 画面 では　支払 条件1 　を　支払 条件2　超過支払 条件1　超過支払 条件2　にコピー するが
		// CSVでは入力した値をそのまま登録
		// 支払 条件1 7
		pram = row[7];
		if( pram != null && pram != "" ) {
			dbPram[0] = DbParameter.string(pram);
			result = db.select('select pnptc from f0014 where pnptc = ?', dbPram, 0);
			if(result.countRow < 1 ) {
//				stErr.append("<p>" + rowPos + "行目 " 
//						+ "8列" +  MessageManager.getMessage('TOMS.PAYMENT.LIST.MESSAGE.DBCHECK.MAY56CTRA1') + pram + "</p>");
				stErr.append(MessageManager.getMessage('TOMS.PAYMENT.LIST.MESSAGE.DBCHECK.MAY56CTRA1', sRowPos, pram));
				ret = false;
			}
		}
	
		// 支払 条件2 9
		pram = row[9];
		if( pram != null && pram != "" ) {
			dbPram[0] = DbParameter.string(pram);
			result = db.select('select pnptc from f0014 where pnptc = ?', dbPram, 0);
			if(result.countRow < 1 ) {
//				stErr.append("<p>" + rowPos + "行目 " 
//						+ "10列" + MessageManager.getMessage('TOMS.PAYMENT.LIST.MESSAGE.DBCHECK.MAY56CTRA2') + pram + "</p>");
				// p>{0}行目 10列 支払条件2は支払条件マスタにデータが存在しません。 支払 条件2={1}</p>
				stErr.append(MessageManager.getMessage('TOMS.PAYMENT.LIST.MESSAGE.DBCHECK.MAY56CTRA2', sRowPos, pram));
				ret = false;
			}
		}

		// 超過支払 条件1 13
		pram = row[13];
		if( pram != null && pram != "" ) {
			dbPram[0] = DbParameter.string(pram);
			result = db.select('select pnptc from f0014 where pnptc = ?', dbPram, 0);
			if(result.countRow < 1 ) {
				// p>{0}行目 14列 超過支払 条件1は支払条件マスタにデータが存在しません。 超過支払 条件1={1}</p>
				stErr.append(MessageManager.getMessage('TOMS.PAYMENT.LIST.MESSAGE.DBCHECK.MAY56CETR1', sRowPos, pram));
				ret = false;
			}
		}

		// 超過支払 条件2 15
		pram = row[15];
		if( pram != null && pram != "" ) {
			dbPram[0] = DbParameter.string(pram);
			result = db.select('select pnptc from f0014 where pnptc = ?', dbPram, 0);
			if(result.countRow < 1 ) {
				// p>{0}行目 16列 超過支払 条件2は支払条件マスタにデータが存在しません。 超過支払 条件2={1}</p>
				stErr.append(MessageManager.getMessage('TOMS.PAYMENT.LIST.MESSAGE.DBCHECK.MAY56CETR2', sRowPos, pram));
				ret = false;
			}
		}

		// 支払手段マスタチェックはE or R チェックするので削除
	}

	return ret;
}

/*
 * DB更新
 * @param csv　csv二次元配列
 * @param stErr エラーメッセージパラメータ.(OUT)
 * @param updateCount (OUT)
 */
function dbUpdate(csv, stErr, counts) {
	
	load("toms/common/master");

	var rowLength = csv.length;
	var ret = true;
	var newCount = 0;
	var updateCount = 0;
	var deleteCount = 0;

	Transaction.begin();
	for(var rowPos=1; rowPos<rowLength; rowPos++) {
		var row = csv[rowPos];
		var ope = row[0];
		var result;
		
		var entity = createEntity(row);
		var condition = "mapyr = ? ";
        var params = [
        	   DbParameter.number(entity['mapyr'])
             ];

		if(ope == "I") {			//挿入
			result = TomsMaster.insertToF56C1030(entity);
			newCount++;
		} else if (ope =="U") {		//更新
			result = TomsMaster.updateToF56C1030(entity, condition, params);
			updateCount++;
		} else if  (ope =="D") {	//削除
			result = TomsMaster.removeFromF56C1030(condition, params);
			deleteCount++;
		}
		
		if (result.error) {
			Transaction.rollback();
			stErr.append(MessageManager.getMessage('TOMS.PAYMENT.LIST.LABEL.MESSAGE.ERRORMSG', result.errorCode, result.errorMessage, String(rowPos)));
			return false;
		}		if(!result.error && result.countRow != 1) {
			Transaction.rollback();
//			stErr.append(MessageManager.getMessage('TOMS.PAYMENT.LIST.LABEL.MESSAGE.FAILUREPROCESSING', String(result.countRow), String(rowPos)));
			stErr.append(MessageManager.getMessage('TOMS.PAYMENT.LIST.LABEL.MESSAGE.FAILUREPROCESSING', String(rowPos)));
			return false;
		}

	}

	counts.newCount = newCount;
	counts.updateCount = updateCount;
	counts.deleteCount = deleteCount;

	Transaction.commit();
	return true;
}

	
	
function createEntity(row) {
	var userContext = Contexts.getUserContext();
	var now = new Date();
	
	// 数字のデータ型
	var maupmj = cmnUtil.convertDateToJulia(now);
	var maupmt = cmnUtil.getTime(now);

	// 文字列のデータ型
	var mapyr = null;
    var macrcd = null;
    var may56cathr = null;
    var may56crper = null;
    var may56carec = null;
    var may56cryi1 = null;
    var may56ctra1 = null;
    var may56cryi2 = null;
    var may56ctra2 = null;
    var may56cerpe = null;
    var may56ceare = null;
    var may56cery1 = null;
    var may56cetr1 = null;
    var may56cery2 = null;
    var may56cetr2 = null;
    // 支払条件
    var maurrf = null;
    var mauser = userContext.userProfile.userCd;
    var mapid = MessageManager.getMessage('TOMS.COMMON.CONSTANT.PROGRAM.ID');
    

	if (cmnUtil.getData(row[1], 1) != "")  {
		mapyr = cmnUtil.getData(row[1], 1);
    }
	if (cmnUtil.getData(row[2], 0) != "")  {
		macrcd = cmnUtil.getData(row[2], 0);
    }
	
	if (cmnUtil.getData(row[3], 1) != "")  {
		may56cathr = cmnUtil.getData(row[3], 1);
    }
	if (cmnUtil.getData(row[4], 1) != "")  {
		may56crper = cmnUtil.getData(row[4], 1)*1000;
    }
	if (cmnUtil.getData(row[5], 1) != "")  {
		may56carec = cmnUtil.getData(row[5], 1);
    }
	if (cmnUtil.getData(row[6], 0) != "")  {
		may56cryi1 = cmnUtil.getData(row[6], 0);
    }
	if (cmnUtil.getData(row[7], 0) != "")  {
		may56ctra1 = cmnUtil.getData(row[7], 0);
    }
	if (cmnUtil.getData(row[8], 0) != "")  {
		may56cryi2 = cmnUtil.getData(row[8], 0);
    }
	if (cmnUtil.getData(row[9], 0) != "")  {
		may56ctra2 = cmnUtil.getData(row[9], 0);
    }
	if (cmnUtil.getData(row[10], 1) != "")  {
		may56cerpe = cmnUtil.getData(row[10], 1)*1000;
    }
	if (cmnUtil.getData(row[11], 1) != "")  {
		may56ceare = cmnUtil.getData(row[11], 1);
    }
	if (cmnUtil.getData(row[12], 0) != "")  {
		may56cery1 = cmnUtil.getData(row[12], 0);
    }
	if (cmnUtil.getData(row[13], 0) != "")  {
		may56cetr1 = cmnUtil.getData(row[13], 0);
    }
	if (cmnUtil.getData(row[14], 0) != "")  {
		may56cery2 = cmnUtil.getData(row[14], 0);
    }
	if (cmnUtil.getData(row[15], 0) != "")  {
		may56cetr2 = cmnUtil.getData(row[15], 0);
    }
	// 支払条件
	if (cmnUtil.getData(row[16], 0) != "")  {
		maurrf = cmnUtil.getData(row[16], 0);
    }

    var entity = {
                	mapyr : mapyr,
                	macrcd: macrcd,
                	may56cathr: may56cathr,
                	may56crper: may56crper,
                	may56carec: may56carec,
                	may56cryi1: may56cryi1,
                	may56ctra1: may56ctra1,
                	may56cryi2: may56cryi2,
                	may56ctra2: may56ctra2,
                	may56cerpe: may56cerpe,
                	may56ceare: may56ceare,
                	may56cery1: may56cery1,
                	may56cetr1: may56cetr1,
                	may56cery2: may56cery2,
                	may56cetr2: may56cetr2,
                	maurrf: maurrf,		// 支払条件
                	mauser: mauser,		// ユーザー ID
                	mapid: mapid,		// プログラム ID
                	maupmj: maupmj,		// 更新 日付
                	maupmt: maupmt		// 更新 時刻
            };
    return entity;
}
/**
 * エラー処理
 * @param response　レスポンス
 * @param stErr エラーメッセージパラメータ.
 */
function doError(response, stErr){

	stErr.insert(0, MessageManager.getMessage('TOMS.PAYMENT.LIST.LABEL.MESSAGE.ENTRY.FAILED2'));
	var st = stErr.toString();
	response.sendMessageBodyString(ImJson.toJSONString([{
        "message":st,
        "isError":"true"
	}]));
}

