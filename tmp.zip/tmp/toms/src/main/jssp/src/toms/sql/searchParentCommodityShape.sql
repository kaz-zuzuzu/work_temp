SELECT
    *
FROM
(
    SELECT
        base.*
      , ROWNUM AS RN
    FROM
    (
    SELECT 
        TRIM(MJ.MJY57ACSC) AS MJY57ACSC
        ,TRIM(MJ.MJY57APCSC) AS MJY57APCSC
        ,MJ.MJDL01 AS MJDL01
    FROM
        F57A5110 MJ

        WHERE
        MJ.MJY57ACSC = MJ.MJY57APCSC
        AND MJ.MJY57ADFLG = 0
        /*IF paramName != null*/
        AND  TRIM(MJ.MJDL01) like /*paramName*/'%TEST%'
        /*END*/
        /*IF paramCode != null*/
        AND  TRIM(MJ.MJY57ACSC) = /*paramCode*/'TISTS01'
        /*END*/
        ORDER BY MJ.MJY57ACSC, MJ.MJY57APCSC, MJ.MJSNN, MJ.MJEFTJ
    ) base
     /*IF end != null*/
        WHERE ROWNUM <= /*end*/'10' 
     /*END*/

)
/*IF start != null*/
WHERE RN >= /*start*/'1' 
/*END*/
