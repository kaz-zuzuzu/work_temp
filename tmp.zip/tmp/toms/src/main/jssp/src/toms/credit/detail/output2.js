/**
 * バインド変数.
 */
var $bind = {};

var $data = {};

/**
 * 初期表示.
 * @param request リクエストパラメータ.
 */
function init(request) {
    request.setAttribute("imui-theme-builder-module", "headwithcontainer");
	setData(request.customerCode);
	
	// ページング
	$data = {
		rowNum  : 12,
		rowList : [50, 100, 150]
	};
}

/**
 * データ設定
 * @param customerCode	請求先コード
 */
function setData(customerCode){
  
   	load("toms/common/master");

	var result = TomsMaster.getPaymentList(customerCode);
	var rsltData = [];
	if (!result.error) {
		$bind.thisMonthPaymentData = result.data;
	}
	//Debug.browse(result.data);
}