/**
 * バインド変数.
 */
var $bind = {};

/**
 * 初期表示
 * @param request リクエストパラメータ
 */
function init(request) {

	load("toms/common/master");
	load("toms/common/delivery");

    // 検索条件設定判定（一覧画面からのパラメータがない場合）
    if(isBlank(request.backFlag)){
    	
        // 出庫日付の初期値設定(Fromにはシステム日付-1を設定)
        var tmpDt = new DateTime();
        var fromDt = tmpDt.minusDays(1);
        var fromYear = fromDt.data.year;
        var fromMonth = fromDt.data.monthOfYear+1 < 10 ? "0"+(fromDt.data.monthOfYear + 1) :(fromDt.data.monthOfYear + 1); 
        var fromDay = fromDt.data.dayOfMonth < 10 ? "0"+ fromDt.data.dayOfMonth :fromDt.data.dayOfMonth;
        $bind.deliveryDateFrom = fromYear + "/" + fromMonth +"/" + fromDay;
        $bind.deliveryDateTo =  DateTimeFormatter.format('yyyy/MM/dd',new Date());
    	
    }else{
    	// 前回の検索条件を設定（一覧画面からのパラメータがある場合）
		$bind.receiveOrderNo = request.receiveOrderNo;				//オーダーNo
		//$bind.orderTypeListNm = request.orderTypeList;				//オーダータイプ
		//$bind.orderTypeListNm = request.orderTypeListNm;			//オーダータイプ名称
		$bind.instructNo = request.instructNo;						//出荷予定番号
		$bind.destination = request.destination;					//納入先
		$bind.exchangeTarget = request.exchangeTarget;				//取引先カナ
    	$bind.deliveryDateFrom = request.deliveryDateFrom;	//出庫日付From
    	$bind.deliveryDateTo = request.deliveryDateTo;		//出庫日付To
    }

    // 上位組織のセレクトボックスの値を初期化.
    setSuperOrganizationData();
    // 組織のセレクトボックスの値を初期化.
    setOrganizationData();    
    // 在庫場所のセレクトボックスの値を初期化.
    setStockPositionData();

    // オーダータイプのセレクトボックスを追加
    setOrderTypeData();
  $bind.organizationLabel = ({
	    selectTopMessage: MessageManager.getMessage('TOMS.COMMON.SELECT.LABEL.ORGANIZATION')
	  }).toSource();
}

/**
 * 上位組織情報を設定する処理
 * 
 */
function setSuperOrganizationData() {
	var result = TomsMaster.getSuperOrganizationList();
	if (!result.error) {
    	// 上位組織	 
    	$bind.superOrganizationSelectList = result.data;
	}
}

/**
 * 組織情報を設定する処理
 * 
 */
function setOrganizationData() {
	var result = TomsMaster.getOrganizationListByCode(' ');
	if (!result.error) {
    	// 組織	 
    	$bind.organizationSelectList = result.data;
	}
}

/*
 * 在庫場所を設定する処理
 */
function setStockPositionData() {
	var result = TomsMaster.getAllStockPositionList();
	if(!result.error) {
		$bind.stockPositionList = result.data;
	}
}

/*
 * オーダータイプを設定する処理 150904追加
 */
function setOrderTypeData() {
	var result = Delivery.getOrderTypeList();
	
	if(!result.error) {
		var allValues=[];
		var listData = result.data;
		for(var i=0, cnt=listData.length; i<cnt; i++){
			allValues.push(listData[i].label);
		}
	
		var obj= {};
		obj.label=MessageManager.getMessage('TOMS.COMMON.SEARCH.INPUT.DEFAULTNONE'),
		obj.value=allValues.join(',');
		
		var allOrder = [];
		allOrder.push(obj);
		
	   for(var ii=0, cnt=listData.length;ii<cnt;ii++ ){
		   allOrder.push(listData[ii]);   
	   }
		$bind.orderTypeList = allOrder;
	}

}

function error(message) {
  Transfer.toErrorPage({
    title: MessageManager.getMessage('TOMS.COMMON.ERROR.PAGE.TITLE'),
    message: MessageManager.getMessage('TOMS.COMMON.ERROR.MESSAGE.SYSTEM'),
    detail: [MessageManager.getMessage('TOMS.ACCOUNT.SEARCH.LABEL.MESSAGE.ERROR'), message],
    returnUrl: 'toms/delivery/search/input', // 戻り先 URL
    returnUrlLabel: MessageManager.getMessage('TOMS.ACCOUNT.SEARCH.LABEL.RETURN.LINK.NAME'),
    parameter: {
    }
  });
}
