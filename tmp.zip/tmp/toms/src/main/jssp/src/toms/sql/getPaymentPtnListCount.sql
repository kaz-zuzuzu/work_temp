select
  count(mapyr) as ROWCOUNT
from
  F56C1030
where
 1=1
  /*IF mapyrFrom != null*/
  and F56C1030.mapyr >= /*mapyrFrom*/91000170
  /*END*/
  /*IF mapyrTo != null*/
  and F56C1030.mapyr <= /*mapyrTo*/91000200
  /*END*/
