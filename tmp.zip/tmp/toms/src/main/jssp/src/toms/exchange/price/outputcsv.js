/**
 * バインド変数.
 */
var $bind = {};

load('toms/common/common');

// 区切り文字（カンマ）
var splitComma = MessageManager.getMessage('TOMS.COMMON.COMMA');

/**
 * 初期表示.
 * @param request リクエストパラメータ.
 */
function init(request) {
	load("toms/common/master");

    $bind.exchangeTargetId = request.torihikisakicd;
	if (request.csvFlag == "1") {
		// CSV出力
        outputCSV($bind.exchangeTargetId);
	}
}

/**
 * 特価一覧のCSV出力処理.
 * 
 * @param exchangeTargetId 取引先コード.
 * @param exchangeTargetName 取引先名.
 */
function outputCSV(exchangeTargetId) {
	// CSV出力用データ取得
    var result = TomsMaster.getSalePriceList(exchangeTargetId);
    var outputContent = "";
    if (!result.error) {
        outputContent = outputCSVHeader();
        for (var i = 0; i < result.countRow; i++) {
            outputContent += outputCSVRow(result.data[i]);
        }
        var strDateTime = DateTimeFormatter.format("yyyyMMddHHmmss", new Date());
        var fileName = MessageManager.getMessage('TOMS.EXCHANGE.LIST.CSV.SALEPRICE.FILENAME') + '_' + strDateTime + '.csv';
        Module.download.send(Unicode.to(outputContent, 'MS932'), fileName, MessageManager.getMessage('TOMS.COMMON.MIME.CSV'));
    } else {
        error(result.errorMessage);
    }
}

/**
 * 特価一覧のCSVヘッダ部分出力処理.
 */
function outputCSVHeader() {
    var outputHeader = common.convertWithSplit(MessageManager.getMessage('TOMS.EXCHANGE.LIST.CSV.SALEPRICE.EXCHANGETARGET.CODE'), splitComma, true)     // 取引先コード
                       + common.convertWithSplit(MessageManager.getMessage('TOMS.EXCHANGE.LIST.CSV.SALEPRICE.EXCHANGETARGET.NAME'), splitComma, true)   // 取引先名
                       + common.convertWithSplit(MessageManager.getMessage('TOMS.EXCHANGE.LIST.CSV.SALEPRICE.SKU.NUMBER'), splitComma, true)            // 品目No
                       + common.convertWithSplit(MessageManager.getMessage('TOMS.EXCHANGE.LIST.CSV.SALEPRICE.PRODUCT.NAME1'), splitComma, true)         // 商品名1
                       + common.convertWithSplit(MessageManager.getMessage('TOMS.EXCHANGE.LIST.CSV.SALEPRICE.PRODUCT.NAME2'), splitComma, true)         // 商品名2
                       + common.convertWithSplit(MessageManager.getMessage('TOMS.EXCHANGE.LIST.CSV.SALEPRICE.EFFECTIVE.START.DATE'), splitComma, true)  // 有効開始日
                       + common.convertWithSplit(MessageManager.getMessage('TOMS.EXCHANGE.LIST.CSV.SALEPRICE.SELE.PRICE'), splitComma, false);          // 特価
	return outputHeader;
}

/**
 * 特価一覧のCSVファイルの行を出力する処理.
 * 
 * @param record DBから検索した行のデータ.
 */
function outputCSVRow(record) {
	var result = common.convertWithSplit(record["torihikisakicd"], splitComma, true)   		// 取引先コード
    			 + common.convertWithSplit(record["torihikisakimei"], splitComma, true) 	// 取引先名
    			 + "'" + common.convertWithSplit(record["hinmokunumber"], splitComma, true)   	// 品目No
    			 + common.convertWithSplit(record["shohinmei1"], splitComma, true)      	// 商品名1
    			 + common.convertWithSplit(record["shohinmei2"], splitComma, true)      	// 商品名2
    			 + common.convertWithSplit(record["yukokaishibi"], splitComma, true)    	// 有効開始日
    			 + common.convertWithSplit(record["tokka"].toString(), splitComma, false);	// 特価
	return result;
}

// エラーページ
function error(message) {
  Transfer.toErrorPage({
    title: MessageManager.getMessage('TOMS.COMMON.ERROR.PAGE.TITLE'),
    message: MessageManager.getMessage('TOMS.COMMON.ERROR.MESSAGE.SYSTEM'),
    detail: [MessageManager.getMessage('TOMS.EXCHANGE.LIST.LABEL.SALEPRICE.MESSAGE.ERROR'), message],
    returnUrl: 'toms/exchange/list/output', // 戻り先 URL
    returnUrlLabel: MessageManager.getMessage('TOMS.EXCHANGE.LIST.LABEL.SALEPRICE.RETURN.LINK.NAME'),
    parameter: {
    }
  });
}

