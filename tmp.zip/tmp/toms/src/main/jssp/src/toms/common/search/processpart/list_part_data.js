var $data;

/**
 * 初期表示
 * @param request リクエストパラメータ
 */
function init(request) {
	$data = ImJson.toJSONString(getList(request));
}

function getList(request) {
	// 表示条件を設定（表示ページ、件数など）
	let page = request.page == undefined ? 1 : request.page;
	let rows = request.rowNum == undefined ? 10 : Module.number.toInt(request.rowNum);
	var searchCondition = request.extension;
	if (!searchCondition || !searchCondition.searchConditionParam) {
		return  {
                		page  : page,
                		total : rows,
                		data  : []
    				};
    }
	
    if (searchCondition.searchConditionParam.popupFlag == "search") {
    	page = 1;
    }
    
	var mky57appc1 = searchCondition.searchConditionParam.mky57appc1;
	var mkdl01 = searchCondition.searchConditionParam.mkdl01;
	var mky57appc2 = searchCondition.searchConditionParam.mky57appc2;
	var mkdl02 = searchCondition.searchConditionParam.mkdl02;
	var mky57apcsc = searchCondition.searchConditionParam.mky57apcsc;
	var mky57apcscName = searchCondition.searchConditionParam.mky57apcscName;
	var mky57acsc = searchCondition.searchConditionParam.mky57acsc;
	var mky57acscName = searchCondition.searchConditionParam.mky57acscName;
	var mky57amtc = searchCondition.searchConditionParam.mky57amtc;
	var mky57amtcName = searchCondition.searchConditionParam.mky57amtcName;
	
	var objParams ={
		mky57appc1 :mky57appc1,
    	mkdl01 :mkdl01,
    	mky57appc2 :mky57appc2,
    	mkdl02 :mkdl02,
    	mky57apcsc :mky57apcsc,
    	mky57apcscName :mky57apcscName,
    	mky57acsc :mky57acsc,
    	mky57acscName :mky57acscName,
    	mky57amtc :mky57amtc,
    	mky57amtcName :mky57amtcName
	};
	
	// 該当する有効な加工部位マスタの件数取得
	var resultCount = searchDataCount(objParams);
	// 全体の件数を設定（件数の母数）
	var listCount = 0;
	if (!resultCount.error) {
		listCount = resultCount.data[0]['rowcount'];
	} else {
		Debug.write(resultCount.errorMessage);
	}
	// ページ番号設定:リクエストパラメータのページ番号、最大ページ番号のうち小さい方の番号を設定
	page = Math.min(page, Math.ceil(listCount / rows)); 
	
	// 指定範囲の加工部位情報を取得
	let start = rows * (page - 1) + 1;
	let end = start + rows - 1;
	
	var result = searchData(objParams, start, end);
	var rsltData = [];
	if (!result.error) {
		rsltData = result.data;
	} else {
		Debug.write(result.error);
	}
	
	var json = {
		page  : page,
		total : listCount,
		data  : rsltData
	};
	return json;
}

function searchDataCount(objParams) {
	load("toms/common/processPart");
	var result = ProcessPart.searchPartData(objParams, true);
	return result;
}

function searchData(objParams,start, end) {
	load("toms/common/processPart");
	var result = ProcessPart.searchPartData(objParams,false, start, end);
	return result;
}

