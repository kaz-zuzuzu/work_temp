SELECT
    *
FROM
(
    SELECT
        base.*
      , ROWNUM AS RN
    FROM
    (
		SELECT DISTINCT
		    UL.ULUSER AS ULUSER
		    ,WW.WWMLNM AS WWMLNM
		FROM
		    F0092 UL
		INNER JOIN 
		    F0111 WW
		   ON UL.ULAN8 = WW.WWAN8
		/*BEGIN*/
		WHERE
		    /*IF userCode != null*/
		    TRIM(UL.ULUSER) = /*userCode*/'TISTS01'
		    /*END*/
		    /*IF userName != null*/
		    AND TRIM(WW.WWMLNM) like /*userName*/'%TEST%'
		    /*END*/
		/*END*/ 
		ORDER BY
            ULUSER
    ) base
     /*IF end != null*/
        WHERE ROWNUM <= /*end*/'10' 
     /*END*/
)
/*IF start != null*/
WHERE RN >= /*start*/'1' 
/*END*/