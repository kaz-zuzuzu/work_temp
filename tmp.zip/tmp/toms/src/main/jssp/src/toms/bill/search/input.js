/**
 * バインド変数.
 */
var $bind = {};

/**
 * 初期表示
 * @param request リクエストパラメータ
 */
function init(request) {
	// 画面入力チェックに表示されるのトップメッセージを初期化.
	// JavaScriptで利用するためオブジェクトの内容をそのまま渡します.
	$bind.errorMessage = ({
	    checkMessage: MessageManager.getMessage('TOMS.BILL.SEARCH.INPUT.CHECK.ERROR.MESSAGE'),
	    checkYearMessage: MessageManager.getMessage('TOMS.BILL.SEARCH.INPUT.CHECK.YEARS.ERROR.MESSAGE')
	  }).toSource();
}




