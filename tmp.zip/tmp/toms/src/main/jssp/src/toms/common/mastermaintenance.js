/**
* staticオブジェクトの作成 
 */ 
load('toms/common/cmnUtil');
 var _SHARED_DB_KEY ="toms-web-dev";
function MasterMain(){};

/**
 * マスタテーブル登録
 * 
 * @param masterName マスタテーブル名称
 * @param entity DB更新用データ
 **/
MasterMain.insertToMasterTable = function(masterName, entity) {
    var db = new SharedDatabase(_SHARED_DB_KEY);
    
    var result = db.insert(masterName, entity);
    
    return result;
}

/**
 * マスタテーブル更新
 * 
 * @param masterName マスタテーブル名称
 * @param entity DB更新用データ
 * @param condition 更新条件
 * @param params 更新条件パラメータ
 **/
MasterMain.updateToMasterTable = function(masterName, entity, condition, params) {
    var db = new SharedDatabase(_SHARED_DB_KEY);
    
    var result = db.update(masterName, entity, condition, params);
    
    return result;
}

/**
 * マスタテーブル削除
 * 
 * @param masterName マスタテーブル名称
 * @param condition 削除条件
 * @param params 削除条件パラメータ
 **/
MasterMain.removeFromMasterTable = function(masterName, condition, params) {
    var db = new SharedDatabase(_SHARED_DB_KEY);
    
    var result = db.remove(masterName, condition, params);
    
    return result;
}

/**
 * 内部コードマスタチェック
 **/
MasterMain.checkCodeMaster = function(processType, codeType,codeValue) {
	var db = new SharedDatabase(_SHARED_DB_KEY);
	var sql ="";
	sql += " SELECT * FROM F57A5190 ";
	sql +="     WHERE ";
	sql +="                  TRIM(MSY57APT) = ? ";
	sql +="          AND MSY57APMT = '  ' ";
	sql +="          AND  TRIM(MSY57ACOTY) = ? ";
	if(codeType =="01"){
		sql +="          AND  TRIM(MSY57AIC) = ? ";
	}else if(codeType=="02" ){
		sql +="          AND  TRIM(MSY57AJDC) = ? ";
	}
	
	var params = [];
	      params.push(DbParameter.string(processType));
	      params.push(DbParameter.string(codeType));
	      params.push(DbParameter.string(codeValue));

	var result = db.execute(sql, params);
	return result;
	
};

/**
 * 内部コードマスタチェック(加工方法明細用)
 **/
MasterMain.checkCodeMasterMethodDetail = function(processType, codeType,codeValue, methodType){
	var db = new SharedDatabase(_SHARED_DB_KEY);
	var sql ="";
	var params = [];
    params.push(DbParameter.string(processType));
    params.push(DbParameter.string(codeType));
    params.push(DbParameter.string(codeValue));

	sql += " SELECT * FROM F57A5190 ";
	sql +="     WHERE ";
	sql +="                  TRIM(MSY57APT) = ? ";
	sql +="          AND  TRIM(MSY57ACOTY) = ? ";
	if(codeType =="01"){
		sql +="          AND  TRIM(MSY57AIC) = ? ";
	}else if(codeType=="02" ){
		sql +="          AND  TRIM(MSY57AJDC) = ? ";
	}
	if(!isBlank(methodType)){
		sql +="          AND TRIM(MSY57APMT) =? ";
	    params.push(DbParameter.string(methodType));
	}else{
		sql +="          AND MSY57APMT = '  ' ";
	}

	var result = db.execute(sql, params);
	return result;
	
}

/**
 * 加工方法コード取得（シーケンス）
 **/
MasterMain.getSequence = function() {
	var db = new TenantDatabase();
	var ret = Transaction.begin(function(){
	var sql =" select SEQ_PROCESSMETHODCODE.nextval as nextval from dual";
	var result = db.execute(sql);
		if(result.error || result.countRow !=1){
			Transaction.rollback();
		}
		return result;
	})
	return ret.data;
};

/**
 * 素材マスタキー検索
 * 
 * @param mly57amtc 素材コード
 * @param mly57apcsc 親商品形態コード
 * @param mly57acsc 商品形態コード
 * @param mleftj 適用開始日
 **/
MasterMain.getMaterialByPk = function(mly57amtc, mly57apcsc, mly57acsc, mleftj) {
    var db = new SharedDatabase(_SHARED_DB_KEY);
    var params = [];

    var sql = ""
            + " SELECT * "
            + "   FROM F57A5130 ML "
            + "  WHERE TRIM(ML.MLY57AMTC) = ? "
            + "    AND TRIM(ML.MLY57APCSC) = ? "
            + "    AND TRIM(ML.MLY57ACSC) = ? "
            + "    AND TRIM(ML.MLEFTJ) = ? ";

    params.push(DbParameter.string(mly57amtc));
    params.push(DbParameter.string(mly57apcsc));
    params.push(DbParameter.string(mly57acsc));
    params.push(DbParameter.number(cmnUtil.convertDateToJulia(new Date(mleftj))));

    var result = db.execute(sql, params);

    return result;
    
}

/**
 * 加工部位マスタキー検索
 * 
 * @param mky57appc1 加工部位コード
 * @param mky57appc2 加工位置コード
 * @param mky57apcsc 親商品形態コード
 * @param mky57acsc 商品形態コード
 * @param mky57amtc 素材コード
 * @param mkeftj 適用開始日
 **/
MasterMain.getProcessPartByPk = function(mky57appc1, mky57appc2, mky57apcsc, mky57acsc, mky57amtc, mleftj) {
    var db = new SharedDatabase(_SHARED_DB_KEY);
    var params = [];

    var sql = ""
            + " SELECT * "
            + "   FROM F57A5120 MK "
            + "  WHERE TRIM(MK.MKY57APPC1) = ? "
            + "    AND TRIM(MK.MKY57APPC2) = ? "
            + "    AND TRIM(MK.MKY57APCSC) = ? "
            + "    AND TRIM(MK.MKY57ACSC) = ? "
            + "    AND TRIM(MK.MKY57AMTC) = ? ";
            
	    params.push(DbParameter.string(mky57appc1));
	    params.push(DbParameter.string(mky57appc2));
	    params.push(DbParameter.string(mky57apcsc));
	    params.push(DbParameter.string(mky57acsc));
	    params.push(DbParameter.string(mky57amtc));

    	if(!isBlank(mleftj)){
            	sql += "    AND TRIM(MK.MKEFTJ) = ? ";
                params.push(DbParameter.number(cmnUtil.convertDateToJulia(new Date(mleftj))));
            };
    var result = db.execute(sql, params);

    return result;
    
}

/**
 * 商品形態マスタ検索
 * 
 * @param mjy57apcsc 親商品形態コード
 * @param mjy57acsc 商品形態コード
 * @param mjeftj 適用開始日
 **/
MasterMain.getCommodyShape = function(mjy57apcsc, mjy57acsc, mjeftj) {
    var db = new SharedDatabase(_SHARED_DB_KEY);
    var params = [];

    var sql = ""
            + " SELECT * "
            + "   FROM F57A5110 MJ"
            + "  WHERE TRIM(MJ.MJY57ACSC) = ? "
            + "    AND TRIM(MJ.MJY57APCSC) = ? ";

            params.push(DbParameter.string(mjy57acsc));
            params.push(DbParameter.string(mjy57apcsc));

    if(!isBlank(mjeftj)){
    	sql += "    AND TRIM(ML.MJEFTJ) <= ? ";
        params.push(DbParameter.number(cmnUtil.convertDateToJulia(new Date(mjeftj))));
    }

    var result = db.execute(sql, params);

    return result;
}

/**
 * 素材マスタ検索
 * 
 * @param mly57amtc 素材コード
 * @param mly57apcsc 親商品形態コード
 * @param mly57acsc 商品形態コード
 * @param mleftj 適用開始日
 **/
MasterMain.getMaterial = function(mly57amtc, mly57apcsc, mly57acsc, mleftj) {
    var db = new SharedDatabase(_SHARED_DB_KEY);
    var params = [];

    var sql = ""
            + " SELECT * "
            + "   FROM F57A5130 ML"
            + "  WHERE TRIM(ML.MLY57AMTC) = ? "
            + "    AND TRIM(ML.MLY57APCSC) = ? "
            + "    AND TRIM(ML.MLY57ACSC) = ? "

            params.push(DbParameter.string(mly57amtc));
            params.push(DbParameter.string(mly57apcsc));
            params.push(DbParameter.string(mly57acsc));

            if(!isBlank(mleftj)){
                sql += "    AND TRIM(ML.MLEFTJ) <= ? ";
                params.push(DbParameter.number(cmnUtil.convertDateToJulia(new Date(mleftj))));
            }


    var result = db.execute(sql, params);

    return result;
}

/**
 * 品目マスタ検索
 * 
 * @param mly57absc たたみ袋SKUコード
 * @param mleftj 適用開始日
 **/
MasterMain.getBagSku = function(mly57absc, mleftj) {
    var db = new SharedDatabase(_SHARED_DB_KEY);
    var params = [];

    var sql = ""
            + " SELECT * "
            + "   FROM (SELECT TRIM(IM.IMLITM) IMLITM "
            + "               ,NVL(TU.TUEFTJ,113001) TUEFTJ "
            + "               ,NVL(TU.TUEXDJ,140366) TUEXDJ "
            + "           FROM F4101 IM "
            + "                LEFT OUTER JOIN F4016 TU "
            + "                   ON IM.IMITM = TU.TUITM ) ET "
            + "  WHERE ET.IMLITM  = ? ";

            params.push(DbParameter.string(mly57absc));
            
            if(!isBlank(mleftj)){
            	sql += "    AND ET.TUEFTJ <= ? ";
            	sql += "    AND ET.TUEXDJ >= ? ";
                params.push(DbParameter.number(cmnUtil.convertDateToJulia(new Date(mleftj))));
                params.push(DbParameter.number(cmnUtil.convertDateToJulia(new Date(mleftj))));
            }
    var result = db.execute(sql, params);
    return result;
}

/**
 * 加工方法ヘッダマスタキー検索
 * @param mmy57apmc :加工方法コード1
 * @param mmy57apcsc :親商品形態コード2
 * @param mmy57acsc :商品形態コード3
 * @param mmy57amtc :素材コード4
 * @param mmy57appc1 :加工部位コード5
 * @param mmy57appc2 :加工位置コード6
 * @param mmy57apmt :加工方法区分7
 * @param mmeftj ：適用開始日8
 * 適用開始日は設定されていない場合は加工方法コードのみで検索
 */
MasterMain.getProcessMethodHeaderByKey = function(mmy57apmc, mmy57apcsc,mmy57acsc,mmy57amtc, mmy57appc1,mmy57appc2, mmy57apmt, mmeftj){
    var db = new SharedDatabase(_SHARED_DB_KEY);
    var params = [];
    var sql = ""
            + " SELECT * "
            + "   FROM F57A5140 MM "
            + "  WHERE ";
    //加工方法コード
    if(!isBlank(mmy57apmc)){
        sql += "      TRIM(MM.MMY57APMC) = ? ";
        params.push(DbParameter.string(mmy57apmc));
    }
    //親商品形態コード
    if(isBlank(mmy57apmc) && !isBlank(mmy57apcsc)){
        sql += "      TRIM(MM.MMY57APCSC) = ? ";
        params.push(DbParameter.string(mmy57apcsc));
    }else if(!isBlank(mmy57apcsc)){
        sql += "      AND TRIM(MM.MMY57APCSC) = ? ";
        params.push(DbParameter.string(mmy57apcsc));
    }
    //商品形態コード
    if(!isBlank(mmy57acsc)){
        sql += "      AND TRIM(MM.MMY57ACSC) = ? ";
        params.push(DbParameter.string(mmy57acsc));
    }
    //素材コード
    if(!isBlank(mmy57amtc)){
        sql += "      AND TRIM(MM.MMY57AMTC) = ? ";
        params.push(DbParameter.string(mmy57amtc));
    }
    //加工部位コード
    if(!isBlank(mmy57appc1)){
        sql += "      AND TRIM(MM.MMY57APPC1) = ? ";
        params.push(DbParameter.string(mmy57appc1));
    }
    //加工位置コード
    if(!isBlank(mmy57appc2)){
        sql += "      AND TRIM(MM.MMY57APPC2) = ? ";
        params.push(DbParameter.string(mmy57appc2));
    }
    //加工方法区分
    if(!isBlank(mmy57apmt)){
        sql += "      AND TRIM(MM.MMY57APMT) = ? ";
        params.push(DbParameter.string(mmy57apmt));
    }
    //適用開始日
    if(!isBlank(mmeftj)){
        sql += "    AND TRIM(MM.MMEFTJ) = ? ";
        params.push(DbParameter.number(cmnUtil.convertDateToJulia(new Date(mmeftj))));
    }

    var result = db.execute(sql, params);
    return result;
}

/**
 * 加工方法明細マスタキー検索
 * @param mny57apmc :加工方法コード
 * @param mny57ajc1 :第1階層JDEコード
 * @param mny57ajc2 :第2階層JDEコード
 * @param mny57ajc3 :第3階層JDEコード
 * @param mneftj ：適用開始日
 * @param mny57apcsc ：親商品形態コード
 * @param mny57acsc ：商品形態コード
 * @param mny57amtc ：素材コード
 * @param mny57appc1 ：加工部位コード
 * @param mny57appc2 ：加工位置コード
 * @param mny57apmt ：加工区分
 * 
 * 
 * 
 * 適用開始日は設定されていない場合は加工方法コードのみで検索
 */
MasterMain.getProcessMethodDetailByKey = function(mny57apmc,mny57ajc1 ,mny57ajc2,mny57ajc3,mneftj, mny57apcsc, mny57acsc,mny57amtc,mny57appc1, mny57appc2,mny57apmt){
    var db = new SharedDatabase(_SHARED_DB_KEY);
    var params = [];

    var sql = ""
            + " SELECT * "
            + "   FROM F57A5141 MN "
            + "  WHERE TRIM(MN.MNY57APMC) = ? "
            + "      AND TRIM(MN.MNY57AJC1) = ? "
            + "      AND TRIM(MN.MNY57AJC2) = ? "
            + "      AND TRIM(MN.MNY57AJC3) = ? "
            
            + "      AND TRIM(MN.MNY57APCSC) = ? "
            + "      AND TRIM(MN.MNY57ACSC) = ? "
            + "      AND TRIM(MN.MNY57AMTC) = ? "
            + "      AND TRIM(MN.MNY57APPC1) = ? "
            + "      AND TRIM(MN.MNY57APPC2) = ? "
            + "      AND TRIM(MN.MNY57APMT) = ? ";
            


    params.push(DbParameter.string(mny57apmc));
    params.push(DbParameter.string(mny57ajc1));
    params.push(DbParameter.string(mny57ajc2));
    params.push(DbParameter.string(mny57ajc3));

    params.push(DbParameter.string(mny57apcsc));
    params.push(DbParameter.string(mny57acsc));
    params.push(DbParameter.string(mny57amtc));
    params.push(DbParameter.string(mny57appc1));
    params.push(DbParameter.string(mny57appc2));
    params.push(DbParameter.string(mny57apmt));
    
    if(!isBlank(mneftj)){
        sql += "    AND TRIM(MN.MNEFTJ) = ? ";
        params.push(DbParameter.number(cmnUtil.convertDateToJulia(new Date(mneftj))));
    }

    var result = db.execute(sql, params);

    return result;
}

/**
 * 加工方法関連付けマスタキー検索
 * @param mpy57apmc :加工方法コード
 * @param mpy57acc :商品コード
 * @param mpeftj ：適用開始日
 * @param mpy57apcsc ：親商品形態コード
 * @param mpy57acsc ：商品形態コード
 * @param mpy57amtc ：素材コード
 * @param mpy57appc1 ：加工部位コード
 * @param mpy57appc2 ：加工位置コード
 * @param mpy57apmt ：加工区分
 * 適用開始日は設定されていない場合は加工方法コードのみで検索
 */
MasterMain.getProcessMethodCommodityByKey = function(mpy57apmc,mpy57acc ,mpeftj, mpy57apcsc, mpy57acsc,mpy57amtc,mpy57appc1, mpy57appc2,mpy57apmt){
    var db = new SharedDatabase(_SHARED_DB_KEY);
    var params = [];

    var sql = ""
            + " SELECT * "
            + "   FROM F57A5160 MP "
            + "  WHERE TRIM(MP.MPY57APMC) = ? "
            + "      AND TRIM(MP.MPY57ACC) = ? "
            
            + "      AND TRIM(MP.MPY57APCSC) = ? "
            + "      AND TRIM(MP.MPY57ACSC) = ? "
            + "      AND TRIM(MP.MPY57AMTC) = ? "
            + "      AND TRIM(MP.MPY57APPC1) = ? "
            + "      AND TRIM(MP.MPY57APPC2) = ? "
            + "      AND TRIM(MP.MPY57APMT) = ? ";

    params.push(DbParameter.string(mpy57apmc));
    params.push(DbParameter.string(mpy57acc));

    params.push(DbParameter.string(mpy57apcsc));
    params.push(DbParameter.string(mpy57acsc));
    params.push(DbParameter.string(mpy57amtc));
    params.push(DbParameter.string(mpy57appc1));
    params.push(DbParameter.string(mpy57appc2));
    params.push(DbParameter.string(mpy57apmt));
    
    if(!isBlank(mpeftj)){
        sql += "    AND TRIM(MP.MPEFTJ) = ? ";
        params.push(DbParameter.number(cmnUtil.convertDateToJulia(new Date(mpeftj))));
    }

    var result = db.execute(sql, params);

    return result;
}

/**
 * ボディ非推奨管理マスタキー検索
 * 
 * @param mqy57apcsc ：親商品形態コード
 * @param mqy57acsc ：商品形態コード
 * @param mqy57amtc ：素材コード
 * @param mqy57appc1 ：加工部位コード
 * @param mqy57appc2 ：加工位置コード
 * @param mqy57apmt ：加工方法区分
 * @param mqy57apmdt ：加工方法明細区分
 * @param mqy57apmd1 :加工方法明細第1階層コード
 * @param mqy57apmd2 :加工方法明細第2階層コード
 * @param mqy57apmd3 :加工方法明細第3階層コード
 * @param mqy57aitcd ：商品コード
 * @param mqy57asc ：サイズコード
 * @param mqy57anrt ：非推奨区分
 * @param mqeftj ：適用開始日
 * 
 */
MasterMain.getBodyNotRecommendedByPk = function(mqy57apcsc, mqy57acsc, mqy57amtc, mqy57appc1, mqy57appc2,
                                                mqy57apmt, mqy57apmdt, mqy57apmd1, mqy57apmd2, mqy57apmd3,
                                                mqy57aitcd, mqy57asc, mqy57anrt, mqeftj) {
    var db = new SharedDatabase(_SHARED_DB_KEY);
    var params = [];
    
    var sql = ""
            + " SELECT * "
            + "   FROM F57A5170 MQ "
            + "  WHERE TRIM(MQ.MQY57APCSC) = ? "
            + "    AND TRIM(MQ.MQY57ACSC) = ? "
            + "    AND TRIM(MQ.MQY57AMTC) = ? "
            + "    AND TRIM(MQ.MQY57APPC1) = ? "
            + "    AND TRIM(MQ.MQY57APPC2) = ? "
            + "    AND TRIM(MQ.MQY57APMT) = ? "
            + "    AND TRIM(MQ.MQY57APMDT) = ? "
            + "    AND TRIM(MQ.MQY57APMD1) = ? "
            + "    AND TRIM(MQ.MQY57APMD2) = ? "
            + "    AND TRIM(MQ.MQY57APMD3) = ? "
            + "    AND TRIM(MQ.MQY57AITCD) = ? "
            + "    AND TRIM(MQ.MQY57ASC) = ? "
            + "    AND TRIM(MQ.MQY57ANRT) = ? "
            + "    AND TRIM(MQ.MQEFTJ) = ? ";
    
    params.push(DbParameter.string(mqy57apcsc));
    params.push(DbParameter.string(mqy57acsc));
    params.push(DbParameter.string(mqy57amtc));
    params.push(DbParameter.string(mqy57appc1));
    params.push(DbParameter.string(mqy57appc2));
    params.push(DbParameter.string(mqy57apmt));
    params.push(DbParameter.string(mqy57apmdt));
    params.push(DbParameter.string(mqy57apmd1));
    params.push(DbParameter.string(mqy57apmd2));
    params.push(DbParameter.string(mqy57apmd3));
    params.push(DbParameter.string(mqy57aitcd));
    params.push(DbParameter.string(mqy57asc));
    params.push(DbParameter.string(mqy57anrt));
    params.push(DbParameter.number(cmnUtil.convertDateToJulia(new Date(mqeftj))));
    
    var result = db.execute(sql, params);
    
    return result;
}

/**
 * 加工方法ヘッダ存在チェック
 * @param mmy57apmc 加工方法コード
 * @param mmy57apcsc 親商品形態コード
 * @param mmy57acsc 商品形態コード
 * @param mmy57amtc 素材コード
 * @param mmy57appc1 加工部位コード
 * @param mmy57appc2 加工位置コード
 * @param mmy57apmt 加工方法区分
 * @param mmy57adflg 削除フラグ
 * @param mmeftj 適用開始日(YYYY/MM/DD)
 */
MasterMain.selectF57A5140 = function(mmy57apmc, mmy57apcsc, mmy57acsc, mmy57amtc, mmy57appc1, mmy57appc2, mmy57apmt, mmy57adflg, mmeftj){
    var db = new SharedDatabase(_SHARED_DB_KEY);
    var params = {};
    
    var param_mmy57apmc = isBlank(mmy57apmc) ? null: DbParameter.string(mmy57apmc);
    var param_mmy57apcsc = isBlank(mmy57apcsc) ? null: DbParameter.string(mmy57apcsc);
    var param_mmy57acsc = isBlank(mmy57acsc) ? null: DbParameter.string(mmy57acsc);
    var param_mmy57amtc = isBlank(mmy57amtc) ? null: DbParameter.string(mmy57amtc);
    var param_mmy57appc1 = isBlank(mmy57appc1) ? null: DbParameter.string(mmy57appc1);
    var param_mmy57appc2 = isBlank(mmy57appc2) ? null: DbParameter.string(mmy57appc2);
    var param_mmy57apmt = isBlank(mmy57apmt) ? null: DbParameter.string(mmy57apmt);
    var param_mmy57adflg = isBlank(mmy57adflg) ? null: DbParameter.number(new Number(mmy57adflg));
    var param_mmeftj = isBlank(mmeftj) ? null: DbParameter.number(cmnUtil.convertDateToJulia(new Date(mmeftj)));

    params = {
    	mmy57apmc : param_mmy57apmc,
	    mmy57apcsc : param_mmy57apcsc,
	    mmy57acsc : param_mmy57acsc,
	    mmy57amtc : param_mmy57amtc,
	    mmy57appc1 : param_mmy57appc1,
	    mmy57appc2 : param_mmy57appc2,
	    mmy57apmt : param_mmy57apmt,
	    mmy57adflg : param_mmy57adflg,
	    mmeftj : param_mmeftj
    };

    var result = database.executeByTemplate('toms/sql/selectA57A5140', params);
	return result;
}

/**
 * 加工方法明細存在チェック
 * @param mny57apcsc 親商品形態コード
 * @param mny57acsc 商品形態コード
 * @param mny57amtc 素材コード
 * @param mny57appc1 加工部位コード
 * @param mny57appc2 加工位置コード
 * @param mny57apmt 加工方法区分
 * @param mny57apmdt 加工方法明細区分
 * @param mny57ajc1 第1階層JDEコード
 * @param mny57ajc2 第2階層JDEコード
 * @param mny57ajc3 第3階層JDEコード
 */
MasterMain.selectF57A5141 = function(mny57apcsc, mny57acsc, mny57amtc, mny57appc1, mny57appc2,
                                     mny57apmt, mny57apmdt, mny57ajc1, mny57ajc2, mny57ajc3) {
    var db = new SharedDatabase(_SHARED_DB_KEY);
    var params = {};
    
    var param_mny57apcsc = isBlank(mny57apcsc) ? null: DbParameter.string(mny57apcsc);
    var param_mny57acsc = isBlank(mny57acsc) ? null: DbParameter.string(mny57acsc);
    var param_mny57amtc = isBlank(mny57amtc) ? null: DbParameter.string(mny57amtc);
    var param_mny57appc1 = isBlank(mny57appc1) ? null: DbParameter.string(mny57appc1);
    var param_mny57appc2 = isBlank(mny57appc2) ? null: DbParameter.string(mny57appc2);
    var param_mny57apmt = isBlank(mny57apmt) ? null: DbParameter.string(mny57apmt);
    var param_mny57apmdt = isBlank(mny57apmdt) ? null: DbParameter.string(mny57apmdt);
    var param_mny57ajc1 = isBlank(mny57ajc1) ? null: DbParameter.string(mny57ajc1);
    var param_mny57ajc2 = isBlank(mny57ajc2) ? null: DbParameter.string(mny57ajc2);
    var param_mny57ajc3 = isBlank(mny57ajc3) ? null: DbParameter.string(mny57ajc3);
    
    params = {
        mny57apcsc : param_mny57apcsc,
        mny57acsc : param_mny57acsc,
        mny57amtc : param_mny57amtc,
        mny57appc1 : param_mny57appc1,
        mny57appc2 : param_mny57appc2,
        mny57apmt : param_mny57apmt,
        mny57apmdt : param_mny57apmdt,
        mny57ajc1 : param_mny57ajc1,
        mny57ajc2 : param_mny57ajc2,
        mny57ajc3 : param_mny57ajc3
    };

    var result = db.executeByTemplate('toms/sql/selectA57A5141', params);
	return result;
}

/**
 * サイズ（ユーザ定義マスタ）検索
 * 
 * @param mqy57asc サイズコード
 */
MasterMain.getSize = function(mqy57asc) {
    var db = new SharedDatabase(_SHARED_DB_KEY);
    var params = [];
    
    var sql = ""
            + " SELECT * "
            + "   FROM F0005 DR "
            + "  WHERE DR.DRSY = RPAD('41F', 4) "
            + "    AND DR.DRRT = RPAD('1S', 2) "
            + "    AND DR.DRKY = LPAD(?, 10) ";
    
    params.push(DbParameter.string(mqy57asc));
    
    var result = db.execute(sql, params);
    
    return result;
}

/**
 * 加工方法区分チェック
 * @param processMethodType
 * 定義ファイルTOMS.MASTER.MAINTENANCE.PROCESS_METHOD_DATAから
 * 選択可能なコード値のリストを生成し、一致するかどうかチェックを行う
 */
MasterMain.checkProcessMethodType = function(processMethodType){
	var flg = false;
	var strList = MessageManager.getMessage('TOMS.MASTER.MAINTENANCE.PROCESS_METHOD_DATA');
	var splitList = strList.split(',');
	if(!isBlank(processMethodType)){
		for(var i=0;i<splitList.length;i++){
			var tmpData = splitList[i].split(':');
			if(processMethodType == tmpData[0]){
				flg = true;
				return flg;
			}
		}
		
	}
	return flg;
}

/**
 * 加工方法明細区分チェック
 * @param processMethodType
 * 定義ファイルTOMS.MASTER.MAINTENANCE.PROCESS_METHOD_DETAIL_DATAから
 * 選択可能なコード値のリストを生成し、一致するかどうかチェックを行う
 */
MasterMain.checkProcessMethodDetailType = function(processMethodType){
	var flg = false;
	var strList = MessageManager.getMessage('TOMS.MASTER.MAINTENANCE.PROCESS_METHOD_DETAIL_DATA');
	var splitList = strList.split(',');
	if(!isBlank(processMethodType)){
		for(var i=0;i<splitList.length; i++){
			var tmpData = splitList[i].split(':');
			if(processMethodType == tmpData[0]){
				flg = true;
				return flg;
			}
		}
		
	}
	return flg;
}

/**
 * 非推奨区分チェック
 * 
 * @param notRecommendedDivide
 * 定義ファイル TOMS.MASTER.MAINTENANCE.NOT_RECOMMENDED_DIVIDE から
 * 選択可能なコード値のリストを生成し、一致するかどうかチェックを行う
 */
MasterMain.checkNotRecommendedDivide = function(notRecommendedDivide) {
    var flg = false;
    var strList = MessageManager.getMessage('TOMS.MASTER.MAINTENANCE.NOT_RECOMMENDED_DIVIDE');
    var splitList = strList.split(',');
    if (!isBlank(notRecommendedDivide)) {
        for (var i = 0; i < splitList.length; i++) {
            var tmpData = splitList[i].split(':');
            if (notRecommendedDivide == tmpData[0]) {
                flg = true;
                return flg;
            }
        }
        
    }
    return flg;
}

/**
 * 加工明細判定区分チェック
 * 
 * @param processDetailJudgeDecision
 * 定義ファイル TOMS.MASTER.MAINTENANCE.PROCESS_DETAIL_JUDGE_DECISION_DATA から
 * 選択可能なコード値のリストを生成し、一致するかどうかチェックを行う
 */
MasterMain.checkProcessDetailJudgeType = function(processDetailJudgeDecision) {
    var flg = false;
    var strList = MessageManager.getMessage('TOMS.MASTER.MAINTENANCE.PROCESS_DETAIL_JUDGE_DECISION_DATA');
    var splitList = strList.split(',');
    if (!isBlank(processDetailJudgeDecision)) {
        for (var i = 0; i < splitList.length; i++) {
            var tmpData = splitList[i].split(':');
            if (processDetailJudgeDecision == tmpData[0]) {
                flg = true;
                return flg;
            }
        }
        
    }
    return flg;
}

/**
 * 加工明細コード管理マスタキー検索
 * 
 * @param y57apcsc ：親商品形態コード
 * @param y57acsc ：商品形態コード
 * @param y57amtc ：素材コード
 * @param y57appc1 ：加工部位コード
 * @param y57appc2 ：加工位置コード
 * @param y57apmt ：加工方法区分
 * @param y57apmdt ：加工方法明細区分
 * @param y57apmd1 :加工方法明細第1階層コード
 * @param y57apmd2 :加工方法明細第2階層コード
 * @param y57apmd3 :加工方法明細第3階層コード
 * @param y57apdjt ：加工明細区分
 * @param uorg ：数量
 * @param eftj ：適用開始日
 * 
 */
MasterMain.getProcessDetailCodePk = function(y57apcsc, y57acsc, y57amtc, y57appc1, y57appc2,
                                                y57apmt, y57apmdt, y57apmd1, y57apmd2, y57apmd3,
                                                y57apdjt, uorg, eftj) {
    var db = new SharedDatabase(_SHARED_DB_KEY);
    var params = [];
    
    var sql = ""
            + " SELECT * "
            + "   FROM F57A5180 MR "
            + "  WHERE TRIM(MR.MRY57APCSC) = ? "
            + "    AND TRIM(MR.MRY57ACSC) = ? "
            + "    AND TRIM(MR.MRY57AMTC) = ? "
            + "    AND TRIM(MR.MRY57APPC1) = ? "
            + "    AND TRIM(MR.MRY57APPC2) = ? "
            + "    AND TRIM(MR.MRY57APMT) = ? "
            + "    AND TRIM(MR.MRY57APMDT) = ? "
            + "    AND TRIM(MR.MRY57APMD1) = ? "
            + "    AND TRIM(MR.MRY57APMD2) = ? "
            + "    AND TRIM(MR.MRY57APMD3) = ? "
            + "    AND TRIM(MR.MRY57APDJT) = ? "
            + "    AND TRIM(MR.MRUORG) = ? "
            + "    AND TRIM(MR.MREFTJ) = ? ";
    
    params.push(DbParameter.string(y57apcsc));
    params.push(DbParameter.string(y57acsc));
    params.push(DbParameter.string(y57amtc));
    params.push(DbParameter.string(y57appc1));
    params.push(DbParameter.string(y57appc2));
    params.push(DbParameter.string(y57apmt));
    params.push(DbParameter.string(y57apmdt));
    params.push(DbParameter.string(y57apmd1));
    params.push(DbParameter.string(y57apmd2));
    params.push(DbParameter.string(y57apmd3));
    params.push(DbParameter.string(y57apdjt));
    params.push(DbParameter.number(new Number(uorg)));
    params.push(DbParameter.number(cmnUtil.convertDateToJulia(new Date(eftj))));
    
    var result = db.execute(sql, params);
    
    return result;
}