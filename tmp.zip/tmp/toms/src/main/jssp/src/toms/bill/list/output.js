/**
 * バインド変数.
 */
var $bind = {};

var $data = {};

// CSVの区切り文字（カンマ）
var splitComma = MessageManager.getMessage('TOMS.COMMON.COMMA');

/**
 * 初期表示.
 * @param request リクエストパラメータ.
 */
function init(request) {
	load("toms/common/master");
	load("toms/common/common");
	
	$data = {
		rowNum  : 12,
		rowList : [12, 24, 36]
	};
	
    // CSV出力処理の場合
    if (request.screenId == "outputCSV") {
    	
    	var exchangeTargetCode = request.csv_exchangeTargetCode;
    	var exchangeTargetKana = request.csv_exchangeTargetKana;
    	var paymentPersonCode = request.csv_paymentPersonCode;
    	var paymentPersonKana = request.csv_paymentPersonKana;
    	
    	outputCSV(exchangeTargetCode, exchangeTargetKana, paymentPersonCode, paymentPersonKana);
    } else {
    	$bind.exchangeTargetCode = request.exchangeTargetCode;
    	$bind.exchangeTargetKana = request.exchangeTargetKana;
    	$bind.paymentPersonCode = request.paymentPersonCode;
    	$bind.paymentPersonKana = request.paymentPersonKana;
    	
        // 「ファイル出力」ボタン押下時の確認ダイアログのメッセージを初期化.
        // JavaScriptで利用するためオブジェクトの内容をそのまま渡します.
        $bind.dialogMessages = ({
          addConfirmTitle: MessageManager.getMessage('TOMS.COMMON.DIALOG.CONFIRM.TITLE'),
          addConfirmMessage: MessageManager.getMessage('TOMS.COMMON.DIALOG.CONFIRM.MESSAGE.COMMA')
        }).toSource();
    }
}

/**
 * 請求書一覧のCSV出力処理.
 * 
 * @param exchangeTargetCode 取引先コード.
 * @param exchangeTargetKana 販売先カナ.
 * @param paymentPersonCode 支払人コード.
 * @param paymentPersonKana 支払人カナ.
 */
function outputCSV(exchangeTargetCode, exchangeTargetKana, paymentPersonCode, paymentPersonKana) {
    var result = TomsMaster.getRequestBillList(exchangeTargetCode, exchangeTargetKana, paymentPersonCode, paymentPersonKana, false);
    var outputContent = "";
    if (!result.error) {
        outputContent = outputCSVHeader();
        for (var i = 0; i < result.countRow; i++) {
            outputContent += outputCSVRow(result.data[i]);
        }
        var strDateTime = DateTimeFormatter.format("yyyyMMddHHmmss", new Date());
        var fileName = MessageManager.getMessage('TOMS.BILL.LIST.LABEL.TITLE') + '_' + strDateTime + '.csv';
        Module.download.send(Unicode.to(outputContent, 'MS932'), fileName, MessageManager.getMessage('TOMS.COMMON.MIME.CSV'));
    } else {
        errorcsv(result.errorMessage);
    }
}

/**
 * 請求書一覧のCSVヘッダ部分出力処理.
 */
function outputCSVHeader() {
    var outputHeader = common.convertWithSplit(MessageManager.getMessage('TOMS.BILL.LIST.LABEL.HEADER.TARGET.YEAR'), splitComma, true)					// 締年月
                       + common.convertWithSplit(MessageManager.getMessage('TOMS.BILL.LIST.LABEL.HEADER.EXCHANGETARGET.KANA'), splitComma, true)		// 販売先カナ
                       + common.convertWithSplit(MessageManager.getMessage('TOMS.BILL.LIST.LABEL.HEADER.EXCHANGETARGET.NAME'), splitComma, true)		// 販売先
                       + common.convertWithSplit(MessageManager.getMessage('TOMS.BILL.LIST.LABEL.HEADER.EXCHANGETARGET.CODE'), splitComma, true)		// 販売先コード
                       + common.convertWithSplit(MessageManager.getMessage('TOMS.BILL.LIST.LABEL.HEADER.PAYMENTPERSON.CODE'), splitComma, true)			// 支払人コード
                       + common.convertWithSplit(MessageManager.getMessage('TOMS.BILL.LIST.LABEL.HEADER.PAYMENTCONDITION'), splitComma, true)			// 支払条件
                       + common.convertWithSplit(MessageManager.getMessage('TOMS.BILL.LIST.LABEL.HEADER.DEPARTMENT.NAME'), splitComma, true)			// 部門
                       + common.convertWithSplit(MessageManager.getMessage('TOMS.BILL.LIST.LABEL.HEADER.CHARGEPERSON'), splitComma, true)				// 営業担当者
                       + common.convertWithSplit(MessageManager.getMessage('TOMS.BILL.LIST.LABEL.HEADER.FACTORING.DIVIDE'), splitComma, true)			// ファクタリング区分
                       + common.convertWithSplit(MessageManager.getMessage('TOMS.BILL.LIST.LABEL.HEADER.LASTTIME.REQUEST.ACCOUNT'), splitComma, true)	// 前回請求額
                       + common.convertWithSplit(MessageManager.getMessage('TOMS.BILL.LIST.LABEL.HEADER.THISMONTH.ACCOUNT'), splitComma, true)			// 当月入金額
                       + common.convertWithSplit(MessageManager.getMessage('TOMS.BILL.LIST.LABEL.HEADER.RECEIVE.RATE'), splitComma, true)				// 回収率
                       + common.convertWithSplit(MessageManager.getMessage('TOMS.BILL.LIST.LABEL.HEADER.REMAIN.ACCOUNT'), splitComma, true)			// 繰越残高
                       + common.convertWithSplit(MessageManager.getMessage('TOMS.BILL.LIST.LABEL.HEADER.NOTAX.SALE.ACCOUNT'), splitComma, true)			// 税抜売上額
                       + common.convertWithSplit(MessageManager.getMessage('TOMS.BILL.LIST.LABEL.HEADER.SALE.TAX.ACCOUNT'), splitComma, true)			// 消費税額
                       + common.convertWithSplit(MessageManager.getMessage('TOMS.BILL.LIST.LABEL.HEADER.SALE.ACCOUNT'), splitComma, true)				// 税込売上額
                       + common.convertWithSplit(MessageManager.getMessage('TOMS.BILL.LIST.LABEL.HEADER.THISTIME.REQUEST.ACCOUNT'), splitComma, false)	// 今回請求額
	return outputHeader;
}

/**
 * 請求書一覧のCSVファイルの行を出力する処理.
 * 
 * @param record DBから検索した行のデータ.
 */
function outputCSVRow(record) {
    var result = common.convertWithSplit(record["tdy56ccym"], splitComma, true)		// 締年月
                + common.convertWithSplit(record["abdc"], splitComma, true)			// 販売先カナ
                + common.convertWithSplit(record["abalph"], splitComma, true)		// 販売先
                + common.convertWithSplit(record["tdpyr"], splitComma, true)		// 販売先コード
                + common.convertWithSplit(record["aiarpy"], splitComma, true)		// 支払人コード
                + common.convertWithSplit(record["pnptd"], splitComma, true)		// 支払条件
                + common.convertWithSplit(record["mcdl01"], splitComma, true)		// 部門
                + common.convertWithSplit(record["wwalph"], splitComma, true)		// 営業担当者
                + common.convertWithSplit(record["tdy56crsd"], splitComma, true)	// ファクタリング区分
                + common.convertWithSplit(record["tdy56cpbl"], splitComma, true)	// 前回請求額
                + common.convertWithSplit(record["tdy56ccda"], splitComma, true)	// 当月入金額
                + common.convertWithSplit(record["rate"], splitComma, true)			// 回収率
                + common.convertWithSplit(record["tdy56cbbf"], splitComma, true)	// 繰越残高
                + common.convertWithSplit(record["tdy56ccba"], splitComma, true)	// 税抜売上額
                + common.convertWithSplit(record["tdy56cta"], splitComma, true)		// 消費税額
                + common.convertWithSplit(record["sumcbata"], splitComma, true)		// 税込売上額
                + common.convertWithSplit(record["tdy56ccbi"], splitComma, false)	// 今回請求額
    return result;
}

/**
 * エラー画面へ遷移の処理.
 */
function error(message) {
  Transfer.toErrorPage({
    title: MessageManager.getMessage('TOMS.COMMON.ERROR.PAGE.TITLE'),
    message: MessageManager.getMessage('TOMS.COMMON.ERROR.MESSAGE.SYSTEM'),
    detail: [MessageManager.getMessage('TOMS.BILL.LIST.LABEL.MESSAGE.ERROR'), message],
    returnUrl: 'toms/bill/search/input', // 戻り先 URL
    returnUrlLabel: MessageManager.getMessage('TOMS.BILL.LIST.LABEL.RETURN.LINK.NAME'),
    parameter: {
    }
  });
}
