/**
 * 商品形態マスタメンテナンスvalidation設定
 */

 var init={
	 'parentFlg':{// 商品形態選択ラジオ
	caption: 'TOMS.MASTER.MAINTENANCE.COMMODITYSHAPE.LABEL.COMMODITY_SHAPE_SELECT', 
    required: true // 必須チェック
 	},
 	'mjy57acsc':{//商品形態コード
 	caption:'TOMS.MASTER.MAINTENANCE.COMMODITYSHAPE.LABEL.COMMODITY_SHAPE_CODE',
    required: true, // 必須チェック
	alphanumeric: true,
    maxlength: 16
 	},
 	'mjy57apcsc':{//親商品形態コード
 	caption:'TOMS.MASTER.MAINTENANCE.COMMODITYSHAPE.LABEL.PARENT_COMMODITY_SHAPE_CODE',
    required: true, // 必須チェック
	alphanumeric: true,
    maxlength: 16
 	},
 	'mjdl01':{//商品形態名称
 	caption:'TOMS.MASTER.MAINTENANCE.COMMODITYSHAPE.LABEL.COMMODITY_SHAPE_NAME',
    required: true, // 必須チェック
    maxlength: 30
 	},
 	'mjsnn':{//表示順
 	caption:'TOMS.MASTER.MAINTENANCE.COMMODITYSHAPE.LABEL.DISPLAY_ORDER',
    numeric: true, // 数字チェック
    maxlength: 8
 	},
// 	'mjy57ajdc':{//JDEコード 
// 	caption:'TOMS.MASTER.MAINTENANCE.COMMODITYSHAPE.LABEL.JDE_CODE',
//    required: true, // 必須チェック
//	alphanumeric: true,
//    maxlength: 8
// 	}, 	
 	'mjeftj':{//有効開始日 
 	caption:'TOMS.MASTER.MAINTENANCE.COMMODITYSHAPE.LABEL.APPLIED_START_DATE',
    required: true, // 必須チェック
	date: true,
    maxlength: 10
 	}, 
 	'mjexdj':{//有効終了日 
 	caption:'TOMS.MASTER.MAINTENANCE.COMMODITYSHAPE.LABEL.APPLIED_END_DATE',
	date: true,
    maxlength: 10
 	}
 }
 
 var search = {
	 	'search-mjy57acsc':{//商品形態コード
	 	caption:'TOMS.MASTER.MAINTENANCE.COMMODITYSHAPE.LABEL.COMMODITY_SHAPE_CODE',
	    maxlength: 16
	 	},
	 	'search-mjy57apcsc':{//親商品形態コード
	 	caption:'TOMS.MASTER.MAINTENANCE.COMMODITYSHAPE.LABEL.PARENT_COMMODITY_SHAPE_CODE',
		alphanumeric: true,
	    maxlength: 16
	 	},
	 	'search-mjdl01':{//商品形態名称
	 	caption:'TOMS.MASTER.MAINTENANCE.COMMODITYSHAPE.LABEL.COMMODITY_SHAPE_NAME',
	    maxlength: 30
	 	},
	 	'search-mjy57ajdc':{//JDEコード 
	 	caption:'TOMS.MASTER.MAINTENANCE.COMMODITYSHAPE.LABEL.JDE_CODE',
		alphanumeric: true,
	    maxlength: 8
	 	}, 	
	 	'search-mjeftj':{//有効開始日 
	 	caption:'TOMS.MASTER.MAINTENANCE.COMMODITYSHAPE.LABEL.APPLIED_START_DATE',
		date: true,
	    maxlength: 10
	 	}, 
	 	'search-mjexdj':{//有効終了日 
	 	caption:'TOMS.MASTER.MAINTENANCE.COMMODITYSHAPE.LABEL.APPLIED_END_DATE',
		date: true,
	    maxlength: 10
	 	}
	 }
 
  var parent={
	 'parentFlg':{// 商品形態選択ラジオ
	caption: 'TOMS.MASTER.MAINTENANCE.COMMODITYSHAPE.LABEL.COMMODITY_SHAPE_SELECT', 
    required: true // 必須チェック
 	},
 	'mjy57acsc':{//商品形態コード
 	caption:'TOMS.MASTER.MAINTENANCE.COMMODITYSHAPE.LABEL.COMMODITY_SHAPE_CODE',
    required: true, // 必須チェック
	alphanumeric: true,
    maxlength: 16
 	},

 	'mjdl01':{//商品形態名称
 	caption:'TOMS.MASTER.MAINTENANCE.COMMODITYSHAPE.LABEL.COMMODITY_SHAPE_NAME',
    required: true, // 必須チェック
    maxlength: 30
 	},
 	'mjsnn':{//表示順
 	caption:'TOMS.MASTER.MAINTENANCE.COMMODITYSHAPE.LABEL.DISPLAY_ORDER',
    numeric: true, // 数字チェック
    maxlength: 8
 	},
 	'mjeftj':{//有効開始日 
 	caption:'TOMS.MASTER.MAINTENANCE.COMMODITYSHAPE.LABEL.APPLIED_START_DATE',
    required: true, // 必須チェック
	date: true,
    maxlength: 10
 	}, 
 	'mjexdj':{//有効終了日 
 	caption:'TOMS.MASTER.MAINTENANCE.COMMODITYSHAPE.LABEL.APPLIED_END_DATE',
	date: true,
    maxlength: 10
 	}
 }
