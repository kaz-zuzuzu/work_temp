/**
 * 加工方法明細マスタメンテナンス一覧（STEP2）
 *
 **/

 var $bind ={};
 
 var $data={};
 load("toms/common/common");
 	

/**
 * 初期表示
 * @param request リクエストパラメータ
 */
function init(request){

	$bind.dialogMessages="";

	$data = {
		pageNum : isBlank(request.pageNum) ? '1' : request.pageNum,
		rowNum  : isBlank(request.rowNum) ? '30' : request.rowNum,
		rowList : isBlank(request.rowList) ? '30, 50, 100' : request.rowList
	};
	
	//加工方法区分生成
	var processMethodData = MessageManager.getMessage('TOMS.MASTER.MAINTENANCE.PROCESS_METHOD_DATA')
	var splitData = processMethodData.split(',');
	var processMethodList =[]; 
	for(var i=0; i<splitData.length;i++){
		var selectFlg = "false";
		var data = splitData[i].split(':');
		if(!isBlank(request.mmy57apmt)){
			if(request.mmy57apmt==data[0]){
				selectFlg = "true";
			}
		}
		var listObj = {
		               label:data[1],
		               value:data[0],
		               selected : selectFlg
		};
		processMethodList.push(listObj);
	}
	$bind.processMethodList = processMethodList;	

	//加工方法明細区分生成
	var processMethodDetailData = MessageManager.getMessage('TOMS.MASTER.MAINTENANCE.PROCESS_METHOD_DETAIL_DATA')
	splitData = processMethodDetailData.split(',');
	var processMethodDetailList =[];
	for(var i=0; i <splitData.length;i++){
		var data = splitData[i].split(':');
		var listObj =null;
		var selectFlg = "false";
//		if(!isBlank(request.mny57apmdt)){
//			if(request.mny57apmdt==data[0]){
//				selectFlg = "true";
//			}
//		}
		listObj = {
		           label : data[1],
		           value:data[0]
//		           selected:selectFlg
		}
			processMethodDetailList.push(listObj);
		
	}
	$bind.processMethodDetailList = processMethodDetailList;

	//ダウrンロード用検索条件

	var csvObj;
	if (request.csvFlag == "1") {
		csvObj ={
//			mny57apmc : isBlank(request.mny57apmc) ? "":request.mny57apmc,//加工方法コード,

            mndl01 : isBlank(request.mndl01) ? "":request.mndl01,//加工方法名称,
            mny57apcsc : isBlank(request.mny57apcsc) ? "":request.mny57apcsc,//親商品形態コード,
            mny57apcscName : isBlank(request.mny57apcscName) ? "":request.mny57apcscName,//親商品形態名称,
            mny57acsc : isBlank(request.mny57acsc) ? "":request.mny57acsc,//商品形態コード,
            mny57acscName : isBlank(request.mny57acscName) ? "":request.mny57acscName,//商品形態名称,
            mny57amtc : isBlank(request.mny57amtc) ? "":request.mny57amtc,//素材コード,
            mny57amtcName : isBlank(request.mny57amtcName) ? "":request.mny57amtcName,//原材料名,
            mny57appc1 : isBlank(request.mny57appc1) ? "":request.mny57appc1,//加工部位コード,
            mny57appc1Name : isBlank(request.mny57appc1Name) ? "":request.mny57appc1Name,//加工部位名称コード,
            mny57appc2 : isBlank(request.mny57appc2) ? "":request.mny57appc2,//加工位置コード,
            mny57appc2Name : isBlank(request.mny57appc2Name) ? "":request.mny57appc2Name,//加工位置名称,
            mny57apmt : isBlank(request.mny57apmt) ? "":request.mny57apmt,//加工方法区分,
            mny57apmdt : isBlank(request.mny57apmdt) ? "":request.mny57apmdt,//加工方法明細区分,
            mny57apmn1 : isBlank(request.mny57apmn1) ? "":request.mny57apmn1,//第1階層名称
            mny57ado1 : isBlank(request.mny57ado1) ? "":request.mny57ado1,//第1階層表示順
            mny57ajc1 : isBlank(request.mny57ajc1) ? "":request.mny57ajc1,//第1階層JDEコード
            mny57agn1 : isBlank(request.mny57agn1) ? "":request.mny57agn1,//第1階層グループ名称
            mny57apmn2 : isBlank(request.mny57apmn2) ? "":request.mny57apmn2,//第2階層名称
            mny57ado2 : isBlank(request.mny57ado2) ? "":request.mny57ado2,//第2階層表示順
            mny57ajc2 : isBlank(request.mny57ajc2) ? "":request.mny57ajc2,//第2階層JDEコード
            mny57agn2 : isBlank(request.mny57agn2) ? "":request.mny57agn2,//第2階層グループ名称
            mny57apmn3 : isBlank(request.mny57apmn3) ? "":request.mny57apmn3,//第3階層名称
            mny57ado3 : isBlank(request.mny57ado3) ? "":request.mny57ado3,//第3階層表示順
            mny57ajc3 : isBlank(request.mny57ajc3) ? "":request.mny57ajc3,//第3階層JDEコード
            mny57agn3 : isBlank(request.mny57agn3) ? "":request.mny57agn3,//第3階層グループ名称
            mneftj : isBlank(request.mneftj) ? "":request.mneftj,//適用開始日
            mneftj2 : isBlank(request.mneftj2) ? "":request.mneftj2,//適用開始日
            mny57adflg : isBlank(request.mny57adflg) ? "":request.mny57adflg
		};

        outputCSV(csvObj);
	}
	
	$bind.checked1 = true; 	
	$bind.checked2 = false;
	$bind.checked3 	=false;

	$bind.dispChecked1 = true; 	
	$bind.dispChecked2 = false;
	$bind.dispChecked3 	=false;
	
	//画面項目
	$bind.select_notdelete=MessageManager.getMessage('TOMS.COMMON.DELETE.SELECT.NOTDELETE');
	$bind.select_delete=MessageManager.getMessage('TOMS.COMMON.DELETE.SELECT.DELETE');
	$bind.select_all=MessageManager.getMessage('TOMS.COMMON.DELETE.SELECT.ALL');

	$bind.message_disp=MessageManager.getMessage('TOMS.COMMON.DISPFLAG.ONLY');
	$bind.message_notdisp=MessageManager.getMessage('TOMS.COMMON.DISPFLAG.NOT_DISP');
	$bind.message_alldisp=MessageManager.getMessage('TOMS.COMMON.DISPFLAG.ALL_DISP');
	
	$bind.control_notcontrol=MessageManager.getMessage('TOMS.COMMON.CONTROL.SELECT.NOTCONTROL');
	$bind.control_control=MessageManager.getMessage('TOMS.COMMON.CONTROL.SELECT.CONTROL');
	$bind.control_all=MessageManager.getMessage('TOMS.COMMON.CONTROL.SELECT.ALL');


  $bind.dialogMessages = ({
    addConfirmTitle: MessageManager.getMessage('TOMS.COMMON.DIALOG.CONFIRM.TITLE'),
    addConfirmMessage: MessageManager.getMessage('TOMS.COMMON.DIALOG.CONFIRM.MESSAGE')
  }).toSource();

}

/**
 * 加工方法明細マスタメンテナンス(STEP2)のCSV出力処理
 * 
 * @param　リクエストパラメータ
 * 
 */
function outputCSV(param){
    load("toms/common/processMethod");
	var result = ProcessMethod.getDetailAllList(param, false, null,null);
	var outputContent = "";
	if (!result.error) {
		outputContent = outputCSVHeader();
    	for(var i = 0; i < result.countRow; i++) {
    		outputContent += outputCSVRow(result.data[i]);
    	}
    	var strDate = DateTimeFormatter.format("yyyyMMdd_HHmmss", new Date());
    	var strUserName = Contexts.getUserContext().userProfile.userName;
    	var fileName = MessageManager.getMessage('TOMS.MASTER.MAINTENANCE.PROCESSMETHOD_DETAIL.DETAIL.INPUT.TITLE') + '_' + strDate + '_' + strUserName + '.csv';
    	Module.download.send(Unicode.to(outputContent, 'MS932'), fileName, MessageManager.getMessage('TOMS.COMMON.MIME.CSV'));
	} else {
		error(result.errorMessage);
	}
}

/**
 * 加工方法明細マスタメンテナンスのCSVヘッダ部分出力処理。
 */
function outputCSVHeader() {
	var outputHeader = common.convert(MessageManager.getMessage('TOMS.COMMON.CSV.UPDATE.DIVIDE'), true)
	  + common.convert(MessageManager.getMessage('TOMS.MASTER.MAINTENANCE.PROCESSMETHOD_HEADER.LABEL.PROCESS_METHOD_CODE'), true)
	  + common.convert(MessageManager.getMessage('TOMS.MASTER.MAINTENANCE.COMMODITYSHAPE.LABEL.PARENT_COMMODITY_SHAPE_CODE'), true)
	  + common.convert(MessageManager.getMessage('TOMS.MASTER.MAINTENANCE.COMMODITYSHAPE.LABEL.COMMODITY_SHAPE_CODE'), true)
	  + common.convert(MessageManager.getMessage('TOMS.MASTER.MAINTENANCE.MATERIAL.LABEL.MATERIAL_CODE'), true)
	  + common.convert(MessageManager.getMessage('TOMS.MASTER.MAINTENANCE.PROCESSPART.LABEL.PROCESSPART_CODE'), true)
	  + common.convert(MessageManager.getMessage('TOMS.MASTER.MAINTENANCE.PROCESSPART.LABEL.PROCESSPART_POSITION_CODE'), true)
	  + common.convert(MessageManager.getMessage('TOMS.MASTER.MAINTENANCE.PROCESSMETHOD_HEADER.LABEL.PROCESS_METHOD_TPYE'), true)
	  + common.convert(MessageManager.getMessage('TOMS.MASTER.MAINTENANCE.PROCESSMETHOD_HEADER.LABEL.PROCESS_METHOD_DETAIL_TPYE'), true)
	  + common.convert(MessageManager.getMessage('TOMS.MASTER.MAINTENANCE.PROCESSMETHOD_DETAIL.LABEL.PROCESS_METHOD_NAME1'), true)
	  + common.convert(MessageManager.getMessage('TOMS.MASTER.MAINTENANCE.PROCESSMETHOD_DETAIL.LABEL.DISPLAY_ORDER1'), true)
	  + common.convert(MessageManager.getMessage('TOMS.MASTER.MAINTENANCE.PROCESSMETHOD_DETAIL.LABEL.JDE_CODE1'), true)
	  + common.convert(MessageManager.getMessage('TOMS.MASTER.MAINTENANCE.PROCESSMETHOD_DETAIL.LABEL.GROUP_NAME1'), true)
	  + common.convert(MessageManager.getMessage('TOMS.MASTER.MAINTENANCE.PROCESSMETHOD_DETAIL.LABEL.PROCESS_METHOD_NAME2'), true)
	  + common.convert(MessageManager.getMessage('TOMS.MASTER.MAINTENANCE.PROCESSMETHOD_DETAIL.LABEL.DISPLAY_ORDER2'), true)
	  + common.convert(MessageManager.getMessage('TOMS.MASTER.MAINTENANCE.PROCESSMETHOD_DETAIL.LABEL.JDE_CODE2'), true)
	  + common.convert(MessageManager.getMessage('TOMS.MASTER.MAINTENANCE.PROCESSMETHOD_DETAIL.LABEL.GROUP_NAME2'), true)
	  + common.convert(MessageManager.getMessage('TOMS.MASTER.MAINTENANCE.PROCESSMETHOD_DETAIL.LABEL.PROCESS_METHOD_NAME3'), true)
	  + common.convert(MessageManager.getMessage('TOMS.MASTER.MAINTENANCE.PROCESSMETHOD_DETAIL.LABEL.DISPLAY_ORDER3'), true)
	  + common.convert(MessageManager.getMessage('TOMS.MASTER.MAINTENANCE.PROCESSMETHOD_DETAIL.LABEL.JDE_CODE3'), true)
	  + common.convert(MessageManager.getMessage('TOMS.MASTER.MAINTENANCE.PROCESSMETHOD_DETAIL.LABEL.GROUP_NAME3'), true)
	  + common.convert(MessageManager.getMessage('TOMS.MASTER.MAINTENANCE.PROCESSMETHOD_DETAIL.LABEL.PATTERN_SIZE_HEIGHT'), true)
	  + common.convert(MessageManager.getMessage('TOMS.MASTER.MAINTENANCE.PROCESSMETHOD_DETAIL.LABEL.PATTERN_SIZE_WIDTH'), true)
	  + common.convert(MessageManager.getMessage('TOMS.MASTER.MAINTENANCE.COMMODITYSHAPE.LABEL.APPLIED_START_DATE'), true)
	  + common.convert(MessageManager.getMessage('TOMS.MASTER.MAINTENANCE.COMMODITYSHAPE.LABEL.DELETE_FLG'), false);

return outputHeader;

}

/**
 * 加工方法明細マスタメンテナンスのCSVファイルの行を出力する処理
 * 
 * @param record DBから検索した行のデータ
 */
function outputCSVRow(record) {
	var result =  MessageManager.getMessage('TOMS.COMMON.CSV.SPLIT')
		    + common.convert(record["mny57apmc"], true)
			+ common.convert(record["mny57apcsc"], true)
			+ common.convert(record["mny57acsc"], true)
			+ common.convert(record["mny57amtc"], true)
			+ common.convert(record["mny57appc1"], true)
			+ common.convert(record["mny57appc2"], true)
			+ common.convert(record["mny57apmt"], true)
			+ common.convert(record["mny57apmdt"], true)
			+ common.convert(record["mny57apmn1"], true)
			+ common.convert(record["mny57ado1"], true)
			+ common.convert(record["mny57ajc1"], true)
			+ common.convert(record["mny57agn1"], true)
			+ common.convert(record["mny57apmn2"], true)
			+ common.convert(record["mny57ado2"], true)
			+ common.convert(record["mny57ajc2"], true)
			+ common.convert(record["mny57agn2"], true)
			+ common.convert(record["mny57apmn3"], true)
			+ common.convert(record["mny57ado3"], true)
			+ common.convert(record["mny57ajc3"], true)
			+ common.convert(record["mny57agn3"], true)
			+ common.convert(record["mny57apsh"], true)
			+ common.convert(record["mny57apsw"], true)
			+ common.convert(record["mneftj"], true)
			+ common.convert(record["mny57adflg"]+"", false);
	return result;
	
}

function error(message) {
  Transfer.toErrorPage({
    title: MessageManager.getMessage('TOMS.COMMON.ERROR.PAGE.TITLE'),
    message: MessageManager.getMessage('TOMS.COMMON.ERROR.MESSAGE.SYSTEM'),
    detail: [MessageManager.getMessage('TOMS.MASTER.MAINTENANCE.PROCESSMETHOD_HEADER.LIST.LABEL.MESSAGE.ERROR'), message],
    returnUrl: 'toms/process_method_h/list/input', // 戻り先 URL
    returnUrlLabel: MessageManager.getMessage('TOMS.MASTER.MAINTENANCE.PROCESSMETHOD_HEADER.LIST.LABEL.RETURN.LINK.NAME'),
    parameter: {
    }
  });
}
