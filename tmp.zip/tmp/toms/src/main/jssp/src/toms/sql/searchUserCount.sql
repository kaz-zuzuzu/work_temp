SELECT
    COUNT(*) AS ROWCOUNT
FROM
(
    SELECT DISTINCT
        UL.ULUSER AS ULUSER
        ,WW.WWMLNM AS WWMLNM
    FROM
        F0092 UL
    INNER JOIN 
        F0111 WW
       ON UL.ULAN8 = WW.WWAN8
    /*BEGIN*/
    WHERE
        /*IF userCode != null*/
        TRIM(UL.ULUSER) = /*userCode*/'TISTS01'
        /*END*/
        /*IF userName != null*/
        AND TRIM(WW.WWMLNM) like /*userName*/'%TEST%'
        /*END*/
    /*END*/ 
)
