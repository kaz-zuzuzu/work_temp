/**
 * バインド変数.
 */
var $bind = {};

/**
 * 初期表示
 * @param request リクエストパラメータ
 */
function init(request) {
	load("toms/common/master");
	
	$bind.flag = request.updateFlag; //新規、更新フラグ　新規：0　更新：1　
	$bind.searchMfpid1 = request.searchMfpid1;
	$bind.searchMfuser1 = request.searchMfuser1;
	$bind.title =MessageManager.getMessage('TOMS.MASTER.MAINTENANCE.REPORT.DETAIL.INPUT.ENTRY.TITLE');
	
	if ($bind.flag == "1") {
		//更新時
		$bind.mfpid1 = request.mfpid1;
        $bind.mfuser1 = request.mfuser1;
        $bind.mfev01 = request.mfev01;
        $bind.mfactntyp = request.mfactntyp;
        $bind.mfpdes = request.mfpdes;
        $bind.mfsrc = request.mfsrc;
        $bind.mfy57cura1 = request.mfy57cura1;
        $bind.mfy57cdl01 = request.mfy57cdl01;
        $bind.mfy57cdl02 = request.mfy57cdl02;
        $bind.mfy57cdl03 = request.mfy57cdl03;
        $bind.title =MessageManager.getMessage('TOMS.MASTER.MAINTENANCE.REPORT.DETAIL.INPUT.UPDATE.TITLE');
	}
	
  // 登録、更新、削除ボタン押下時の確認ダイアログのメッセージを初期化.
  // JavaScriptで利用するためオブジェクトの内容をそのまま渡します.
  $bind.dialogMessages = ({
	entryTitle: MessageManager.getMessage('TOMS.MASTER.MAINTENANCE.REPORT.DETAIL.INPUT.ENTRY.MESSAGE.TITLE'),
    entryMessage: MessageManager.getMessage('TOMS.MASTER.MAINTENANCE.REPORT.DETAIL.INPUT.ENTRY.MESSAGE'),
	updateTitle: MessageManager.getMessage('TOMS.MASTER.MAINTENANCE.REPORT.DETAIL.INPUT.UPDATE.MESSAGE.TITLE'),
    updateMessage: MessageManager.getMessage('TOMS.MASTER.MAINTENANCE.REPORT.DETAIL.INPUT.UPDATE.MESSAGE'),
    deleteTitle: MessageManager.getMessage('TOMS.MASTER.MAINTENANCE.REPORT.DETAIL.INPUT.DELETE.MESSAGE.TITLE'),
    deleteMessage: MessageManager.getMessage('TOMS.MASTER.MAINTENANCE.REPORT.DETAIL.INPUT.DELETE.MESSAGE')
  }).toSource();
}


