/**
 * バインド変数.
 */
var $bind = {};

/**
 * 初期表示
 * @param request リクエストパラメータ
 */
function init(request) {
	
	$bind.flag = request.updateFlag;
	$bind.searchMgan8 = request.searchMgan8;
	$bind.title = MessageManager.getMessage('TOMS.MASTER.MAINTENANCE.ITEMS.DETAIL.INPUT.ENTRY.TITLE');
	$bind.classTxtRequired = "imui-required";
	
	if ($bind.flag == "1") {
		$bind.mgan8 = request.mgan8;
        $bind.mgy57aspcd = request.mgy57aspcd;
        $bind.mgrno = request.mgrno;
        $bind.mgds01 = request.mgds01;
        $bind.title = MessageManager.getMessage('TOMS.MASTER.MAINTENANCE.ITEMS.DETAIL.INPUT.UPDATE.TITLE');
    	$bind.classTxtRequired = "";
	} 
	
  // 登録、更新、削除ボタン押下時の確認ダイアログのメッセージを初期化.
  // JavaScriptで利用するためオブジェクトの内容をそのまま渡します.
  $bind.dialogMessages = ({
	entryTitle: MessageManager.getMessage('TOMS.MASTER.MAINTENANCE.ITEMS.DETAIL.INPUT.ENTRY.MESSAGE.TITLE'),
    entryMessage: MessageManager.getMessage('TOMS.MASTER.MAINTENANCE.ITEMS.DETAIL.INPUT.ENTRY.MESSAGE'),
	updateTitle: MessageManager.getMessage('TOMS.MASTER.MAINTENANCE.ITEMS.DETAIL.INPUT.UPDATE.MESSAGE.TITLE'),
    updateMessage: MessageManager.getMessage('TOMS.MASTER.MAINTENANCE.ITEMS.DETAIL.INPUT.UPDATE.MESSAGE'),
    deleteTitle: MessageManager.getMessage('TOMS.MASTER.MAINTENANCE.ITEMS.DETAIL.INPUT.DELETE.MESSAGE.TITLE'),
    deleteMessage: MessageManager.getMessage('TOMS.MASTER.MAINTENANCE.ITEMS.DETAIL.INPUT.DELETE.MESSAGE')
  }).toSource();
}


