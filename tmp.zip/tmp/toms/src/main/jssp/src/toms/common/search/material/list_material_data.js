var $data;

/**
 * 初期表示
 * @param request リクエストパラメータ
 */
function init(request) {
	$data = ImJson.toJSONString(getList(request));
}

function getList(request) {
	// 表示条件を設定（表示ページ、件数など）
	let page = request.page == undefined ? 1 : request.page;
	let rows = request.rowNum == undefined ? 10 : Module.number.toInt(request.rowNum);
	var searchCondition = request.extension;
	if (!searchCondition || !searchCondition.searchConditionParam) {
		return  {
                		page  : page,
                		total : rows,
                		data  : []
    				};
    }
	
    if (searchCondition.searchConditionParam.popupFlag == "search") {
    	page = 1;
    }
    
	var materialCode = searchCondition.searchConditionParam.materialCode;
	var materialName = searchCondition.searchConditionParam.materialName;
	var commodityShapeCode = searchCondition.searchConditionParam.paramCode;
	var commodityShapeName = searchCondition.searchConditionParam.paramName;
	var commodityShapeParentCode = searchCondition.searchConditionParam.paramParentCode;
	var commodityShapeParentName = searchCondition.searchConditionParam.paramParentName;
	

	// 該当する商品形態の件数取得
	let resultCount = searchDataCount(materialCode,materialName, commodityShapeCode, commodityShapeName,commodityShapeParentCode,commodityShapeParentName);
	// 全体の件数を設定（件数の母数）
	var listCount = 0;
	if (!resultCount.error) {
		listCount = resultCount.data[0]['rowcount'];
	} else {
		Debug.write(resultCount.errorMessage);
	}
	// ページ番号設定:リクエストパラメータのページ番号、最大ページ番号のうち小さい方の番号を設定
	page = Math.min(page, Math.ceil(listCount / rows)); 
	
	// 指定範囲の会社情報を取得
	let start = rows * (page - 1) + 1;
	let end = start + rows - 1;
	
	var result = searchData(materialCode,materialName, commodityShapeCode, commodityShapeName, commodityShapeParentCode, commodityShapeParentName, start, end);
	var rsltData = [];
	if (!result.error) {
		rsltData = result.data;
	} else {
		Debug.write(result.error);
	}
	
	var json = {
		page  : page,
		total : listCount,
		data  : rsltData
	};
	return json;
}

function searchDataCount(materialCode,materialName, commodityShapeCode, commodityShapeName,commodityShapeParentCode, commodityShapeParentName, flg) {
	load("toms/common/Material");
	var result = Material.searchMaterialData(materialCode,materialName, commodityShapeCode, commodityShapeName,commodityShapeParentCode, commodityShapeParentName, true);
	return result;
}

function searchData(materialCode,materialName, commodityShapeCode, commodityShapeName,commodityShapeParentCode, commodityShapeParentName,start, end) {
	load("toms/common/Material");
	var result = Material.searchMaterialData(materialCode,materialName, commodityShapeCode, commodityShapeName,commodityShapeParentCode, commodityShapeParentName,false, start, end);
	return result;
}

