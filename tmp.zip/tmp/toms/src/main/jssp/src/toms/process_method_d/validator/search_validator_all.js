/**
 * 加工方法明細マスタメンテナンス検索画面(STEP2)用validation設定
 */

 var init ={
		 'search_mndl01':{//加工方法名称
	 	caption:'TOMS.MASTER.MAINTENANCE.PROCESSMETHOD_HEADER.LABEL.PROCESS_METHOD_NAME',
	 	maxlength: 30
 		},
 
		 'search_mny57apcsc':{//親商品形態コード
	 	caption:'TOMS.MASTER.MAINTENANCE.COMMODITYSHAPE.LABEL.PARENT_COMMODITY_SHAPE_CODE',
		alphanumeric: true,
	 	maxlength: 16
 		},
		 'search_mny57apcscName':{//親商品形態名称
		 	caption:'TOMS.MASTER.MAINTENANCE.COMMODITYSHAPE.LABEL.PARENT_COMMODITY_SHAPE_NAME',
		 	maxlength: 30
 		},
		 'search_mny57acsc':{//商品形態コード
		 	caption:'TOMS.MASTER.MAINTENANCE.COMMODITYSHAPE.LABEL.COMMODITY_SHAPE_CODE',
			alphanumeric: true,
		 	maxlength: 16
	 		},
		 'search_mny57acscName':{//商品形態名称
		 	caption:'TOMS.MASTER.MAINTENANCE.COMMODITYSHAPE.LABEL.COMMODITY_SHAPE_NAME',
		 	maxlength: 30
 		},
 		'search_mny57amtc':{//素材コード
	 	caption:'TOMS.MASTER.MAINTENANCE.MATERIAL.LABEL.MATERIAL_CODE',
	 	alphanumeric: true,
		maxlength: 16
 		},
 		'search_mny57amtcName':{//原材料名
 		caption:'TOMS.MASTER.MAINTENANCE.MATERIAL.LABEL.MATERIAL_NAME',
		maxlength: 30
 		},

 		'search_mny57appc1':{//加工部位コード
	 	caption:'TOMS.MASTER.MAINTENANCE.PROCESSPART.LABEL.PROCESSPART_CODE',
		 alphanumeric: true,
		 maxlength: 16
 		},
 		'search_mny57appc1Name':{//加工部位名称
 		caption:'TOMS.MASTER.MAINTENANCE.PROCESSPART.LABEL.PROCESSPART_NAME',
		maxlength: 30
 		},


 		'search_mny57appc2':{//加工位置コード
	 	caption:'TOMS.MASTER.MAINTENANCE.PROCESSPART.LABEL.PROCESSPART_POSITION_CODE',
		 alphanumeric: true,
		 maxlength: 16
 		},
 		'search_mny57appc2Name':{//加工位置名称
 		caption:'TOMS.MASTER.MAINTENANCE.PROCESSPART.LABEL.PROCESSPART_POSITION_NAME',
		maxlength: 30
 		},
		'search_mny57apmn1':{//第一階層名称
	 	caption:'TOMS.MASTER.MAINTENANCE.PROCESSMETHOD_DETAIL.LABEL.PROCESS_METHOD_NAME1',
		maxlength: 30
 		},	
		'search_mny57agn1':{//第一階層グループ名称
	 	caption:'TOMS.MASTER.MAINTENANCE.PROCESSMETHOD_DETAIL.LABEL.GROUP_NAME1',
		maxlength: 20
 		},	
		'search_mny57ado1':{//第一階層表示順
	 	caption:'TOMS.MASTER.MAINTENANCE.PROCESSMETHOD_DETAIL.LABEL.DISPLAY_ORDER1',
		numeric: true,
		maxlength: 8
 		},	
		'search_mny57ajc1':{//第一階層JDEコード
	 	caption:'TOMS.MASTER.MAINTENANCE.PROCESSMETHOD_DETAIL.LABEL.PROCESS_METHOD_NAME1',
		alphanumeric: true,
		maxlength: 8
 		},	
		'search_mny57apmn2':{//第2階層名称
	 	caption:'TOMS.MASTER.MAINTENANCE.PROCESSMETHOD_DETAIL.LABEL.PROCESS_METHOD_NAME2',
		maxlength: 30
 		},	
		'search_mny57agn2':{//第2階層グループ名称
	 	caption:'TOMS.MASTER.MAINTENANCE.PROCESSMETHOD_DETAIL.LABEL.GROUP_NAME2',
		maxlength: 20
 		},	
		'search_mny57ado2':{//第2階層表示順
	 	caption:'TOMS.MASTER.MAINTENANCE.PROCESSMETHOD_DETAIL.LABEL.DISPLAY_ORDER2',
		numeric: true,
		maxlength: 8
 		},	
		'search_mny57ajc2':{//第2階層JDEコード
	 	caption:'TOMS.MASTER.MAINTENANCE.PROCESSMETHOD_DETAIL.LABEL.PROCESS_METHOD_NAME2',
		alphanumeric: true,
		maxlength: 8
 		},	
		'search_mny57apmn3':{//第3階層名称
	 	caption:'TOMS.MASTER.MAINTENANCE.PROCESSMETHOD_DETAIL.LABEL.PROCESS_METHOD_NAME3',
		maxlength: 30
 		},	
		'search_mny57agn3':{//第3階層グループ名称
	 	caption:'TOMS.MASTER.MAINTENANCE.PROCESSMETHOD_DETAIL.LABEL.GROUP_NAME3',
		maxlength: 20
 		},	
		'search_mny57ado3':{//第3階層表示順
	 	caption:'TOMS.MASTER.MAINTENANCE.PROCESSMETHOD_DETAIL.LABEL.DISPLAY_ORDER3',
		numeric: true,
		maxlength: 8
 		},	
		'search_mny57ajc3':{//第3階層JDEコード
	 	caption:'TOMS.MASTER.MAINTENANCE.PROCESSMETHOD_DETAIL.LABEL.PROCESS_METHOD_NAME3',
		alphanumeric: true,
		maxlength: 8
 		},	
		'search_mny57apmn4':{//第4階層名称
	 	caption:'TOMS.MASTER.MAINTENANCE.PROCESSMETHOD_DETAIL.LABEL.PROCESS_METHOD_NAME4',
		maxlength: 30
 		},	
		'search_mny57agn4':{//第4階層グループ名称
	 	caption:'TOMS.MASTER.MAINTENANCE.PROCESSMETHOD_DETAIL.LABEL.GROUP_NAME4',
		maxlength: 20
 		},	
		'search_mny57ado4':{//第4階層表示順
	 	caption:'TOMS.MASTER.MAINTENANCE.PROCESSMETHOD_DETAIL.LABEL.DISPLAY_ORDER4',
		numeric: true,
		maxlength: 8
 		},	
		'search_mny57ajc4':{//第4階層JDEコード
	 	caption:'TOMS.MASTER.MAINTENANCE.PROCESSMETHOD_DETAIL.LABEL.PROCESS_METHOD_NAME4',
		alphanumeric: true,
		maxlength: 8
 		},	

 		//有効開始日 
	 	'search_mneftj':{
	 	caption:'TOMS.MASTER.MAINTENANCE.COMMODITYSHAPE.LABEL.APPLIED_START_DATE',
		date: true,
	    maxlength: 10
	 	}, 
 		//有効開始日2 
	 	'search_mneftj2':{
	 	caption:'TOMS.MASTER.MAINTENANCE.COMMODITYSHAPE.LABEL.APPLIED_START_DATE',
		date: true,
	    maxlength: 10
	 	}, 
	 	//有効終了日 
	 	'search_mnexdj':{
	 	caption:'TOMS.MASTER.MAINTENANCE.COMMODITYSHAPE.LABEL.APPLIED_END_DATE',
		date: true,
	    maxlength: 10
	 	}
 }