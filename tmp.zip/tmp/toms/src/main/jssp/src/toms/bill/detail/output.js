/**
 * バインド変数.
 */
var $bind = {};
var $data ={};

// CSVの区切り文字（カンマ）
var splitComma = MessageManager.getMessage('TOMS.COMMON.COMMA');

/**
 * 初期表示.
 * @param request リクエストパラメータ.
 */
function init(request) {
	load("toms/common/master");
	
	$data = {
	rowNum  : 1500,
	rowList : [1500, 3000, 5000]
	};


	// 受け取るパラメータを画面表示内容に設定する
	$bind.lblCloseDate = request.closeDate;
	$bind.exchangeTargetName = request.exchangeTargetName;
	$bind.chargePerson = request.chargePerson;
	$bind.lastTimeRequestAccount = request.lastTimeRequestAccount;
	$bind.thisMonthAccount = request.thisMonthAccount;
	$bind.priceOffAccount = request.priceOffAccount;
	$bind.remainAccount = request.remainAccount;
	$bind.saleAccount = request.saleAccount;
	$bind.saleTaxAccount = request.saleTaxAccount;
	$bind.thisMonthRequestAccount = request.thisMonthRequestAccount;
	$bind.comment = request.comment;
	$bind.targetYearFrom = request.targetYearFrom;
	$bind.targetYearTo = request.targetYearTo;
	$bind.exchangeTargetCode = request.exchangeTargetCode;
	$bind.exchangeTargetKana = request.exchangeTargetKana;
	$bind.paymentPersonCode = request.paymentPersonCode;
	$bind.paymentPersonKana = request.paymentPersonKana;

	// 受け取るパラメータを詳細画面データを取得する検索条件に設定する
	$bind.requestNo = request.requestNo;
	$bind.etCode = request.etCode;
	$bind.searchCloseDate = request.searchCloseDate;
	
	if (request.screenId == "outputCSV") {
		load("toms/common/common");
    	// 区切り文字（カンマ）
    	outputCSV(request.exchangeTargetCode, request.requestNo, request.searchCloseDate);
    	
	} else {
	$bind.dialogMessages = ({
          addConfirmTitle: MessageManager.getMessage('TOMS.COMMON.DIALOG.CONFIRM.TITLE'),
          addConfirmMessage: MessageManager.getMessage('TOMS.COMMON.DIALOG.CONFIRM.MESSAGE.COMMA')
        }).toSource();
	}
    
}

function outputCSV(exchangeTargetCode, requestNo, searchCloseDate) {
    var result = TomsMaster.getRequestBillDetail(exchangeTargetCode, requestNo, searchCloseDate, false);
    var outputContent = "";
    if (!result.error) {
        for (var i = 0; i < result.countRow; i++) {
        	outputContent += outputCSVRow(result.data[i]);
     		}
        var strDateTime = DateTimeFormatter.format("yyyyMMddHHmmss", new Date());
        var fileName = MessageManager.getMessage('TOMS.BILL.DETAIL.LABEL.TITLE') + '_' + strDateTime + '.csv';
        Module.download.send(Unicode.to(outputContent, 'MS932'), fileName, MessageManager.getMessage('TOMS.COMMON.MIME.CSV'));
    } else {
        //errorcsv(result.errorMessage);
    }
}

function outputCSVRow(record) {

	var result =common.convertWithSplit(record["div1"], splitComma, true)		// 締日
                + common.convertWithSplit(record["div2"], splitComma, true)		// 販売先
                + common.convertWithSplit(record["div3"], splitComma, true)		// 営業担当者
                + common.convertWithSplit(record["div4"], splitComma, true)		// 前回請求額
                + common.convertWithSplit(record["div5"], splitComma, true)		// 今回入金額
                + common.convertWithSplit(record["div6"], splitComma, true)		// 値引額
                + common.convertWithSplit(record["div7"], splitComma, true)		// 繰越残高
                + common.convertWithSplit(record["div8"], splitComma, true)		// 今回売上
                + common.convertWithSplit(record["div9"], splitComma, true)		// 消費税額
                + common.convertWithSplit(record["div10"], splitComma, false)	// 今回請求額
    return result;
}

