/**
 * 加工方法商品関連付けマスタメンテナンス検索画面用validation設定
 */

 var init ={
		'search_mpy57acc':{//商品コード
	 	caption:'TOMS.MASTER.MAINTENANCE.PROCESSMETHOD_COMMODITY.LABEL.COMMODITY_CODE',
		alphanumeric: true,
		maxlength: 5
 		},	
 		//有効開始日 
	 	'search_mpeftj':{
	 	caption:'TOMS.MASTER.MAINTENANCE.COMMODITYSHAPE.LABEL.APPLIED_START_DATE',
		date: true,
	    maxlength: 10
	 	}, 
 		//有効開始日2 
	 	'search_mpeftj2':{
	 	caption:'TOMS.MASTER.MAINTENANCE.COMMODITYSHAPE.LABEL.APPLIED_START_DATE',
		date: true,
	    maxlength: 10
	 	}
 }