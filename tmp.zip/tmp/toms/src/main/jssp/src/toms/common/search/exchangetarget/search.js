var $data = {};

/**
 * 初期表示
 * @param request リクエストパラメータ
 */
function init(request) {
//	load("toms/common/master");
//	
//	var popupExchangeTargetFlag = request.popupExchangeTargetFlag;
//	if (popupExchangeTargetFlag == "search") {
//    	var exchangeTargetName = request.commonExchangeTargetName;
//    	var exchangeTargetNameKana = request.commonExchangeTargetNameKana;
//    	var chargePersonKana = request.commonChargePersonKana;
//    	searchExchangeTarget(exchangeTargetName, exchangeTargetNameKana, chargePersonKana);
//	} else {
//		$bind.exchangeTargetlistData = [];
//	}

	$data = {
		rowNum  : 10,
		rowList : [10, 20, 30]
	};
}
