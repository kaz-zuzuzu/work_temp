/**
 * 加工方法ヘッダマスタメンテナンス検索画面用validation設定
 */

 var init ={
		'search_mmdl01':{//加工方法名称
	 	caption:'TOMS.MASTER.MAINTENANCE.PROCESSMETHOD_HEADER.LABEL.PROCESS_METHOD_NAME',
		maxlength: 30
 		},	
		 'search_mmy57apcsc':{//親商品形態コード
		 	caption:'TOMS.MASTER.MAINTENANCE.COMMODITYSHAPE.LABEL.PARENT_COMMODITY_SHAPE_CODE',
		 	alphanumeric: true,
			maxlength: 16
	 		},
			 'search_mmy57acsc':{//商品形態コード
		 	caption:'TOMS.MASTER.MAINTENANCE.COMMODITYSHAPE.LABEL.COMMODITY_SHAPE_CODE',
		 	alphanumeric: true,
			maxlength: 16
	 		},	
 		'search_mmy57amtc':{//素材コード
	 	caption:'TOMS.MASTER.MAINTENANCE.MATERIAL.LABEL.MATERIAL_CODE',
	 	alphanumeric: true,
		maxlength: 16
 		},

		 'search_mmy57ada':{//階層数
	 	caption:'TOMS.MASTER.MAINTENANCE.PROCESSMETHOD_HEADER.LABEL.DEPTH_AMOUNT',
	 	numeric: true,
		maxlength: 2
 		},	 		
		 //加工部位コード
		 'search_mmy57appc1':{
	 	caption:'TOMS.MASTER.MAINTENANCE.PROCESSPART.LABEL.PROCESSPART_CODE',
		 alphanumeric: true,
		 maxlength: 16
 		},	 		
		 //加工位置コード
		 'search_mmy57appc2':{
	 	caption:'TOMS.MASTER.MAINTENANCE.PROCESSPART.LABEL.PROCESSPART_POSITION_CODE',
		 alphanumeric: true,
		 maxlength: 16
 		},	 		

 		//有効開始日 
	 	'search_mmeftj':{
	 	caption:'TOMS.MASTER.MAINTENANCE.COMMODITYSHAPE.LABEL.APPLIED_START_DATE',
		date: true,
	    maxlength: 10
	 	}, 
 		//有効開始日2 
	 	'search_mmeftj2':{
	 	caption:'TOMS.MASTER.MAINTENANCE.COMMODITYSHAPE.LABEL.APPLIED_START_DATE',
		date: true,
	    maxlength: 10
	 	}, 
	 	//有効終了日 
	 	'search_mmexdj':{
	 	caption:'TOMS.MASTER.MAINTENANCE.COMMODITYSHAPE.LABEL.APPLIED_END_DATE',
		date: true,
	    maxlength: 10
	 	}
 }