/**
 * バインド変数.
 */
var $bind = {};


/**
 * 初期表示.
 * @param request リクエストパラメータ.
 */
function init(request) {
	load("toms/common/master");	

	request.setAttribute("imui-theme-builder-module", "bodyonly");
	var stockPositionCode = request.stockPositionCode;
	var storePositionCode = request.storePositionCode;
	var stockCategory = request.stockCategory;
	var manufacturerProduct = request.manufacturerProduct;
	var manufacturerFlag = request.manufacturerFlag;
	var addtionNo = request.addtionNo;
	var productCodeList = null;
	if (request.productCodes) {
		productCodeList = request.productCodes.split(",");
	}
	
	if (manufacturerFlag == "1") {
		getProductSizeList(stockPositionCode, storePositionCode, stockCategory, manufacturerProduct, productCodeList, addtionNo);
		getStockList(stockPositionCode, storePositionCode, stockCategory, manufacturerProduct, productCodeList, addtionNo);
	} else {
		getProductSizeList(stockPositionCode, storePositionCode, stockCategory, null, productCodeList, addtionNo);
		getStockList(stockPositionCode, storePositionCode, stockCategory, null, productCodeList, addtionNo);
	}
}
/****************************************************************
 * 在庫一覧のヘッダー情報を取得する処理
 *****************************************************************/
function getProductSizeList(stockPositionCode, storePositionCode, stockCategory, manufacturerCode, productCodes, addtionNo) {
	var result = TomsMaster.getProductSizeList(stockPositionCode, storePositionCode, stockCategory, manufacturerCode, productCodes, addtionNo);
	if (!result.error) {
		$bind.productSizeList = result.data;
		$bind.columns = {};
		$bind.plainParameter = "colModel: [{},{},";
		for(var i = 0; i < result.countRow; i++) {
    		$bind.columns[result.data[i]["name"]] = null;
    		$bind.plainParameter += "{formatter : currencyFormatter},";
    	}
		$bind.plainParameter += "{formatter : currencyFormatter}]";
	} else {
		error(result.errorMessage);
	}
}
/****************************************************************
 * 在庫一覧のデータ情報を取得し、画面に表示するようにデータを組込む処理
 *****************************************************************/
function getStockList(stockPositionCode, storePositionCode, stockCategory, manufacturerCode, productCodes, addtionNo) {
	var result = TomsMaster.getStockList(stockPositionCode, storePositionCode, stockCategory, manufacturerCode, productCodes, addtionNo);
	if (!result.error) {
		var stockList = [];
		var slIndex = 0;
		stockList[slIndex] = {};
		var columns = {};
		var recordData = {};
		var sumLipqoh = -1;
		for(var i = 0; i < result.countRow; i++) {
			var productItemNo = result.data[i]["imlitm"];
			if (productItemNo && productItemNo.length > 10) {
				var productMpc = productItemNo.substring(0, 10);

				if (i == 0) {
					recordData["imlitm_mpc"] = productMpc;
					recordData["imdsc1"] = result.data[i]["imdsc1"];
					recordData["drdl01_cl"] = result.data[i]["drdl01_cl"];
				} else if (i > 0) {
					var preProductItemNo = result.data[i - 1]["imlitm"];
					if (preProductItemNo && preProductItemNo.length > 10) {
						var preProductMpc = preProductItemNo.substring(0, 10);
						if (productMpc != preProductMpc) {
							columns = {};
							for (var key in $bind.columns) {
								columns[key] = $bind.columns[key];
							}
							recordData = {};	
							recordData["imlitm_mpc"] = productMpc;
							recordData["imdsc1"] = result.data[i]["imdsc1"];
							recordData["drdl01_cl"] = result.data[i]["drdl01_cl"];
						}
						
					}
				} 
				columns['c1' + result.data[i]["imlitm_s"]] = result.data[i]["lipqoh"];
				if (sumLipqoh == -1) {
					sumLipqoh = 0;
				}
				sumLipqoh += result.data[i]["lipqoh"];
				
				if (i == result.countRow - 1){
					for (var key in recordData) {
						stockList[slIndex][key] = recordData[key];
					}
					
					for (var key in columns) {
						stockList[slIndex][key] = columns[key];
					}
					if (sumLipqoh > -1) {
						stockList[slIndex]["sumLipqoh"] = sumLipqoh;
					} else {
						stockList[slIndex]["sumLipqoh"] = "";
					}
					
					recordData = {};
					columns = {};
					sumLipqoh = -1;
					slIndex++;
					stockList[slIndex] = {};
				} else {
					var nextProductItemNo = result.data[i + 1]["imlitm"];
					if (nextProductItemNo && nextProductItemNo.length > 10) {
						var nextProductMpc = nextProductItemNo.substring(0, 10);
						if (productMpc != nextProductMpc) {
							for (var key in recordData) {
								stockList[slIndex][key] = recordData[key];
							}
							
							for (var key in columns) {
								stockList[slIndex][key] = columns[key];
							}
							if (sumLipqoh > -1) {
								stockList[slIndex]["sumLipqoh"] = sumLipqoh;
							} else {
								stockList[slIndex]["sumLipqoh"] = "";
							}
							
							recordData = {};
							columns = {};
							sumLipqoh = -1;
							slIndex++;
							stockList[slIndex] = {};
						}
					}
				}
			}
    	}
		$bind.stockList = stockList;
	} else {
		error(result.errorMessage);
	}
}
/**
 * エラー画面へ遷移の処理.
 */
function error(message) {
  Transfer.toErrorPage({
    title: MessageManager.getMessage('TOMS.COMMON.ERROR.PAGE.TITLE'),
    message: MessageManager.getMessage('TOMS.COMMON.ERROR.MESSAGE.SYSTEM'),
    detail: [MessageManager.getMessage('TOMS.STOCK.LIST.LABEL.MESSAGE.ERROR'), message],
    returnUrl: 'toms/stock/search/input', // 戻り先 URL
    returnUrlLabel: MessageManager.getMessage('TOMS.BILL.LIST.LABEL.RETURN.LINK.NAME'),
    parameter: {
    }
  });
}
