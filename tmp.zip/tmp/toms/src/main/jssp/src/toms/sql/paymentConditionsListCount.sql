select
 count(pnptc) cnt
from
 f0014
where
 1=1
/*IF pnptc != null*/
 and pnptc like /*pnptc*/'%085%'
/*END*/
/*IF pnptd != null*/
 and pnptd like /*pnptd*/'%手形%'
/*END*/