SELECT
    COUNT(*) AS ROWCOUNT
FROM
(
SELECT
  MNY57APMC
  , MNY57APMN1
  , MNY57ADO1
  , MNY57AJC1
  , MNY57AGN1
  , MNY57APMN2
  , MNY57ADO2
  , MNY57AJC2
  , MNY57AGN2
  , MNY57APMN3
  , MNY57ADO3
  , MNY57AJC3
  , MNY57AGN3
  , MNY57APMN4
  , MNY57ADO4
  , MNY57AJC4
  , MNY57AGN4
  , MNY57APMN5
  , MNY57ADO5
  , MNY57AJC5
  , MNY57AGN5
  , MNY57AHFLG
  , MNEFTJ
  , MNEXDJ
  , MNY57ADFLG
  , MNURCD
  , MNURDT
  , MNURAT
  , MNURAB
  , MNURRF
  , MNUSER
  , MNPID
  , MNJOBN
  , MNUPMJ
  , MNUPMT
  , MNY57APSH
  , MNY57APSW
  , MNY57APCSC
  , MNY57ACSC
  , MNY57AMTC
  , MNY57APPC1
  , MNY57APPC2
  , MNY57APMT
  , MNY57APMDT 
FROM
  F57A5141 

/*BEGIN*/
  WHERE
        /*IF mny57apmc !=null */
             TRIM(MNY57APMC) =/*mny57apmc*/
        /*END*/
    /*IF mny57apmn1 !=null */
      AND TRIM(MNY57APMN1) LIKE /*mny57apmn1*/
    /*END*/
    /*IF mny57ado1 !=null */
      AND MNY57ADO1 = /*mny57ado1*/
    /*END*/
    /*IF mny57ajc1 !=null */
      AND TRIM(MNY57AJC1) = /*mny57ajc1*/
    /*END*/
    /*IF mny57agn1 !=null */
      AND TRIM(MNY57AGN1) LIKE /*mny57agn1*/
    /*END*/
    /*IF mny57apmn2 !=null */
      AND TRIM(MNY57APMN2) LIKE /*mny57apmn2*/
    /*END*/
    /*IF mny57ado2 !=null */
      AND MNY57ADO2 = /*mny57ado2*/
    /*END*/
    /*IF mny57ajc2 !=null */
      AND TRIM(MNY57AJC2) = /*mny57ajc2*/
    /*END*/
    /*IF mny57agn2 !=null */
      AND TRIM(MNY57AGN2) LIKE /*mny57agn2*/
    /*END*/
    /*IF mny57apmn3 !=null */
      AND TRIM(MNY57APMN3) LIKE /*mny57apmn3*/
    /*END*/
    /*IF mny57ado3 !=null */
      AND MNY57ADO3 = /*mny57ado3*/
    /*END*/
    /*IF mny57ajc3 !=null */
      AND TRIM(MNY57AJC3) = /*mny57ajc3*/
    /*END*/
    /*IF mny57agn3 !=null */
      AND TRIM(MNY57AGN3) LIKE /*mny57agn3*/
    /*END*/
    
    /*IF mny57apmn4 !=null */
      AND TRIM(MNY57APMN4) LIKE /*mny57apmn4*/
    /*END*/
    /*IF mny57ado4 !=null */
      AND MNY57ADO4 = /*mny57ado4*/
    /*END*/
    /*IF mny57ajc4 !=null */
      AND MNY57AJC4 = /*mny57ajc4*/
    /*END*/
    /*IF mny57agn4 !=null */
      AND TRIM(MNY57AGN4) LIKE /*mny57agn4*/
    /*END*/
        /*IF mneftj !=null */
          AND MNEFTJ >= /*mneftj*/
        /*END*/
        /*IF mneftj2 !=null */
          AND MNEFTJ <= /*mneftj2*/
        /*END*/
        /*IF mny57adflg !=null */
          AND MNY57ADFLG = /*mny57adflg*/
        /*END*/
    /*END*/
	ORDER BY
          MNY57APMC  
          , MNY57AJC1 
          , MNY57AJC2 
          , MNY57AJC3 
          , MNEFTJ DESC 

)
