/**
 * バインド変数.
 */
var $bind = {};

var $data = {};

/**
 * 初期表示.
 * @param request リクエストパラメータ.
 */
function init(request) {
	load("toms/common/master");
	
	$data = {
		rowNum  : 30,
		rowList : [30, 50, 100]
	};

	$bind.stockPositionName = request.stockPositionName;
    $bind.storePositionName = request.storePositionName;
    $bind.stockCategoryName = request.stockCategoryName;
    $bind.stockPositionCode = request.stockPositionCode;
	$bind.storePositionCode = request.storePositionCode;
	$bind.stockCategory = request.stockCategory;
	$bind.manufacturerProduct = request.manufacturerProduct;
	$bind.manufacturerFlag = request.manufacturerFlag;
	$bind.productCodes = request.productCodes;
	$bind.addtionNo = request.addtionNo;
	
	var stockPositionCode = request.stockPositionCode;
	var storePositionCode = request.storePositionCode;
	var manufacturerProduct = request.manufacturerProduct;
	var manufacturerFlag = request.manufacturerFlag;
	var productCodeList = null;
	if (request.productCodes) {
		productCodeList = request.productCodes.split(",");
	}
	
	
	if (request.screenId == "outputCSV") {
		if (manufacturerFlag == "1") {
			outputCSV(stockPositionCode, storePositionCode, $bind.stockCategory, manufacturerProduct, productCodeList, $bind.addtionNo);
    	} else {
    		outputCSV(stockPositionCode, storePositionCode, $bind.stockCategory, null, productCodeList, $bind.addtionNo);
    	}
	}

  // CSV出力ボタン押下時の確認ダイアログのメッセージを初期化.
  // JavaScriptで利用するためオブジェクトの内容をそのまま渡します.
  $bind.dialogMessages = ({
    addConfirmTitle: MessageManager.getMessage('TOMS.COMMON.DIALOG.CONFIRM.TITLE'),
    addConfirmMessage: MessageManager.getMessage('TOMS.COMMON.DIALOG.CONFIRM.MESSAGE'),
    groupHeaderRealStock: MessageManager.getMessage('TOMS.STOCK.DETAIL.LABEL.LIST.GROUP.REAL.STOCK'),
    groupHeaderRserve: MessageManager.getMessage('TOMS.STOCK.DETAIL.LABEL.LIST.GROUP.PURCHASE.RESERVE'),
    groupHeaderRserve1: MessageManager.getMessage('TOMS.STOCK.DETAIL.LABEL.LIST.GROUP.PURCHASE.RESERVE1'),
    groupHeaderRserve2: MessageManager.getMessage('TOMS.STOCK.DETAIL.LABEL.LIST.GROUP.PURCHASE.RESERVE2'),
    groupHeaderRserve3: MessageManager.getMessage('TOMS.STOCK.DETAIL.LABEL.LIST.GROUP.PURCHASE.RESERVE3'),
    groupHeaderRserve4: MessageManager.getMessage('TOMS.STOCK.DETAIL.LABEL.LIST.GROUP.PURCHASE.RESERVE4'),
    groupHeaderRserve5: MessageManager.getMessage('TOMS.STOCK.DETAIL.LABEL.LIST.GROUP.PURCHASE.RESERVE5'),
    groupHeaderRserve6: MessageManager.getMessage('TOMS.STOCK.DETAIL.LABEL.LIST.GROUP.PURCHASE.RESERVE6'),
    groupHeaderRserve7: MessageManager.getMessage('TOMS.STOCK.DETAIL.LABEL.LIST.GROUP.PURCHASE.RESERVE7'),
    groupHeaderRserve8: MessageManager.getMessage('TOMS.STOCK.DETAIL.LABEL.LIST.GROUP.PURCHASE.RESERVE8'),
    groupHeaderRserve9: MessageManager.getMessage('TOMS.STOCK.DETAIL.LABEL.LIST.GROUP.PURCHASE.RESERVE9'),
    groupHeaderRserve10: MessageManager.getMessage('TOMS.STOCK.DETAIL.LABEL.LIST.GROUP.PURCHASE.RESERVE10')
  }).toSource();
}

/****************************************************************
 * 在庫詳細一覧の情報を取得する処理
 *****************************************************************/
function getDetailStockList(stockPositionCode, storePositionCode, stockCategory, manufacturerCode, productCodes, addtionNo) {
	var result = TomsMaster.getDetailStockList(stockPositionCode, storePositionCode, stockCategory, manufacturerCode, productCodes, addtionNo);
	if (!result.error) {
		$bind.detailStockList = result.data;
	} else {
		error(result.errorMessage);
	}
}


/**
 * 在庫詳細のCSV出力処理
 */
function outputCSV(stockPositionCode, storePositionCode, stockCategory, manufacturerCode, productCodes, addtionNo) {
	var result = TomsMaster.getDetailStockList(stockPositionCode, storePositionCode, stockCategory, manufacturerCode, productCodes, addtionNo);
	var outputContent = "";
	if (!result.error) {
		outputContent = outputCSVHeader();
    	for(var i = 0; i < result.countRow; i++) {
    		outputContent += outputCSVRow(result.data[i]);
    	}
    	var strDate = DateTimeFormatter.format("yyyyMMdd", new Date());
    	var strUserName = Contexts.getUserContext().userProfile.userName;
    	var fileName = MessageManager.getMessage('TOMS.STOCK.DETAIL.LABEL.CSV.FILE.NAME') + '_' + strDate + '_' + strUserName + '.csv';
    	Module.download.send(Unicode.to(outputContent, 'MS932'), fileName, MessageManager.getMessage('TOMS.COMMON.MIME.CSV'));
	} else {
		error(result.errorMessage);
	}
}

/**
 * 在庫詳細のCSVヘッダ部分出力処理。
 */
function outputCSVHeader() {
	var outputHeader = convert('', true)
				  + convert('', true)
				  + convert('', true)
				  + convert(MessageManager.getMessage('TOMS.STOCK.DETAIL.LABEL.LIST.GROUP.REAL.STOCK'), true)
				  + convert('', true)
				  + convert(MessageManager.getMessage('TOMS.STOCK.DETAIL.LABEL.LIST.GROUP.PURCHASE.RESERVE'), true)
				  + convert('', true)
				  + convert(MessageManager.getMessage('TOMS.STOCK.DETAIL.LABEL.LIST.GROUP.PURCHASE.RESERVE1'), true)
				  + convert('', true)
				  + convert('', true)
				  + convert(MessageManager.getMessage('TOMS.STOCK.DETAIL.LABEL.LIST.GROUP.PURCHASE.RESERVE2'), true)
				  + convert('', true)
				  + convert('', true)
				  + convert(MessageManager.getMessage('TOMS.STOCK.DETAIL.LABEL.LIST.GROUP.PURCHASE.RESERVE3'), true)
				  + convert('', true)
				  + convert('', true)
				  + convert(MessageManager.getMessage('TOMS.STOCK.DETAIL.LABEL.LIST.GROUP.PURCHASE.RESERVE4'), true)
				  + convert('', true)
				  + convert('', true)
				  + convert(MessageManager.getMessage('TOMS.STOCK.DETAIL.LABEL.LIST.GROUP.PURCHASE.RESERVE5'), true)
				  + convert('', true)
				  + convert('', true)
				  + convert(MessageManager.getMessage('TOMS.STOCK.DETAIL.LABEL.LIST.GROUP.PURCHASE.RESERVE6'), true)
				  + convert('', true)
				  + convert('', true)
				  + convert(MessageManager.getMessage('TOMS.STOCK.DETAIL.LABEL.LIST.GROUP.PURCHASE.RESERVE7'), true)
				  + convert('', true)
				  + convert('', true)
				  + convert(MessageManager.getMessage('TOMS.STOCK.DETAIL.LABEL.LIST.GROUP.PURCHASE.RESERVE8'), true)
				  + convert('', true)
				  + convert('', true)
				  + convert(MessageManager.getMessage('TOMS.STOCK.DETAIL.LABEL.LIST.GROUP.PURCHASE.RESERVE9'), true)
				  + convert('', true)
				  + convert('', true)
				  + convert(MessageManager.getMessage('TOMS.STOCK.DETAIL.LABEL.LIST.GROUP.PURCHASE.RESERVE10'), false);

	outputHeader = outputHeader + convert(MessageManager.getMessage('TOMS.STOCK.DETAIL.LABEL.LIST.SKU'), true)
				  + convert(MessageManager.getMessage('TOMS.STOCK.DETAIL.LABEL.LIST.SKU.DESCRIPTION1'), true)
				  + convert(MessageManager.getMessage('TOMS.STOCK.DETAIL.LABEL.LIST.SKU.DESCRIPTION2'), true)
				  + convert(MessageManager.getMessage('TOMS.STOCK.DETAIL.LABEL.LIST.STOCK.COUNT'), true)
				  + convert(MessageManager.getMessage('TOMS.STOCK.DETAIL.LABEL.LIST.KEEP.COUNT'), true)
				  + convert(MessageManager.getMessage('TOMS.STOCK.DETAIL.LABEL.LIST.STOCK.COUNT'), true)
				  + convert(MessageManager.getMessage('TOMS.STOCK.DETAIL.LABEL.LIST.KEEP.COUNT'), true)
				  + convert(MessageManager.getMessage('TOMS.STOCK.DETAIL.LABEL.LIST.PURCHASE.RESERVE.DATE'), true)
				  + convert(MessageManager.getMessage('TOMS.STOCK.DETAIL.LABEL.LIST.STOCK.COUNT'), true)
				  + convert(MessageManager.getMessage('TOMS.STOCK.DETAIL.LABEL.LIST.KEEP.COUNT'), true)
				  + convert(MessageManager.getMessage('TOMS.STOCK.DETAIL.LABEL.LIST.PURCHASE.RESERVE.DATE'), true)
				  + convert(MessageManager.getMessage('TOMS.STOCK.DETAIL.LABEL.LIST.STOCK.COUNT'), true)
				  + convert(MessageManager.getMessage('TOMS.STOCK.DETAIL.LABEL.LIST.KEEP.COUNT'), true)
				  + convert(MessageManager.getMessage('TOMS.STOCK.DETAIL.LABEL.LIST.PURCHASE.RESERVE.DATE'), true)
				  + convert(MessageManager.getMessage('TOMS.STOCK.DETAIL.LABEL.LIST.STOCK.COUNT'), true)
				  + convert(MessageManager.getMessage('TOMS.STOCK.DETAIL.LABEL.LIST.KEEP.COUNT'), true)
				  + convert(MessageManager.getMessage('TOMS.STOCK.DETAIL.LABEL.LIST.PURCHASE.RESERVE.DATE'), true)
				  + convert(MessageManager.getMessage('TOMS.STOCK.DETAIL.LABEL.LIST.STOCK.COUNT'), true)
				  + convert(MessageManager.getMessage('TOMS.STOCK.DETAIL.LABEL.LIST.KEEP.COUNT'), true)
				  + convert(MessageManager.getMessage('TOMS.STOCK.DETAIL.LABEL.LIST.PURCHASE.RESERVE.DATE'), true)
				  + convert(MessageManager.getMessage('TOMS.STOCK.DETAIL.LABEL.LIST.STOCK.COUNT'), true)
				  + convert(MessageManager.getMessage('TOMS.STOCK.DETAIL.LABEL.LIST.KEEP.COUNT'), true)
				  + convert(MessageManager.getMessage('TOMS.STOCK.DETAIL.LABEL.LIST.PURCHASE.RESERVE.DATE'), true)
				  + convert(MessageManager.getMessage('TOMS.STOCK.DETAIL.LABEL.LIST.STOCK.COUNT'), true)
				  + convert(MessageManager.getMessage('TOMS.STOCK.DETAIL.LABEL.LIST.KEEP.COUNT'), true)
				  + convert(MessageManager.getMessage('TOMS.STOCK.DETAIL.LABEL.LIST.PURCHASE.RESERVE.DATE'), true)
				  + convert(MessageManager.getMessage('TOMS.STOCK.DETAIL.LABEL.LIST.STOCK.COUNT'), true)
				  + convert(MessageManager.getMessage('TOMS.STOCK.DETAIL.LABEL.LIST.KEEP.COUNT'), true)
				  + convert(MessageManager.getMessage('TOMS.STOCK.DETAIL.LABEL.LIST.PURCHASE.RESERVE.DATE'), true)
				  + convert(MessageManager.getMessage('TOMS.STOCK.DETAIL.LABEL.LIST.STOCK.COUNT'), true)
				  + convert(MessageManager.getMessage('TOMS.STOCK.DETAIL.LABEL.LIST.KEEP.COUNT'), true)
				  + convert(MessageManager.getMessage('TOMS.STOCK.DETAIL.LABEL.LIST.PURCHASE.RESERVE.DATE'), true)
				  + convert(MessageManager.getMessage('TOMS.STOCK.DETAIL.LABEL.LIST.STOCK.COUNT'), true)
				  + convert(MessageManager.getMessage('TOMS.STOCK.DETAIL.LABEL.LIST.KEEP.COUNT'), true)
				  + convert(MessageManager.getMessage('TOMS.STOCK.DETAIL.LABEL.LIST.PURCHASE.RESERVE.DATE'), true)
				  + convert(MessageManager.getMessage('TOMS.STOCK.DETAIL.LABEL.LIST.STOCK.COUNT'), true)
				  + convert(MessageManager.getMessage('TOMS.STOCK.DETAIL.LABEL.LIST.KEEP.COUNT'), false);
	return outputHeader;
}

/**
 * 在庫詳細のCSVファイルの行を出力する処理
 * 
 * @param record DBから検索した行のデータ
 */
function outputCSVRow(record) {
	var result = convert(record["imlitm"], true)
			+ convert(record["imdsc1"], true)
			+ convert(record["imdsc2"], true)
			+ convert(record["lipqoh"], true)
			+ convert(record["tcy57akrqt_r"], true)
			+ convert(record["tqy57bqtya"], true)
			+ convert(record["tcy57akrqt_f"], true)
			+ convert(record["tpy57brdd1_1"], true)
			+ convert(record["tqy57bqtya_1"], true)
			+ convert(record["ify57akqty_1"], true)
			+ convert(record["tpy57brdd1_2"], true)
			+ convert(record["tqy57bqtya_2"], true)
			+ convert(record["ify57akqty_2"], true)
			+ convert(record["tpy57brdd1_3"], true)
			+ convert(record["tqy57bqtya_3"], true)
			+ convert(record["ify57akqty_3"], true)
			+ convert(record["tpy57brdd1_4"], true)
			+ convert(record["tqy57bqtya_4"], true)
			+ convert(record["ify57akqty_4"], true)
			+ convert(record["tpy57brdd1_5"], true)
			+ convert(record["tqy57bqtya_5"], true)
			+ convert(record["ify57akqty_5"], true)
			+ convert(record["tpy57brdd1_6"], true)
			+ convert(record["tqy57bqtya_6"], true)
			+ convert(record["ify57akqty_6"], true)
			+ convert(record["tpy57brdd1_7"], true)
			+ convert(record["tqy57bqtya_7"], true)
			+ convert(record["ify57akqty_7"], true)
			+ convert(record["tpy57brdd1_8"], true)
			+ convert(record["tqy57bqtya_8"], true)
			+ convert(record["ify57akqty_8"], true)
			+ convert(record["tpy57brdd1_9"], true)
			+ convert(record["tqy57bqtya_9"], true)
			+ convert(record["ify57akqty_9"], true)
			+ convert(record["tpy57brdd1_10"], true)
			+ convert(record["tqy57bqtya_10"], true)
			+ convert(record["ify57akqty_10"], false);

	return result;
}

/**
 * CSV出力ファイルの各カラムデータ変換処理
 * 項目の区切り文字はカーマである
 * 
 * @param data 項目
 * @param flag 非改行フラグ
 */
function convert(data, flag) {
	if (data != null && data != "") {
		if (flag) {
			return transferComma(data) + getComma();
		} else {
			return transferComma(data) + getNewLine();
		}
	} else {
		if (flag) {
			return  getComma();
		} else {
			return  getNewLine();
		}
		
	}
}

/**
 * 項目の区切り文字を取得する処理
 */
function getComma() {
	return MessageManager.getMessage('TOMS.COMMON.COMMA');
}

/**
 * 改行の区切り文字を取得する処理
 */
function getNewLine() {
	return MessageManager.getMessage('TOMS.COMMON.NEWLINE');
}

/**
 * 項目データ中に半角カーマがある場合、全角のカーマに変換する処理
 */
function transferComma(data) {
	if (data != null && data != "") {
		if (data instanceof String) {
			var comma = MessageManager.getMessage('TOMS.COMMON.COMMA');
			return data.replace(/,/g, MessageManager.getMessage('TOMS.COMMON.COMMA.JP'));
		} else {
			return data;
		}
	} else {
		return data;
	}
}


/**
 * エラー画面へ遷移の処理.
 */
function error(message) {
  Transfer.toErrorPage({
    title: MessageManager.getMessage('TOMS.COMMON.ERROR.PAGE.TITLE'),
    message: MessageManager.getMessage('TOMS.COMMON.ERROR.MESSAGE.SYSTEM'),
    detail: [MessageManager.getMessage('TOMS.STOCK.DETAIL.LABEL.MESSAGE.ERROR'), message],
    returnUrl: 'toms/stock/search/input', // 戻り先 URL
    returnUrlLabel: MessageManager.getMessage('TOMS.STOCK.SEARCH.LABEL.RETURN.LINK.NAME'),
    parameter: {
    }
  });
}