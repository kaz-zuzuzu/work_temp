SELECT
   MFPID1
    ,MFUSER1
    ,MFEV01
FROM
  F57C1050
/*BEGIN*/
WHERE
    /*IF mfpid1 != null*/
    TRIM(MFPID1) = /*mfpid1*/'010015200102'
    /*END*/
    /*IF mfuser1 != null*/
    AND TRIM(MFUSER1) = /*mfuser1*/'31'
    /*END*/
    /*IF mfev01 != null*/
    AND TRIM(MFEV01) = /*mfev01*/'31'
    /*END*/
/*END*/