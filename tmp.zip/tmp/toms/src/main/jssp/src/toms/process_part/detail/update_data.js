/**
 * 加工部位マスタ設定更新処理群
 * 
 * toms\src\main\jssp\src\toms\process_part\detail\update_data.js
 * 
 */

load('toms/common/common');
load('toms/common/cmnUtil');
load('toms/common/mastermaintenance');
var _SHARED_DB_KEY = "toms-web-dev";

function init(request){
	
	var entity = createEntity(request);
	var msg;
	var result;
	
	//更新用SQL
	var condition =" TRIM(mky57appc1) =?"+ 
							" AND TRIM(mky57appc2) =? " + 
							" AND TRIM(mky57apcsc) =? " + 
							" AND TRIM(mky57acsc) =? " + 
							" AND TRIM(mky57amtc) =? " + 
							" AND mky57adflg =0 " + 
							" AND mkeftj =? ";
							
	//更新用キー
	var params = [
		   DbParameter.string(entity['mky57appc1']),
		   DbParameter.string(entity['mky57appc2']),
		   DbParameter.string(entity['mky57apcsc']),
		   DbParameter.string(entity['mky57acsc']),
		   DbParameter.string(entity['mky57amtc']),
		   DbParameter.number(entity['mkeftj'])
	];
	
	//------------------------------------
	//新規登録時
	//------------------------------------
	if(request.operateFlag=="0"){
	/*重複チェック*/
		result = _dbCheck(entity['mky57appc1'],entity['mky57appc2'],entity['mky57apcsc'],entity['mky57acsc'],entity['mky57amtc'],entity['mkeftj']);
    	if(result.error){
            // SELECTが失敗した場合
        	msg = MessageManager.getMessage('TOMS.COMMON.MAINTENANCE.AJAX.ERROR.INSERT.MESSAGE', MessageManager.getMessage('TOMS.MASTER.MAINTENANCE.PROCESSPART.DETAIL.INPUT.TITLE'));
        	common.sendErrorResult(msg, "");
    	}
    	if(result.countRow !=0){
    		// 既に登録済みの場合
        	msg = MessageManager.getMessage('TOMS.COMMON.MAINTENANCE.AJAX.ERROR.INSERT.MESSAGE', MessageManager.getMessage('TOMS.MASTER.MAINTENANCE.PROCESSPART.DETAIL.INPUT.TITLE'));
        	common.sendErrorResult(msg, MessageManager.getMessage('TOMS.COMMON.MAINTENANCE.AJAX.ERROR.INSERT.NOTNEWDATA.MESSAGE'));
    	}
    	
	/*内部コードマスタ存在チェック*/
		//加工部位コード
		result = MasterMain.checkCodeMaster("04","01",entity['mky57appc1']);
    	if(result.error){
            // SELECTが失敗した場合
        	msg = MessageManager.getMessage('TOMS.COMMON.MAINTENANCE.AJAX.ERROR.INSERT.MESSAGE', MessageManager.getMessage('TOMS.MASTER.MAINTENANCE.PROCESSPART.DETAIL.INPUT.TITLE'));
        	common.sendErrorResult(msg, "");
    	}
    	if(result.countRow ==0){
    		// 存在しない場合
        	msg = MessageManager.getMessage('TOMS.COMMON.MAINTENANCE.AJAX.ERROR.INSERT.MESSAGE', MessageManager.getMessage('TOMS.MASTER.MAINTENANCE.PROCESSPART.DETAIL.INPUT.TITLE'));
        	common.sendErrorResult(msg, MessageManager.getMessage('TOMS.COMMON.MAINTENANCE.AJAX.ERROR.CODEMASTER.NOTINLINE.MESSAGE',MessageManager.getMessage('TOMS.MASTER.MAINTENANCE.PROCESSPART.LABEL.PROCESSPART_CODE')));
    	}
		//加工位置コード
		result = MasterMain.checkCodeMaster("05","01",entity['mky57appc2']);
    	if(result.error){
            // SELECTが失敗した場合
        	msg = MessageManager.getMessage('TOMS.COMMON.MAINTENANCE.AJAX.ERROR.INSERT.MESSAGE', MessageManager.getMessage('TOMS.MASTER.MAINTENANCE.PROCESSPART.DETAIL.INPUT.TITLE'));
        	common.sendErrorResult(msg, "");
    	}
    	if(result.countRow ==0){
    		// 存在しない場合
        	msg = MessageManager.getMessage('TOMS.COMMON.MAINTENANCE.AJAX.ERROR.INSERT.MESSAGE', MessageManager.getMessage('TOMS.MASTER.MAINTENANCE.PROCESSPART.DETAIL.INPUT.TITLE'));
        	common.sendErrorResult(msg, MessageManager.getMessage('TOMS.COMMON.MAINTENANCE.AJAX.ERROR.CODEMASTER.NOTINLINE.MESSAGE',MessageManager.getMessage('TOMS.MASTER.MAINTENANCE.PROCESSPART.LABEL.PROCESSPART_POSITION_CODE')));
    	}
    	//親商品形態コード
		result = MasterMain.checkCodeMaster("01","01",entity['mky57apcsc']);
    	if(result.error){
            // SELECTが失敗した場合
        	msg = MessageManager.getMessage('TOMS.COMMON.MAINTENANCE.AJAX.ERROR.INSERT.MESSAGE', MessageManager.getMessage('TOMS.MASTER.MAINTENANCE.PROCESSPART.DETAIL.INPUT.TITLE'));
        	common.sendErrorResult(msg, "");
    	}
    	if(result.countRow ==0){
    		// 存在しない場合
        	msg = MessageManager.getMessage('TOMS.COMMON.MAINTENANCE.AJAX.ERROR.INSERT.MESSAGE', MessageManager.getMessage('TOMS.MASTER.MAINTENANCE.PROCESSPART.DETAIL.INPUT.TITLE'));
        	common.sendErrorResult(msg, MessageManager.getMessage('TOMS.COMMON.MAINTENANCE.AJAX.ERROR.CODEMASTER.NOTINLINE.MESSAGE',MessageManager.getMessage('TOMS.MASTER.MAINTENANCE.COMMODITYSHAPE.LABEL.PARENT_COMMODITY_SHAPE_CODE')));
    	}    	
    	//商品形態コード
		result = MasterMain.checkCodeMaster("02","01",entity['mky57acsc']);
		if(result.error){
            // SELECTが失敗した場合
        	msg = MessageManager.getMessage('TOMS.COMMON.MAINTENANCE.AJAX.ERROR.INSERT.MESSAGE', MessageManager.getMessage('TOMS.MASTER.MAINTENANCE.PROCESSPART.DETAIL.INPUT.TITLE'));
        	common.sendErrorResult(msg, "");
    	}
    	if(result.countRow ==0){
    		// 存在しない場合
        	msg = MessageManager.getMessage('TOMS.COMMON.MAINTENANCE.AJAX.ERROR.INSERT.MESSAGE', MessageManager.getMessage('TOMS.MASTER.MAINTENANCE.PROCESSPART.DETAIL.INPUT.TITLE'));
        	common.sendErrorResult(msg, MessageManager.getMessage('TOMS.COMMON.MAINTENANCE.AJAX.ERROR.CODEMASTER.NOTINLINE.MESSAGE',MessageManager.getMessage('TOMS.MASTER.MAINTENANCE.COMMODITYSHAPE.LABEL.COMMODITY_SHAPE_CODE')));
    	}    	
    	//素材コード
		result = MasterMain.checkCodeMaster("03","01",entity['mky57amtc']);
    	if(result.error){
            // SELECTが失敗した場合
        	msg = MessageManager.getMessage('TOMS.COMMON.MAINTENANCE.AJAX.ERROR.INSERT.MESSAGE', MessageManager.getMessage('TOMS.MASTER.MAINTENANCE.PROCESSPART.DETAIL.INPUT.TITLE'));
        	common.sendErrorResult(msg, "");
    	}
    	if(result.countRow ==0){
    		// 存在しない場合
        	msg = MessageManager.getMessage('TOMS.COMMON.MAINTENANCE.AJAX.ERROR.INSERT.MESSAGE', MessageManager.getMessage('TOMS.MASTER.MAINTENANCE.PROCESSPART.DETAIL.INPUT.TITLE'));
        	common.sendErrorResult(msg, MessageManager.getMessage('TOMS.COMMON.MAINTENANCE.AJAX.ERROR.CODEMASTER.NOTINLINE.MESSAGE',MessageManager.getMessage('TOMS.MASTER.MAINTENANCE.MATERIAL.LABEL.MATERIAL_CODE')));
    	}    	
//		//JDEコード　部位
//		result = MasterMain.checkCodeMaster("04","02",entity['mky57ajcp1']);
//    	if(result.error){
//            // SELECTが失敗した場合
//        	msg = MessageManager.getMessage('TOMS.COMMON.MAINTENANCE.AJAX.ERROR.INSERT.MESSAGE', MessageManager.getMessage('TOMS.MASTER.MAINTENANCE.PROCESSPART.DETAIL.INPUT.TITLE'));
//        	common.sendErrorResult(msg, "");
//    	}
//    	if(result.countRow ==0){
//    		// 存在しない場合
//        	msg = MessageManager.getMessage('TOMS.COMMON.MAINTENANCE.AJAX.ERROR.INSERT.MESSAGE', MessageManager.getMessage('TOMS.MASTER.MAINTENANCE.PROCESSPART.DETAIL.INPUT.TITLE'));
//        	common.sendErrorResult(msg, MessageManager.getMessage('TOMS.COMMON.MAINTENANCE.AJAX.ERROR.CODEMASTER.NOTINLINE.MESSAGE',MessageManager.getMessage('TOMS.MASTER.MAINTENANCE.PROCESSPART.LABEL.PROCESSPART_JDECODE_PART')));
//    	}  
//		//JDEコード 位置
//		result = MasterMain.checkCodeMaster("05","02",entity['mky57ajcp2']);
//    	if(result.error){
//            // SELECTが失敗した場合
//        	msg = MessageManager.getMessage('TOMS.COMMON.MAINTENANCE.AJAX.ERROR.INSERT.MESSAGE', MessageManager.getMessage('TOMS.MASTER.MAINTENANCE.PROCESSPART.DETAIL.INPUT.TITLE'));
//        	common.sendErrorResult(msg, "");
//    	}
//    	if(result.countRow ==0){
//    		// 存在しない場合
//        	msg = MessageManager.getMessage('TOMS.COMMON.MAINTENANCE.AJAX.ERROR.INSERT.MESSAGE', MessageManager.getMessage('TOMS.MASTER.MAINTENANCE.PROCESSPART.DETAIL.INPUT.TITLE'));
//        	common.sendErrorResult(msg, MessageManager.getMessage('TOMS.COMMON.MAINTENANCE.AJAX.ERROR.CODEMASTER.NOTINLINE.MESSAGE',MessageManager.getMessage('TOMS.MASTER.MAINTENANCE.PROCESSPART.LABEL.PROCESSPART_JDECODE_POSITION')));
//    	}  
   	/*DB存在チェック*/
    	//素材マスタ
		result = _dbCheckMaterial(entity['mky57amtc'],entity['mky57apcsc'],entity['mky57acsc']);
		if(result.error){
            // SELECTが失敗した場合
        	msg = MessageManager.getMessage('TOMS.COMMON.MAINTENANCE.AJAX.ERROR.INSERT.MESSAGE', MessageManager.getMessage('TOMS.MASTER.MAINTENANCE.PROCESSPART.DETAIL.INPUT.TITLE'));
        	common.sendErrorResult(msg, "");
    	}
    	if(result.countRow ==0){
    		// 存在しない場合
        	msg = MessageManager.getMessage('TOMS.COMMON.MAINTENANCE.AJAX.ERROR.INSERT.MESSAGE', MessageManager.getMessage('TOMS.MASTER.MAINTENANCE.PROCESSPART.DETAIL.INPUT.TITLE'));
        	common.sendErrorResult(msg, MessageManager.getMessage('TOMS.COMMON.MAINTENANCE.AJAX.ERROR.CODEMASTER.NOTINLINE.MESSAGE',MessageManager.getMessage('TOMS.MASTER.MAINTENANCE.MATERIAL.LABEL.MATERIAL_CODE')));
    	}   	
    	//登録実行
    	result = insertToF57A5120(entity);
        if (result.error) {
            // 処理が失敗した場合
        	msg = MessageManager.getMessage('TOMS.COMMON.MAINTENANCE.AJAX.ERROR.INSERT.MESSAGE', MessageManager.getMessage('TOMS.MASTER.MAINTENANCE.PROCESSPART.DETAIL.INPUT.TITLE'));
        	common.sendErrorResult(msg, "");
        }
        
        // 処理が成功した場合
        msg = MessageManager.getMessage('TOMS.COMMON.MAINTENANCE.AJAX.SUCCESS.INSERT.MESSAGE', MessageManager.getMessage('TOMS.MASTER.MAINTENANCE.PROCESSPART.DETAIL.INPUT.TITLE'));
        common.sendResult(msg,"");
        
	//------------------------------------
	//更新時
	//------------------------------------
	}else if(request.operateFlag=="1"){

//	/*内部コードマスタ存在チェック*/
//		//JDEコード 部位
//		result = MasterMain.checkCodeMaster("04","02",entity['mky57ajcp1']);
//    	if(result.error){
//            // SELECTが失敗した場合
//        	msg = MessageManager.getMessage('TOMS.COMMON.MAINTENANCE.AJAX.ERROR.UPDATE.MESSAGE', MessageManager.getMessage('TOMS.MASTER.MAINTENANCE.PROCESSPART.DETAIL.INPUT.TITLE'));
//        	common.sendErrorResult(msg, "");
//    	}
//    	if(result.countRow ==0){
//    		// 存在しない場合
//        	msg = MessageManager.getMessage('TOMS.COMMON.MAINTENANCE.AJAX.ERROR.UPDATE.MESSAGE', MessageManager.getMessage('TOMS.MASTER.MAINTENANCE.PROCESSPART.DETAIL.INPUT.TITLE'));
//        	common.sendErrorResult(msg, MessageManager.getMessage('TOMS.COMMON.MAINTENANCE.AJAX.ERROR.CODEMASTER.NOTINLINE.MESSAGE',MessageManager.getMessage('TOMS.MASTER.MAINTENANCE.PROCESSPART.LABEL.PROCESSPART_JDECODE_PART')));
//    	}  			
//		//JDEコード 位置
//		result = MasterMain.checkCodeMaster("05","02",entity['mky57ajcp2']);
//    	if(result.error){
//            // SELECTが失敗した場合
//        	msg = MessageManager.getMessage('TOMS.COMMON.MAINTENANCE.AJAX.ERROR.UPDATE.MESSAGE', MessageManager.getMessage('TOMS.MASTER.MAINTENANCE.PROCESSPART.DETAIL.INPUT.TITLE'));
//        	common.sendErrorResult(msg, "");
//    	}
//    	if(result.countRow ==0){
//    		// 存在しない場合
//        	msg = MessageManager.getMessage('TOMS.COMMON.MAINTENANCE.AJAX.ERROR.UPDATE.MESSAGE', MessageManager.getMessage('TOMS.MASTER.MAINTENANCE.PROCESSPART.DETAIL.INPUT.TITLE'));
//        	common.sendErrorResult(msg, MessageManager.getMessage('TOMS.COMMON.MAINTENANCE.AJAX.ERROR.CODEMASTER.NOTINLINE.MESSAGE',MessageManager.getMessage('TOMS.MASTER.MAINTENANCE.PROCESSPART.LABEL.PROCESSPART_JDECODE_POSITION')));
//    	}  			
//    	/*DB存在チェック*/
//		result = _dbCheck(entity['mky57appc1'],entity['mky57appc2'],entity['mky57apcsc'],entity['mky57acsc'],entity['mky57amtc'],entity['mkeftj']);
//     	if(result.error){
//            // SELECTが失敗した場合
//        	msg = MessageManager.getMessage('TOMS.COMMON.MAINTENANCE.AJAX.ERROR.UPDATE.MESSAGE', MessageManager.getMessage('TOMS.MASTER.MAINTENANCE.PROCESSPART.DETAIL.INPUT.TITLE'));
//        	common.sendErrorResult(msg, "");
//    	}
//    	if(result.countRow ==0){
//    		// 既に登録済みの場合
//        	msg = MessageManager.getMessage('TOMS.COMMON.MAINTENANCE.AJAX.ERROR.UPDATE.MESSAGE', MessageManager.getMessage('TOMS.MASTER.MAINTENANCE.PROCESSPART.DETAIL.INPUT.TITLE'));
//        	common.sendErrorResult(msg, MessageManager.getMessage('TOMS.COMMON.MAINTENANCE.AJAX.ERROR.UPDATE.NODATA.MESSAGE'));
//    	}
    	//更新処理
		result = updateToF57A5120(entity, condition, params);
        if (result.error) {
            // 処理が失敗した場合
        	msg = MessageManager.getMessage('TOMS.COMMON.MAINTENANCE.AJAX.ERROR.UPDATE.MESSAGE', MessageManager.getMessage('TOMS.MASTER.MAINTENANCE.PROCESSPART.DETAIL.INPUT.TITLE'));
        	common.sendErrorResult(msg, "");
        }
        if (result.countRow != 1) {
            // 対象データが存在しない場合
        	msg = MessageManager.getMessage('TOMS.COMMON.MAINTENANCE.AJAX.ERROR.UPDATE.MESSAGE', MessageManager.getMessage('TOMS.MASTER.MAINTENANCE.PROCESSPART.DETAIL.INPUT.TITLE'));
        	common.sendErrorResult(msg, MessageManager.getMessage('TOMS.COMMON.MAINTENANCE.AJAX.ERROR.UPDATE.NODATA.MESSAGE'));
        }
        // 処理が成功した場合
        msg = MessageManager.getMessage('TOMS.COMMON.MAINTENANCE.AJAX.SUCCESS.UPDATE.MESSAGE', MessageManager.getMessage('TOMS.MASTER.MAINTENANCE.PROCESSPART.DETAIL.INPUT.TITLE'));
        common.sendResult(msg,"");

//------------------------------------
//削除時
//------------------------------------
	}else if(request.operateFlag=="2"){
    	/*
    	 * DB存在チェック
    	 */
		result = removeFromF57A5120(condition, params);
	    if (result.error) {
	        // 処理が失敗した場合
        	msg = MessageManager.getMessage('TOMS.COMMON.MAINTENANCE.AJAX.ERROR.DELETE.MESSAGE', MessageManager.getMessage('TOMS.MASTER.MAINTENANCE.PROCESSPART.DETAIL.INPUT.TITLE'));
        	common.sendErrorResult(msg, "");
	    }
        if(result.countRow != 1){
	    	// 処理件数が１件でない場合
        	msg = MessageManager.getMessage('TOMS.COMMON.MAINTENANCE.AJAX.ERROR.DELETE.MESSAGE', MessageManager.getMessage('TOMS.MASTER.MAINTENANCE.PROCESSPART.DETAIL.INPUT.TITLE'));
        	common.sendErrorResult(msg, MessageManager.getMessage('TOMS.COMMON.MAINTENANCE.AJAX.ERROR.DELETE.NODATA.MESSAGE'));
	    }
	    // 処理が成功した場合
        msg = MessageManager.getMessage('TOMS.COMMON.MAINTENANCE.AJAX.SUCCESS.DELETE.MESSAGE', MessageManager.getMessage('TOMS.MASTER.MAINTENANCE.PROCESSPART.DETAIL.INPUT.TITLE'));
        common.sendResult(msg,"");	
	}
}


/**
 * DBへの登録オブジェクト生成処理
 */
function createEntity(request){
	
	var userContext = Contexts.getUserContext();
	var now = new Date();
	
	//変数初期化
	var mky57appc1 = null; //加工部位コード
	var mky57appc2 = null; //加工位置コード
	var mky57apcsc =null;//親商品形態コード
	var mky57acsc = null;//商品形態コード
	var mky57amtc = null; //素材コード
	var mkdl01 = null; //加工部位名称
	var mkdl02 = null; //加工位置名称

	var mky57adop1 =null;//表示順 部位
	var mky57adop2 =null;//表示順 位置
	var mky57ajcp1 =null;//JDEコード 部位
	var mky57ajcp2 =null;//JDEコード 位置
	var mkeftj =null;//適用開始日
	
	var mkuser = userContext.userProfile.userCd; //ユーザID
    var mkpid = "TOMS-WEB"; //プログラムID
	var mkupmj = cmnUtil.convertDateToJulia(now);  //更新日付
	var mkupmt = cmnUtil.getTime(now);  //更新時刻
	
	//加工部位コード
    if(!isBlank(request.mky57appc1)){
    	mky57appc1 = request.mky57appc1;
    }
	//加工位置コード
    if(!isBlank(request.mky57appc2)){
    	mky57appc2 = request.mky57appc2;
    }
	//親商品形態コード
    if(!isBlank(request.mky57apcsc)){
    	mky57apcsc = request.mky57apcsc;
    }
	//商品形態コード
    if(!isBlank(request.mky57acsc)){
    	mky57acsc = request.mky57acsc;
    }
    //素材コード
    if(!isBlank(request.mky57amtc)){
    	mky57amtc = request.mky57amtc;
    }

    //加工部位名称
    if(!isBlank(request.mkdl01)){
    	mkdl01 = request.mkdl01;
    }
    //加工位置名称
    if(!isBlank(request.mkdl02)){
    	mkdl02 = request.mkdl02;
    }
    if(mky57appc2=="P2999" && isBlank(mkdl02)){
		//加工位置コードが99で加工位置名称がblankの場合、半角スペースをセットする
		mkdl02 ="　";
	}

	//表示順 部位
    if(!isBlank(request.mky57adop1)){
    	mky57adop1 = cmnUtil.getData(request.mky57adop1,1);
    }
	//表示順 位置
    if(!isBlank(request.mky57adop2)){
    	mky57adop2 = cmnUtil.getData(request.mky57adop2,1);
    }
	//JDEコード 部位
    if(!isBlank(request.mky57ajcp1)){
    	mky57ajcp1 = request.mky57ajcp1;
    }
	//JDEコード 位置
    if(!isBlank(request.mky57ajcp2)){
    	mky57ajcp2 = request.mky57ajcp2;
    }
	//適用開始日
    if(!isBlank(request.mkeftj)){
    	mkeftj = cmnUtil.convertDateToJulia(new Date(request.mkeftj));
    }
    
    var entity ={
    	mky57appc1 : mky57appc1,
    	mky57appc2 : mky57appc2,
	    mky57apcsc : mky57apcsc,
	    mky57acsc : mky57acsc,
	    mky57amtc : mky57amtc,
	    mkdl01 : mkdl01,
	    mkdl02 : mkdl02,
		mky57adop1 : mky57adop1,
		mky57adop2 : mky57adop2,
//    	mky57ajcp1 : mky57ajcp1,
//    	mky57ajcp2 : mky57ajcp2,
    	mky57ajcp1 : "　",
    	mky57ajcp2 : "　",
//		mky57adflg : mky57adflg,
        mkeftj : mkeftj,
    	mkuser : mkuser,
    	mkpid : mkpid,
    	mkupmj : mkupmj,
    	mkupmt : mkupmt 
    };
    return entity;
}

/*データ存在チェック*/

function _dbCheck( mky57appc1, mky57appc2 , mky57apcsc, mky57acsc ,mky57amtc , mkeftj){
	var db = new SharedDatabase(_SHARED_DB_KEY);
	var params = [];

	var sql ="";
	sql += " SELECT * FROM F57A5120 ";
	sql +="     WHERE ";
	sql +="              TRIM(MKY57APPC1) = ? ";
	sql +="          AND TRIM(MKY57APPC2) = ? ";
	sql +="          AND TRIM(MKY57APCSC) = ? ";
	sql +="          AND TRIM(MKY57ACSC) = ? ";
	sql +="          AND TRIM(MKY57AMTC) = ? ";
	sql +="          AND TRIM(MKEFTJ) = ? ";

  params.push(DbParameter.string(mky57appc1));
  params.push(DbParameter.string(mky57appc2));
  params.push(DbParameter.string(mky57apcsc));
  params.push(DbParameter.string(mky57acsc));
  params.push(DbParameter.string(mky57amtc));
  params.push(DbParameter.string(mkeftj+""));
	var result = db.execute(sql, params);
	return result;
}



/**
 * データ存在チェック
 */
function _dbCheckCommodity( commodityShapCode , parentCommodityShapeCode){
	var db = new SharedDatabase(_SHARED_DB_KEY);
	var params = [];

	var sql ="";
	sql += " SELECT * FROM F57A5110 ";
	sql +="     WHERE ";
	sql +="          TRIM(MLY57ACSC) = ? ";
	sql +="          AND TRIM(MLY57APCSC) = ? ";

  params.push(DbParameter.string(commodityShapCode));
  params.push(DbParameter.string(parentCommodityShapeCode));
	var result = db.execute(sql, params);
	return result;
}

/* DB存在チェック */
	
function _dbCheckMaterial(materialCode, parentCode, commodityCode){
	var db = new SharedDatabase(_SHARED_DB_KEY);
	var params = [];

	var sql ="";
	sql += " SELECT * FROM F57A5130 ";
	sql +="     WHERE ";
	sql +="          TRIM(MLY57AMTC) = ? ";
	sql +="          AND TRIM(MLY57APCSC) = ? ";
	sql +="          AND TRIM(MLY57ACSC) = ? ";

  params.push(DbParameter.string(materialCode));
  params.push(DbParameter.string(parentCode));
  params.push(DbParameter.string(commodityCode));
	var result = db.execute(sql, params);
	return result;
	
	
}
	
	
	
/**
 * 登録処理
 */
function insertToF57A5120(entity){
	var database = new SharedDatabase(_SHARED_DB_KEY);
	var ret = Transaction.begin(function(){
		entity.mky57adflg=0;//削除フラグ追加
		entity.mkexdj = cmnUtil.convertDateToJulia(new Date(MessageManager.getMessage('TOMS.COMMON.CONSTANT.ENDDATE')));
		var result = database.insert('F57A5120', entity);
		if(result.error || result.countRow !=1){
			Transaction.rollback();
		}
		return result;
	})
	return ret.data;
}
function updateToF57A5120(entity, condition, params) {
	var database = new SharedDatabase(_SHARED_DB_KEY);
	var ret = Transaction.begin(function(){
		var result = database.update('F57A5120', entity, condition, params);
		if(result.error || result.countRow !=1){
			Transaction.rollback();
		}
			return result;
	})
	return ret.data;
}
function removeFromF57A5120(condition, params) {
	var database = new SharedDatabase(_SHARED_DB_KEY);
	var ret = Transaction.begin(function(){
		var entity ={
			mky57adflg : 1
			};
		var result = database.update('F57A5120',entity,  condition, params);
		if(result.error || result.countRow !=1){
			Transaction.rollback();
		}
		return result;
	})
	return ret.data;
}
