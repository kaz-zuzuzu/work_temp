SELECT
    *
FROM
(
    SELECT
        base.*
      , ROWNUM AS RN
    FROM
    (
select
   TRIM(bui.MKY57APPC1) AS MKY57APPC1
  ,TRIM(bui.MKY57APPC2) AS MKY57APPC2
  ,TRIM(OYA.MJY57ACSC) AS MKY57APCSC
  ,TRIM(KO.MJY57ACSC) AS MKY57ACSC
  ,TRIM(SOZAI.MLY57AMTC) AS MKY57AMTC
  ,TRIM(bui.MKDL01) AS MKDL01
  ,TRIM(bui.MKDL02) AS MKDL02
  ,TRIM(SOZAI.MLDL01) AS MKY57AMTCNAME  
  ,TRIM(KO.MJDL01) AS MKY57ACSCNAME
  ,TRIM(OYA.MJDL01) AS MKY57APCSCNAME 
from  				
  ( 
    select
      MKY57APPC1 
      , MKY57APPC2
      , MKY57APCSC
      , MKY57ACSC
      , MKY57AMTC
      , MKDL01
      , MKDL02
      , dense_rank() over ( partition by MKY57APPC1 ,MKY57APPC2  ,MKY57APCSC ,MKY57ACSC ,MKY57AMTC order by MKEFTJ desc ) rnk 
    from
      F57A5120
    where
      mky57adflg = 0 
      and MKEFTJ <= FC_JDI9902_TO_JULIAN(sysdate)
  ) bui,
  ( 
    select
      MLY57AMTC 
      , MLY57APCSC
      , MLY57ACSC
      , MLDL01
      , dense_rank() over ( partition by MLY57AMTC ,MLY57APCSC, MLY57ACSC order by MLEFTJ desc ) rnk 
    from
      F57A5130 a
    where
      mly57adflg = 0 
      and MLEFTJ <= FC_JDI9902_TO_JULIAN(sysdate)
  ) sozai,

  ( 
    select
      MJY57ACSC
      , MJY57APCSC
      , MJDL01
      , dense_rank() over ( partition by MJY57ACSC ,MJY57APCSC order by MJEFTJ desc ) rnk 
    from
      F57A5110 
    where
      mjy57adflg = 0 
      and MJEFTJ <= FC_JDI9902_TO_JULIAN(sysdate)
  ) ko,

  ( 
    select
      MJY57ACSC
      , MJY57APCSC
      , MJDL01
      , dense_rank() over ( partition by MJY57ACSC ,MJY57APCSC order by MJEFTJ desc ) rnk 
    from
      F57A5110 
    where
      mjy57adflg = 0 
      and MJEFTJ <= FC_JDI9902_TO_JULIAN(sysdate)
  ) oya

where
   bui.rnk=1
  and sozai.rnk=1
  and ko.rnk = 1
  and oya.rnk = 1
  and bui.MKY57AMTC = sozai.MLY57AMTC
  and bui.MKY57APCSC = sozai.MLY57APCSC
  and bui.MKY57ACSC = sozai.MLY57ACSC
  and bui.MKY57ACSC = sozai.MLY57ACSC
  and sozai.MLY57APCSC = ko.MJY57APCSC
  and sozai.MLY57APCSC = oya.MJY57ACSC
  and sozai.MLY57ACSC = ko.MJY57ACSC
  and ko.MJY57APCSC = oya.MJY57ACSC
           /*IF mky57acsc !=null*/
           AND TRIM(ko.MJY57ACSC) =/*mky57acsc*/
           /*END*/
            /*IF mky57acscName != null*/
           AND ko.MJDL01 like /*mky57acscName*/
           /*END*/
           /*IF mky57apcsc != null*/
            AND TRIM(oya.MJY57ACSC) = /*mky57apcsc*/
           /*END*/
            /*IF mky57apcscName != null*/
           AND oya.MJDL01 like /*mky57apcscName*/
           /*END*/
           /*IF mky57amtc != null*/
            AND TRIM(sozai.MLY57AMTC) = /*mky57amtc*/
           /*END*/
            /*IF mky57amtcName != null*/
           AND sozai.MLDL01 like /*mky57amtcName*/
           /*END*/
           
           /*IF mky57appc1 != null*/
            AND TRIM(bui.MKY57APPC1) = /*mky57appc1*/
           /*END*/
            /*IF mkdl01 != null*/
           AND bui.MKDL01 like /*mkdl01*/
           /*END*/
           /*IF mky57appc2 != null*/
            AND TRIM(bui.MKY57APPC2) = /*mky57appc2*/
           /*END*/
            /*IF mkdl02 != null*/
           AND bui.MKDL02 like /*mkdl02*/
           /*END*/
           order by bui.MKY57APPC1,bui.MKY57APPC2, sozai.MLY57AMTC,oya.MJY57ACSC,ko.MJY57ACSC
    ) base
     /*IF end != null*/
        WHERE ROWNUM <= /*end*/'10' 
     /*END*/

)
/*IF start != null*/
WHERE RN >= /*start*/'1' 
/*END*/
