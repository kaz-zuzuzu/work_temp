var init={
   'paymentPersonCode': { // バリデーション対象のformのname属性を指定する.
       caption: 'TOMS.BILL.SEARCH.INPUT.PAYMENTPERSON.CODE', // キャプションのメッセージキーを指定する. 
       numeric:  true,
       required: false
   },
   'exchangeTargetCode': { // バリデーション対象のformのname属性を指定する.
       caption: 'TOMS.BILL.SEARCH.INPUT.EXCHANGETARGET.CODE', // キャプションのメッセージキーを指定する. 
       numeric:  true,
       required: false
   },
   'paymentPersonKana': { // バリデーション対象のformのname属性を指定する.
       caption: 'TOMS.BILL.SEARCH.INPUT.PAYMENTPERSON.KANA', // キャプションのメッセージキーを指定する. 
       regex: /^[ｧ-ﾝﾞﾟ]+$/
   },
   'exchangeTargetKana': { // バリデーション対象のformのname属性を指定する.
       caption: 'TOMS.EXCHANGE.SEARCH.INPUT.EXCHANGETARGET.KANA', // キャプションのメッセージキーを指定する. 
       regex: /^[ｧ-ﾝﾞﾟ]+$/
   }
}