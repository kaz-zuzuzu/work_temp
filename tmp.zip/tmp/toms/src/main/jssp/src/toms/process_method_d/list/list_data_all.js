var $data;

/**
 * 初期表示
 * @param request リクエストパラメータ
 */
	
function init(request) {
	$data = ImJson.toJSONString(getList(request)); 
}

function getList(request) {

	// 表示条件を設定（表示ページ、件数など）
	let page = request.page == undefined ? 1 : request.page;
	let rows = request.rowNum == undefined ? 15 : Module.number.toInt(request.rowNum);
	
	// 検索条件の状況に応じて条件を設定する
	var param = request.extension;
	if (!param || !param.searchCondition) {
    	return  {
                		page  : page,
                		total : rows,
                		data  : []
    				};
	}
	
	//検索条件の設定
//	var mny57apmc = isBlank(param.searchCondition.mny57apmc) ? null : param.searchCondition.mny57apmc;//加工方法コード


	var mndl01 = isBlank(param.searchCondition.mndl01) ? null : param.searchCondition.mndl01;//加工方法名称
	var mny57apcsc = isBlank(param.searchCondition.mny57apcsc) ? null : param.searchCondition.mny57apcsc;//親商品形態コード
	var mny57apcscName = isBlank(param.searchCondition.mny57apcscName) ? null : param.searchCondition.mny57apcscName;//親商品形態名称
	var mny57acsc = isBlank(param.searchCondition.mny57acsc) ? null : param.searchCondition.mny57acsc;//商品形態コード
	var mny57acscName = isBlank(param.searchCondition.mny57acscName) ? null : param.searchCondition.mny57acscName;//商品形態名称
	var mny57amtc = isBlank(param.searchCondition.mny57amtc) ? null : param.searchCondition.mny57amtc;//素材コード
	var mny57amtcName = isBlank(param.searchCondition.mny57amtcName) ? null : param.searchCondition.mny57amtcName;//原材料名
	var mny57appc1= isBlank(param.searchCondition.mny57appc1) ? null : param.searchCondition.mny57appc1;//加工部位コード
	var mny57appc1Name = isBlank(param.searchCondition.mny57appc1Name) ? null : param.searchCondition.mny57appc1Name;//加工部位名称
	var mny57appc2 = isBlank(param.searchCondition.mny57appc2) ? null : param.searchCondition.mny57appc2;//加工位置コード
	var mny57appc2Name= isBlank(param.searchCondition.mny57appc2Name) ? null : param.searchCondition.mny57appc2Name;//加工位置名称
	var mny57apmt = isBlank(param.searchCondition.mny57apmt) ? null : param.searchCondition.mny57apmt;//加工方法区分
	var mny57apmdt = isBlank(param.searchCondition.mny57apmdt) ? null : param.searchCondition.mny57apmdt;//加工方法明細区分

    var mny57apmn1 = isBlank(param.searchCondition.mny57apmn1) ? null : param.searchCondition.mny57apmn1;//第1階層名称
    var mny57ado1  = isBlank(param.searchCondition.mny57ado1) ? null : param.searchCondition.mny57ado1;//第1階層表示順
    var mny57ajc1  = isBlank(param.searchCondition.mny57ajc1) ? null : param.searchCondition.mny57ajc1;//第1階層JDEコード
    var mny57agn1  = isBlank(param.searchCondition.mny57agn1) ? null : param.searchCondition.mny57agn1;//第1階層グループ名称
    
    var mny57apmn2 = isBlank(param.searchCondition.mny57apmn2) ? null : param.searchCondition.mny57apmn2;//第2階層名称
    var mny57ado2  = isBlank(param.searchCondition.mny57ado2) ? null : param.searchCondition.mny57ado2;//第2階層表示順
    var mny57ajc2 = isBlank(param.searchCondition.mny57ajc2) ? null : param.searchCondition.mny57ajc2;//第2階層JDEコード
    var mny57agn2  = isBlank(param.searchCondition.mny57agn2) ? null : param.searchCondition.mny57agn2;//第2階層グループ名称

	var mny57apmn3 = isBlank(param.searchCondition.mny57apmn3) ? null : param.searchCondition.mny57apmn3;//第3階層名称
    var mny57ado3  = isBlank(param.searchCondition.mny57ado3) ? null : param.searchCondition.mny57ado3;//第1階層表示順
    var mny57ajc3  = isBlank(param.searchCondition.mny57ajc3) ? null : param.searchCondition.mny57ajc3;//第3階層JDEコード
    var mny57agn3  = isBlank(param.searchCondition.mny57agn3) ? null : param.searchCondition.mny57agn3;//第3階層グループ名称

	var mneftj = isBlank(param.searchCondition.mneftj) ? null :param.searchCondition.mneftj ;//適用開始日
	var mneftj2 = isBlank(param.searchCondition.mneftj2) ? null :param.searchCondition.mneftj2 ;//適用開始日
	var mny57adflg = isBlank(param.searchCondition.mny57adflg) ? null : param.searchCondition.mny57adflg ;//削除フラグ


	var objParams = {
//		mny57apmc : mny57apmc,
		mndl01 : mndl01,
        mny57apcsc : mny57apcsc,
        mny57apcscName : mny57apcscName,
        mny57acsc : mny57acsc,
        mny57acscName : mny57acscName,
        mny57amtc : mny57amtc,
        mny57amtcName : mny57amtcName,
        mny57appc1 : mny57appc1,
        mny57appc1Name : mny57appc1Name,
        mny57appc2 : mny57appc2,
        mny57appc2Name : mny57appc2Name,
        mny57apmt : mny57apmt,
        mny57apmdt : mny57apmdt,
        mny57apmn1 : mny57apmn1,
		mny57ado1 : mny57ado1,
		mny57ajc1 : mny57ajc1,
		mny57agn1 : mny57agn1,
    	mny57apmn2 : mny57apmn2,
    	mny57ado2 : mny57ado2,
    	mny57ajc2 : mny57ajc2,
    	mny57agn2 : mny57agn2,
    	mny57apmn3 : mny57apmn3,
    	mny57ado3 : mny57ado3,
    	mny57ajc3 : mny57ajc3,
    	mny57agn3 : mny57agn3,
		mneftj : mneftj,
		mneftj2 : mneftj2,
		mny57adflg : mny57adflg		
	}
	//加工方法明細マスタの件数取得
	var resultCount = getDetailListCount(objParams);
	// 全体の件数を設定（件数の母数）
	var listCount = 0;
	if (!resultCount.error) {
		listCount = resultCount.data[0]['rowcount'];
	} else {
		Debug.write(resultCount.errorMessage);
	}

	// ページ番号設定:リクエストパラメータのページ番号、最大ページ番号のうち小さい方の番号を設定
	page = Math.min(page, Math.ceil(listCount / rows)); 
	
	// 指定範囲の加工方法明細情報(STEP2)を取得
	var start = rows * (page - 1) + 1;
	var end = start + rows - 1;

	//加工方法明細マスタの一覧取得(STEP2)
	var result = getDetailList(objParams, start, end);
	var resultData =[];
	if(!result.error){
		resultData = result.data;
	}else{
		Debug.write(result.errorMessage);
	}

	var json = {
		page  : page,
		total : listCount,
		data  : resultData
	};
	
	return json;

	
	}

/**
 * 加工方法明細一覧件数取得
 */	
function getDetailListCount(objParams){
    load("toms/common/processMethod");
    var result = ProcessMethod.getDetailAllList(objParams, true,"","");
    return result;
}

/**
 * 加工方法明細一覧データ取得
 */
function getDetailList(objParams, start , end){
    load("toms/common/processMethod");
    var result = ProcessMethod.getDetailAllList(objParams, false,start,end);
    return result;
	
}

function createResult(page, total, data){
	return {
		page : page == null ? 1 : page,
		total : total == null ? 0 : total,
		data : data == null ? [] : data
	};
}


/**
 * エラーオブジェクト生成
 */
function createErrorResult(message, details){
	return {
		error : true,
		errorMessage : message,
		detailMessages : details

	}
}
