SELECT
    COUNT(*) AS ROWCOUNT

    FROM
(
    SELECT 
        MJ.MJY57ACSC AS MJY57ACSC
        ,MJ.MJY57APCSC AS MJY57APCSC
        ,MJ.MJDL01 AS MJDL01
    FROM
        F57A5110 MJ

    WHERE
       MJ.MJY57ACSC = MJ.MJY57APCSC
        AND MJ.MJY57ADFLG = 0
        AND MJ.MJEFTJ <= FC_JDI9902_TO_JULIAN(SYSDATE)

        /*IF paramName != null*/
        AND  TRIM(MJ.MJDL01) like /*paramName*/'%TEST%'
        /*END*/
        /*IF paramCode != null*/
        AND  TRIM(MJ.MJY57ACSC) = /*paramCode*/'TISTS01'
        /*END*/
)
