/**
 * 検索画面validation設定
 */
var init = {
  'receiveOrderNo':{
    caption:'TOMS.DELIVERY.SEARCH.INPUT.RECEIVEORDER.NO',
    numeric: true
  },
  'instructNo':{
    caption:'TOMS.DELIVERY.SEARCH.INPUT.INSTRUCT_NO',
    numeric: true
  },
  'exchangeTarget': { // バリデーション対象のformのname属性を指定する.
	  caption: 'TOMS.DELIVERY.SEARCH.INPUT.EXCHANGETARGET.KANA', // キャプションのメッセージキーを指定する. 
	  regex: /^[ｧ-ﾝﾞﾟ]+$/  
  },
  'deliveryDateFrom':{
	  caption:'TOMS.COMMON.SEARCH.INPUT.STARTDATE',
	  date: true
  },
  'deliveryDateTo':{
	  caption:'TOMS.COMMON.SEARCH.INPUT.ENDDATE',
	  date: true
  }

};