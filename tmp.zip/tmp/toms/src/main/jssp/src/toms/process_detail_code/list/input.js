/**
 * 加工明細コード管理マスタメンテナンス一覧
 *
 **/
// バインド変数
var $bind = {};
var $data = {};
load("toms/common/common");

/**
 * 初期表示
 * @param request リクエストパラメータ
 */
function init(request) {
    var csvObj;
    
    // ***** 初期表示処理 or 検索処理 *****
    //--------------------
    // 共通部品ヘッダー情報取得用のパラメータ取得
    //--------------------
    $bind.mmy57apmc = isBlank(request.mmy57apmc) ? "" : request.mmy57apmc ;//加工方法コード
    $bind.mmyeftj = isBlank(request.mmyeftj) ? "" : request.mmyeftj;//適用開始日（加工方法ヘッダ）

    if (request.csvFlag != "1") {
        $bind.dialogMessages="";
        
        $bind.beforeUrl = request.beforeUrl;
        
        $data = {
            pageNum : isBlank(request.pageNum) ? '1' : request.pageNum,
            rowNum  : isBlank(request.rowNum) ? '30' : request.rowNum,
            rowList : isBlank(request.rowList) ? '30, 50, 100' : request.rowList
        };
        
        //--------------------
        // 加工方法区分生成
        //--------------------
        var processMethodData = MessageManager.getMessage('TOMS.MASTER.MAINTENANCE.PROCESS_METHOD_DATA');
        var splitData = processMethodData.split(',');
        // 加工方法区分のチェックボックスオブジェクト格納用
        var processMethodList = []; 
        // チェックされている要素の情報を配列で取得
        var arrMry57apmt = request.getParameters("search_mry57apmt");
        // チェックされている値を格納する配列
        var checkedList = [];
        for (var i = 0; i < splitData.length; i++) {
            var checkFlg = "false";
            var data = splitData[i].split(':');
            // プロパティから取得した加工方法区分と、チェックされているデータが一致したら「checked：true」とする
            for (var key in arrMry57apmt) {
                var value = arrMry57apmt[key].getValue();
                if (!isBlank(value)) {
                    if (value == data[0]) {
                        checkFlg = "true";
                        checkedList.push(value);
                    }
                }
            }
            var listObj = {
                        label : data[1],
                        value : data[0],
                        checked : checkFlg
            };
            processMethodList.push(listObj);
        }
        $bind.processMethodList = processMethodList;
        
        //--------------------
        // 加工方法明細区分生成
        //--------------------
        var processMethodDetailData = MessageManager.getMessage('TOMS.MASTER.MAINTENANCE.PROCESS_METHOD_DETAIL_DATA');
        var splitDetailData = processMethodDetailData.split(',');
        // 加工方法明細区分のチェックボックスオブジェクト格納用
        var processMethodDetailList = [];
        // チェックされている要素の情報を配列で取得
        var arrMry57apmdt = request.getParameters("search_mry57apmdt");
        // チェックされている値を格納する配列
        var checkedDetailList = [];
        
        for (var i = 0; i < splitDetailData.length; i++) {
            var checkFlg = "false";
            var data = splitDetailData[i].split(':');
            // プロパティから取得した加工方法区分と、チェックされているデータが一致したら「checked：true」とする
            for (var key in arrMry57apmdt) {
                var value = arrMry57apmdt[key].getValue();
                if (!isBlank(value)) {
                    if (value == data[0]) {
                        checkFlg = "true";
                        checkedDetailList.push(value);
                    }
                }
            }
            var listObj = {
                        label : data[1],
                        value : data[0],
                        checked : checkFlg
            }
            processMethodDetailList.push(listObj);
        }
        $bind.processMethodDetailList = processMethodDetailList;
        
        //--------------------
        // 加工明細判定区分
        //--------------------
        var processDetailJudgeData = MessageManager.getMessage('TOMS.MASTER.MAINTENANCE.PROCESS_DETAIL_JUDGE_DECISION_DATA');
        var splitJudgeData = processDetailJudgeData.split(',');
        // 加工明細判定区分のチェックボックスオブジェクト格納用
        var processDetailJudgeTypeList = [];
        // チェックされている要素の情報を配列で取得
        var arrMry57apdjt = request.getParameters("search_mry57apdjt");
        // チェックされている値を格納する配列
        var checkedJudgeList = [];
        
        for (var i = 0; i < splitJudgeData.length; i++) {
            var checkFlg = "false";
            var data = splitJudgeData[i].split(':');
            // プロパティから取得した加工方法区分と、チェックされているデータが一致したら「checked：true」とする
            for (var key in arrMry57apdjt) {
                var value = arrMry57apdjt[key].getValue();
                if (!isBlank(value)) {
                    if (value == data[0]) {
                        checkFlg = "true";
                        checkedJudgeList.push(value);
                    }
                }
            }
            var listObj = {
                        label : data[1],
                        value : data[0],
                        checked : checkFlg
            }
            processDetailJudgeTypeList.push(listObj);
        }
        $bind.processDetailJudgeTypeList = processDetailJudgeTypeList;
        
        // ***** 検索条件設定（画面表示およびCSV出力用） *****
        $bind.mry57apcsc = isBlank(request.search_mry57apcsc) ? "" : request.search_mry57apcsc;             // 親商品形態コード
        $bind.mry57apcscName = isBlank(request.search_mry57apcscName) ? "" : request.search_mry57apcscName; // 親商品形態名称
        $bind.mry57acsc = isBlank(request.search_mry57acsc) ? "" : request.search_mry57acsc;                // 商品形態コード
        $bind.mry57acscName = isBlank(request.search_mry57acscName) ? "" : request.search_mry57acscName;    // 商品形態名称
        $bind.mry57amtc = isBlank(request.search_mry57amtc) ? "" : request.search_mry57amtc;                // 素材コード
        $bind.mldl01 = isBlank(request.search_mldl01) ? "" : request.search_mldl01;                         // 原材料名称
        $bind.mry57appc1 = isBlank(request.search_mry57appc1) ? "" : request.search_mry57appc1;             // 加工部位コード
        $bind.mkdl01 = isBlank(request.search_mkdl01) ? "" : request.search_mkdl01;                         // 加工部位名称
        $bind.mry57appc2 = isBlank(request.search_mry57appc2) ? "" : request.search_mry57appc2;             // 加工位置コード
        $bind.mkdl02 = isBlank(request.search_mkdl02) ? "" : request.search_mkdl02;                         // 加工位置名称
        $bind.mry57apmt = isBlank(request.search_mry57apmt) ? "" : checkedList.join(",");                   // 加工方法区分
        $bind.mry57apmdt = isBlank(request.search_mry57apmdt) ? "" : checkedDetailList.join(",");           // 加工方法明細区分
        $bind.mry57apmd1 = isBlank(request.search_mry57apmd1) ? "" : request.search_mry57apmd1;             // 加工方法明細第1階層コード
        $bind.mny57apmn1 = isBlank(request.search_mny57apmn1) ? "" : request.search_mny57apmn1;             // 加工方法明細第1階層名称
        $bind.mry57apmd2 = isBlank(request.search_mry57apmd2) ? "" : request.search_mry57apmd2;             // 加工方法明細第2階層コード
        $bind.mny57apmn2 = isBlank(request.search_mny57apmn2) ? "" : request.search_mny57apmn2;             // 加工方法明細第2階層名称
        $bind.mry57apmd3 = isBlank(request.search_mry57apmd3) ? "" : request.search_mry57apmd3;             // 加工方法明細第3階層コード
        $bind.mny57apmn3 = isBlank(request.search_mny57apmn3) ? "" : request.search_mny57apmn3;             // 加工方法明細第3階層名称
        $bind.mry57apdjt = isBlank(request.search_mry57apdjt) ? "" : checkedJudgeList.join(",");            // 加工明細判定区分
        $bind.mruorg = isBlank(request.search_mruorg) ? "" : request.search_mruorg;                         // 数量
        $bind.mry57alsku = isBlank(request.search_mry57alsku) ? "" : request.search_mry57alsku;             // 紐づけSKUコード
        $bind.mry57alskuName = isBlank(request.search_mry57alskuName) ? "" : request.search_mry57alskuName; // 紐づけSKU名称
        $bind.mry57aoa = isBlank(request.search_mry57aoa) ? "" : request.search_mry57aoa;                   // 注文枚数
        // 削除フラグ（初期表示時は「0：未削除」とする）
        if (((!request.search_mry57adflg) && (request.search_mry57adflg != "")) ||
            (request.search_mry57adflg == "0")) {
            $bind.mry57adflg = "0";
            $bind.checked_notdelete = true;
        } else if (request.search_mry57adflg == "1") {
            $bind.mry57adflg = "1";
            $bind.checked_delete = true;
        } else if (request.search_mry57adflg == "") {
            $bind.mry57adflg = "";
            $bind.checked_both = true;
        }
        $bind.mreftj_from = isBlank(request.search_mreftj_from) ? "" : request.search_mreftj_from;          // 適用開始日From
        $bind.mreftj_to = isBlank(request.search_mreftj_to) ? "" : request.search_mreftj_to;                // 適用開始日To
        
        // 削除フラグ用ラジオボタンのラベル設定
        $bind.select_notdelete=MessageManager.getMessage('TOMS.COMMON.DELETE.SELECT.NOTDELETE');
        $bind.select_delete=MessageManager.getMessage('TOMS.COMMON.DELETE.SELECT.DELETE');
        $bind.select_both=MessageManager.getMessage('TOMS.COMMON.DELETE.SELECT.ALL');
        
        // 「ファイル出力」ボタン押下時の確認ダイアログのメッセージを初期化.
        // JavaScriptで利用するためオブジェクトの内容をそのまま渡します.
        $bind.dialogMessages = ({
            addConfirmTitle: MessageManager.getMessage('TOMS.COMMON.DIALOG.CONFIRM.TITLE'),
            addConfirmMessage: MessageManager.getMessage('TOMS.COMMON.DIALOG.CONFIRM.MESSAGE')
        }).toSource();
    }
    // ***** ファイル出力 *****
    else if (request.csvFlag == "1") {
        // ファイル出力用検索条件設定
        csvObj = {
            mry57apcsc : isBlank(request.csv_mry57apcsc) ? "" : request.csv_mry57apcsc,             // 親商品形態コード
            mry57apcscName : isBlank(request.csv_mry57apcscName) ? "" : request.csv_mry57apcscName, // 親商品形態名称
            mry57acsc : isBlank(request.csv_mry57acsc) ? "" : request.csv_mry57acsc,                // 商品形態コード
            mry57acscName : isBlank(request.csv_mry57acscName) ? "" : request.csv_mry57acscName,    // 商品形態名称
            mry57amtc : isBlank(request.csv_mry57amtc) ? "" : request.csv_mry57amtc,                // 素材コード
            mldl01 : isBlank(request.csv_mldl01) ? "" : request.csv_mldl01,                         // 原材料名称
            mry57appc1 : isBlank(request.csv_mry57appc1) ? "" : request.csv_mry57appc1,             // 加工部位コード
            mkdl01 : isBlank(request.csv_mkdl01) ? "" : request.csv_mkdl01,                         // 加工部位名称
            mry57appc2 : isBlank(request.csv_mry57appc2) ? "" : request.csv_mry57appc2,             // 加工位置コード
            mkdl02 : isBlank(request.csv_mkdl02) ? "" : request.csv_mkdl02,                         // 加工位置名称
            mry57apmt : isBlank(request.csv_mry57apmt) ? "" : request.csv_mry57apmt,                // 加工方法区分
            mry57apmdt : isBlank(request.csv_mry57apmdt) ? "" : request.csv_mry57apmdt,             // 加工方法明細区分
            mry57apmd1 : isBlank(request.csv_mry57apmd1) ? "" : request.csv_mry57apmd1,             // 加工方法明細第1階層コード
            mny57apmn1 : isBlank(request.csv_mny57apmn1) ? "" : request.csv_mny57apmn1,             // 加工方法明細第1階層名称
            mry57apmd2 : isBlank(request.csv_mry57apmd2) ? "" : request.csv_mry57apmd2,             // 加工方法明細第2階層コード
            mny57apmn2 : isBlank(request.csv_mny57apmn2) ? "" : request.csv_mny57apmn2,             // 加工方法明細第2階層名称
            mry57apmd3 : isBlank(request.csv_mry57apmd3) ? "" : request.csv_mry57apmd3,             // 加工方法明細第3階層コード
            mny57apmn3 : isBlank(request.csv_mny57apmn3) ? "" : request.csv_mny57apmn3,             // 加工方法明細第3階層名称
            mry57apdjt : isBlank(request.csv_mry57apdjt) ? "" : request.csv_mry57apdjt,             // 加工明細判定区分
            mruorg : isBlank(request.csv_mruorg) ? "" : request.csv_mruorg,                         // 数量
            mry57alsku : isBlank(request.csv_mry57alsku) ? "" : request.csv_mry57alsku,             // 紐づけSKUコード
            mry57alskuName : isBlank(request.csv_mry57alskuName) ? "" : request.csv_mry57alskuName, // 紐づけSKU名称
            mry57aoa : isBlank(request.csv_mry57aoa) ? "" : request.csv_mry57aoa,                   // 注文枚数
            mry57adflg : isBlank(request.csv_mry57adflg) ? "" : request.csv_mry57adflg,             // 削除フラグ
            mreftj_from : isBlank(request.csv_mreftj_from) ? "" : request.csv_mreftj_from,          // 適用開始日From
            mreftj_to : isBlank(request.csv_mreftj_to) ? "" : request.csv_mreftj_to                 // 適用開始日To
        };
        outputCSV(csvObj);
    }
}

/**
 * 加工明細コード管理マスタメンテナンスのCSV出力処理
 * 
 * @param リクエストパラメータ
 * 
 */
function outputCSV(param){
    load("toms/common/processDetailCode");
    var result = ProcessDetailCode.getList(param, false, null, null);

    var outputContent = "";
    if (!result.error) {
        outputContent = outputCSVHeader();
        for(var i = 0; i < result.countRow; i++) {
            outputContent += outputCSVRow(result.data[i]);
        }
        var strDate = DateTimeFormatter.format("yyyyMMdd_HHmmss", new Date());
        var strUserName = Contexts.getUserContext().userProfile.userName;
        var fileName = MessageManager.getMessage('TOMS.MASTER.MAINTENANCE.PROCESS_DETAIL_CODE.CSV.FILE.NAME') + '_' + strDate + '_' + strUserName + '.csv';
        Module.download.send(Unicode.to(outputContent, 'MS932'), fileName, MessageManager.getMessage('TOMS.COMMON.MIME.CSV'));
    } else {
        error(result.errorMessage);
    }
}

/**
 * 加工明細コード管理マスタメンテナンスのCSVヘッダ部分出力処理。
 */
function outputCSVHeader() {
    var outputHeader = common.convert(MessageManager.getMessage('TOMS.COMMON.CSV.UPDATE.DIVIDE'), true)                                                // 更新区分
                + common.convert(MessageManager.getMessage("TOMS.MASTER.MAINTENANCE.COMMODITYSHAPE.LABEL.PARENT_COMMODITY_SHAPE_CODE"), true)          // 親商品形態コード
                + common.convert(MessageManager.getMessage("TOMS.MASTER.MAINTENANCE.COMMODITYSHAPE.LABEL.COMMODITY_SHAPE_CODE"), true)                 // 商品形態コード
                + common.convert(MessageManager.getMessage("TOMS.MASTER.MAINTENANCE.MATERIAL.LABEL.MATERIAL_CODE"), true)                              // 素材コード
                + common.convert(MessageManager.getMessage("TOMS.MASTER.MAINTENANCE.PROCESSPART.LABEL.PROCESSPART_CODE"), true)                        // 加工部位コード
                + common.convert(MessageManager.getMessage("TOMS.MASTER.MAINTENANCE.PROCESSPART.LABEL.PROCESSPART_POSITION_CODE"), true)               // 加工位置コード
                + common.convert(MessageManager.getMessage("TOMS.MASTER.MAINTENANCE.PROCESSMETHOD_HEADER.LABEL.PROCESS_METHOD_TPYE"), true)            // 加工方法区分
                + common.convert(MessageManager.getMessage("TOMS.MASTER.MAINTENANCE.PROCESSMETHOD_HEADER.LABEL.PROCESS_METHOD_DETAIL_TPYE"), true)     // 加工方法明細区分
                + common.convert(MessageManager.getMessage("TOMS.MASTER.MAINTENANCE.BODY_NOT_RECOMMENDED.PROCESS_DETAIL_FIRST_HIERARCHY_CODE"), true)  // 加工方法明細第1階層コード
                + common.convert(MessageManager.getMessage("TOMS.MASTER.MAINTENANCE.BODY_NOT_RECOMMENDED.PROCESS_DETAIL_SECOND_HIERARCHY_CODE"), true) // 加工方法明細第2階層コード
                + common.convert(MessageManager.getMessage("TOMS.MASTER.MAINTENANCE.BODY_NOT_RECOMMENDED.PROCESS_DETAIL_THIRD_HIERARCHY_CODE"), true)  // 加工方法明細第3階層コード
                + common.convert(MessageManager.getMessage("TOMS.MASTER.MAINTENANCE.PROCESS_DETAIL_CODE.PROCESS_DETAIL_DECISION_DIVIDE"), true)        // 加工明細判定区分
                + common.convert(MessageManager.getMessage("TOMS.MASTER.MAINTENANCE.SALES.DETAIL.INPUT.MAUORG"), true)                                 // 数量
                + common.convert(MessageManager.getMessage("TOMS.MASTER.MAINTENANCE.PROCESS_DETAIL_CODE.LINK_SKU_CODE"), true)                         // 紐づけSKUコード
                + common.convert(MessageManager.getMessage("TOMS.MASTER.MAINTENANCE.PROCESS_DETAIL_CODE.ORDER_COUNT"), true)                           // 注文枚数
                + common.convert(MessageManager.getMessage("TOMS.MASTER.MAINTENANCE.PROCESS_DETAIL_CODE.COMMODITY_SHAPE_JDE"), true)                           // 商品形態_JDEコード
                + common.convert(MessageManager.getMessage("TOMS.MASTER.MAINTENANCE.PROCESS_DETAIL_CODE.MATERIAL_JDE"), true)                           // 素材_JDEコード
                + common.convert(MessageManager.getMessage("TOMS.MASTER.MAINTENANCE.PROCESS_DETAIL_CODE.PART_JDE"), true)                           // 加工部位_JDEコード
                + common.convert(MessageManager.getMessage("TOMS.MASTER.MAINTENANCE.PROCESS_DETAIL_CODE.POSITION_JDE"), true)                           // 加工位置_JDEコード
                + common.convert(MessageManager.getMessage("TOMS.MASTER.MAINTENANCE.COMMODITYSHAPE.LABEL.APPLIED_START_DATE"), true)                   // 適用開始日
                + common.convert(MessageManager.getMessage("TOMS.MASTER.MAINTENANCE.COMMODITYSHAPE.LABEL.DELETE_FLG"), false);                         // 削除フラグ

    return outputHeader;
}

/**
 * ボディ非推奨管理マスタメンテナンスのCSVファイルの行を出力する処理
 * 
 * @param record DBから検索した行のデータ
 */
function outputCSVRow(record) {
    var result =  MessageManager.getMessage('TOMS.COMMON.CSV.SPLIT')
                + common.convert(record["mry57apcsc"], true)   // 親商品形態コード
                + common.convert(record["mry57acsc"], true)    // 商品形態コード
                + common.convert(record["mry57amtc"], true)    // 素材コード
                + common.convert(record["mry57appc1"], true)   // 加工部位コード
                + common.convert(record["mry57appc2"], true)   // 加工位置コード
                + common.convert(record["mry57apmt"], true)    // 加工方法区分
                + common.convert(record["mry57apmdt"], true)   // 加工方法明細区分
                + common.convert(record["mry57apmd1"], true)   // 加工方法明細第1階層コード
                + common.convert(record["mry57apmd2"], true)   // 加工方法明細第2階層コード
                + common.convert(record["mry57apmd3"], true)   // 加工方法明細第3階層コード
                + common.convert(record["mry57apdjt"], true)   // 加工明細判定区分
                + common.convert(record["mruorg"] +"", true)       // 数量
                + common.convert(record["mry57alsku"], true)   // 紐づけSKUコード
                + common.convert(record["mry57aoa"] +"", true)     // 注文枚数
                + common.convert(record["mry57acsj"], true)     // 商品形態_JDEコード
                + common.convert(record["mry57amjc"], true)     // 素材_JDEコード
                + common.convert(record["mry57appa"], true)     // 加工部位_JDEコード
                + common.convert(record["mry57appo"], true)     // 加工位置_JDEコード
                + common.convert(record["mreftj"], true)       // 適用開始日
                + common.convert(record["mry57adflg"] + "", false); // 削除フラグ
                
    return result;
}

function error(message) {
    Transfer.toErrorPage({
        title: MessageManager.getMessage('TOMS.COMMON.ERROR.PAGE.TITLE'),
        message: MessageManager.getMessage('TOMS.COMMON.ERROR.MESSAGE.SYSTEM'),
        detail: [MessageManager.getMessage('TOMS.MASTER.MAINTENANCE.PROCESS_DETAIL_CODE.LIST.LABEL.MESSAGE.ERROR'), message],
        returnUrl: 'toms/process_detail_code/list/input', // 戻り先 URL
        returnUrlLabel: MessageManager.getMessage('TOMS.MASTER.MAINTENANCE.PROCESS_DETAIL_CODE.LIST.LABEL.RETURN.LINK.NAME'),
        parameter: {
        }
    });
}
