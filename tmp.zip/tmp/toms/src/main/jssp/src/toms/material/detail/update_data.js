/**
 * 素材マスタ設定更新処理群
 * 
 * toms\src\main\jssp\src\toms\material\detail\update_data.js
 * 
 */

load('toms/common/common');
load('toms/common/cmnUtil');
load('toms/common/mastermaintenance');
var _SHARED_DB_KEY = "toms-web-dev";

function init(request){

	var entity = createEntity(request);
	var msg;
	var result;
	
	//更新用SQL
	var condition =" TRIM(mly57amtc) =?"+ 
							" AND TRIM(mly57apcsc) =? " + 
							" AND TRIM(mly57acsc) =? " + 
							" AND mly57adflg =0  "+
							" AND mleftj =? ";
							
	//更新用キー
	var params = [
		   DbParameter.string(entity['mly57amtc']),
		   DbParameter.string(entity['mly57apcsc']),
		   DbParameter.string(entity['mly57acsc']),
		   DbParameter.number(entity['mleftj'])
	];
	
	//------------------------------------
	//新規登録時
	//------------------------------------
	if(request.operateFlag=="0"){
	/*重複チェック*/
		result = _dbCheck(entity['mly57amtc'],entity['mly57acsc'],entity['mly57apcsc'],entity['mleftj']);
    	if(result.error){
            // SELECTが失敗した場合
        	msg = MessageManager.getMessage('TOMS.COMMON.MAINTENANCE.AJAX.ERROR.INSERT.MESSAGE', MessageManager.getMessage('TOMS.MASTER.MAINTENANCE.MATERIAL.DETAIL.INPUT.TITLE'));
        	common.sendErrorResult(msg, "");
    	}
    	if(result.countRow !=0){
    		// 既に登録済みの場合
        	msg = MessageManager.getMessage('TOMS.COMMON.MAINTENANCE.AJAX.ERROR.INSERT.MESSAGE', MessageManager.getMessage('TOMS.MASTER.MAINTENANCE.MATERIAL.DETAIL.INPUT.TITLE'));
        	common.sendErrorResult(msg, MessageManager.getMessage('TOMS.COMMON.MAINTENANCE.AJAX.ERROR.INSERT.NOTNEWDATA.MESSAGE'));
    	}
    	
	/*内部コードマスタ存在チェック*/
		//素材コード
		result = MasterMain.checkCodeMaster("03","01",entity['mly57amtc']);
    	if(result.error){
            // SELECTが失敗した場合
        	msg = MessageManager.getMessage('TOMS.COMMON.MAINTENANCE.AJAX.ERROR.INSERT.MESSAGE', MessageManager.getMessage('TOMS.MASTER.MAINTENANCE.MATERIAL.DETAIL.INPUT.TITLE'));
        	common.sendErrorResult(msg, "");
    	}
    	if(result.countRow ==0){
    		// 存在しない場合
        	msg = MessageManager.getMessage('TOMS.COMMON.MAINTENANCE.AJAX.ERROR.INSERT.MESSAGE', MessageManager.getMessage('TOMS.MASTER.MAINTENANCE.MATERIAL.DETAIL.INPUT.TITLE'));
        	common.sendErrorResult(msg, MessageManager.getMessage('TOMS.COMMON.MAINTENANCE.AJAX.ERROR.CODEMASTER.NOTINLINE.MESSAGE',MessageManager.getMessage('TOMS.MASTER.MAINTENANCE.MATERIAL.LABEL.MATERIAL_CODE')));
    	}
		//商品形態コード
		result = MasterMain.checkCodeMaster("02","01",entity['mly57acsc']);
    	if(result.error){
            // SELECTが失敗した場合
        	msg = MessageManager.getMessage('TOMS.COMMON.MAINTENANCE.AJAX.ERROR.INSERT.MESSAGE', MessageManager.getMessage('TOMS.MASTER.MAINTENANCE.MATERIAL.DETAIL.INPUT.TITLE'));
        	common.sendErrorResult(msg, "");
    	}
    	if(result.countRow ==0){
    		// 存在しない場合
        	msg = MessageManager.getMessage('TOMS.COMMON.MAINTENANCE.AJAX.ERROR.INSERT.MESSAGE', MessageManager.getMessage('TOMS.MASTER.MAINTENANCE.MATERIAL.DETAIL.INPUT.TITLE'));
        	common.sendErrorResult(msg, MessageManager.getMessage('TOMS.COMMON.MAINTENANCE.AJAX.ERROR.CODEMASTER.NOTINLINE.MESSAGE',MessageManager.getMessage('TOMS.MASTER.MAINTENANCE.COMMODITYSHAPE.LABEL.COMMODITY_SHAPE_CODE')));
    	}
    	//親商品形態コード
		result = MasterMain.checkCodeMaster("01","01",entity['mly57apcsc']);
    	if(result.error){
            // SELECTが失敗した場合
        	msg = MessageManager.getMessage('TOMS.COMMON.MAINTENANCE.AJAX.ERROR.INSERT.MESSAGE', MessageManager.getMessage('TOMS.MASTER.MAINTENANCE.MATERIAL.DETAIL.INPUT.TITLE'));
        	common.sendErrorResult(msg, "");
    	}
    	if(result.countRow ==0){
    		// 存在しない場合
        	msg = MessageManager.getMessage('TOMS.COMMON.MAINTENANCE.AJAX.ERROR.INSERT.MESSAGE', MessageManager.getMessage('TOMS.MASTER.MAINTENANCE.MATERIAL.DETAIL.INPUT.TITLE'));
        	common.sendErrorResult(msg, MessageManager.getMessage('TOMS.COMMON.MAINTENANCE.AJAX.ERROR.CODEMASTER.NOTINLINE.MESSAGE',MessageManager.getMessage('TOMS.MASTER.MAINTENANCE.COMMODITYSHAPE.LABEL.PARENT_COMMODITY_SHAPE_CODE')));
    	}    	
//		//JDEコード
//		result = MasterMain.checkCodeMaster("03","02",entity['mly57ajdc']);
//    	if(result.error){
//            // SELECTが失敗した場合
//        	msg = MessageManager.getMessage('TOMS.COMMON.MAINTENANCE.AJAX.ERROR.INSERT.MESSAGE', MessageManager.getMessage('TOMS.MASTER.MAINTENANCE.MATERIAL.DETAIL.INPUT.TITLE'));
//        	common.sendErrorResult(msg, "");
//    	}
//    	if(result.countRow ==0){
//    		// 存在しない場合
//        	msg = MessageManager.getMessage('TOMS.COMMON.MAINTENANCE.AJAX.ERROR.INSERT.MESSAGE', MessageManager.getMessage('TOMS.MASTER.MAINTENANCE.MATERIAL.DETAIL.INPUT.TITLE'));
//        	common.sendErrorResult(msg, MessageManager.getMessage('TOMS.COMMON.MAINTENANCE.AJAX.ERROR.CODEMASTER.NOTINLINE.MESSAGE',MessageManager.getMessage('TOMS.MASTER.MAINTENANCE.COMMODITYSHAPE.LABEL.JDE_CODE')));
//    	}  
   	/*DB存在チェック*/
    	//商品形態
		result = _dbCheckCommodity(entity['mly57acsc'],entity['mly57apcsc']);
    	if(result.error){
            // SELECTが失敗した場合
        	msg = MessageManager.getMessage('TOMS.COMMON.MAINTENANCE.AJAX.ERROR.INSERT.MESSAGE', MessageManager.getMessage('TOMS.MASTER.MAINTENANCE.MATERIAL.DETAIL.INPUT.TITLE'));
        	common.sendErrorResult(msg, "");
    	}
    	if(result.countRow ==0){
    		// 存在しない場合
        	msg = MessageManager.getMessage('TOMS.COMMON.MAINTENANCE.AJAX.ERROR.INSERT.MESSAGE', MessageManager.getMessage('TOMS.MASTER.MAINTENANCE.MATERIAL.DETAIL.INPUT.TITLE'));
        	common.sendErrorResult(msg, MessageManager.getMessage('TOMS.COMMON.MAINTENANCE.AJAX.ERROR.CODEMASTER.NOTINLINE.MESSAGE',MessageManager.getMessage('TOMS.MASTER.MAINTENANCE.COMMODITYSHAPE.LABEL.COMMODITY_SHAPE_CODE')));
    	}   	

    /*DB存在チェック*/
    if(!isBlank(entity['mly57absc'])){
        //たたみ袋SKUコード
		result = _dbCheckSku(entity['mly57absc'],entity['mleftj']);
    	if(result.error){
            // SELECTが失敗した場合
        	msg = MessageManager.getMessage('TOMS.COMMON.MAINTENANCE.AJAX.ERROR.INSERT.MESSAGE', MessageManager.getMessage('TOMS.MASTER.MAINTENANCE.MATERIAL.DETAIL.INPUT.TITLE'));
        	common.sendErrorResult(msg, "");
    	}
    	if(result.countRow ==0){
    		// 存在しない場合
        	msg = MessageManager.getMessage('TOMS.COMMON.MAINTENANCE.AJAX.ERROR.INSERT.MESSAGE', MessageManager.getMessage('TOMS.MASTER.MAINTENANCE.MATERIAL.DETAIL.INPUT.TITLE'));
        	common.sendErrorResult(msg, MessageManager.getMessage('TOMS.COMMON.MAINTENANCE.AJAX.ERROR.CODEMASTER.NOTINLINE.MESSAGE',MessageManager.getMessage('TOMS.MASTER.MAINTENANCE.MATERIAL.LABEL.BAG_SKU_CODE')));
    	}   	
    	
    }
    	
    	//登録実行
    	result = insertToF57A5130(entity);
        if (result.error) {
            // 処理が失敗した場合
        	msg = MessageManager.getMessage('TOMS.COMMON.MAINTENANCE.AJAX.ERROR.INSERT.MESSAGE', MessageManager.getMessage('TOMS.MASTER.MAINTENANCE.MATERIAL.DETAIL.INPUT.TITLE'));
        	common.sendErrorResult(msg, "");
        }
        
        // 処理が成功した場合
        msg = MessageManager.getMessage('TOMS.COMMON.MAINTENANCE.AJAX.SUCCESS.INSERT.MESSAGE', MessageManager.getMessage('TOMS.MASTER.MAINTENANCE.MATERIAL.DETAIL.INPUT.TITLE'));
        common.sendResult(msg,"");
        
	//------------------------------------
	//更新時
	//------------------------------------
	}else if(request.operateFlag=="1"){

//	/*内部コードマスタ存在チェック*/
//		//JDEコード
//		result = MasterMain.checkCodeMaster("03","02",entity['mly57ajdc']);
//    	if(result.error){
//            // SELECTが失敗した場合
//        	msg = MessageManager.getMessage('TOMS.COMMON.MAINTENANCE.AJAX.ERROR.UPDATE.MESSAGE', MessageManager.getMessage('TOMS.MASTER.MAINTENANCE.MATERIAL.DETAIL.INPUT.TITLE'));
//        	common.sendErrorResult(msg, "");
//    	}
//    	if(result.countRow ==0){
//    		// 存在しない場合
//        	msg = MessageManager.getMessage('TOMS.COMMON.MAINTENANCE.AJAX.ERROR.UPDATE.MESSAGE', MessageManager.getMessage('TOMS.MASTER.MAINTENANCE.MATERIAL.DETAIL.INPUT.TITLE'));
//        	common.sendErrorResult(msg, MessageManager.getMessage('TOMS.COMMON.MAINTENANCE.AJAX.ERROR.CODEMASTER.NOTINLINE.MESSAGE',MessageManager.getMessage('TOMS.MASTER.MAINTENANCE.COMMODITYSHAPE.LABEL.JDE_CODE')));
//    	}  			
    	/*DB存在チェック*/
		result = _dbCheck(entity['mly57amtc'],entity['mly57acsc'],entity['mly57apcsc'],entity['mleftj']);
    	if(result.error){
            // SELECTが失敗した場合
        	msg = MessageManager.getMessage('TOMS.COMMON.MAINTENANCE.AJAX.ERROR.UPDATE.MESSAGE', MessageManager.getMessage('TOMS.MASTER.MAINTENANCE.MATERIAL.DETAIL.INPUT.TITLE'));
        	common.sendErrorResult(msg, "");
    	}
    	if(result.countRow ==0){
    		// 既に登録済みの場合
        	msg = MessageManager.getMessage('TOMS.COMMON.MAINTENANCE.AJAX.ERROR.UPDATE.MESSAGE', MessageManager.getMessage('TOMS.MASTER.MAINTENANCE.MATERIAL.DETAIL.INPUT.TITLE'));
        	common.sendErrorResult(msg, MessageManager.getMessage('TOMS.COMMON.MAINTENANCE.AJAX.ERROR.UPDATE.NODATA.MESSAGE'));
    	}
    /*DB存在チェック*/
    	//たたみ袋SKUコード
		result = _dbCheckSku(entity['mly57absc'],entity['mleftj']);
    	if(result.error){
            // SELECTが失敗した場合
        	msg = MessageManager.getMessage('TOMS.COMMON.MAINTENANCE.AJAX.ERROR.UPDATE.MESSAGE', MessageManager.getMessage('TOMS.MASTER.MAINTENANCE.MATERIAL.DETAIL.INPUT.TITLE'));
        	common.sendErrorResult(msg, "");
    	}
    	if(result.countRow ==0){
    		// 存在しない場合
        	msg = MessageManager.getMessage('TOMS.COMMON.MAINTENANCE.AJAX.ERROR.UPDATE.MESSAGE', MessageManager.getMessage('TOMS.MASTER.MAINTENANCE.MATERIAL.DETAIL.INPUT.TITLE'));
        	common.sendErrorResult(msg, MessageManager.getMessage('TOMS.COMMON.MAINTENANCE.AJAX.ERROR.CODEMASTER.NOTINLINE.MESSAGE',MessageManager.getMessage('TOMS.MASTER.MAINTENANCE.MATERIAL.LABEL.BAG_SKU_CODE')));
    	}   	
    	
    	//更新処理
		result = updateToF57A5130(entity, condition, params);
        if (result.error) {
            // 処理が失敗した場合
        	msg = MessageManager.getMessage('TOMS.COMMON.MAINTENANCE.AJAX.ERROR.UPDATE.MESSAGE', MessageManager.getMessage('TOMS.MASTER.MAINTENANCE.MATERIAL.DETAIL.INPUT.TITLE'));
        	common.sendErrorResult(msg, "");
        }
        if (result.countRow != 1) {
            // 対象データが存在しない場合
        	msg = MessageManager.getMessage('TOMS.COMMON.MAINTENANCE.AJAX.ERROR.UPDATE.MESSAGE', MessageManager.getMessage('TOMS.MASTER.MAINTENANCE.MATERIAL.DETAIL.INPUT.TITLE'));
        	common.sendErrorResult(msg, MessageManager.getMessage('TOMS.COMMON.MAINTENANCE.AJAX.ERROR.UPDATE.NODATA.MESSAGE'));
        }
        // 処理が成功した場合
        msg = MessageManager.getMessage('TOMS.COMMON.MAINTENANCE.AJAX.SUCCESS.UPDATE.MESSAGE', MessageManager.getMessage('TOMS.MASTER.MAINTENANCE.MATERIAL.DETAIL.INPUT.TITLE'));
        common.sendResult(msg,"");

//------------------------------------
//削除時
//------------------------------------
	}else if(request.operateFlag=="2"){
    	/*
    	 * DB存在チェック
    	 */
		result = removeFromF57A5130(condition, params);
	    if (result.error) {
	        // 処理が失敗した場合
        	msg = MessageManager.getMessage('TOMS.COMMON.MAINTENANCE.AJAX.ERROR.DELETE.MESSAGE', MessageManager.getMessage('TOMS.MASTER.MAINTENANCE.MATERIAL.DETAIL.INPUT.TITLE'));
        	common.sendErrorResult(msg, "");
	    }
        if(result.countRow != 1){
	    	// 処理件数が１件でない場合
        	msg = MessageManager.getMessage('TOMS.COMMON.MAINTENANCE.AJAX.ERROR.DELETE.MESSAGE', MessageManager.getMessage('TOMS.MASTER.MAINTENANCE.MATERIAL.DETAIL.INPUT.TITLE'));
        	common.sendErrorResult(msg, MessageManager.getMessage('TOMS.COMMON.MAINTENANCE.AJAX.ERROR.DELETE.NODATA.MESSAGE'));
	    }
	    // 処理が成功した場合
        msg = MessageManager.getMessage('TOMS.COMMON.MAINTENANCE.AJAX.SUCCESS.DELETE.MESSAGE', MessageManager.getMessage('TOMS.MASTER.MAINTENANCE.MATERIAL.DETAIL.INPUT.TITLE'));
        common.sendResult(msg,"");	
	}
}


/**
 * DBへの登録オブジェクト生成処理
 */
function createEntity(request){
	
	var userContext = Contexts.getUserContext();
	var now = new Date();
	
	//変数初期化
	var mly57amtc = null; //素材コード
	var mldl01 = null; //原材料名
	var mly57acsc = null;//商品形態コード
	var mly57apcsc =null;//親商品形態コード

	var mlpct1 =null;//パーセント
	var mlsnn =null;//表示順
	var mly57ajdc =null;//JDEコード
	var mly57amflg =null;//たたみ袋制御フラグ
	var mly57absc =null;//たたみ袋SKUコード
	var mleftj =null;//適用開始日
	var mly57adflg =0; //削除フラグ
	
	var mluser = userContext.userProfile.userCd; //ユーザID
    var mlpid = "TOMS-WEB"; //プログラムID
	var mlupmj = cmnUtil.convertDateToJulia(now);  //更新日付
	var mlupmt = cmnUtil.getTime(now);  //更新時刻
	
	//素材コード
    if(!isBlank(request.mly57amtc)){
    	mly57amtc = request.mly57amtc;
    }
	//原材料名
    if(!isBlank(request.mldl01)){
    	mldl01 = request.mldl01;
    }
	//商品形態コード
    if(!isBlank(request.mly57acsc)){
    	mly57acsc = request.mly57acsc;
    }
	//親商品形態コード
    if(!isBlank(request.mly57apcsc)){
    	mly57apcsc = request.mly57apcsc;
    }
	//パーセント
    if(!isBlank(request.mlpct1)){
    	mlpct1 = cmnUtil.getData(request.mlpct1,1);
    }
	//表示順
    if(!isBlank(request.mlsnn)){
    	mlsnn = cmnUtil.getData(request.mlsnn,1);
    }
	//JDEコード
    if(!isBlank(request.mly57ajdc)){
    	mly57ajdc = request.mly57ajdc;
    }
	//たたみ袋制御フラグ
    if(!isBlank(request.mly57amflg)){
    	mly57amflg = cmnUtil.getData(request.mly57amflg,1);
    }
	//たたみ袋SKUコード
    if(!isBlank(request.mly57absc)){
    	mly57absc = request.mly57absc;
    }
	//適用開始日
    if(!isBlank(request.mleftj)){
    	mleftj = cmnUtil.convertDateToJulia(new Date(request.mleftj));
    }
    
    var entity ={
    	mly57amtc : mly57amtc,
        mldl01 : mldl01,
        mly57acsc : mly57acsc,
        mly57apcsc : mly57apcsc,
        mlpct1 : mlpct1,
        mlsnn : mlsnn,
//        mly57ajdc : mly57ajdc,//JDEコード廃止に伴い全角スペースを設定
        mly57ajdc : "　",
        mly57amflg : mly57amflg,
        mly57absc : mly57absc,
        mleftj : mleftj,
        mly57adflg : mly57adflg,
    	mluser : mluser,
    	mlpid : mlpid,
    	mlupmj : mlupmj,
    	mlupmt : mlupmt 
    };
    return entity;
}

/**
 * データ存在チェック(素材マスタ)
 */
function _dbCheck( materialCode, commodityShapCode , parentCommodityShapeCode , appliedStartDate){
	var db = new SharedDatabase(_SHARED_DB_KEY);
	var params = [];

	var sql ="";
	sql += " SELECT * FROM F57A5130 ";
	sql +="     WHERE ";
	sql +="              TRIM(MLY57AMTC) = ? ";
	sql +="          AND TRIM(MLY57APCSC) = ? ";
	sql +="          AND TRIM(MLY57ACSC) = ? ";
	sql +="          AND TRIM(MLEFTJ) = ? ";

  params.push(DbParameter.string(materialCode));
  params.push(DbParameter.string(parentCommodityShapeCode));
  params.push(DbParameter.string(commodityShapCode));
  params.push(DbParameter.string(appliedStartDate+""));
	var result = db.execute(sql, params);
	return result;
}

/**
 * データ存在チェック（商品形態）
 */
function _dbCheckCommodity( commodityShapCode , parentCommodityShapeCode){
	var db = new SharedDatabase(_SHARED_DB_KEY);
	var params = [];

	var sql ="";
	sql += " SELECT * FROM F57A5110 ";
	sql +="     WHERE ";
	sql +="          TRIM(MJY57ACSC) = ? ";
	sql +="          AND TRIM(MJY57APCSC) = ? ";

  params.push(DbParameter.string(commodityShapCode));
  params.push(DbParameter.string(parentCommodityShapeCode));
	var result = db.execute(sql, params);
	return result;
}
/**
 * データ存在チェック（SKU品目）
 */
function _dbCheckSku( imlitm, appliedStartDate){
	var db = new SharedDatabase(_SHARED_DB_KEY);
	var params = [];

	var sql ="";
	sql += " SELECT * FROM F4101 IM ";
	sql += "  INNER JOIN F4016 TU ";
	sql += "  ON IM.IMITM = TU.TUITM  ";
	sql +="     WHERE ";
	sql +="          TRIM(IM.IMLITM) = ? ";
	sql +="      AND TU.TUEFTJ <= ? ";
	sql +="      AND TU.TUEXDJ >= ? ";

  params.push(DbParameter.string(imlitm));
  params.push(DbParameter.string(appliedStartDate+""));
  params.push(DbParameter.string(appliedStartDate+""));
	var result = db.execute(sql, params);
	return result;
}
/**
 * 登録処理
 */
function insertToF57A5130(entity){
	var database = new SharedDatabase(_SHARED_DB_KEY);
	var ret = Transaction.begin(function(){
		entity.mlexdj = cmnUtil.convertDateToJulia(new Date(MessageManager.getMessage('TOMS.COMMON.CONSTANT.ENDDATE')));

		var result = database.insert('F57A5130', entity);
		if(result.error || result.countRow !=1){
			Debug.console("登録処理",result, entity);
			Transaction.rollback();
		}
		return result;
	});
	return ret.data;
}
function updateToF57A5130(entity, condition, params) {
	var database = new SharedDatabase(_SHARED_DB_KEY);
	var ret = Transaction.begin(function(){
		var result = database.update('F57A5130', entity, condition, params);
		if(result.error || result.countRow !=1){
			Transaction.rollback();
		}
			return result;
	})
	return ret.data;
}
function removeFromF57A5130(condition, params) {
	var database = new SharedDatabase(_SHARED_DB_KEY);
	var ret = Transaction.begin(function(){
		var entity ={
			mly57adflg : 1
			};
		var result = database.update('F57A5130',entity,  condition, params);
		if(result.error || result.countRow !=1){
			Transaction.rollback();
		}
		return result;
	})
	return ret.data;
}
