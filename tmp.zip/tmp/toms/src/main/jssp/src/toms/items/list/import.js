/**
 * バインド変数.
 */
var $bind = {};

/**
 * 初期表示.
 * @param request リクエストパラメータ.
 */
function init(request) {

	load("toms/common/csv/CsvUtil");
	load("toms/common/csv/CsvCheker");
	load("toms/common/master");
	load("toms/common/cmnUtil");

    var response = Web.getHTTPResponse();
    response.setContentType('text/plain; charset=utf-8');
    var csv = []; // csv二次元配列
    var stErr = new java.lang.StringBuilder(); // エラー文言
    var updateCount = { newCount:0, updateCount:0, deleteCount:0};
    
   
    // ファイルロード csv二次元ファイル化
    if(!CsvUtil.load2Csv(request, csv, stErr)) {
    	doError(response, stErr);
	    return;
	}

	// チェック
	if(!check(csv, stErr)) {
		doError(response, stErr);
		return;
	}
	
	// DBによるチェック
	if(!dbCheck(csv, stErr)) {
		doError(response, stErr);
		return;
	}

	// DB更新
	if(!dbUpdate(csv, stErr, updateCount)) {
		doError(response, stErr);
		return;
	}

	// 正常値の返却
//	stErr.append("<p>登録に成功しました。</p>");
//	stErr.append("<p>挿入件数 " + updateCount.newCount + "件</p>");
//	stErr.append("<p>更新件数 " + updateCount.updateCount + "件</p>");
//	stErr.append("<p>削除件数 " + updateCount.deleteCount + "件</p>");

	stErr.append(MessageManager.getMessage('TOMS.MASTER.MAINTENANCE.ITEMS.LIST.LABEL.MESSAGE.ENTRY'));
	stErr.append(MessageManager.getMessage('TOMS.MASTER.MAINTENANCE.ITEMS.LIST.LABEL.MESSAGE.ENTRYNUM', String(updateCount.newCount)));
	stErr.append(MessageManager.getMessage('TOMS.MASTER.MAINTENANCE.ITEMS.LIST.LABEL.MESSAGE.UPDATENUM', String(updateCount.updateCount)));
	stErr.append(MessageManager.getMessage('TOMS.MASTER.MAINTENANCE.ITEMS.LIST.LABEL.MESSAGE.DELETENUM', String(updateCount.deleteCount)));
	
	var st = stErr.toString();
    response.sendMessageBodyString(ImJson.toJSONString([{
        "message": st,
        "isError": "false"
    }]));
}

/**
 * チェック
 * @param csv csv二次元配列.(IN)
 * @param stErr エラーメッセージパラメータ.(OUT)
 */
function check(csv, stErr) {
	var rowLength = csv.length;	//行数	
	var ret = true;

	// CSVデータ無し
	if(rowLength < 2) {
//		stErr.append("<p>csvファイルにデータがありません。</p>");
		stErr.append(MessageManager.getMessage('TOMS.MASTER.MAINTENANCE.ITEMS.LIST.LABEL.MESSAGE.ERROR.CSVNODATA'));
		return false;
	}

	for(var rowPos=1; rowPos<rowLength; rowPos++) {
		var row = csv[rowPos];
		var sRowPos = String(rowPos);

		// 列数チェック
		if(row.length != 5) {
			if(row.length > 5) {
//				stErr.append("<p>" + rowPos + "行目は" + row.length + "列になっています。</p>");
				stErr.append(MessageManager.getMessage('TOMS.MASTER.MAINTENANCE.ITEMS.LIST.LABEL.MESSAGE.ERROR.COLUMN1',sRowPos, String(row.length)));
			} else if(row.length < 5){
				stErr.append(MessageManager.getMessage('TOMS.MASTER.MAINTENANCE.ITEMS.LIST.LABEL.MESSAGE.ERROR.COLUMN2',sRowPos, String(row.length)));
			}
			ret = false;
			continue;
		}

		// 更新区分　0
		if(row[0] != "I" && row[0] != "U" && row[0] != "D" ) {
//			stErr.append("<p>" + rowPos + "行目 1列　登録区分にはIかUかDを設定して下さい。</p>");
			stErr.append(MessageManager.getMessage('TOMS.MASTER.MAINTENANCE.ITEMS.LIST.LABEL.MESSAGE.ERROR.UPDATEDIVISION', sRowPos)); //OK
			ret = false;
		}

		//CsvCheker
		var mgan8 = MessageManager.getMessage('TOMS.MASTER.MAINTENANCE.ITEMS.LIST.INPUT.MGAN8');
		var mgy57aspcd = MessageManager.getMessage('TOMS.MASTER.MAINTENANCE.ITEMS.LIST.INPUT.MGY57ASPCD');
		var mgrno = MessageManager.getMessage('TOMS.MASTER.MAINTENANCE.ITEMS.LIST.INPUT.MGRNO');
		var mgds01 = MessageManager.getMessage('TOMS.MASTER.MAINTENANCE.ITEMS.LIST.INPUT.MGDS01');
		
		// 取引先コード
		// 必須
		if(!CsvCheker.required(row[1], rowPos, 1, mgan8, stErr)) {
			ret = false;
		}
		// 文字数
		if(!CsvCheker.maxLength(row[1], 8, rowPos, 1, mgan8, stErr)) {
			ret = false;
		}
		// 数値
		if(!CsvCheker.isNum(row[1], rowPos, 1, mgan8, stErr)) {
			ret = false;
		}
		
		// 特記事項項目コード
		// 必須
		if(!CsvCheker.required(row[2], rowPos, 2, mgy57aspcd, stErr)) {
			ret = false;
		}
		// 文字数
		if(!CsvCheker.maxLength(row[2], 2, rowPos, 2, mgy57aspcd, stErr)) {
			ret = false;
		}
		
		// 特記事項メモ行No
		// 必須
		if(!CsvCheker.required(row[3], rowPos, 3, mgan8, stErr)) {
			ret = false;
		}
		// 文字数
		if(!CsvCheker.maxLength(row[3], 8, rowPos, 3, mgan8, stErr)) {
			ret = false;
		}
		// 数値
		if(!CsvCheker.isNum(row[3], rowPos, 3, mgan8, stErr)) {
			ret = false;
		}

		// 削除の場合 支払人No(keyのみ必要)
		if(row[0] == "D") {
			continue;
		}

		// 特記事項項目コード
		// 必須
		if(!CsvCheker.required(row[4], rowPos, 4, mgds01, stErr)) {
			ret = false;
		}
		// 文字数
		if(!CsvCheker.maxLength(row[4], 80, rowPos, 4, mgds01, stErr)) {
			ret = false;
		}
	}

	return ret;
}

/*
 * DBによるデータ有無チェック
 * @param csv　csv二次元配列
 * @param stErr エラーメッセージパラメータ.(OUT)
 */
function dbCheck(csv, stErr) {
	var rowLength = csv.length;
	var result;
	var ret = true;
	
	var mgan8 = MessageManager.getMessage('TOMS.MASTER.MAINTENANCE.ITEMS.LIST.INPUT.MGAN8');
	var mgy57aspcd = MessageManager.getMessage('TOMS.MASTER.MAINTENANCE.ITEMS.LIST.INPUT.MGY57ASPCD');
	var mgrno = MessageManager.getMessage('TOMS.MASTER.MAINTENANCE.ITEMS.LIST.INPUT.MGRNO');
	
	for(var rowPos=1; rowPos<rowLength; rowPos++) {
		var row = csv[rowPos];
		var ope = row[0];

		result = getItemByPk(row[1], row[2],row[3]);
		// 挿入の場合
		if(ope == "I") {			
			if(result.countRow > 0 ) {
//				stErr.append("<p>" + rowPos + "行目はデータが重複しています。 " + mgan8 + "=" + row[1] + ", " + mgy57aspcd + "=" + row[2] + ", " + mgrno + "=" + row[3] + "</p>");
				stErr.append(MessageManager.getMessage('TOMS.MASTER.MAINTENANCE.ITEMS.LIST.LABEL.MESSAGE.ERROR.DUPLICATE', String(rowPos),String(row[1]),String(row[2]),String(row[3])));
				ret = false;
			}
		// 更新、削除の場合
		} else {
			if(result.countRow < 1 ) {
//				stErr.append("<p>" + rowPos + "行目はデータが存在しません。 " + mgan8 + "=" + row[1] + ", " + mgy57aspcd + "=" + row[2] + ", " + mgrno + "=" + row[3] + "</p>");
				stErr.append(MessageManager.getMessage('TOMS.MASTER.MAINTENANCE.ITEMS.LIST.LABEL.MESSAGE.ERROR.DATANOTEXIST', String(rowPos),String(row[1]),String(row[2]),String(row[3])));
				ret = false;
			}
			if(result.countRow > 1 ) {
//				stErr.append("<p>" + rowPos + "行目はデータが１件以上存在しています。 " + mgan8 + "=" + row[1] + ", " + mgy57aspcd + "=" + row[2] + ", " + mgrno + "=" + row[3] + "</p>");
				stErr.append(MessageManager.getMessage('TOMS.MASTER.MAINTENANCE.ITEMS.LIST.LABEL.MESSAGE.ERROR.DATAEXIST', String(rowPos),String(row[1]),String(row[2]),String(row[3])));
				ret = false;
			}
		}
	}

	return ret;
}

/*
 * DB更新
 * @param csv csv二次元配列
 * @param stErr エラーメッセージパラメータ.(OUT)
 * @param updateCount (OUT)
 */
function dbUpdate(csv, stErr, counts) {
	var rowLength = csv.length;
	var ret = true;
	var newCount = 0;
	var updateCount = 0;
	var deleteCount = 0;
	
	Transaction.begin();
	for(var rowPos=1; rowPos<rowLength; rowPos++) {
		var row = csv[rowPos];
		var ope = row[0];
		var result;

		var entity = createEntity(row);
		var condition = "MGAN8 = ? " +
            		" AND MGY57ASPCD = ? " +
            		" AND MGRNO = ? ";
        var params = [
            		   DbParameter.number(entity['mgan8']),
            		   DbParameter.string(entity['mgy57aspcd']),
            		   DbParameter.number(entity['mgrno'])
                 ];
		if(ope == "I") {			//挿入
			result = TomsMaster.insertToF57A5070(entity);
			newCount++;
		} else if (ope =="U") {		//更新
			result = TomsMaster.updateToF57A5070(entity, condition, params);
			updateCount++;
		} else if  (ope =="D") {	//削除
//			result = TomsMaster.removeToF57A5070(condition, params);
			result = TomsMaster.removeFromF57A5070(condition, params);
			deleteCount++;
		}
		if(!result.error && result.countRow != 1) {
			Transaction.rollback();
//			stErr.append("<p>処理数が異常でした。(1件が正常):" + result.countRow);
//			stErr.append(" CSV行数:" + rowPos);
//			stErr.append("</p>");
			stErr.append(MessageManager.getMessage('TOMS.MASTER.MAINTENANCE.ITEMS.LIST.LABEL.MESSAGE.ERROR.ABNORMAL',String(rowPos)));
			return false;
		}
		if (result.error) {
			Transaction.rollback();
//			stErr.append("<p>データベースエラー \n");
//			stErr.append(" エラーコード:" + result.errorCode);
//			stErr.append(" エラーメッセージ:" + result.errorMessage);
//			stErr.append(" CSV行数:" + rowPos);
//			stErr.append("</p>");

			stErr.append(MessageManager.getMessage('TOMS.MASTER.MAINTENANCE.ITEMS.LIST.LABEL.MESSAGE.ERROR.DB'));
//			stErr.append(MessageManager.getMessage('TOMS.MASTER.MAINTENANCE.ITEMS.LIST.LABEL.MESSAGE.ERRORCODE.DB',String(result.errorCode)));
//			stErr.append(MessageManager.getMessage('TOMS.MASTER.MAINTENANCE.ITEMS.LIST.LABEL.MESSAGE.ERRORMSG.DB',String(result.errorMessage)));
			stErr.append(MessageManager.getMessage('TOMS.MASTER.MAINTENANCE.ITEMS.LIST.LABEL.MESSAGE.CSVLINE',String(rowPos)));
			return false;
		}
	}

	counts.newCount = newCount;
	counts.updateCount = updateCount;
	counts.deleteCount = deleteCount;

	Transaction.commit();
	return true;
}

/**
 * エラー処理
 * @param response　レスポンス
 * @param stErr エラーメッセージパラメータ.
 */
function doError(response, stErr){
//		stErr.insert(0,"<p>登録に失敗しました。</p>");
		stErr.insert(0, MessageManager.getMessage('TOMS.MASTER.MAINTENANCE.ITEMS.LIST.LABEL.MESSAGE.ERROR.ENTRY'));

		var st = stErr.toString();
		response.sendMessageBodyString(ImJson.toJSONString([{
	        "message":st,
	        "isError":"true"
		}]));
}

function getItemByPk(mgan8, mgy57aspcd, mgrno) {
    var result = TomsMaster.getItemByPk(mgan8, mgy57aspcd, mgrno);
	return result;
}

function createEntity(row) {
	var userContext = Contexts.getUserContext();
	var now = new Date();
	
    // 数字のデータ型
	var mgan8 = null;
	var mgrno = null;
	var mgupmj = cmnUtil.convertDateToJulia(now);
	var mgupmt = cmnUtil.getTime(now);

	// 文字列のデータ型
	var mgy57aspcd = null;
    var mgds01 = null;
    var mguser = userContext.userProfile.userCd;
    var mgpid = MessageManager.getMessage('TOMS.COMMON.CONSTANT.PROGRAM.ID');
    
    // 数字設定
    if (cmnUtil.getData(row[1], 1) != "")  {
    	mgan8 = cmnUtil.getData(row[1], 1);
    }
    if (cmnUtil.getData(row[3], 1) != "")  {
    	mgrno = cmnUtil.getData(row[3], 1);
    }

	if (cmnUtil.getData(row[2], 0) != "")  {
		mgy57aspcd = cmnUtil.getData(row[2], 0);
    }
	if (cmnUtil.getData(row[4], 0) != "")  {
		mgds01 = cmnUtil.getData(row[4], 0);
    }
    var entity = {
            		mgan8 : mgan8,
                    mgy57aspcd : mgy57aspcd,
                    mgrno : mgrno,
                    mgds01 : mgds01,
                    mguser : mguser,
                    mgpid : mgpid,
                    mgupmj : mgupmj,
                    mgupmt : mgupmt
            };
    return entity;
}
