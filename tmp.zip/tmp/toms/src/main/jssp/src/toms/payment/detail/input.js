/**
 * バインド変数.
 */
var $bind = {};


/**
 * 初期表示.
 * @param request リクエストパラメータ.
 */
function init(request) {
	
	load("toms/common/master");

	$bind.operation = request.operation;
	$bind.mapyrFrom = request.mapyrFrom;
	$bind.mapyrTo = request.mapyrTo;
	$bind.currencyList = getCurrencyList();
	$bind.meansOfPaymentList = getMeansOfPaymentList();
	$bind.title = MessageManager.getMessage('TOMS.MASTER.MAINTENANCE.PAYMENT.DETAIL.LABEL.UPDATE.TITLE');
	$bind.mapyr = request.mapyr;
	$bind.flag;
	$bind.errorMessage1 = MessageManager.getMessage('TOMS.PAYMENT.DETAIL.MESSAGE.UPDATE.MAY56CRPER2');
	$bind.errorMessage2 = MessageManager.getMessage('TOMS.PAYMENT.DETAIL.MESSAGE.UPDATE.MAY56CRPER1');
	if($bind.operation == "new" || $bind.operation == "new2") {
		//新規登録時
		var data = {
				mapyr : "",
				macrcd : MessageManager.getMessage('TOMS.COMMON.CONSTANT.CURRENCY.CODE.DEFAULT'),//初期値
				may56cathr : MessageManager.getMessage('TOMS.COMMON.CONSTANT.THRESHOLD.DEFAULT'),//初期値
				may56crper : "",
				may56carec : "",
				may56cryi1 : "",
				may56ctra1 : "",
				may56cryi2 : "",
				may56ctra2 : "",
				may56cerpe : "",
				may56ceare : "",
				may56cery1 : "",
				may56cetr1 : "",
				may56cery2 : "",
				may56cetr2 : "",
				// 支払条件
				maurrf : ""
		};
		$bind.payment = data;
		$bind.flag="0";
		$bind.title = MessageManager.getMessage('TOMS.MASTER.MAINTENANCE.PAYMENT.DETAIL.LABEL.ENTRY.TITLE');

	} else {
		// 更新時
		var result = TomsMaster.getPaymentPtn(request.mapyr);
		if (!result.error) {
			$bind.payment = result.data[0];
			$bind.payment.mapyr=convert($bind.payment.mapyr);

			$bind.payment.may56cathr=convert($bind.payment.may56cathr);
			$bind.payment.may56crper=convert($bind.payment.may56crper/1000);
			$bind.payment.may56carec=convert($bind.payment.may56carec);

			$bind.payment.may56cerpe=convert($bind.payment.may56cerpe/1000);
			$bind.payment.may56ceare=convert($bind.payment.may56ceare);

			// 支払条件
			$bind.payment.maurrf=convert($bind.payment.maurrf);
		}
		$bind.flag="1";
	}
	  // 登録、更新、削除ボタン押下時の確認ダイアログのメッセージを初期化.
  // JavaScriptで利用するためオブジェクトの内容をそのまま渡します.
  $bind.dialogMessages = ({
	entryTitle: 	MessageManager.getMessage('TOMS.MASTER.MAINTENANCE.PAYMENT.DETAIL.LABEL.ENTRY.MESSAGE.TITLE'),
    entryMessage: 	MessageManager.getMessage('TOMS.MASTER.MAINTENANCE.PAYMENT.DETAIL.LABEL.ENTRY.MESSAGE'),
	updateTitle: 	MessageManager.getMessage('TOMS.MASTER.MAINTENANCE.PAYMENT.DETAIL.LABEL.UPDATE.MESSAGE.TITLE'),
    updateMessage: 	MessageManager.getMessage('TOMS.MASTER.MAINTENANCE.PAYMENT.DETAIL.LABEL.UPDATE.MESSAGE'),
    deleteTitle: 	MessageManager.getMessage('TOMS.MASTER.MAINTENANCE.PAYMENT.DETAIL.LABEL.DELETE.MESSAGE.TITLE'),
    deleteMessage: 	MessageManager.getMessage('TOMS.MASTER.MAINTENANCE.PAYMENT.DETAIL.LABEL.DELETE.MESSAGE')
  }).toSource();
}

function convert(v) {
	if(isNull(v)) {
		return "";
	} else {
		return String(v);
	}
}

function getCurrencyList() {
	var result = TomsMaster.getCurrencyList();
	return result.data;
}

function getMeansOfPaymentList() {
	var result = TomsMaster.getMeansOfPaymentList();
	return result.data;
}