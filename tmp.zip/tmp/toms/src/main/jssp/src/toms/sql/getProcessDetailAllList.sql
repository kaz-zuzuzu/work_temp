	SELECT 
	 *
	FROM
	 (
	
		SELECT
	    TRIM(MNY57APMC) AS MNY57APMC
	  , TRIM(MNY57APMN1) AS MNY57APMN1
	  , MNY57ADO1
	  , TRIM(MNY57AJC1) AS MNY57AJC1
	  , TRIM(MNY57AGN1) AS MNY57AGN1
	  , TRIM(MNY57APMN2) AS MNY57APMN2
	  , MNY57ADO2
	  , TRIM(MNY57AJC2) AS MNY57AJC2
	  , TRIM(MNY57AGN2) AS MNY57AGN2
	  , TRIM(MNY57APMN3) AS MNY57APMN3
	  , MNY57ADO3
	  , TRIM(MNY57AJC3) AS MNY57AJC3
	  , TRIM(MNY57AGN3) AS MNY57AGN3
	  , TRIM(MNY57APMN4) AS MNY57APMN4
	  , MNY57ADO4
	  , TRIM(MNY57AJC4) AS MNY57AJC4
	  , TRIM(MNY57AGN4) AS MNY57AGN4
	  , TRIM(MNY57APMN5) AS MNY57APMN5
	  , MNY57ADO5
	  , TRIM(MNY57AJC5) AS MNY57AJC5
	  , TRIM(MNY57AGN5) AS MNY57AGN5
	  , MNY57AHFLG
	  , TO_CHAR(FC_JDI9902_TO_DATE(MNEFTJ), 'YYYY/MM/DD') AS MNEFTJ
	  , TO_CHAR(FC_JDI9902_TO_DATE(MNEXDJ), 'YYYY/MM/DD') AS MNEXDJ
	  , MNY57ADFLG
	  , MNURCD
	  , MNURDT
	  , MNURAT
	  , MNURAB
	  , MNURRF
	  , TRIM(MNUSER) AS MNUSER
	  , TRIM(MNPID) AS MNPID
	  , MNJOBN
	  , TO_CHAR(FC_JDI9902_TO_DATE(MNUPMJ), 'YYYY/MM/DD') AS MNUPMJ
	  , MNUPMT
	  , TRIM(MNY57APSH) AS MNY57APSH
	  , TRIM(MNY57APSW) AS MNY57APSW
	  , TRIM(MNY57APCSC) AS MNY57APCSC
	  , TRIM(MNY57ACSC) AS MNY57ACSC
	  , TRIM(MNY57AMTC) AS MNY57AMTC
	  , TRIM(MNY57APPC1) AS MNY57APPC1
	  , TRIM(MNY57APPC2) AS MNY57APPC2
	  , TRIM(MNY57APMT) AS MNY57APMT
	  , TRIM(MNY57APMDT) AS MNY57APMDT
	  , ROWNUM AS RN 
		FROM
	(
	SELECT
	  MNY57APMC
	  , MNY57APMN1
	  , MNY57ADO1
	  , MNY57AJC1
	  , MNY57AGN1
	  , MNY57APMN2
	  , MNY57ADO2
	  , MNY57AJC2
	  , MNY57AGN2
	  , MNY57APMN3
	  , MNY57ADO3
	  , MNY57AJC3
	  , MNY57AGN3
	  , MNY57APMN4
	  , MNY57ADO4
	  , MNY57AJC4
	  , MNY57AGN4
	  , MNY57APMN5
	  , MNY57ADO5
	  , MNY57AJC5
	  , MNY57AGN5
	  , MNY57AHFLG
	  , MNEFTJ
	  , MNEXDJ
	  , MNY57ADFLG
	  , MNURCD
	  , MNURDT
	  , MNURAT
	  , MNURAB
	  , MNURRF
	  , MNUSER
	  , MNPID
	  , MNJOBN
	  , MNUPMJ
	  , MNUPMT
	  , MNY57APSH
	  , MNY57APSW
	  , MNY57APCSC
	  , MNY57ACSC
	  , MNY57AMTC
	  , MNY57APPC1
	  , MNY57APPC2
	  , MNY57APMT
	  , MNY57APMDT 
	FROM
	  F57A5141 d
 INNER JOIN 
    (
    SELECT

    MMY57APMC,
    MMY57APCSC,
    MMY57ACSC,
    MMY57AMTC,
    MMY57APPC1,
    MMY57APPC2,
    MMY57APMT,
    MMY57APMDT

    FROM 
     F57A5140
/*IF mndl01 != null*/
    WHERE 
            TRIM(MMDL01) LIKE /*mndl01*/'%%'
/*END*/
    GROUP BY 
        MMY57APMC,
        MMY57APCSC,
        MMY57ACSC,
        MMY57AMTC,
        MMY57APPC1,
        MMY57APPC2,
        MMY57APMT,
        MMY57APMDT
    ) h
  ON d.MNY57APMC = h.MMY57APMC
 and d.MNY57APCSC = h.MMY57APCSC
 and d.MNY57ACSC = h.MMY57ACSC
 and d.MNY57AMTC = h.MMY57AMTC
 and d.MNY57APPC1 = h.MMY57APPC1
 and d.MNY57APPC2 = h.MMY57APPC2
 and d.MNY57APMT = h.MMY57APMT
 and d.MNY57APMDT = h.MMY57APMDT

 INNER JOIN 
    (
    SELECT
        MKY57APPC1,
        MKY57APPC2,
        MKY57APCSC,
        MKY57ACSC,
        MKY57AMTC
    FROM 
        F57A5120
        /*IF mny57appc1Name!=null || mny57appc2Name !=null*/
    WHERE 
        /*END*/
        /*IF mny57appc1Name!=null*/    
          TRIM(MKDL01) LIKE /*mny57appc1Name*/'%%'
        /*END*/
        /*IF mny57appc1Name !=null && mny57appc2Name!=null*/
          AND TRIM(MKDL02) LIKE /*mny57appc2Name*/'%%'
        /*END*/
        /*IF mny57appc1Name ==null && mny57appc2Name!=null*/
          TRIM(MKDL02) LIKE /*mny57appc2Name*/'%%'
        /*END*/
          
          GROUP BY 
         MKY57APPC1,
        MKY57APPC2,
        MKY57APCSC,
        MKY57ACSC,
        MKY57AMTC       
    ) bui
  ON d.MNY57AMTC = bui.MKY57AMTC
 and d.MNY57APCSC = bui.MKY57APCSC
 and d.MNY57ACSC = bui.MKY57ACSC
 and d.MNY57APPC1 = bui.MKY57APPC1
 and d.MNY57APPC2 = bui.MKY57APPC2

 INNER JOIN 
    (
    SELECT
        MLY57AMTC,
        MLY57APCSC,
        MLY57ACSC
    FROM 
        F57A5130
/*IF mny57amtcName!=null*/
        WHERE         
          TRIM(MLDL01) LIKE /*mny57amtcName*/'%%'
          /*END*/
    GROUP BY 
        MLY57AMTC,
        MLY57APCSC,
        MLY57ACSC
      ) sozai
  ON d.MNY57AMTC = sozai.MLY57AMTC
 and d.MNY57APCSC = sozai.MLY57APCSC
 and d.MNY57ACSC = sozai.MLY57ACSC
 
 INNER JOIN
     (
    SELECT 
        MJY57ACSC
      , MJY57APCSC
     FROM
        F57A5110 
     WHERE
        MJY57ACSC = MJY57APCSC
     /*IF mny57apcscName!= null*/
     AND TRIM(MJDL01) LIKE /*mny57apcscName*/'%%'
     /*END*/
     GROUP BY 
        MJY57ACSC
      , MJY57APCSC
    ) oya
    ON d.MNY57APCSC = oya.MJY57ACSC
    
 INNER JOIN
     (
    SELECT 
        MJY57ACSC
      , MJY57APCSC
     FROM
        F57A5110 
     WHERE 
        MJY57ACSC <> MJY57APCSC
     /*IF mny57acscName!= null*/
     AND TRIM(MJDL01) LIKE /*mny57acscName*/'%%'
     /*END*/
     GROUP BY 
        MJY57ACSC
      , MJY57APCSC
    ) ko
    ON d.MNY57ACSC = ko.MJY57ACSC
    and d.MNY57APCSC = ko.MJY57APCSC
    /*BEGIN*/
      WHERE
            /*IF mny57apmc !=null*/
                 TRIM(d.MNY57APMC) =/*mny57apmc*/''
            /*END*/
        /*IF mny57apmn1 !=null*/
          AND TRIM(d.MNY57APMN1) LIKE /*mny57apmn1*/'%%'
        /*END*/
        /*IF mny57ado1 !=null*/
          AND d.MNY57ADO1 = /*mny57ado1*/''
        /*END*/
        /*IF mny57ajc1 !=null*/
          AND TRIM(d.MNY57AJC1) = /*mny57ajc1*/''
        /*END*/
        /*IF mny57agn1 !=null*/
          AND TRIM(d.MNY57AGN1) LIKE /*mny57agn1*/''
        /*END*/
        /*IF mny57apmn2 !=null*/
          AND TRIM(d.MNY57APMN2) LIKE /*mny57apmn2*/'%%'
        /*END*/
        /*IF mny57ado2 !=null*/
          AND d.MNY57ADO2 = /*mny57ado2*/''
        /*END*/
        /*IF mny57ajc2 !=null*/
          AND TRIM(d.MNY57AJC2) = /*mny57ajc2*/''
        /*END*/
        /*IF mny57agn2 !=null*/
          AND TRIM(d.MNY57AGN2) LIKE /*mny57agn2*/'%%'
        /*END*/
        /*IF mny57apmn3 !=null*/
          AND TRIM(d.MNY57APMN3) LIKE /*mny57apmn3*/'%%'
        /*END*/
        /*IF mny57ado3 !=null*/
          AND d.MNY57ADO3 = /*mny57ado3*/''
        /*END*/
        /*IF mny57ajc3 !=null*/
          AND TRIM(d.MNY57AJC3) = /*mny57ajc3*/''
        /*END*/
        /*IF mny57agn3 !=null*/
          AND TRIM(d.MNY57AGN3) LIKE /*mny57agn3*/''
        /*END*/
            /*IF mneftj !=null*/
              AND d.MNEFTJ >= /*mneftj*/''
            /*END*/
            /*IF mneftj2 !=null*/
              AND d.MNEFTJ <= /*mneftj2*/''
            /*END*/
            /*IF mny57adflg !=null*/
              AND d.MNY57ADFLG = /*mny57adflg*/''
            /*END*/
            /*IF mny57apcsc !=null*/
              AND TRIM(d.MNY57APCSC) = /*mny57apcsc*/''
            /*END*/
            /*IF mny57acsc !=null*/
              AND TRIM(d.MNY57ACSC) = /*mny57acsc*/''
            /*END*/
            /*IF mny57amtc !=null*/
              AND TRIM(d.MNY57AMTC) = /*mny57amtc*/''
            /*END*/
            /*IF mny57appc1 !=null*/
              AND TRIM(d.MNY57APPC1) = /*mny57appc1*/''
            /*END*/
            /*IF mny57appc2 !=null*/
              AND TRIM(d.MNY57APPC2) = /*mny57appc2*/''
            /*END*/ 
            /*IF mny57apmt !=null*/
              AND TRIM(d.MNY57APMT) IN /*mny57apmt*/('1','2','3')
            /*END*/
            /*IF mny57apmdt !=null*/
              AND TRIM(d.MNY57APMDT) IN /*mny57apmdt*/('0','1')
            /*END*/
        /*END*/
		ORDER BY
			  MNY57APMC  
			  , MNY57AJC1 
			  , MNY57AJC2 
			  , MNY57AJC3 
			  , MNEFTJ DESC 
	) base 
	     /*IF end != null*/
	        WHERE ROWNUM <= /*end*/'30' 
	     /*END*/
	)
	/*IF start != null*/
	WHERE RN >= /*start*/'1' 
	/*END*/