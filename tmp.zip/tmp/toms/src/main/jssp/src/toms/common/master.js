

/**
* staticオブジェクトの作成 
 */ 
function TomsMaster(){}

/**
 * 上位組織検索処理の関数。
 * 
 */
TomsMaster.getSuperOrganizationList = function(){
	var database = new SharedDatabase("toms-web-dev");
	var result = database.executeByTemplate('resources/toms/common/search/organization/getTopOrganizations');
	return result;
}

/**
 * 組織検索処理の関数。
 * 
 */
TomsMaster.getOrganizationListByCode = function(superOrganizationCode){
	var database = new SharedDatabase("toms-web-dev");
	
	if (superOrganizationCode == " ") {	
		var result = database.executeByTemplate('resources/toms/common/search/organization/getAllOrganizations');
		return result;
	} else {
		var params =  {superOrganizationCodeParam : DbParameter.string(superOrganizationCode)}; 
		var result = database.executeByTemplate('resources/toms/common/search/organization/getOrganizations', params);
		return result;
	}
	
}

/**
 * 在庫場所検索処理の関数。
 * 
 */
TomsMaster.getAllStockPositionList = function(){
	var database = new SharedDatabase("toms-web-dev");
	var result = database.executeByTemplate('resources/toms/common/search/position/getAllStockPositions');
	return result;
}

/**
 * 在庫場所取得
 */
TomsMaster.getStockStorePositionList = function(stockPositionCode){
	var database = new SharedDatabase("toms-web-dev");
	if(stockPositionCode == "1000") {
		var params =  {stockPositionCode : DbParameter.string(stockPositionCode)}; 
		var result = database.executeByTemplate('resources/toms/common/search/position/getStockStorePositions_1000', params);
		return result;
	} else if(stockPositionCode == "2000") {
		var params =  {stockPositionCode : DbParameter.string(stockPositionCode)}; 
		var result = database.executeByTemplate('resources/toms/common/search/position/getStockStorePositions_2000', params);
		return result;
	} else if(stockPositionCode == "3000") {
    	var params =  {stockPositionCode : DbParameter.string(stockPositionCode)}; 
    	var result = database.executeByTemplate('resources/toms/common/search/position/getStockStorePositions_3000', params);
    	return result;
	}
}

/**
 * 在庫種別取得
 */
TomsMaster.getStockTypeList = function(key1, key2){
	var database = new TenantDatabase();
	var paramKey1 = null;
	var paramKey2 = null;
	if (key1 != null) {
		paramKey1 = DbParameter.string(key1);
	}
	if (key2 != null) {
		paramKey2 = DbParameter.string(key2);
	}
	var params =  {key1 : paramKey1, key2 : paramKey2}; 
	var result = database.executeByTemplate('resources/toms/common/search/position/getStockTypes', params);
	return result;
}

/**
 * 売掛金回収残高管理表情報を取得する処理。
 * 
 */
TomsMaster.getAccountData = function(organizationCode, paymentDayFrom, paymentDayTo){
	var database = new SharedDatabase("toms-web-dev");
	var paramOrganizationCode = null;
	var paramPaymentDayFrom = null;
	var paramPaymentDayTo = null;
	
	if (organizationCode != null) {
		var paramTempOrganizationCode = organizationCode.split(',');
		paramOrganizationCode = [paramTempOrganizationCode.length];
		for (var i = 0; i < paramTempOrganizationCode.length; i++) {
			paramOrganizationCode[i] = DbParameter.string(paramTempOrganizationCode[i]);
		}
	}
	if (paymentDayFrom != null) {
		paramPaymentDayFrom = DbParameter.string(paymentDayFrom);
	}
	if (paymentDayTo != null) {
		paramPaymentDayTo = DbParameter.string(paymentDayTo);
	}
	var params =  {
            		organizationCode : paramOrganizationCode,
                	paymentDayFrom : paramPaymentDayFrom,
                	paymentDayTo : paramPaymentDayTo
                  }
	var result = database.executeByTemplate('resources/toms/account/search/getAccountData', params);
	return result;
}


/**
 * 取引先情報を検索する処理。
 * 
 * @param exchangeTargetName 取引先の名称
 * @param exchangeTargetKana 取引先のカナ
 * @param chargePersonKana 担当者のカナ
 */
TomsMaster.searchExchangeTarget = function(exchangeTargetName, exchangeTargetKana, chargePersonKana, countFlag, start, end){
	var database = new SharedDatabase("toms-web-dev");
	var paramExchangeTargetName = null;
	var paramExchangeTargetKana = null;
	var paramChargePersonKana = null;
	var paramStart = null;
	var paramEnd = null;
	
	if (exchangeTargetName != null && exchangeTargetName != "") {
		paramExchangeTargetName = DbParameter.string("%" + exchangeTargetName + "%");
	}
	if (exchangeTargetKana != null && exchangeTargetKana != "") {
		paramExchangeTargetKana = DbParameter.string("%" + exchangeTargetKana + "%");
	}
	if (chargePersonKana != null && chargePersonKana != "") {
		paramChargePersonKana = DbParameter.string("%" + chargePersonKana + "%");
	}

	var result;
	if (countFlag) {
    	var params =  {
                		exchangeTargetName : paramExchangeTargetName,
                    	exchangeTargetKana : paramExchangeTargetKana,
                    	chargePersonKana : paramChargePersonKana
                      }
    	var result = database.executeByTemplate('resources/toms/common/search/exchangetarget/searchExchangeTargetCount', params);
	
	} else {
		if (start != null && start != "") {
			paramStart = DbParameter.number(start);
		}
		if (end != null && end != "") {
			paramEnd = DbParameter.number(end);
		}
		
		var params =  {
				exchangeTargetName : paramExchangeTargetName,
				exchangeTargetKana : paramExchangeTargetKana,
				chargePersonKana : paramChargePersonKana,
            	start : paramStart,
            	end : paramEnd
          }
		result = database.executeByTemplate('resources/toms/common/search/exchangetarget/searchExchangeTarget', params);
	}
	return result;
}

/**
 * 品目情報を検索する処理。
 * 
 * @param productCode 品目No
 * @param description1 記述１
 * @param description2 記述２
 * @param countFlag 件数取得フラグ
 */
TomsMaster.searchProduct = function(productCode, description1, description2, countFlag, start, end){
	var database = new SharedDatabase("toms-web-dev");
	var paramProductCode = null;
	var paramDescription1 = null;
	var paramDescription2 = null;
	var paramStart = null;
	var paramEnd = null;
	
	if (productCode != null && productCode != "") {
		paramProductCode = DbParameter.string(productCode);
	}
	if (description1 != null && description1 != "") {
		paramDescription1 = DbParameter.string("%" + description1 + "%");
	}
	if (description2 != null && description2 != "") {
		paramDescription2 = DbParameter.string("%" + description2 + "%");
	}

	var result;
	if (countFlag) {
    	var params =  {
                		productCode : paramProductCode,
                    	description1 : paramDescription1,
                    	description2 : paramDescription2
                      }
    	var result = database.executeByTemplate('toms/sql/searchProductCount', params);
	
	} else {
		if (start != null && start != "") {
			paramStart = DbParameter.number(start);
		}
		if (end != null && end != "") {
			paramEnd = DbParameter.number(end);
		}
		
		var params =  {
						productCode : paramProductCode,
						description1 : paramDescription1,
						description2 : paramDescription2,
						start : paramStart,
						end : paramEnd
          }
		result = database.executeByTemplate('toms/sql/searchProduct', params);
	}
	return result;
}

	
/**
 * ユーザ情報を検索する処理。
 * 
 * @param userCode ユーザコード
 * @param userName ユーザ名称
 * @param countFlag 件数取得フラグ
 */
TomsMaster.searchUser = function(userCode, userName, countFlag, start, end){
	var database = new SharedDatabase("toms-web-dev");
	var paramUserCode = null;
	var paramUserName = null;
	var paramStart = null;
	var paramEnd = null;
	
	if (userCode != null && userCode != "") {
		paramUserCode = DbParameter.string(userCode);
	}
	if (userName != null && userName != "") {
		paramUserName = DbParameter.string("%" + userName + "%");
	}


	var result;
	if (countFlag) {
    	var params =  {
    					userCode : paramUserCode,
    					userName : paramUserName
                      }
    	var result = database.executeByTemplate('toms/sql/searchUserCount', params);
	
	} else {
		if (start != null && start != "") {
			paramStart = DbParameter.number(start);
		}
		if (end != null && end != "") {
			paramEnd = DbParameter.number(end);
		}
		
		var params =  {
						userCode : paramUserCode,
						userName : paramUserName,
						start : paramStart,
						end : paramEnd
          }
		result = database.executeByTemplate('toms/sql/searchUser', params);
	}
	return result;
}

/**
 * 請求書一覧情報を検索する処理。
 * 
 * @param exchangeTargetCode 取引先コード
 * @param exchangeTargetKana 取引先カナ
 * @param paymentPersonCode 支払人コード
 * @param paymentPersonKana 支払人カナ
 */
TomsMaster.getRequestBillList = function(exchangeTargetCode, exchangeTargetKana, 
										paymentPersonCode, paymentPersonKana, countFlag,
										start, end) {
	var database = new SharedDatabase("toms-web-dev");
	var paramExchangeTargetCode = null;
	var paramExchangeTargetKana = null;
	var paramPaymentPersonCode = null;
	var paramPaymentPersonKana = null;
	var paramStart = null;
	var paramEnd = null;
	
	if (exchangeTargetCode != null && exchangeTargetCode != "") {
		paramExchangeTargetCode = DbParameter.string(exchangeTargetCode);
	}
	if (exchangeTargetKana != null && exchangeTargetKana != "") {
		paramExchangeTargetKana = DbParameter.string("%" + exchangeTargetKana + "%");
	}
	if (paymentPersonCode != null && paymentPersonCode != "") {
		paramPaymentPersonCode = DbParameter.string(paymentPersonCode);
	}
	if (paymentPersonKana != null && paymentPersonKana != "") {
		paramPaymentPersonKana = DbParameter.string("%" + paymentPersonKana + "%");
	}

	
	var result;
	if (countFlag) {
    	var params =  {
            	exchangeTargetCode : paramExchangeTargetCode,
            	exchangeTargetKana : paramExchangeTargetKana,
            	paymentPersonCode : paramPaymentPersonCode,
            	paymentPersonKana : paramPaymentPersonKana
        }
		result = database.executeByTemplate('resources/toms/bill/search/getRequestBillListCount', params);
	} else {
		if (start != null && start != "") {
			paramStart = DbParameter.number(start);
		}
		if (end != null && end != "") {
			paramEnd = DbParameter.number(end);
		}
		
		var params =  {
            	exchangeTargetCode : paramExchangeTargetCode,
            	exchangeTargetKana : paramExchangeTargetKana,
            	paymentPersonCode : paramPaymentPersonCode,
            	paymentPersonKana : paramPaymentPersonKana,
            	start : paramStart,
            	end : paramEnd
          }
		result = database.executeByTemplate('resources/toms/bill/search/getRequestBillList', params);
	}
	return result;
}

/**
 * 請求書明細情報件数取得処理
 * 
 * @param exchangeTargetCode 取引先コード
 * @param requestNo 請求書番号
 * @param searchCloseDate 締日
 * 
 */
 TomsMaster.getRequestBillDetailCount = function(exchangeTargetCode, requestNo, searchCloseDate) {
		var database = new SharedDatabase("toms-web-dev");
		var paramExchangeTargetCode = null;
		var paramRequestNo = null;
		var paramSearchCloseDate = null;
		
		if (exchangeTargetCode != null && exchangeTargetCode != "") {
			paramExchangeTargetCode = DbParameter.number(new Number(exchangeTargetCode));
		}
		if (requestNo != null && requestNo != "" && requestNo != 0) {
			paramRequestNo = DbParameter.number(new Number(requestNo));
		}
		if (searchCloseDate != null && searchCloseDate != "") {
			paramSearchCloseDate = DbParameter.number(new Number(searchCloseDate));
		}
		var params =  {
						exchangeTargetCode : paramExchangeTargetCode,
						requestNo : paramRequestNo,
						searchCloseDate : paramSearchCloseDate
	                  }
		var result = database.executeByTemplate('resources/toms/bill/search/getRequestBillDetailCount', params);
		return result;
	}
	
	

/**
 * 請求書明細情報を検索する処理。
 * 
 * @param exchangeTargetCode 取引先コード
 * @param requestNo 請求書番号
 * @param searchCloseDate 締日
 * @param start 
 * @param end
 * @param countFlag 詳細一覧情報取得　(true: 詳細一覧情報取得/false: CSVファイル出力情報取得)
 */
TomsMaster.getRequestBillDetail = function(exchangeTargetCode, requestNo, searchCloseDate, start, end, countFlag) {
	
	var database = new SharedDatabase("toms-web-dev");
	var paramExchangeTargetCode = null;
	var paramRequestNo = null;
	var paramSearchCloseDate = null;
	var paramStart = null;
	var paramEnd = null;
	

	if (exchangeTargetCode != null && exchangeTargetCode != "") {
		paramExchangeTargetCode = DbParameter.number(new Number(exchangeTargetCode));
	}
	if (requestNo != null && requestNo != "" && requestNo != 0) {
		paramRequestNo = DbParameter.number(new Number(requestNo));
	}
	if (searchCloseDate != null && searchCloseDate != "") {
		paramSearchCloseDate = DbParameter.number(new Number(searchCloseDate));
	}
	if(!isBlank(start)){
		paramStart = DbParameter.number(start);
	}
	if(!isBlank(end)){
		paramEnd = DbParameter.number(end);
	}
	var params =  {
					exchangeTargetCode : paramExchangeTargetCode,
					requestNo : paramRequestNo,
					searchCloseDate : paramSearchCloseDate,
					start : paramStart,
					end : paramEnd
                  }
	if (countFlag) {
		var result = database.executeByTemplate('resources/toms/bill/search/getRequestBillDetail', params);
	} else {
		var result = database.executeByTemplate('resources/toms/bill/search/getBillDetail', params);
	}
	return result;
}

/**
 * 商品在庫情報を検索する処理。
 * 
 * @param stockPositionCode 在庫場所
 * @param storePositionCode 保管場所
 * @param manufacturerCode メーカー
 */
TomsMaster.getProductList = function(stockPositionCode, storePositionCode, stockCategory, 
											manufacturerCode, productCode, addtionNo) {
	var database = new SharedDatabase("toms-web-dev");
	var paramStockPositionCode = null;
	var paramStorePositionCode = null;
	var paramStockCategory = null;
	var paramManufacturerCode = null;
	var paramProductCode = null;
	var paramAddtionNo = null;
	
	if (stockPositionCode != null && stockPositionCode != "") {
		paramStockPositionCode = DbParameter.string(stockPositionCode);
	}
	if (storePositionCode != null && storePositionCode != "") {
		if (stockCategory != null && stockCategory != "") {
			paramStorePositionCode = DbParameter.string(storePositionCode + stockCategory);
		} else {
			paramStorePositionCode = DbParameter.string(storePositionCode);
		}
	} else {
    	if (stockCategory != null && stockCategory != "") {
    		paramStockCategory = DbParameter.string(stockCategory);
    	}
	}
	if (manufacturerCode != null && manufacturerCode != "") {
		paramManufacturerCode = DbParameter.string(manufacturerCode);
	}
	if (productCode != null && productCode != "") {
		paramProductCode = DbParameter.string(productCode);
	}
	
	if (addtionNo == "1") {
		paramAddtionNo = DbParameter.string(addtionNo);
	}
	

	var params =  {
					stockPositionCode : paramStockPositionCode,
					storePositionCode : paramStorePositionCode,
					stockCategory : paramStockCategory,
					manufacturerCode : paramManufacturerCode,
					productCode : paramProductCode,
					addtionNo : paramAddtionNo,
					stockCode : stockPositionCode
                  }
	var result = database.executeByTemplate('resources/toms/stock/search/getProductList', params);
	return result;
}

/**
 * マスタから在庫のサイズ情報を検索する処理。
 * 
 * @param stockPositionCode 在庫場所
 * @param storePositionCode 保管場所
 * @param manufacturerCode メーカー
 * @param productCodes 商品コードリスト
 */
TomsMaster.getProductSizeList = function(stockPositionCode, storePositionCode, stockCategory,
											manufacturerCode, productCodes, addtionNo) {
	var database = new SharedDatabase("toms-web-dev");
	var paramStockPositionCode = null;
	var paramStorePositionCode = null;
	var paramStockCategory = null;
	var paramManufacturerCode = null;
	var paramProductCodes = null;
	var paramOrderBy = null;
	var paramAddtionNo = null;
	
	if (stockPositionCode != null && stockPositionCode != "") {
		paramStockPositionCode = DbParameter.string(stockPositionCode);
	}
	if (storePositionCode != null && storePositionCode != "") {
		if (stockCategory != null && stockCategory != "") {
			paramStorePositionCode = DbParameter.string(storePositionCode + stockCategory);
		} else {
			paramStorePositionCode = DbParameter.string(storePositionCode);
		}
	} else {
    	if (stockCategory != null && stockCategory != "") {
    		paramStockCategory = DbParameter.string(stockCategory);
    	}
	}
	if (manufacturerCode != null && manufacturerCode != "") {
		paramManufacturerCode = DbParameter.string(manufacturerCode);
		if (manufacturerCode == "01") {
			paramOrderBy = DbParameter.string("01");
		}
	}

	if (productCodes != null) {
		paramProductCodes = [];
		for (var i = 0; i < productCodes.length; i++) {
			paramProductCodes[i] = DbParameter.string(productCodes[i]);
		}
	}
	
	if (addtionNo == "1") {
		paramAddtionNo = DbParameter.string(addtionNo);
	}

	var params =  {
					stockPositionCode : paramStockPositionCode,
					storePositionCode : paramStorePositionCode,
					stockCategory : paramStockCategory,
					manufacturerCode : paramManufacturerCode,
					productCodes : paramProductCodes,
					orderBy : paramOrderBy,
					addtionNo : paramAddtionNo,
					stockCode : stockPositionCode
                  }
	var result = database.executeByTemplate('resources/toms/stock/search/getProductSizeList', params);
	return result;
}

/**
 * 在庫の情報一覧を検索する処理。
 * 
 * @param stockPositionCode 在庫場所
 * @param storePositionCode 保管場所
 * @param manufacturerCode メーカー
 * @param productCodes 商品コードリスト
 */
TomsMaster.getStockList = function(stockPositionCode, storePositionCode, stockCategory,
											manufacturerCode, productCodes, addtionNo) {
	var database = new SharedDatabase("toms-web-dev");
	var paramStockPositionCode = null;
	var paramStorePositionCode = null;
	var paramStockCategory = null;
	var paramManufacturerCode = null;
	var paramProductCodes = null;
	var paramAddtionNo = null;
	
	if (stockPositionCode != null && stockPositionCode != "") {
		paramStockPositionCode = DbParameter.string(stockPositionCode);
	}
	if (storePositionCode != null && storePositionCode != "") {
		if (stockCategory != null && stockCategory != "") {
			paramStorePositionCode = DbParameter.string(storePositionCode + stockCategory);
		} else {
			paramStorePositionCode = DbParameter.string(storePositionCode);
		}
	} else {
    	if (stockCategory != null && stockCategory != "") {
    		paramStockCategory = DbParameter.string(stockCategory);
    	}
	}
	if (manufacturerCode != null && manufacturerCode != "") {
		paramManufacturerCode = DbParameter.string(manufacturerCode);

	}
	if (productCodes != null) {
		paramProductCodes = [];
		for (var i = 0; i < productCodes.length; i++) {
			paramProductCodes[i] = DbParameter.string(productCodes[i]);
		}
	}
	
	if (addtionNo == "1") {
		paramAddtionNo = DbParameter.string(addtionNo);
	}


	var params =  {
					stockPositionCode : paramStockPositionCode,
					storePositionCode : paramStorePositionCode,
					stockCategory : paramStockCategory,
					manufacturerCode : paramManufacturerCode,
					productCodes : paramProductCodes,
					addtionNo : paramAddtionNo,
					stockCode : stockPositionCode
                  }
	
	var result = null;
	if (stockPositionCode == "1000" && (stockCategory == null || stockCategory == "")) {
		result = database.executeByTemplate('toms/sql/getStockListForThousand', params);
	} else {
		result = database.executeByTemplate('resources/toms/stock/search/getStockList', params);
	}
	return result;
}

/**
 * 在庫詳細の情報一覧を検索する処理。
 * 
 * @param stockPositionCode 在庫場所
 * @param storePositionCode 保管場所
 * @param manufacturerCode メーカー
 * @param productCodes 商品コードリスト
 */
TomsMaster.getDetailStockList = function(stockPositionCode, storePositionCode, stockCategory,
											manufacturerCode, productCodes, addtionNo, start, end) {
	var database = new SharedDatabase("toms-web-dev");
	var paramStockPositionCode = null;
	var paramStorePositionCode = null;
	var paramStockCategory = null;
	var paramManufacturerCode = null;
	var paramProductCodes = null;
	var paramAddtionNo = null;
	var paramStart = null;
	var paramEnd = null;
	
	if (stockPositionCode != null && stockPositionCode != "") {
		paramStockPositionCode = DbParameter.string(stockPositionCode);
	}
	if (storePositionCode != null && storePositionCode != "") {
		if (stockCategory != null && stockCategory != "") {
			paramStorePositionCode = DbParameter.string(storePositionCode + stockCategory);
		} else {
			paramStorePositionCode = DbParameter.string(storePositionCode);
		}
	} else {
    	if (stockCategory != null && stockCategory != "") {
    		paramStockCategory = DbParameter.string(stockCategory);
    	}
	}
	if (manufacturerCode != null && manufacturerCode != "") {
		paramManufacturerCode = DbParameter.string(manufacturerCode);

	}
	if (productCodes != null) {
		paramProductCodes = [];
		for (var i = 0; i < productCodes.length; i++) {
			paramProductCodes[i] = DbParameter.string(productCodes[i]);
		}
	}
	
	if (addtionNo == "1") {
		paramAddtionNo = DbParameter.string(addtionNo);
	}

	if (start != null && start != "") {
		paramStart = DbParameter.number(start);
	}
	if (end != null && end != "") {
		paramEnd = DbParameter.number(end);
	}

	var params =  {
					stockPositionCode : paramStockPositionCode,
					storePositionCode : paramStorePositionCode,
					stockCategory : paramStockCategory,
					manufacturerCode : paramManufacturerCode,
					productCodes : paramProductCodes,
					addtionNo : paramAddtionNo,
					stockCode : stockPositionCode,
                	start : paramStart,
                	end : paramEnd
                  }
	var result = null;
	if (stockPositionCode == "1000" && (stockCategory == null || stockCategory == "")) {
		result = database.executeByTemplate('toms/sql/getDetailStockListForThousand', params);
	} else {
		result = database.executeByTemplate('resources/toms/stock/search/getDetailStockList', params);
	}
	return result;
}

	
/**
 * 在庫詳細の情報一覧を検索する処理。
 * 
 * @param stockPositionCode 在庫場所
 * @param storePositionCode 保管場所
 * @param manufacturerCode メーカー
 * @param productCodes 商品コードリスト
 */
TomsMaster.getDetailStockListCount = function(stockPositionCode, storePositionCode, stockCategory,
											manufacturerCode, productCodes, addtionNo) {
	var database = new SharedDatabase("toms-web-dev");
	var paramStockPositionCode = null;
	var paramStorePositionCode = null;
	var paramStockCategory = null;
	var paramManufacturerCode = null;
	var paramProductCodes = null;
	var paramAddtionNo = null;
	
	if (stockPositionCode != null && stockPositionCode != "") {
		paramStockPositionCode = DbParameter.string(stockPositionCode);
	}
	if (storePositionCode != null && storePositionCode != "") {
		if (stockCategory != null && stockCategory != "") {
			paramStorePositionCode = DbParameter.string(storePositionCode + stockCategory);
		} else {
			paramStorePositionCode = DbParameter.string(storePositionCode);
		}
	} else {
    	if (stockCategory != null && stockCategory != "") {
    		paramStockCategory = DbParameter.string(stockCategory);
    	}
	}
	if (manufacturerCode != null && manufacturerCode != "") {
		paramManufacturerCode = DbParameter.string(manufacturerCode);

	}
	if (productCodes != null) {
		paramProductCodes = [];
		for (var i = 0; i < productCodes.length; i++) {
			paramProductCodes[i] = DbParameter.string(productCodes[i]);
		}
	}
	
	if (addtionNo == "1") {
		paramAddtionNo = DbParameter.string(addtionNo);
	}

	var params =  {
					stockPositionCode : paramStockPositionCode,
					storePositionCode : paramStorePositionCode,
					stockCategory : paramStockCategory,
					manufacturerCode : paramManufacturerCode,
					productCodes : paramProductCodes,
					addtionNo : paramAddtionNo,
					stockCode : stockPositionCode
                  }

	var result = null;
	if (stockPositionCode == "1000" && (stockCategory == null || stockCategory == "")) {
		result = database.executeByTemplate('toms/sql/getDetailStockListCountForThousand', params);
	} else {
		result = database.executeByTemplate('resources/toms/stock/search/getDetailStockListCount', params);
	}	
	return result;
}
/**
 * キープ情報一覧を検索する処理。
 * 
 * @param stockPositionCode 在庫場所
 * @param storePositionCode 保管場所
 * @param stockCategory 在庫種別
 * @param skuCode 品番
 */
TomsMaster.getKeepList = function(stockPositionCode, storePositionCode, stockCategory, skuCode) {
	var database = new SharedDatabase("toms-web-dev");
	var paramStockPositionCode = null;
	var paramStorePositionCode = null;
	var paramStockCategory = null;
	var paramSkuCode = null;
	
	if (stockPositionCode != null && stockPositionCode != "") {
		paramStockPositionCode = DbParameter.string(stockPositionCode);
	}
	if (storePositionCode != null && storePositionCode != "") {
		if (stockCategory != null && stockCategory != "") {
			paramStorePositionCode = DbParameter.string(storePositionCode + stockCategory);
		} else {
			paramStorePositionCode = DbParameter.string(storePositionCode);
		}
	} else {
    	if (stockCategory != null && stockCategory != "") {
    		paramStockCategory = DbParameter.string(stockCategory);
    	}
	}
	if (skuCode != null && skuCode != "") {
		paramSkuCode = DbParameter.string(skuCode);
	}
	

	var params =  {
					stockPositionCode : paramStockPositionCode,
					storePositionCode : paramStorePositionCode,
					stockCategory : paramStockCategory,
					skuCode : paramSkuCode,
					stockCode : stockPositionCode
                  }
	var result = database.executeByTemplate('resources/toms/stock/search/getKeepList', params);
	return result;
}

/**
 * キープ情報一覧を検索する処理。
 * 
 * @param skuCode 品番
 */
TomsMaster.getKeepListBySku = function(skuCode) {
    var database = new SharedDatabase("toms-web-dev");
    var paramSkuCode = null;

    if (skuCode != null && skuCode != "") {
        paramSkuCode = DbParameter.string(skuCode);
    }

    var params =  {
            skuCode : paramSkuCode
                  }
    var result = database.executeByTemplate('resources/toms/stock/search/getKeepListBySku', params);
    return result;
}

/**
 * 取引先一覧情報を検索する処理。
 * 
 * @param telNo 電話番号
 * @param bunruicd1
 */
TomsMaster.getTorihikisakiList = function(telNo, bunruicd1) {
	var database = new SharedDatabase("toms-web-dev");
    
	var paramTelNo = null;
	
	if (telNo != null && telNo != "") {
		paramTelNo = DbParameter.string(telNo);
	}
	
    var params =  {
    	            telNo : paramTelNo,
    	            bunruicd1 : DbParameter.string(bunruicd1)
                  }	

    var result = database.executeByTemplate('resources/toms/exchange/search/getTorihikisakiList', params);
		
	return result;
}

/**
 * 分類１リストを検索する処理。
 * 
 */
TomsMaster.getBunrui1List = function() {
	var database = new SharedDatabase("toms-web-dev");
    
    var result = database.executeByTemplate('resources/toms/exchange/search/getBunrui1List');
		
	return result;
}

/**
 * 出庫ダミーデータ取得
 */
TomsMaster.getDummyList = function(){
	var database = new SharedDatabase("toms-web-dev");
	var result = database.executeByTemplate('resources/toms/common/search/dummy/getDummyData');
	return result;
}

TomsMaster.getDummyList2 = function(destination){
	var database = new SharedDatabase("toms-web-dev");
    var paramdestination = null;
    
    if (destination != null){
    	paramdestination = DbParameter.string(destination);
    }
    var params = {destination : paramdestination}
    var result = database.executeByTemplate('resources/toms/common/search/dummy/getDummyData', params);
    return result;
}
TomsMaster.getDummyList3 = function(stockPositionList, destination){
	var database = new SharedDatabase("toms-web-dev");
    var paramdestination = null;
    var paramstockPositionList = null;
    
    if (destination != null){
    	paramdestination = DbParameter.string(destination);
    }
    if (stockPositionList != null){
    	paramstockPositionList = DbParameter.string(stockPositionList);
    }
    var params = {destination : paramdestination, stockPositionList : paramstockPositionList}
    var result = database.executeByTemplate('resources/toms/common/search/dummy/getDummyData2', params);
    return result;
}

/* 追加
 * 出庫リスト
 */
TomsMaster.getDeliveryItemList = function(stockPositionList, superOrganization, organization, receiveOrderNo,
	                                      instructNo, destination, exchangeTargetKana, deliveryDateFrom, deliveryDateTo){
	var database = new SharedDatabase("toms-web-dev");
	var paramstockPositionList = null;
	var paramsuperOrganization = null;
	var paramorganization = null;
	var paramreceiveOrderNo = null;
	var paraminstructNo = null;
	var paramdestination = null;
	var paramexchangeTargetKana = null;
	var paramdeliveryDateFrom = null;
	var paramdeliveryDateTo = null;
	
	if (paramstockPositionList != null && paramstockPositionList != ""){
		paramstockPositionList = DbParameter.string(stockPositionList);
	}
	if (paramsuperOrganization != null && paramsuperOrganization != ""){
		paramsuperOrganization = DbParameter.string(superOrganization);
	}
	if (paramorganization != null && paramorganization != ""){
		paramorganization = DbParameter.string(organization);
	}
	if (paramreceiveOrderNo != null && paramreceiveOrderNo != ""){
		paramreceiveOrderNo = DbParameter.string(receiveOrderNo);
	}
	if (paraminstructNo != null && paraminstructNo != ""){
		paraminstructNo = DbParameter.string(instructNo);
	}
	if (paramdestination != null && paramdestination != ""){
		paramdestination = DbParameter.string(destination);
	}
	if (paramexchangeTargetKana != null && paramexchangeTargetKana != ""){
		paramexchangeTargetKana = DbParameter.string(exchangeTargetKana);
	}

	if (paramdeliveryDateFrom != null && paramdeliveryDateFrom != ""){
		paramdeliveryDateFrom = DbParameter.string(deliveryDateFrom);
	}
	if (paramdeliveryDateTo != null && paramdeliveryDateTo != ""){
		paramdeliveryDateTo = DbParameter.string(deliveryDateTo);
	}

	var params = { stockPositionList : paramstockPositionList, 
	               superOrganization : paramsuperOrganization,
	               organization : paramorganization,
	               receiveOrderNo : paramreceiveOrderNo,
	               instructNo : paraminstructNo,
	               destination : paramdestination,
	               exchangeTargetKana : paramexchangeTargetKana,
	               deliveryDateFrom : paramdeliveryDateFrom,
	               deliveryDateTo : paramdeliveryDateTo
	              }
	
	var result = database.executeByTemplate('resources/toms/common/search/dummy/getDummyData', params);
	return result;
	
}

/**
 * 取引先一覧情報を検索する処理。
 * 
 * @param exchangeTargetId     取引先コード
 * @param exchangeCategoryCd   取引種別
 * @param organizationCd　　　　　　組織
 * @param bunrui1Cd　　　　　　　　　　分類１
 * @param notinBunrui1Cd      　　　除外の分類１
 * @param bunrui2Cd　　　　　　　　　　分類２
 * @param chargePersonCd      担当者コード
 * @param chargePersonNm      担当者名
 * @param todoufukenCd        都道府県
 * @param exchangeTargetKn    取引先カナ
 * @param telNo               電話番号
 * @param faxNo               FAX番号
 * @param countFlag           件数取得　(true: 件数取得/false: リスト情報取得)
 */
TomsMaster.getExchangeTargetList = function(exchangeTargetId, exchangeCategoryCd, organizationCd,
	                                            bunrui1Cd, notinBunrui1Cd, bunrui2Cd, chargePersonCd, chargePersonNm, 
	                                            todoufukenCd, exchangeTargetKn, telNo, faxNo, countFlag) {	
	var database = new SharedDatabase("toms-web-dev");
    
	var MAX_COUNT = 1500;    // 取得最大件数
	var paramExchangeTargetId = null;
	var paramExchangeCategoryCd = null;
	var paramOrganizationCd = null;
	var paramBunrui1Cd = null;
	var paramNotinBunrui1Cd = null;
	var paramBunrui2Cd = null;
	var paramChargePersonCd = null;
	var paramChargePersonNm = null;
	var paramTodoufukenCd = null;
	var paramExchangeTargetKn = null;
	var paramTelNo = null;
	var paramFaxNo = null;
	
	if (exchangeTargetId != null && exchangeTargetId != "") {
		paramExchangeTargetId = DbParameter.string(exchangeTargetId);
	}
	
    var paramTempExchangeCategoryCd = exchangeCategoryCd.split(',');
    paramExchangeCategoryCd = [paramTempExchangeCategoryCd.length];
	for (var i = 0; i < paramTempExchangeCategoryCd.length; i++) {
		paramExchangeCategoryCd[i] = DbParameter.string(paramTempExchangeCategoryCd[i]);
	}		
	
	if (organizationCd != null && organizationCd != ""  && organizationCd != " ") {
		var paramTemporganizationCd = organizationCd.split(',');
		paramOrganizationCd = [paramTemporganizationCd.length];
		for (var i = 0; i < paramTemporganizationCd.length; i++) {
			paramOrganizationCd[i] = DbParameter.string(paramTemporganizationCd[i]);
		}
	}
	
	if (bunrui1Cd != null && bunrui1Cd != ""  && bunrui1Cd != " ") {
		paramBunrui1Cd = DbParameter.string(bunrui1Cd);
	}
	
	if (notinBunrui1Cd != null) {
		var paramTempNotinBunrui1Cd = notinBunrui1Cd.split(',');
		paramNotinBunrui1Cd = [paramTempNotinBunrui1Cd.length];
		for (var i = 0; i < paramTempNotinBunrui1Cd.length; i++) {
			paramNotinBunrui1Cd[i] = DbParameter.string(paramTempNotinBunrui1Cd[i]);
		}
	}

	if (bunrui2Cd != null && bunrui2Cd != ""  && bunrui2Cd != " ") {
		var paramTempBunrui2Cd = bunrui2Cd.split(',');
		paramBunrui2Cd = [paramTempBunrui2Cd.length];
		for (var i = 0; i < paramTempBunrui2Cd.length; i++) {
			paramBunrui2Cd[i] = DbParameter.string(paramTempBunrui2Cd[i]);
		}
	}

	if (chargePersonCd != null && chargePersonCd != ""  && chargePersonCd != " ") {
		paramChargePersonCd = DbParameter.string(chargePersonCd);
	}
	
	if (chargePersonNm != null && chargePersonNm != ""  ) {
		paramChargePersonNm = DbParameter.string("%" + chargePersonNm + "%");
	}

	if (todoufukenCd != null && todoufukenCd != ""  && todoufukenCd != " ") {
		paramTodoufukenCd = DbParameter.string(todoufukenCd);
	}

	if (exchangeTargetKn != null && exchangeTargetKn != "") {
		paramExchangeTargetKn = DbParameter.string("%" + exchangeTargetKn + "%");
	}

	if (telNo != null && telNo != "") {
		paramTelNo = DbParameter.string(telNo);
	}
	
	if (faxNo != null && faxNo != "") {
		paramFaxNo = DbParameter.string(faxNo);
	}

    var params =  {
    	exchangeTargetId     : paramExchangeTargetId   ,
        exchangeCategoryCd   : paramExchangeCategoryCd ,
        organizationCd       : paramOrganizationCd     ,
        bunrui1Cd            : paramBunrui1Cd          ,
        notinBunrui1Cd       : paramNotinBunrui1Cd     ,
        bunrui2Cd            : paramBunrui2Cd          ,
        chargePersonCd       : paramChargePersonCd     ,
        chargePersonNm       : paramChargePersonNm     ,
        todoufukenCd         : paramTodoufukenCd       ,
        exchangeTargetKn     : paramExchangeTargetKn   ,
        telNo                : paramTelNo              ,
        faxNo                : paramFaxNo
                  }
    var result;
	if (countFlag) {
		result = database.executeByTemplate('resources/toms/exchange/list/getExchangeTargetListCount', params);
	} else {
		result = database.fetchByTemplate('resources/toms/exchange/list/getExchangeTargetList', 1, MAX_COUNT, params);
	}
	
	return result;
}

/**
 * 取引種別リストを検索する処理。
 * 
 */
TomsMaster.getSearchTypeList = function() {
	var database = new TenantDatabase("tenant1-dev");
    
    var result = database.executeByTemplate('resources/toms/exchange/search/getSearchTypeList');

	return result;
}

/**
 * 担当者リストを検索する処理。
 * 
 * @param exchangeCategoryCd   取引種別
 * @param organizationCd　　　　　　組織
 */
TomsMaster.getChargePersonList = function(exchangeCategoryCd, organizationCd) {
	var database = new SharedDatabase("toms-web-dev");
	
	var paramExchangeCategoryCd = null;
	var paramOrganizationCd = null;	
	
    var paramTempExchangeCategoryCd = exchangeCategoryCd.split(',');
    paramExchangeCategoryCd = [paramTempExchangeCategoryCd.length];
	for (var i = 0; i < paramTempExchangeCategoryCd.length; i++) {
		paramExchangeCategoryCd[i] = DbParameter.string(paramTempExchangeCategoryCd[i]);
	}
	
	if (organizationCd != null && organizationCd != ""  && organizationCd != " ") {
		var paramTemporganizationCd = organizationCd.split(',');
		paramOrganizationCd = [paramTemporganizationCd.length];
		for (var i = 0; i < paramTemporganizationCd.length; i++) {
			paramOrganizationCd[i] = DbParameter.string(paramTemporganizationCd[i]);
		}
	}

	var params =  {
		              exchangeCategoryCd : paramExchangeCategoryCd,
	                  organizationCd     : paramOrganizationCd
                  }
    
    var result = database.executeByTemplate('resources/toms/exchange/search/getChargePersonList', params);
		
	return result;
}

	
/**
 * 営業担当者リストを検索する処理。
 * 
 * @param organizationCd　　　　　　組織
 */
TomsMaster.getSalesChargePersonList = function(organizationCd) {
	var database = new SharedDatabase("toms-web-dev");
	
	var paramOrganizationCd = null;
	
	if (organizationCd != null && organizationCd != ""  && organizationCd != " ") {
		var paramTemporganizationCd = organizationCd.split(',');
		paramOrganizationCd = [paramTemporganizationCd.length];
		for (var i = 0; i < paramTemporganizationCd.length; i++) {
			paramOrganizationCd[i] = DbParameter.string(paramTemporganizationCd[i]);
		}
	}

	var params =  {
                     organizationCd : paramOrganizationCd
                  }
    
    var result = database.executeByTemplate('resources/toms/credit/search/getSalesChargePersonLis', params);
		
	return result;
}
	
/**
 * 分類１リストを検索する処理。
 * 
 */
TomsMaster.getBunrui1List = function() {
	var database = new SharedDatabase("toms-web-dev");
    
    var result = database.executeByTemplate('resources/toms/exchange/search/getBunrui1List');
		
	return result;
}

/**
 * 分類２リストを検索する処理。
 * 
 */
TomsMaster.getBunrui2List = function() {
	var database = new SharedDatabase("toms-web-dev");
    
    var result = database.executeByTemplate('resources/toms/exchange/search/getBunrui2List');
		
	return result;
}

/**
 * 都道府県リストを検索する処理。
 * 
 */
TomsMaster.getTodoufukenList = function() {
	var database = new SharedDatabase("toms-web-dev");
    
    var result = database.executeByTemplate('resources/toms/exchange/search/getTodoufukenList');
		
	return result;
}

/**
 * 取引先明細を検索する処理。
 * 
 * @param exchangeTargetId 取引先コード
 */
TomsMaster.getExchangeTargetDetail = function(exchangeTargetId) {
	var database = new SharedDatabase("toms-web-dev");
	
	var paramExchangeTargetId= DbParameter.string(exchangeTargetId);
	
	var params =  {
	               exchangeTargetId   : paramExchangeTargetId
                  }

    var result = database.executeByTemplate('resources/toms/exchange/detail/getExchangeTargetDetail', params);
	
	return result;
}

/**
 * 特価一覧を検索する処理。
 * 
 * @param exchangeTargetId 取引先コード
 */
TomsMaster.getSalePriceList = function(exchangeTargetId) {
	var database = new SharedDatabase("toms-web-dev");
	
	var paramExchangeTargetId = DbParameter.string(exchangeTargetId);
	
	var params =  {
	               exchangeTargetId   : paramExchangeTargetId
                  }

    var result = database.executeByTemplate('resources/toms/exchange/price/getSalePriceList', params);
		
	return result;
	
}

/**
 * 特記事項一覧を検索する処理。
 * 
 * @param exchangeTargetId 取引先コード
 */
TomsMaster.getNoticeList = function(exchangeTargetId) {
	var database = new SharedDatabase("toms-web-dev");
	
	var paramExchangeTargetId = DbParameter.string(exchangeTargetId);
	
	var params =  {
	               exchangeTargetId   : paramExchangeTargetId
                  }

    var result = database.executeByTemplate('resources/toms/exchange/notice/getNoticeList', params);
		
	return result;
	
}

/**
 * 送付先一覧を検索する処理。
 * 
 * @param exchangeTargetId 取引先コード
 */
TomsMaster.getSendList = function(exchangeTargetId) {
	var database = new SharedDatabase("toms-web-dev");
	
	var paramExchangeTargetId = DbParameter.string(exchangeTargetId);
	
	var params =  {
	               exchangeTargetId   : paramExchangeTargetId
                  }

    var result = database.executeByTemplate('resources/toms/exchange/send/getSendList', params);
		
	return result;
	
}

/**
 * 与信残高一覧を検索する処理。
 *
 * @param organization            組織
 * @param searchExchangeTargetType  取引先種別
 * @param searchExchangeTargetId  取引先コード
 * @param exchangeTargetKn        取引先カナ
 * @param chargePerson            担当者コード
 * @param chargePersonText        担当者カナ
 * @param creditAmountOver        与信超過
 */
TomsMaster.geCreditList = function(
							organization,
							searchExchangeTargetType,
							searchExchangeTargetId,
							exchangeTargetKn,
							chargePerson,
							chargePersonText,
							creditAmountOver) {
	
	var database = new SharedDatabase("toms-web-dev")

	var paraOrganization = null;
	var paraSearchExchangeTargetType = null;
	var paraSearchExchangeTargetId = null;
	var paraExchangeTargetKn = null;
	var paraChargePerson = null;
	var paraChargePersonText = null;
	
	if (organization != null && organization != ""  && organization != " ") {
		var paramTemporganization = organization.split(',');
		paraOrganization = [paramTemporganization.length];
		for (var i = 0; i < paramTemporganization.length; i++) {
			paraOrganization[i] = DbParameter.string(paramTemporganization[i]);
		}
	}
	if (searchExchangeTargetType != null && searchExchangeTargetType != "" && searchExchangeTargetType != " ") {
		paraSearchExchangeTargetType = DbParameter.string(searchExchangeTargetType);
	}
	if (searchExchangeTargetId != null && searchExchangeTargetId != "") {
		paraSearchExchangeTargetId = DbParameter.string(searchExchangeTargetId);
	}
	if (exchangeTargetKn != null && exchangeTargetKn != "") {
		paraExchangeTargetKn = DbParameter.string("%" + exchangeTargetKn + "%");
	}
	if (chargePerson != null && chargePerson != "") {
		paraChargePerson = DbParameter.string(chargePerson);
	}
	if (chargePersonText != null && chargePersonText != "") {
		paraChargePersonText = DbParameter.string("%" + chargePersonText + "%");
	}
	
	// 与信超過 
	var creditAmountOver_0001_flag = false; // '0001'  100万未満
	var creditAmountOver_0002_flag = false; // '0002'  100万～1000万未満
	var creditAmountOver_0003_flag = false; // '0003'  1000万以上
	if (creditAmountOver != null && creditAmountOver != "") {
		if(creditAmountOver == "0001") {
			creditAmountOver_0001_flag = true;
		}
	}
	
	var params =  {
					organization : paraOrganization,
					searchExchangeTargetType : paraSearchExchangeTargetType,
					searchExchangeTargetId : paraSearchExchangeTargetId,
					exchangeTargetKn : paraExchangeTargetKn,
					chargePerson : paraChargePerson,
					chargePersonText : paraChargePersonText,
					creditAmountOver_0001_flag : creditAmountOver_0001_flag
                  }

    var result = database.executeByTemplate('resources/toms/credit/search/geCreditList', params);
	return result;
}

/**
 * 入金一覧一覧を検索する処理。
 * 
 * @param customerCode	顧客コード
 */
TomsMaster.getPaymentList = function(customerCode) {
	
	var database = new SharedDatabase("toms-web-dev");
	
	var paraCustomerCode = DbParameter.string(customerCode);
	
	var params =  {
					customerCode : paraCustomerCode
                  }

    var result = database.executeByTemplate('resources/toms/credit/search/getPaymentList', params);
	return result;
}

/**
 * 受取手形未決済一覧を検索する処理。
 * 
 * @param customerCode	顧客コード
 */
TomsMaster.getBillList = function(customerCode) {
	
	var database = new SharedDatabase("toms-web-dev");
	
	var paraCustomerCode = DbParameter.string(customerCode);
	
	var params =  {
					customerCode : paraCustomerCode
                  }

    var result = database.executeByTemplate('resources/toms/credit/search/getBillList', params);
	return result;
}


/**
 * 在庫場所取得
 */
TomsMaster.getStockPositionList = function(){
	var database = new SharedDatabase("toms-web-dev");
	var result = database.executeByTemplate('resources/toms/common/search/delivery/getStockPosition');
	return result;
}

/**
 * 入金パターン取得
 *
 * @param mapyrFrom 支払人NoFrom
 * @param mapyrTo 支払人NoTo
 * @param start 
 * @param end 
 * @param countFlag　取得件数制御　true:全件/false：件数
 * 
 * 
*/
TomsMaster.getPaymentPtnList = function(mapyrFrom, mapyrTo, start, end, countFlag) {
	var database = new SharedDatabase("toms-web-dev");
	var paraMapyrFrom = null;
	var paraMapyrTo = null;
	var paraStart = 1;
	var paraEnd = 30;	

	if (mapyrFrom != null && mapyrFrom != ""){
		paraMapyrFrom = DbParameter.string(mapyrFrom);
	}
	if (mapyrTo != null && mapyrTo != ""){
		paraMapyrTo = DbParameter.string(mapyrTo);
	}
	
	if (start != null && start != ""){
		paraStart = start;
	}
	if (end != null && end != ""){
		paraEnd = end;
	}
	
	var params = {  mapyrFrom : paraMapyrFrom, 
					mapyrTo : paraMapyrTo
	             };

	var result;
	if(countFlag){
		//CSVダウンロード時に使用（全件取得）
		result = database.fetchByTemplate('toms/sql/getPaymentPtnList', 1, 0, params);
	}else{
		//一覧表示時に使用（件数取得）
		result = database.fetchByTemplate('toms/sql/getPaymentPtnList', paraStart, paraEnd, params);
	}
	return result;
}

/**
 * 入金パターン件数取得
*/
TomsMaster.getPaymentPtnListCount = function(mapyrFrom, mapyrTo) {
	var database = new SharedDatabase("toms-web-dev");
	var paraMapyrFrom = null;
	var paraMapyrTo = null;

	if (mapyrFrom != null && mapyrFrom != ""){
		paraMapyrFrom = DbParameter.string(mapyrFrom);
	}
	if (mapyrTo != null && mapyrTo != ""){
		paraMapyrTo = DbParameter.string(mapyrTo);
	}
	var params = {  mapyrFrom : paraMapyrFrom, 
					mapyrTo : paraMapyrTo
	             };

	var result = database.executeByTemplate('toms/sql/getPaymentPtnListCount', params);
	return result;
}

/**
 * 入金パターン取得
*/
TomsMaster.getPaymentPtn = function(mapyr) {
	
	var result = null
	try {
		var database = new SharedDatabase("toms-web-dev");
		var paraMapyr = null;
	
		if (mapyr != null && mapyr != ""){
			paraMapyr = DbParameter.string(mapyr);
		}
	
		var params = {mapyr : paraMapyr};
	
		result = database.executeByTemplate('resources/toms/payment/detail/getPaymentPtn', params);
		return result;
	} catch(e) {
	    Debug.console(e);
	    // エラー情報の返却
	    return result;
	}
}

/**
 * 入金パターン情報を登録する
*/
TomsMaster.insertToF56C1030 = function(entity) {
	var database = new SharedDatabase("toms-web-dev");
	var result = database.insert('F56C1030', entity);
	return result;
}

/**
 * 入金パターン情報を更新する
*/
TomsMaster.updateToF56C1030 = function(entity, condition, params) {
	var database = new SharedDatabase("toms-web-dev");
	var result = database.update('F56C1030', entity, condition, params);
	return result;
}

/**
 * 入金パターン情報を削除する
*/
TomsMaster.removeFromF56C1030 = function(condition, params) {
	var database = new SharedDatabase("toms-web-dev");
	var result = database.remove('F56C1030', condition, params);
	return result;
}

/**
 * 販売単価一覧情報を検索する処理。
 * 
 * @param malitm 第2品目番号
 * @param maan8 住所番号
 * @param macpgp 顧客価格グループ
 * @param maeftj 有効開始日付
 * @param start 開始No
 * @param end 終了No
 * @param countFlag 件数処理フラグ
 */
TomsMaster.getSalesList = function(malitm, maan8, macpgp, maeftj,
										start, end, countFlag) {
	var database = new SharedDatabase("toms-web-dev");
	var paramMalitm = null;
	var paramMaan8 = null;
	var paramMacpgp = null;
	var paramMaeftj = null;
	var paramStart = null;
	var paramEnd = null;
	
	if (malitm != null && malitm != "") {
		paramMalitm = DbParameter.string(malitm + "%");
	}
	if (maan8 != null && maan8 != "") {
		paramMaan8 = DbParameter.string(maan8 + "%");
	}
	if (macpgp != null && macpgp != "") {
		paramMacpgp = DbParameter.string(macpgp);
	}
	if (maeftj != null && maeftj != "") {
		paramMaeftj = DbParameter.string(maeftj);
	}

	
	var result;
	if (countFlag) {
    	var params =  {
    		malitm : paramMalitm,
        	maan8 : paramMaan8,
        	macpgp : paramMacpgp,
        	maeftj : paramMaeftj
        }
		result = database.executeByTemplate('toms/sql/getSalesListCount', params);
	} else {
		if (start != null && start != "") {
			paramStart = DbParameter.number(start);
		}
		if (end != null && end != "") {
			paramEnd = DbParameter.number(end);
		}
		
		var params =  {
            	malitm : paramMalitm,
            	maan8 : paramMaan8,
            	macpgp : paramMacpgp,
            	maeftj : paramMaeftj,
            	start : paramStart,
            	end : paramEnd
          }
		result = database.executeByTemplate('toms/sql/getSalesList', params);
	}
	return result;
}

/**
 * PKより販売単価マスタを検索する処理。
 * 
 * @param malitm 品目コード
 * @param macpgp ランクコード
 * @param mauorg 数量
 * @param macrcd 通貨コード
 * @param maeftj 開始日
 */
TomsMaster.getSaleByPk = function(malitm, macpgp, mauorg, macrcd, maeftj) {
	var database = new SharedDatabase("toms-web-dev");
	var paramMalitm = null;
	var paramMacpgp = null;
	var paramMauorg = null;
	var paramMacrcd = null;
	var paramMaeftj = null;
	
	if (malitm != null && malitm != "") {
		paramMalitm = DbParameter.string(malitm);
	}
	if (macpgp != null && macpgp != "") {
		paramMacpgp = DbParameter.string(macpgp);
	}
	if (mauorg != null && mauorg != "") {
		paramMauorg = DbParameter.string(mauorg);
	}
	if (macrcd != null && macrcd != "") {
		paramMacrcd = DbParameter.string(macrcd);
	}
	if (maeftj != null && maeftj != "") {
		paramMaeftj = DbParameter.string(maeftj);
	}
	
	var params =  {
		malitm : paramMalitm,
		macpgp : paramMacpgp,
    	mauorg : paramMauorg,
    	macrcd : paramMacrcd,
    	maeftj : paramMaeftj
      }
	var result = database.executeByTemplate('toms/sql/getSaleByPk', params);

	return result;
}

/**
 * 販売単価情報チェック
 */
TomsMaster.selectFromF57A5010 = function(params){
	var database = new SharedDatabase("toms-web-dev");
	var sql=" SELECT count(*) as cnt FROM F57A5010 " +
		" WHERE " +
    	" MALITM = RPAD(?, 25) " +
    	"   AND MAMCU = ? " +
    	"   AND MALOCN = ? " +
    	"   AND MALOTN = ? " +
    	"   AND MAAN8 = ? " +
    	"   AND MACPGP = RPAD(?, 8) " +
    	"   AND MAPRGR = ? " +
    	"   AND MAUORG = ? " +
    	"   AND MACRCD = ? " +
    	"   AND MAEFTJ = ? ";

	var ret = database.select(sql, params, 0);
	return ret;
}



/**
 * 販売単価情報を登録する
*/
TomsMaster.insertToF57A5010 = function(entity) {
	var database = new SharedDatabase("toms-web-dev");
	var ret = Transaction.begin(function(){
    	var result = database.insert('F57A5010', entity);
    	if(result.error || result.countRow !=1){
    		Transaction.rollback();
    		var errorObj = {
                error :true
    		};
    		return errorObj;
    	}
    	return result;
	});//<DatabaseResult
	return ret.data;
}

/**
 * 販売単価情報を更新する
*/
TomsMaster.updateToF57A5010 = function(entity, condition, params) {
	var database = new SharedDatabase("toms-web-dev");
	var ret = Transaction.begin(function(){
		var result = database.update('F57A5010', entity, condition, params);
		if(result.error || result.countRow !=1){
			Transaction.rollback();
			var errorObj = {
                error :true
			};
			return errorObj;
		}
		return result;
	});//<DatabaseResult
	return ret.data;
}

/**
 * 販売単価情報を削除する
*/
TomsMaster.removeFromF57A5010 = function(condition, params) {
	var database = new SharedDatabase("toms-web-dev");
	var ret = Transaction.begin(function(){
		var result = database.remove('F57A5010', condition, params);
		if(result.error || result.countRow !=1){
			Transaction.rollback();
		}
		return result;
	});//<DatabaseResult
	return ret.data;
}

/**
 * 特記事項マスタを検索する処理。
 * 
 * @param mgan8 取引先コード
 * @param start 開始No
 * @param end 終了No
 * @param countFlag 件数処理フラグ
 */
TomsMaster.getItemsList = function(mgan8, start, end, countFlag) {
	var database = new SharedDatabase("toms-web-dev");
	var paramMgan8 = null;
	var paramStart = null;
	var paramEnd = null;
	
	if (mgan8 != null && mgan8 != "") {
		paramMgan8 = DbParameter.string(mgan8);
	}
	
	var result;
	if (countFlag) {
    	var params =  {
    		mgan8 : paramMgan8
        }
		result = database.executeByTemplate('toms/sql/getItemsListCount', params);
	} else {
		if (start != null && start != "") {
			paramStart = DbParameter.number(start);
		}
		if (end != null && end != "") {
			paramEnd = DbParameter.number(end);
		}
		
		var params =  {
				mgan8 : paramMgan8,
            	start : paramStart,
            	end : paramEnd
          }
		result = database.executeByTemplate('toms/sql/getItemsList', params);
	}
	return result;
}

/**
 * PKより特記事項マスタを検索する処理。
 * 
 * @param mgan8 取引先コード
 * @param mgy57aspcd 特記事項項目コード
 * @param mgrno 特記事項メモ行№
 */
TomsMaster.getItemByPk = function(mgan8, mgy57aspcd, mgrno) {
	var database = new SharedDatabase("toms-web-dev");
	var paramMgan8 = null;
	var paramMgy57aspcd = null;
	var paramMgrno = null;
	
	if (mgan8 != null && mgan8 != "") {
		paramMgan8 = DbParameter.string(mgan8);
	}
	if (mgy57aspcd != null && mgy57aspcd != "") {
		paramMgy57aspcd = DbParameter.string(mgy57aspcd);
	}
	if (mgrno != null && mgrno != "") {
		paramMgrno = DbParameter.string(mgrno);
	}
	
	var params =  {
			mgan8 : paramMgan8,
			mgy57aspcd : paramMgy57aspcd,
			mgrno : paramMgrno
      }
	var result = database.executeByTemplate('toms/sql/getItemByPk', params);

	return result;
}

/**
 * 特記事項情報チェック
 * 
 */
TomsMaster.selectFromF57A5070 = function(condition, params){
	var database = new SharedDatabase("toms-web-dev");
	var sql=" SELECT count(*) as cnt FROM F57A5070 ";
	sql +=" WHERE " + condition;
	var ret = database.select(sql, params, 0);
	return ret;

}

/**
 * 特記事項情報を登録する
*/
TomsMaster.insertToF57A5070 = function(entity) {
	var database = new SharedDatabase("toms-web-dev");
	var ret = Transaction.begin(function(){
		var result = database.insert('F57A5070', entity);
		if(result.error){
			Transaction.rollback();
		}
		return result;
	});//<DatabaseResult
	return ret.data;
}

/**
 * 特記事項情報を更新する
*/
TomsMaster.updateToF57A5070 = function(entity, condition, params) {
	var database = new SharedDatabase("toms-web-dev");
	var ret = Transaction.begin(function(){
		var result = database.update('F57A5070', entity, condition, params);
		if(result.error || result.countRow !=1){
			Transaction.rollback();
		}
		return result;
	});
	return ret.data;
}

/**
 * 特記事項情報を削除する
*/
TomsMaster.removeFromF57A5070 = function(condition, params) {
	var database = new SharedDatabase("toms-web-dev");
	var ret = Transaction.begin(function(){
		var result = database.remove('F57A5070', condition, params);
		if(result.error || result.countRow ==0){
			Transaction.rollback();
		}
		return result;
	})
	return ret.data;
}




/**
 * 帳票設定マスタ一覧情報を検索する処理。
 * 
 * @param mfpid1 帳票ID
 * @param mfuser1 ユーザーID
 * @param start 開始No
 * @param end 終了No
 * @param countFlag 件数処理フラグ
 */
TomsMaster.getReportList = function(mfpid1, mfuser1,
										start, end, countFlag) {
	var database = new SharedDatabase("toms-web-dev");
	var paramMfpid1 = null;
	var paramMfuser1 = null;
	var paramStart = null;
	var paramEnd = null;
	
	if (mfpid1 != null && mfpid1 != "") {
		paramMfpid1 = DbParameter.string(mfpid1);
	}
	if (mfuser1 != null && mfuser1 != "") {
		paramMfuser1 = DbParameter.string(mfuser1);
	}
	
	var result;
	if (countFlag) {
    	var params =  {
    		mfpid1 : paramMfpid1,
    	    mfuser1 : paramMfuser1
        }
		result = database.executeByTemplate('toms/sql/getReportListCount', params);
	} else {
		if (start != null && start != "") {
			paramStart = DbParameter.number(start);
		}
		if (end != null && end != "") {
			paramEnd = DbParameter.number(end);
		}
		
		var params =  {
    		    mfpid1 : paramMfpid1,
	            mfuser1 : paramMfuser1,
            	start : paramStart,
            	end : paramEnd
          }
		result = database.executeByTemplate('toms/sql/getReportList', params);
	}
	return result;
}

/**
 * 帳票設定マスタ一覧情報を検索する処理。
 * 
 * @param mfpid1 帳票ID
 * @param mfuser1 ユーザーID
 * @param mfev01 オプションコード
 */
TomsMaster.getReportByPk = function(mfpid1, mfuser1, mfev01) {
	var database = new SharedDatabase("toms-web-dev");
	var paramMfpid1 = null;
	var paramMfuser1 = null;
	var paramMfev01 = null;
	
	if (mfpid1 != null && mfpid1 != "") {
		paramMfpid1 = DbParameter.string(mfpid1);
	}
	if (mfuser1 != null && mfuser1 != "") {
		paramMfuser1 = DbParameter.string(mfuser1);
	}
	if (mfev01 != null && mfev01 != "") {
		paramMfev01 = DbParameter.string(mfev01);
	}
	
	
	var params =  {
    		    mfpid1 : paramMfpid1,
	            mfuser1 : paramMfuser1,
	            mfev01 : paramMfev01
          }
	var result = database.executeByTemplate('toms/sql/getReportByPk', params);
	return result;
}

/**
 * 帳票設定情報を登録する
*/
TomsMaster.insertToF57C1050 = function(entity) {
	var database = new SharedDatabase("toms-web-dev");
	var ret = Transaction.begin(function(){
		var result = database.insert('F57C1050', entity);
		if(result.error || result.countRow !=1){
			Transaction.rollback();
		}
		return result;
	})
	return ret.data;
}

/**
 * 帳票設定情報を更新する
*/
TomsMaster.updateToF57C1050 = function(entity, condition, params) {
	var database = new SharedDatabase("toms-web-dev");
	var ret = Transaction.begin(function(){
		var result = database.update('F57C1050', entity, condition, params);
		if(result.error || result.countRow !=1){
			Transaction.rollback();
		}
			return result;
	})
	return ret.data;
}

/**
 * 帳票設定情報を削除する
*/
TomsMaster.removeFromF57C1050 = function(condition, params) {
	var database = new SharedDatabase("toms-web-dev");
	var ret = Transaction.begin(function(){
		var result = database.remove('F57C1050', condition, params);
		if(result.error || result.countRow !=1){
			Transaction.rollback();
		}
		return result;
	})
	return ret.data;
}
	
/**
 * 通貨一覧取得
*/
TomsMaster.getCurrencyList = function() {
	var database = new SharedDatabase("toms-web-dev");
	
	var result = database.executeByTemplate('toms/sql/getCurrencyList', null);
	return result;
}

//searchPaymentConditionsCount
/**
 * 支払条件一覧数取得 searchPaymentCondition(condPnptc, condAabdc);
*/
TomsMaster.searchPaymentConditionsCount = function(pnptc, pnptd) {

	var database = new SharedDatabase("toms-web-dev");		
	var paramPnptc = null;
	var paramPnptd = null;
	
	if (pnptc != null && pnptc != "") {
		paramPnptc = DbParameter.string("%" + pnptc + "%");
	}
	if (pnptd != null && pnptd != "") {
		paramPnptd = DbParameter.string("%" + pnptd + "%");
	}
	var params =  {
		pnptc : paramPnptc,
		pnptd : paramPnptd
    }
	var result = database.executeByTemplate('toms/sql/paymentConditionsListCount', params);
	return result;
}

/**
 * 支払条件一覧取得 searchPaymentCondition(condPnptc, condAabdc);
*/
TomsMaster.searchPaymentCondition = function(pnptc, pnptd, start, end) {
	
	var database = new SharedDatabase("toms-web-dev");		
	var paramPnptc = null;
	var paramPnptd = null;
	
	if (pnptc != null && pnptc != "") {
		paramPnptc = DbParameter.string("%" + pnptc + "%");
	}
	if (pnptd != null && pnptd != "") {
		paramPnptd = DbParameter.string("%" + pnptd + "%");
	}
	var params =  {
		pnptc : paramPnptc,
		pnptd : paramPnptd,
		start : DbParameter.number(start),
		end   : DbParameter.number(end)
    }
	var result = database.executeByTemplate('toms/sql/paymentConditionsList', params);
	return result;
}

/**
 * 支払い手段一覧取得
 *
*/
TomsMaster.getMeansOfPaymentList = function() {
	var database = new SharedDatabase("toms-web-dev");	
	var params =  {};
	var result = database.executeByTemplate('toms/sql/getMeansOfPaymentList', params);
	return result;
}

/**
 * 口座名義人取得処理
 * @param    なし
 * @return   口座名義人
 * 
 */

TomsMaster.getHanyouMasterKouzanin = function(){
	var database = new TenantDatabase();
	var params ={};
	var result = database.executeByTemplate('toms/sql/getHanyouMasterKouzanin', params);
	return result;
	


}
