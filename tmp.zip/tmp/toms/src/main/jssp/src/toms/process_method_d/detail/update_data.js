/**
 * 加工方法明細マスタ設定更新処理群
 * 
 * toms\src\main\jssp\src\toms\process_method_d\detail\update_data.js
 * 
 */

load('toms/common/common');
load('toms/common/cmnUtil');
load('toms/common/mastermaintenance');
var _SHARED_DB_KEY = "toms-web-dev";

function init(request){

	var msg;
	var result;
	//登録・更新データ設定
	var entity = createEntity(request);
	
	var searchInfo = setData(request);


	//遷移先への返却用オブジェクト（加工方法ヘッダー情報を設定）
	var backParam ={};

	
	
	//更新用SQL
	var condition =" TRIM(mny57apmc) =?"+ 
							" AND TRIM(mny57ajc1) =? " +
							" AND TRIM(mny57ajc2) =? " +
							" AND TRIM(mny57ajc3) =? " +
							" AND mny57adflg =0 " +
							" AND mneftj =? ";
							
	//更新用キー
	var params = [
		   DbParameter.string(entity['mny57apmc']),
		   DbParameter.string(entity['mny57ajc1']),
		   DbParameter.string(entity['mny57ajc2']),
		   DbParameter.string(entity['mny57ajc3']),
		   DbParameter.number(entity['mneftj'])
	];
	
	//------------------------------------
	//新規登録時
	//------------------------------------
	if(request.operateFlag=="0"){
	/*重複チェック*/
		result = _dbCheck(entity['mny57apmc'],entity['mny57ajc1'],entity['mny57ajc2'],entity['mny57ajc3'],entity['mneftj']);
    	if(result.error){
            // SELECTが失敗した場合
        	msg = MessageManager.getMessage('TOMS.COMMON.MAINTENANCE.AJAX.ERROR.INSERT.MESSAGE', MessageManager.getMessage('TOMS.MASTER.MAINTENANCE.PROCESSMETHOD_DETAIL.DETAIL.INPUT.TITLE'));
        	common.sendErrorResult(msg, "");
    	}
    	if(result.countRow !=0){
    		// 既に登録済みの場合
        	msg = MessageManager.getMessage('TOMS.COMMON.MAINTENANCE.AJAX.ERROR.INSERT.MESSAGE', MessageManager.getMessage('TOMS.MASTER.MAINTENANCE.PROCESSMETHOD_DETAIL.DETAIL.INPUT.TITLE'));
        	common.sendErrorResult(msg, MessageManager.getMessage('TOMS.COMMON.MAINTENANCE.AJAX.ERROR.INSERT.NOTNEWDATA.MESSAGE'));
    	}
    	/* 加工方法ヘッダ存在チェック　紐づく先のヘッダーがあるかどうか */
		result = _dbCheckHeader(entity['mny57apmc']);
    	if(result.error){
            // SELECTが失敗した場合
        	msg = MessageManager.getMessage('TOMS.COMMON.MAINTENANCE.AJAX.ERROR.INSERT.MESSAGE', MessageManager.getMessage('TOMS.MASTER.MAINTENANCE.PROCESSMETHOD_DETAIL.DETAIL.INPUT.TITLE'));
        	common.sendErrorResult(msg, "");
    	}
        if (result.countRow != 1) {
            // 対象データが存在しない場合
        	msg = MessageManager.getMessage('TOMS.COMMON.MAINTENANCE.AJAX.ERROR.INSERT.MESSAGE', MessageManager.getMessage('TOMS.MASTER.MAINTENANCE.PROCESSMETHOD_DETAIL.DETAIL.INPUT.TITLE'));
        	common.sendErrorResult(msg, MessageManager.getMessage('TOMS.COMMON.MAINTENANCE.AJAX.ERROR.MASTER.NODATA',MessageManager.getMessage('TOMS.MASTER.MAINTENANCE.PROCESSMETHOD_HEADER.LABEL.INFOMATION')));
        }
        
    	/*内部コードマスタ存在チェック*/
    	//第1階層JDEコード
		result = MasterMain.checkCodeMasterMethodDetail("07","02",entity['mny57ajc1'], entity['mny57apmt']);
    	if(result.error){
            // SELECTが失敗した場合
        	msg = MessageManager.getMessage('TOMS.COMMON.MAINTENANCE.AJAX.ERROR.INSERT.MESSAGE', MessageManager.getMessage('TOMS.MASTER.MAINTENANCE.PROCESSMETHOD_DETAIL.DETAIL.INPUT.TITLE'));
        	common.sendErrorResult(msg, "");
    	}
    	if(result.countRow ==0){
    		// 存在しない場合
        	msg = MessageManager.getMessage('TOMS.COMMON.MAINTENANCE.AJAX.ERROR.INSERT.MESSAGE', MessageManager.getMessage('TOMS.MASTER.MAINTENANCE.PROCESSMETHOD_DETAIL.DETAIL.INPUT.TITLE'));
        	common.sendErrorResult(msg, MessageManager.getMessage('TOMS.COMMON.MAINTENANCE.AJAX.ERROR.CODEMASTER.NOTINLINE.MESSAGE',MessageManager.getMessage('TOMS.MASTER.MAINTENANCE.PROCESSMETHOD_DETAIL.LABEL.JDE_CODE1')));
    	}    	
  	
    //第2階層JDEコード
		result = MasterMain.checkCodeMasterMethodDetail("07","02",entity['mny57ajc2'], entity['mny57apmt']);
    	if(result.error){
            // SELECTが失敗した場合
        	msg = MessageManager.getMessage('TOMS.COMMON.MAINTENANCE.AJAX.ERROR.INSERT.MESSAGE', MessageManager.getMessage('TOMS.MASTER.MAINTENANCE.PROCESSMETHOD_DETAIL.DETAIL.INPUT.TITLE'));
        	common.sendErrorResult(msg, "");
    	}
    	if(result.countRow ==0){
    		// 存在しない場合
        	msg = MessageManager.getMessage('TOMS.COMMON.MAINTENANCE.AJAX.ERROR.INSERT.MESSAGE', MessageManager.getMessage('TOMS.MASTER.MAINTENANCE.PROCESSMETHOD_DETAIL.DETAIL.INPUT.TITLE'));
        	common.sendErrorResult(msg, MessageManager.getMessage('TOMS.COMMON.MAINTENANCE.AJAX.ERROR.CODEMASTER.NOTINLINE.MESSAGE',MessageManager.getMessage('TOMS.MASTER.MAINTENANCE.PROCESSMETHOD_DETAIL.LABEL.JDE_CODE2')));
    	}    	

    	//第3階層JDEコード
		result = MasterMain.checkCodeMasterMethodDetail("07","02",entity['mny57ajc3'], entity['mny57apmt']);
    	if(result.error){
            // SELECTが失敗した場合
        	msg = MessageManager.getMessage('TOMS.COMMON.MAINTENANCE.AJAX.ERROR.INSERT.MESSAGE', MessageManager.getMessage('TOMS.MASTER.MAINTENANCE.PROCESSMETHOD_DETAIL.DETAIL.INPUT.TITLE'));
        	common.sendErrorResult(msg, "");
    	}
    	if(result.countRow ==0){
    		// 存在しない場合
        	msg = MessageManager.getMessage('TOMS.COMMON.MAINTENANCE.AJAX.ERROR.INSERT.MESSAGE', MessageManager.getMessage('TOMS.MASTER.MAINTENANCE.PROCESSMETHOD_DETAIL.DETAIL.INPUT.TITLE'));
        	common.sendErrorResult(msg, MessageManager.getMessage('TOMS.COMMON.MAINTENANCE.AJAX.ERROR.CODEMASTER.NOTINLINE.MESSAGE',MessageManager.getMessage('TOMS.MASTER.MAINTENANCE.PROCESSMETHOD_DETAIL.LABEL.JDE_CODE3')));
    	}    	

    	//登録実行
    	result = insertToF57A5141(entity);
        if (result.error) {
            // 処理が失敗した場合
        	msg = MessageManager.getMessage('TOMS.COMMON.MAINTENANCE.AJAX.ERROR.INSERT.MESSAGE', MessageManager.getMessage('TOMS.MASTER.MAINTENANCE.PROCESSMETHOD_DETAIL.DETAIL.INPUT.TITLE'));
        	common.sendErrorResult(msg, "");
        }
        
        // 処理が成功した場合
        msg = MessageManager.getMessage('TOMS.COMMON.MAINTENANCE.AJAX.SUCCESS.INSERT.MESSAGE', MessageManager.getMessage('TOMS.MASTER.MAINTENANCE.PROCESSMETHOD_DETAIL.DETAIL.INPUT.TITLE'));
        common.sendResultParameter(msg,searchInfo);
        
	//------------------------------------
	//更新時
	//------------------------------------
	}else if(request.operateFlag=="1"){


    	//更新処理
		result = updateToF57A5141(entity, condition, params);
        if (result.error) {
            // 処理が失敗した場合
        	msg = MessageManager.getMessage('TOMS.COMMON.MAINTENANCE.AJAX.ERROR.UPDATE.MESSAGE', MessageManager.getMessage('TOMS.MASTER.MAINTENANCE.PROCESSMETHOD_DETAIL.DETAIL.INPUT.TITLE'));
        	common.sendErrorResult(msg, "");
        }
        if (result.countRow != 1) {
            // 対象データが存在しない場合
        	msg = MessageManager.getMessage('TOMS.COMMON.MAINTENANCE.AJAX.ERROR.UPDATE.MESSAGE', MessageManager.getMessage('TOMS.MASTER.MAINTENANCE.PROCESSMETHOD_DETAIL.DETAIL.INPUT.TITLE'));
        	common.sendErrorResult(msg, MessageManager.getMessage('TOMS.COMMON.MAINTENANCE.AJAX.ERROR.UPDATE.NODATA.MESSAGE'));
        }
        // 処理が成功した場合
        msg = MessageManager.getMessage('TOMS.COMMON.MAINTENANCE.AJAX.SUCCESS.UPDATE.MESSAGE', MessageManager.getMessage('TOMS.MASTER.MAINTENANCE.PROCESSMETHOD_DETAIL.DETAIL.INPUT.TITLE'));
        common.sendResultParameter(msg,searchInfo);

//------------------------------------
//削除時
//------------------------------------
	}else if(request.operateFlag=="2"){
    	/*
    	 * DB存在チェック
    	 */
		result = removeFromF57A5141(condition, params);
	    if (result.error) {
	        // 処理が失敗した場合
        	msg = MessageManager.getMessage('TOMS.COMMON.MAINTENANCE.AJAX.ERROR.DELETE.MESSAGE', MessageManager.getMessage('TOMS.MASTER.MAINTENANCE.PROCESSMETHOD_DETAIL.DETAIL.INPUT.TITLE'));
        	common.sendErrorResult(msg, "");
	    }
        if(result.countRow != 1){
	    	// 処理件数が１件でない場合
        	msg = MessageManager.getMessage('TOMS.COMMON.MAINTENANCE.AJAX.ERROR.DELETE.MESSAGE', MessageManager.getMessage('TOMS.MASTER.MAINTENANCE.PROCESSMETHOD_DETAIL.DETAIL.INPUT.TITLE'));
        	common.sendErrorResult(msg, MessageManager.getMessage('TOMS.COMMON.MAINTENANCE.AJAX.ERROR.DELETE.NODATA.MESSAGE'));
	    }
	    // 処理が成功した場合
        msg = MessageManager.getMessage('TOMS.COMMON.MAINTENANCE.AJAX.SUCCESS.DELETE.MESSAGE', MessageManager.getMessage('TOMS.MASTER.MAINTENANCE.PROCESSMETHOD_DETAIL.DETAIL.INPUT.TITLE'));
        common.sendResultParameter(msg,searchInfo);	
	}
}


/**
 * DBへの登録オブジェクト生成処理
 */
function createEntity(request){

	var userContext = Contexts.getUserContext();
	var now = new Date();
	
	//変数初期化
	var mny57apmc = null; //加工方法コード
	var mny57apmt = null; //加工方法区分
	
	var mny57apmn1 = null; //第1階層名称
	var mny57ado1 =null;//第1階層表示順
	var mny57ajc1 = null;//第1階層JDEコード
	var mny57agn1 = null; //第1階層グループ名称

	var mny57apmn2 = null; //第2階層名称
	var mny57ado2 =null;//第2階層表示順
	var mny57ajc2 = null;//第2階層JDEコード
	var mny57agn2 = null; //第2階層グループ名称

	var mny57apmn3 = null; //第3階層名称
	var mny57ado3 =null;//第3階層表示順
	var mny57ajc3 = null;//第3階層JDEコード
	var mny57agn3 = null; //第3階層グループ名称

	var mny57apsh =null;//柄サイズ 縦
	var mny57apsw =null;//柄サイズ 横
	var mny57ahflg =null;//非表示フラグ
	var mneftj =null;//適用開始日
	
	//ヘッダ情報
	var mny57apcsc= null;//親商品形態コード
	var mny57acsc= null;//商品形態コード
	var mny57amtc= null;//素材コード
	var mny57appc1= null;//加工部位コード
	var mny57appc2= null;//加工位置コード
	var mny57apmt= null;//加工方法区分
	var mny57apmdt= null;//加工方法明細区分
	var mmdl01 = null//加工方法名称




	var mnuser = userContext.userProfile.userCd; //ユーザID
    var mnpid = "TOMS-WEB"; //プログラムID
	var mnupmj = cmnUtil.convertDateToJulia(now);  //更新日付
	var mnupmt = cmnUtil.getTime(now);  //更新時刻
	
	//加工方法コード 加工方法ヘッダーのキー情報
    if(!isBlank(request.mny57apmc)){
    	mny57apmc = request.mny57apmc;
    }
    //加工方法区分 登録時に必要
    if(!isBlank(request.mny57apmt)){
    	mny57apmt = request.mny57apmt;
    }
    //ヘッダーからの設定
    //親商品形態コード
    if(!isBlank(request.mmy57apcsc)){
    	mny57apcsc = request.mmy57apcsc;
    }
    //商品形態コード
    if(!isBlank(request.mmy57acsc)){
    	mny57acsc = request.mmy57acsc;
    }
    //素材コード
    if(!isBlank(request.mmy57amtc)){
    	mny57amtc = request.mmy57amtc;
    }
    //加工部位コード
    if(!isBlank(request.mmy57appc1)){
    	mny57appc1 = request.mmy57appc1;
    }
    //加工位置コード
    if(!isBlank(request.mmy57appc2)){
    	mny57appc2 = request.mmy57appc2;
    }
    //加工明細区分
    if(!isBlank(request.mmy57apmdt)){
    	mny57apmdt = request.mmy57apmdt;
    }
    //------------------------------------------------
    //明細情報
	//第1階層名称
    if(!isBlank(request.mny57apmn1)){
    	mny57apmn1 = request.mny57apmn1;
    }
	//第2階層名称
    if(!isBlank(request.mny57apmn2)){
    	mny57apmn2 = request.mny57apmn2;
    }
    //第3階層名称
    if(!isBlank(request.mny57apmn3)){
    	mny57apmn3 = request.mny57apmn3;
    }

    //第1階層表示順
    if(!isBlank(request.mny57ado1)){
    	mny57ado1 = cmnUtil.getData(request.mny57ado1,1);
    }
	//第2階層表示順
    if(!isBlank(request.mny57ado2)){
    	mny57ado2 = cmnUtil.getData(request.mny57ado2,1);
    }
    //第3階層表示順
    if(!isBlank(request.mny57ado3)){
    	mny57ado3 = cmnUtil.getData(request.mny57ado3,1);
    }

    //第1階層JDEコード
    if(!isBlank(request.mny57ajc1)){
    	mny57ajc1 = request.mny57ajc1;
    }
	//第2階層JDEコード
    if(!isBlank(request.mny57ajc2)){
    	mny57ajc2 = request.mny57ajc2;
    }
    //第3階層JDEコード
    if(!isBlank(request.mny57ajc3)){
    	mny57ajc3 = request.mny57ajc3;
    }

    //第1階層グループ名称
    if(!isBlank(request.mny57agn1)){
    	mny57agn1 = request.mny57agn1;
    }
	//第2階層グループ名称
    if(!isBlank(request.mny57agn2)){
    	mny57agn2 = request.mny57agn2;
    }
    //第3階層グループ名称
    if(!isBlank(request.mny57agn3)){
    	mny57agn3 = request.mny57agn3;
    }
    
    //柄サイズ 縦
    if(!isBlank(request.mny57apsh)){
    	mny57apsh = cmnUtil.getData(request.mny57apsh,1);
    }
	//柄サイズ 横
    if(!isBlank(request.mny57apsw)){
    	mny57apsw = cmnUtil.getData(request.mny57apsw,1);
    }
    //非表示フラグ
    if(!isBlank(request.mny57ahflg)){
    	mny57ahflg = cmnUtil.getData(request.mny57ahflg,1);
    }else{
    	mny57ahflg = 0;
    }
    
	//適用開始日
    if(!isBlank(request.mneftj)){
    	mneftj = cmnUtil.convertDateToJulia(new Date(request.mneftj));
    }
    
    var entity ={
    	mny57apmc : mny57apmc,
    	mny57apmt : mny57apmt,
	    mny57apmn1 : mny57apmn1,
	    mny57apmn2 : mny57apmn2,
	    mny57apmn3 : mny57apmn3,
	    mny57ajc1 : mny57ajc1,
	    mny57ajc2 : mny57ajc2,
	    mny57ajc3 : mny57ajc3,
	    mny57agn1 : mny57agn1,
	    mny57agn2 : mny57agn2,
	    mny57agn3 : mny57agn3,
	    mny57ado1 : mny57ado1,
	    mny57ado2 : mny57ado2,
	    mny57ado3 : mny57ado3,
        mny57apsh : mny57apsh,
        mny57apsw : mny57apsw,
	    mny57ahflg : mny57ahflg,
	    mneftj : mneftj,
    	mnuser : mnuser,
    	mnpid : mnpid,
    	mnupmj : mnupmj,
    	mnupmt : mnupmt,
    	mny57apcsc : mny57apcsc,
    	mny57acsc : mny57acsc,
    	mny57amtc : mny57amtc,
    	mny57appc1 : mny57appc1,
    	mny57appc2 : mny57appc2,
    	mny57apmdt : mny57apmdt
    };
    return entity;
}

/*データ存在チェック*/

function _dbCheck(mny57apmc,mny57ajc1,mny57ajc2,mny57ajc3,mneftj){
	var db = new SharedDatabase(_SHARED_DB_KEY);
	var params = [];

	var sql ="";
	sql += " SELECT * FROM F57A5141 ";
	sql +="     WHERE ";
	sql +="              TRIM(MNY57APMC) = ? ";
	sql +="          AND TRIM(MNY57AJC1) = ? ";
	sql +="          AND TRIM(MNY57AJC2) = ? ";
	sql +="          AND TRIM(MNY57AJC3) = ? ";
	sql +="          AND MNEFTJ = ? ";

  params.push(DbParameter.string(mny57apmc));
  params.push(DbParameter.string(mny57ajc1));
  params.push(DbParameter.string(mny57ajc2));
  params.push(DbParameter.string(mny57ajc3));
  params.push(DbParameter.number(mneftj));
	var result = db.execute(sql, params);
	return result;
}


/*データ存在チェック(加工方法ヘッダチェック)*/

function _dbCheckHeader(mny57apmc){
	var db = new SharedDatabase(_SHARED_DB_KEY);
	var params = [];

	var sql ="";
	sql += " SELECT * FROM F57A5140 ";
	sql +="     WHERE ";
	sql +="              TRIM(MMY57APMC) = ? ";

  params.push(DbParameter.string(mny57apmc));
	var result = db.execute(sql, params);
	return result;
}
	
/**
 * 登録処理
 */
function insertToF57A5141(entity){
	var database = new SharedDatabase(_SHARED_DB_KEY);
	var ret = Transaction.begin(function(){
		entity.mny57adflg=0;//削除フラグ追加
		entity.mnexdj = cmnUtil.convertDateToJulia(new Date(MessageManager.getMessage('TOMS.COMMON.CONSTANT.ENDDATE')));
		var result = database.insert('F57A5141', entity);
		if(result.error || result.countRow !=1){
			Transaction.rollback();
		}
		return result;
	})
	return ret.data;
}
function updateToF57A5141(entity, condition, params) {
	var database = new SharedDatabase(_SHARED_DB_KEY);
	var ret = Transaction.begin(function(){
		var result = database.update('F57A5141', entity, condition, params);
		if(result.error || result.countRow !=1){
			Transaction.rollback();
		}
			return result;
	})
	return ret.data;
}
function removeFromF57A5141(condition, params) {
	var database = new SharedDatabase(_SHARED_DB_KEY);
	var ret = Transaction.begin(function(){
		var entity ={
			mny57adflg : 1
			};
		var result = database.update('F57A5141',entity,  condition, params);
		if(result.error || result.countRow !=1){
			Transaction.rollback();
		}
		return result;
	})
	return ret.data;
}


// ヘッダー情報設定
function setData(request){
	var mmy57apmc = isBlank(request.mny57apmc) ? "": request.mny57apmc; //加工方法コード 
	var mmy57apcsc = isBlank(request.mmy57apcsc) ? "": request.mmy57apcsc; //親商品形態コード
	var mmy57acsc = isBlank(request.mmy57acsc) ? "": request.mmy57acsc; //商品形態コード
	var mmy57amtc = isBlank(request.mmy57amtc) ? "": request.mmy57amtc; //素材コード
	var mmy57appc1 = isBlank(request.mmy57appc1) ? "": request.mmy57appc1; //加工部位コード
	var mmy57appc2 = isBlank(request.mmy57appc2) ? "": request.mmy57appc2; //加工位置コード
	var mmy57apmt = isBlank(request.mmy57apmt) ? "": request.mmy57apmt; //加工方法区分
	var mmy57apmdt = isBlank(request.mmy57apmdt) ? "": request.mmy57apmdt; //加工方法明細区分
	var mmdl01 = isBlank(request.mmdl01) ? "": request.mmdl01; //加工方法名称
	
	var seachObj ={
		mmy57apmc:mmy57apmc,
	mmy57apcsc : mmy57apcsc,
	mmy57acsc : mmy57acsc,
	mmy57amtc : mmy57amtc,
	mmy57amtc : mmy57amtc,
	mmy57appc1 : mmy57appc1,
	mmy57appc2 : mmy57appc2,
	mmy57apmt : mmy57apmt,
	mmy57apmdt : mmy57apmdt,
	mmdl01 : mmdl01
	}

	return seachObj;

}
