/**
 * ボディ非推奨管理マスタメンテナンス検索画面用validation設定
 */

var init = {
    // 親商品形態コード
    'search_mqy57apcsc' : {
        caption:'TOMS.MASTER.MAINTENANCE.COMMODITYSHAPE.LABEL.PARENT_COMMODITY_SHAPE_CODE',
        alphanumeric: true,
        maxlength: 16
    },
    // 親商品形態名称
    'search_mqy57apcscName' : {
        caption:'TOMS.MASTER.MAINTENANCE.COMMODITYSHAPE.LABEL.PARENT_COMMODITY_SHAPE_NAME',
        maxlength: 30
    },
    // 商品形態コード
    'search_mqy57acsc' : {
        caption:'TOMS.MASTER.MAINTENANCE.COMMODITYSHAPE.LABEL.COMMODITY_SHAPE_CODE',
        alphanumeric: true,
        maxlength: 16
    },
    // 商品形態名称
    'search_mqy57acscName' : {
        caption:'TOMS.MASTER.MAINTENANCE.COMMODITYSHAPE.LABEL.COMMODITY_SHAPE_NAME',
        maxlength: 30
    },
    // 素材コード
    'search_mqy57amtc' : {
        caption:'TOMS.MASTER.MAINTENANCE.MATERIAL.LABEL.MATERIAL_CODE',
        alphanumeric: true,
        maxlength: 16
    },
    // 原材料名
    'search_mldl01' : {
        caption:'TOMS.MASTER.MAINTENANCE.MATERIAL.LABEL.MATERIAL_NAME',
        maxlength: 30
    },
    // 加工部位コード
    'search_mqy57appc1' : {
        caption:'TOMS.MASTER.MAINTENANCE.PROCESSPART.LABEL.PROCESSPART_CODE',
        alphanumeric: true,
        maxlength: 16
    },
    // 加工部位名称
    'search_mkdl01' : {
        caption:'TOMS.MASTER.MAINTENANCE.PROCESSPART.LABEL.PROCESSPART_NAME',
        maxlength: 30
    },
    // 加工位置コード
    'search_mqy57appc2' : {
        caption:'TOMS.MASTER.MAINTENANCE.PROCESSPART.LABEL.PROCESSPART_POSITION_CODE',
        alphanumeric: true,
        maxlength: 16
    },
    // 加工位置名称
    'search_mkdl02' : {
        caption:'TOMS.MASTER.MAINTENANCE.PROCESSPART.LABEL.PROCESSPART_POSITION_NAME',
        maxlength: 30
    },
    // 加工方法明細第1階層コード
    'search_mqy57apmd1' : {
        caption:'TOMS.MASTER.MAINTENANCE.BODY_NOT_RECOMMENDED.PROCESS_DETAIL_FIRST_HIERARCHY_CODE',
        alphanumeric: true,
        maxlength: 8
    },
    // 加工方法明細第1階層名称
    'search_mny57apmn1' : {
        caption:'TOMS.MASTER.MAINTENANCE.BODY_NOT_RECOMMENDED.PROCESS_DETAIL_FIRST_HIERARCHY_NAME',
        maxlength: 30
    },
    // 加工方法明細第2階層コード
    'search_mqy57apmd2' : {
        caption:'TOMS.MASTER.MAINTENANCE.BODY_NOT_RECOMMENDED.PROCESS_DETAIL_SECOND_HIERARCHY_CODE',
        alphanumeric: true,
        maxlength: 8
    },
    // 加工方法明細第1階層名称
    'search_mny57apmn2' : {
        caption:'TOMS.MASTER.MAINTENANCE.BODY_NOT_RECOMMENDED.PROCESS_DETAIL_SECOND_HIERARCHY_NAME',
        maxlength: 30
    },
    // 加工方法明細第3階層コード
    'search_mqy57apmd3' : {
        caption:'TOMS.MASTER.MAINTENANCE.BODY_NOT_RECOMMENDED.PROCESS_DETAIL_THIRD_HIERARCHY_CODE',
        alphanumeric: true,
        maxlength: 8
    },
    // 加工方法明細第3階層名称
    'search_mny57apmn3' : {
        caption:'TOMS.MASTER.MAINTENANCE.BODY_NOT_RECOMMENDED.PROCESS_DETAIL_THIRD_HIERARCHY_NAME',
        maxlength: 30
    },
    // 商品コード
    'search_mqy57aitcd' : {
        caption:'TOMS.MASTER.MAINTENANCE.PROCESSMETHOD_COMMODITY.LABEL.COMMODITY_CODE',
        alphanumeric: true,
        maxlength: 16
    },
    // 商品名称
    'search_mqy57aitcdName' : {
        caption:'TOMS.MASTER.MAINTENANCE.BODY_NOT_RECOMMENDED.PRODUCT_NAME',
        maxlength: 30
    },
    // サイズコード
    'search_mqy57asc' : {
        caption:'TOMS.MASTER.MAINTENANCE.BODY_NOT_RECOMMENDED.SIZE_CODE',
        alphanumeric: true,
        maxlength: 20
    },
    // サイズ名称
    'search_mqy57ascName' : {
        caption:'TOMS.MASTER.MAINTENANCE.BODY_NOT_RECOMMENDED.SIZE_NAME',
        maxlength: 30
    },
    // 適用開始日From
    'search_mqeftj_from' : {
        caption:'TOMS.MASTER.MAINTENANCE.COMMODITYSHAPE.LABEL.APPLIED_START_DATE',
        date: true,
        maxlength: 10
    }, 
    // 適用開始日To
    'search_mqeftj_to' : {
        caption:'TOMS.MASTER.MAINTENANCE.COMMODITYSHAPE.LABEL.APPLIED_START_DATE',
        date: true,
        maxlength: 10
    }
}
