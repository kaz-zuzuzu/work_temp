var $data;

/**
 * 初期表示
 * @param request リクエストパラメータ
 */
	
function init(request) {
	$data = ImJson.toJSONString(getList(request)); 
}

function getList(request) {

	// 表示条件を設定（表示ページ、件数など）
	let page = request.page == undefined ? 1 : request.page;
	let rows = request.rowNum == undefined ? 15 : Module.number.toInt(request.rowNum);
	
	// 検索条件の状況に応じて条件を設定する
	var param = request.extension;
	if (!param || !param.searchCondition) {
    	return  {
                		page  : page,
                		total : rows,
                		data  : []
    				};
	}
	
	//検索条件の設定
	var mmy57apmc = isBlank(param.searchCondition.mmy57apmc) ? null : param.searchCondition.mmy57apmc;//加工方法コード
	var mmy57apcsc = isBlank(param.searchCondition.mmy57apcsc) ? null : param.searchCondition.mmy57apcsc;//親商品形態コード
	var mmy57acsc = isBlank(param.searchCondition.mmy57acsc) ? null : param.searchCondition.mmy57acsc;//商品形態コード
	var mmy57amtc = isBlank(param.searchCondition.mmy57amtc) ? null : param.searchCondition.mmy57amtc;//素材コード
	var mmy57appc1 = isBlank(param.searchCondition.mmy57appc1) ? null : param.searchCondition.mmy57appc1;//加工部位コード
	var mmy57appc2 = isBlank(param.searchCondition.mmy57appc2) ? null : param.searchCondition.mmy57appc2;//加工位置コード
	var mmy57ada = isBlank(param.searchCondition.mmy57ada) ? null : param.searchCondition.mmy57ada;//階層数
	var mmy57asrt = isBlank(param.searchCondition.mmy57asrt) ? null : param.searchCondition.mmy57asrt;//特記事項区分
	var mmy57apmt = isBlank(param.searchCondition.mmy57apmt) ? null : param.searchCondition.mmy57apmt ;//加工方法区分
	var mmy57apmdt = isBlank(param.searchCondition.mmy57apmdt) ? null : param.searchCondition.mmy57apmdt;//加工方法明細区分
	var mmdl01 = isBlank(param.searchCondition.mmdl01) ? null : param.searchCondition.mmdl01 ;//加工方法名称
	var mmeftj = isBlank(param.searchCondition.mmeftj) ? null :param.searchCondition.mmeftj ;//適用開始日
	var mmeftj2 = isBlank(param.searchCondition.mmeftj2) ? null :param.searchCondition.mmeftj2 ;//適用開始日
	var mmexdj = isBlank(param.searchCondition.mmexdj) ? null : param.searchCondition.mmexdj;//適用終了日
	var mmy57adflg = isBlank(param.searchCondition.mmy57adflg) ? null : param.searchCondition.mmy57adflg ;//削除フラグ

	var objParams = {
		mmy57apmc : mmy57apmc,
		mmy57apcsc : mmy57apcsc,
		mmy57acsc : mmy57acsc,
		mmy57amtc : mmy57amtc,
		mmy57appc1 : mmy57appc1,
		mmy57appc2 : mmy57appc2,
		mmy57ada : mmy57ada,
		mmy57asrt : mmy57asrt,
		mmy57apmt : mmy57apmt,
		mmy57apmdt : mmy57apmdt,
		mmdl01 : mmdl01,
		mmeftj : mmeftj,
		mmeftj2 : mmeftj2,
		mmexdj : mmexdj,
		mmy57adflg : mmy57adflg
	}

	//加工方法ヘッダマスタの件数取得
	var resultCount = getHeaderListCount(objParams);
	// 全体の件数を設定（件数の母数）
	var listCount = 0;
	if (!resultCount.error) {
		listCount = resultCount.data[0]['rowcount'];
	} else {
		Debug.write(resultCount.errorMessage);
	}
	
	// ページ番号設定:リクエストパラメータのページ番号、最大ページ番号のうち小さい方の番号を設定
	page = Math.min(page, Math.ceil(listCount / rows)); 
	
	// 指定範囲の加工部位情報を取得
	var start = rows * (page - 1) + 1;
	var end = start + rows - 1;

	//加工方法ヘッダマスタの一覧取得
	var result = getHeaderList(objParams, start, end);
	var resultData =[];
	if(!result.error){
		resultData = result.data;
	}else{
		Debug.write(result.errorMessage);
	}

	var json = {
		page  : page,
		total : listCount,
		data  : resultData
	};
	return json;

	
	}

/**
 * 加工方法ヘッダ一覧件数取得
 */	
function getHeaderListCount(objParams){
    load("toms/common/processMethod");
    var result = ProcessMethod.getHeaderList(objParams, true,"","");
    return result;
}

/**
 * 加工方法ヘッダ一覧データ取得
 */
function getHeaderList(objParams, start , end){
    load("toms/common/processMethod");
    var result = ProcessMethod.getHeaderList(objParams, false,start,end);
    return result;
	
}

function createResult(page, total, data){
	return {
		page : page == null ? 1 : page,
		total : total == null ? 0 : total,
		data : data == null ? [] : data
	};
}


/**
 * エラーオブジェクト生成
 */
function createErrorResult(message, details){
	return {
		error : true,
		errorMessage : message,
		detailMessages : details

	}
}
