/**
 * 検索画面validation設定
 */
var init = {
  'mgan8': { // バリデーション対象のformのname属性を指定する.
    caption: 'TOMS.MASTER.MAINTENANCE.ITEMS.LIST.INPUT.MGAN8', // キャプションのメッセージキーを指定する. 
    required: true, // 必須チェック
    numeric: true, // 数字チェック
    minlength: 8,
    maxlength: 8
  },
  'mgy57aspcd': { // バリデーション対象のformのname属性を指定する.
    caption: 'TOMS.MASTER.MAINTENANCE.ITEMS.LIST.INPUT.MGY57ASPCD', // キャプションのメッセージキーを指定する. 
    required: true, // 必須チェック
    alphanumeric: true, // 数字チェック
    //minlength: 2
    maxlength: 2
  },
  'mgrno': { // バリデーション対象のformのname属性を指定する.
    caption: 'TOMS.MASTER.MAINTENANCE.ITEMS.LIST.INPUT.MGRNO', // キャプションのメッセージキーを指定する. 
    required: true, // 必須チェック
    numeric: true, // 数字チェック
    maxlength: 8
  },
  'mgds01': { // バリデーション対象のformのname属性を指定する.
	  caption: 'TOMS.MASTER.MAINTENANCE.ITEMS.LIST.INPUT.MGDS01', // キャプションのメッセージキーを指定する. 
	  required: true, // 必須チェック
	  maxlength: 80
   }
};