SELECT
    COUNT(*) AS ROWCOUNT
FROM
	(
	SELECT
           MFPID1
            ,MFUSER1
            ,MFEV01
            ,MFACTNTYP
            ,MFPDES
            ,MFSRC
            ,MFY57CEV01
            ,MFY57CEV02
            ,MFY57CEV03
            ,MFY57CDT1
            ,MFY57CDT2
            ,MFY57CDT3
            ,MFY57CURA1
            ,MFY57CURA2
            ,MFY57CURA3
            ,MFY57CAMT1
            ,MFY57CAMT2
            ,MFY57CAMT3
            ,MFY57CDL01
            ,MFY57CDL02
            ,MFY57CDL03
            ,MFURRF
            ,MFURCD
            ,MFURAB
            ,MFURAT
            ,MFURDT
            ,MFUSER
            ,MFPID
            ,MFJOBN
            ,MFUPMJ
            ,MFUPMT
        FROM
          F57C1050
        /*BEGIN*/
        WHERE
            /*IF mfpid1 != null*/
            TRIM(MFPID1) = /*mfpid1*/'010015200102'
            /*END*/
            /*IF mfuser1 != null*/
            AND TRIM(MFUSER1) = /*mfuser1*/'31'
            /*END*/
        /*END*/
        ORDER BY
            MFPID1
            ,MFUSER1
	)
