/**
 * 販売単価更新処理群
 * 
 * toms\src\main\jssp\src\toms\sales\detail\update_data.js
 * 
 */

load('toms/common/common');
load('toms/common/cmnUtil');


function init(request) {
	load("toms/common/master");
	
	var entity = createEntity(request);
	// 更新時の検索キーの有効開始日付を変換
	var old_maeftj;
	if (request.oprateFlag == "2" || request.oprateFlag == "3") {
    	var tempOldMaeftj = cmnUtil.getData(request.old_maeftj, 0);
        if (tempOldMaeftj != "")  {
        	old_maeftj = cmnUtil.convertDateToJulia(new Date(tempOldMaeftj));
        }
    }
	var condition = "MALITM = RPAD(?, 25) " +
        		" AND MAMCU = ? " +
        		" AND MALOCN = ? " +
        		" AND MALOTN = ? " +
        		" AND MAAN8 = ? " +
        		" AND MACPGP = RPAD(?, 8) " +
        		" AND MAPRGR = ? " +
        		" AND MAUORG = ? " +
        		" AND MACRCD = ? " +
        		" AND MAEFTJ = ? ";
    var key_maeftj = isBlank(old_maeftj) ? entity['maeftj']: old_maeftj;
    var params = [
        	   DbParameter.string(entity['malitm']),
        	   DbParameter.string(entity['mamcu']),
        	   DbParameter.string(entity['malocn']),
        	   DbParameter.string(entity['malotn']),
        	   DbParameter.number(entity['maan8']),
        	   DbParameter.string(entity['macpgp']),
        	   DbParameter.string(entity['maprgr']),
        	   DbParameter.number(entity['mauorg']),
        	   DbParameter.string(entity['macrcd']),
        	   DbParameter.number(key_maeftj)
             ];

	//------------------------------------
	//新規登録時
	//------------------------------------
	var msg;
	if (request.oprateFlag == "1") {
		//重複チェックの確認

		var result = dbCheck(params);
		if(result.error){
            // SELECTが失敗した場合
        	msg = MessageManager.getMessage('TOMS.COMMON.MAINTENANCE.AJAX.ERROR.INSERT.MESSAGE', MessageManager.getMessage('TOMS.MASTER.MAINTENANCE.SALES.LIST.INPUT.FILENAME'));
        	common.sendErrorResult(msg, "");
		}
		if(result.data[0].cnt !=0){
			// 既に登録済みの場合
        	msg = MessageManager.getMessage('TOMS.COMMON.MAINTENANCE.AJAX.ERROR.INSERT.MESSAGE', MessageManager.getMessage('TOMS.MASTER.MAINTENANCE.SALES.LIST.INPUT.FILENAME'));
        	common.sendErrorResult(msg, MessageManager.getMessage('TOMS.COMMON.MAINTENANCE.AJAX.ERROR.INSERT.NOTNEWDATA.MESSAGE'));
		}
		//登録実行
		result = entry(entity);
        if (result.error) {
            // 処理が失敗した場合
        	msg = MessageManager.getMessage('TOMS.COMMON.MAINTENANCE.AJAX.ERROR.INSERT.MESSAGE', MessageManager.getMessage('TOMS.MASTER.MAINTENANCE.SALES.LIST.INPUT.FILENAME'));
        	common.sendErrorResult(msg, "");
        }

        // 処理が成功した場合
        msg = MessageManager.getMessage('TOMS.COMMON.MAINTENANCE.AJAX.SUCCESS.INSERT.MESSAGE', MessageManager.getMessage('TOMS.MASTER.MAINTENANCE.SALES.LIST.INPUT.FILENAME'));
        common.sendResult(msg,{organization: result.data});

	//------------------------------------
	//更新時
	//------------------------------------
	} else if (request.oprateFlag == "2") {
		var result = update(entity, condition, params);
        if (result.error) {
            // 処理が失敗した場合
        	msg = MessageManager.getMessage('TOMS.COMMON.MAINTENANCE.AJAX.ERROR.UPDATE.MESSAGE', MessageManager.getMessage('TOMS.MASTER.MAINTENANCE.SALES.LIST.INPUT.FILENAME'));
        	common.sendErrorResult(msg, "");
        }
        if (result.countRow != 1) {
            // 対象データが存在しない場合
        	msg = MessageManager.getMessage('TOMS.COMMON.MAINTENANCE.AJAX.ERROR.UPDATE.MESSAGE', MessageManager.getMessage('TOMS.MASTER.MAINTENANCE.SALES.LIST.INPUT.FILENAME'));
        	common.sendErrorResult(msg, MessageManager.getMessage('TOMS.COMMON.MAINTENANCE.AJAX.ERROR.UPDATE.NODATA.MESSAGE'));
        }
        // 処理が成功した場合
         msg = MessageManager.getMessage('TOMS.COMMON.MAINTENANCE.AJAX.SUCCESS.UPDATE.MESSAGE', MessageManager.getMessage('TOMS.MASTER.MAINTENANCE.SALES.LIST.INPUT.FILENAME'));
        common.sendResult(msg,{organization: result.data});
 	//------------------------------------
	//削除時
	//------------------------------------
	} else if (request.oprateFlag == "3") {
		var result = remove(condition, params);
	    if (result.error) {
	        // 処理が失敗した場合
        	msg = MessageManager.getMessage('TOMS.COMMON.MAINTENANCE.AJAX.ERROR.DELETE.MESSAGE', MessageManager.getMessage('TOMS.MASTER.MAINTENANCE.SALES.LIST.INPUT.FILENAME'));
        	common.sendErrorResult(msg, "");
        }
	    if(result.countRow != 1){
	    	// 処理件数が１件でない場合
        	msg = MessageManager.getMessage('TOMS.COMMON.MAINTENANCE.AJAX.ERROR.DELETE.MESSAGE', MessageManager.getMessage('TOMS.MASTER.MAINTENANCE.SALES.LIST.INPUT.FILENAME'));
        	common.sendErrorResult(msg, MessageManager.getMessage('TOMS.COMMON.MAINTENANCE.AJAX.ERROR.UPDATE.NODATA.MESSAGE'));
	    }

	    // 処理が成功した場合
        msg = MessageManager.getMessage('TOMS.COMMON.MAINTENANCE.AJAX.SUCCESS.DELETE.MESSAGE', MessageManager.getMessage('TOMS.MASTER.MAINTENANCE.SALES.LIST.INPUT.FILENAME'));
        common.sendResult(msg,{organization: result.data});
	}
}

function dbCheck(params){
	return TomsMaster.selectFromF57A5010(params);
}

function entry(entity) {
	return TomsMaster.insertToF57A5010(entity);
}

function update(entity, condition, params) {
	return TomsMaster.updateToF57A5010(entity, condition, params);
}
function remove(condition, params) {
	return TomsMaster.removeFromF57A5010(condition, params);
}

function createEntity(request) {
	var userContext = Contexts.getUserContext();
	
	var now = new Date();
	
// 数字のデータ型
	var maitm = null;
	var maan8 = null;
	var mauorg = null;
	var maeftj = null;
	var may57adt1 = null;
	var may57adt2 = null;
	var may57adt3 = null;
	var may57aura1 = null;
	var may57aura2 = null;
	var may57aura3 = null;
	var may57aamt1 = null;
	var may57aamt2 = null;
	var may57aamt3 = null;
	var maurdt = null;
	var maurat = null;
	var maurab = null;
	
	var maupmj = cmnUtil.convertDateToJulia(now);
	var maupmt = cmnUtil.getTime(now);

	// 文字列のデータ型
	var malitm = null;
    var mamcu = null;
    var malocn = null;
    var malotn = null;
    var macpgp = null;
    var maprgr = null;
    var macrcd = null;
    var mauom = null;
    var mauprc = null;
    var maev01 = null;
    var maev02 = null;
    var maev03 = null;
    var may57adl01 = null;
    var may57adl02 = null;
    var may57adl03 = null;
    var maurcd = null;
    var maurrf = null;
    var mauser = userContext.userProfile.userCd;
    var mapid = MessageManager.getMessage('TOMS.COMMON.CONSTANT.PROGRAM.ID');
    var majobn = null;
    
    // 数字設定
    if (cmnUtil.getData(request.maitm, 1) != "")  {
    	maitm = cmnUtil.getData(request.maitm, 1);
    }
    if (cmnUtil.getData(request.maan8, 1) != "")  {
    	maan8 = cmnUtil.getData(request.maan8, 1);
    } else {
    	maan8 = 0;
    }
    if (cmnUtil.getData(request.mauorg, 1) != "")  {
    	mauorg = cmnUtil.getData(request.mauorg, 1);
    } else {
    	//999999999999999
    	mauorg = Number(MessageManager.getMessage('TOMS.COMMON.CONSTANT.THRESHOLD.DEFAULT'));
    }
    var tempMaeftj = cmnUtil.getData(request.maeftj, 0);
    if (tempMaeftj != "")  {
    	maeftj = cmnUtil.convertDateToJulia(new Date(tempMaeftj));
    } else {
    	maeftj = cmnUtil.convertDateToJulia(new Date());
    }
    
    if (cmnUtil.getData(request.mauprc, 1) != "")  {
		mauprc = cmnUtil.getData(request.mauprc, 1) * 10000;
    }
    var tempMay57adt1 = cmnUtil.getData(request.may57adt1, 0);
    if (tempMay57adt1 != "")  {
    	may57adt1 = cmnUtil.convertDateToJulia(new Date(tempMay57adt1));
    }
    var tempMay57adt2 = cmnUtil.getData(request.may57adt2, 0);
    if (tempMay57adt2 != "")  {
    	may57adt1 = cmnUtil.convertDateToJulia(new Date(tempMay57adt2));
    }
    var tempMay57adt3 = cmnUtil.getData(request.may57adt3, 0);
    if (tempMay57adt3 != "")  {
    	may57adt1 = cmnUtil.convertDateToJulia(new Date(tempMay57adt3));
    }
    
    if (cmnUtil.getData(request.may57aura1, 1) != "")  {
    	may57aura1 = cmnUtil.getData(request.may57aura1, 1);
    }
    if (cmnUtil.getData(request.may57aura2, 1) != "")  {
    	may57aura2 = cmnUtil.getData(request.may57aura2, 1);
    }
    if (cmnUtil.getData(request.may57aura3, 1) != "")  {
    	may57aura3 = cmnUtil.getData(request.may57aura3, 1);
    }
    if (cmnUtil.getData(request.may57aamt1, 1) != "")  {
    	may57aamt1 = cmnUtil.getData(request.may57aamt1, 1);
    }
    if (cmnUtil.getData(request.may57aamt2, 1) != "")  {
    	may57aamt2 = cmnUtil.getData(request.may57aamt2, 1);
    }
    if (cmnUtil.getData(request.may57aamt3, 1) != "")  {
    	may57aamt3 = cmnUtil.getData(request.may57aamt3, 1);
    }

	if (cmnUtil.getData(request.malitm, 0) != "")  {
		malitm = cmnUtil.getData(request.malitm, 0);
    } else {
    	malitm = "                         ";
    }
	if (cmnUtil.getData(request.mamcu, 0) != "")  {
		mamcu = cmnUtil.getData(request.mamcu, 0);
    } else {
    	mamcu = "            ";
    }
	if (cmnUtil.getData(request.malocn, 0) != "")  {
		malocn = cmnUtil.getData(request.malocn, 0);
    } else {
    	malocn = "                    ";
    }
	if (cmnUtil.getData(request.malotn, 0) != "")  {
		malotn = cmnUtil.getData(request.malotn, 0);
    } else {
    	malotn = "                              ";
    }
	if (cmnUtil.getData(request.macpgp, 0) != "")  {
		macpgp = cmnUtil.getData(request.macpgp, 0);
    } else {
    	macpgp = "        ";
    }
	if (cmnUtil.getData(request.maprgr, 0) != "")  {
		maprgr = cmnUtil.getData(request.maprgr, 0);
    } else {
    	maprgr = "        ";
    }
	if (cmnUtil.getData(request.macrcd, 0) != "")  {
		macrcd = cmnUtil.getData(request.macrcd, 0);
    } else {
    	//JPY
    	macrcd = MessageManager.getMessage('TOMS.COMMON.CONSTANT.CURRENCY.CODE.DEFAULT');
    }
	if (cmnUtil.getData(request.mauom, 0) != "")  {
		mauom = cmnUtil.getData(request.mauom, 0);
    } else {
    	//PC
    	mauom = MessageManager.getMessage('TOMS.MASTER.MAINTENANCE.SALES.DEFAULT.MAUOM');
    }

	if (cmnUtil.getData(request.maev01, 0) != "")  {
		maev01 = cmnUtil.getData(request.maev01, 0);
    }
	if (cmnUtil.getData(request.maev02, 0) != "")  {
		maev02 = cmnUtil.getData(request.maev02, 0);
    }
	if (cmnUtil.getData(request.maev03, 0) != "")  {
		maev03 = cmnUtil.getData(request.maev03, 0);
    }
	if (cmnUtil.getData(request.may57adl01, 0) != "")  {
		may57adl01 = cmnUtil.getData(request.may57adl01, 0);
    }
	if (cmnUtil.getData(request.may57adl02, 0) != "")  {
		may57adl02 = cmnUtil.getData(request.may57adl02, 0);
    }
	if (cmnUtil.getData(request.may57adl03, 0) != "")  {
		may57adl03 = cmnUtil.getData(request.may57adl03, 0);
    }

    
    var entity = {
                        maitm : maitm,
                        malitm : malitm,
                        mamcu : mamcu,
                        malocn : malocn,
                        malotn : malotn,
                        maan8 : maan8,
                        macpgp : macpgp,
                        maprgr : maprgr,
                        mauorg : mauorg,
                        macrcd : macrcd,
                        mauom : mauom,
                        maeftj : maeftj,
                        mauprc : mauprc,
                        maev01 : maev01,
                        maev02 : maev02,
                        maev03 : maev03,
                        may57adt1 : may57adt1,
                        may57adt2 : may57adt2,
                        may57adt3 : may57adt3,
                        may57aura1 : may57aura1,
                        may57aura2 : may57aura2,
                        may57aura3 : may57aura3,
                        may57aamt1 : may57aamt1,
                        may57aamt2 : may57aamt2,
                        may57aamt3 : may57aamt3,
                        may57adl01 : may57adl01,
                        may57adl02 : may57adl02,
                        may57adl03 : may57adl03,
                        maurcd : maurcd,
                        maurdt : maurdt,
                        maurat : maurat,
                        maurab : maurab,
                        maurrf : maurrf,
                        mauser : mauser,
                        mapid : mapid,
                        majobn : majobn,
                        maupmj : maupmj,
                        maupmt : maupmt
            };
    return entity;
}
