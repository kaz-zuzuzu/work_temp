/**
 * バインド変数.
 */
var $bind = {};

load("toms/common/mastermaintenance");

// 加工部位コード
var processPartCode = MessageManager.getMessage("TOMS.MASTER.MAINTENANCE.PROCESSPART.LABEL.PROCESSPART_CODE");
// 加工位置コード
var processPositionCode = MessageManager.getMessage("TOMS.MASTER.MAINTENANCE.PROCESSPART.LABEL.PROCESSPART_POSITION_CODE");
// 親商品形態コード
var parentCommodityShapeCode = MessageManager.getMessage("TOMS.MASTER.MAINTENANCE.COMMODITYSHAPE.LABEL.PARENT_COMMODITY_SHAPE_CODE");
// 商品形態コード
var commodityShapeCode = MessageManager.getMessage("TOMS.MASTER.MAINTENANCE.COMMODITYSHAPE.LABEL.COMMODITY_SHAPE_CODE");
// 素材コード
var materialCode = MessageManager.getMessage("TOMS.MASTER.MAINTENANCE.MATERIAL.LABEL.MATERIAL_CODE");
// 加工部位名称
var processPartName = MessageManager.getMessage("TOMS.MASTER.MAINTENANCE.PROCESSPART.LABEL.PROCESSPART_NAME");
// 加工位置名称
var processPositionName = MessageManager.getMessage("TOMS.MASTER.MAINTENANCE.PROCESSPART.LABEL.PROCESSPART_POSITION_NAME");
// 表示順_部位
var displayOrderPart = MessageManager.getMessage("TOMS.MASTER.MAINTENANCE.PROCESSPART.LABEL.PROCESSPART_DISPLAY_PART");
// 表示順_位置
var displayOrderPosition = MessageManager.getMessage("TOMS.MASTER.MAINTENANCE.PROCESSPART.LABEL.PROCESSPART_DISPLAY_POSITION");
//// JDEコード_部位
//var jdeCodePart = MessageManager.getMessage("TOMS.MASTER.MAINTENANCE.PROCESSPART.LABEL.PROCESSPART_JDECODE_PART");
//// JDEコード_位置
//var jdeCodePosition = MessageManager.getMessage("TOMS.MASTER.MAINTENANCE.PROCESSPART.LABEL.PROCESSPART_JDECODE_POSITION");
// 運用開始日
var appliedStartDate = MessageManager.getMessage("TOMS.MASTER.MAINTENANCE.COMMODITYSHAPE.LABEL.APPLIED_START_DATE");
// 運用終了日
var appliedEndDate = MessageManager.getMessage("TOMS.MASTER.MAINTENANCE.COMMODITYSHAPE.LABEL.APPLIED_END_DATE");

/**
 * 初期表示.
 * @param request リクエストパラメータ.
 */
function init(request) {

    load("toms/common/csv/CsvUtil");
    load("toms/common/csv/CsvCheker");
    load("toms/common/cmnUtil");

    var response = Web.getHTTPResponse();
    response.setContentType("text/plain; charset=utf-8");
    var csv = []; // csv二次元配列
    var stErr = new java.lang.StringBuilder(); // エラーメッセージ
    var stMsg = new java.lang.StringBuilder(); // 成功メッセージ
    var updateCount = { newCount: 0, updateCount: 0, deleteCount: 0};
    var ret = true;

    // ファイルロード csv二次元ファイル化
    if (!CsvUtil.load2Csv(request, csv, stErr)) {
        doError(response, stErr);
        return;
    }

    // CSVデータ有無チェック
    if (csv.length < 2) {
        // CSVファイルにデータ行が存在しない場合はエラー
        stErr.append(MessageManager.getMessage("TOMS.MASTER.MAINTENANCE.PROCESSPART.LIST.LABEL.MESSAGE.ERROR.CSVNODATA"));
        doError(response, stErr);
        return;
    }

    // CSVデータの行数分繰り返す（先頭行はヘッダ行のため次の行から始める）
    for (var rowPos = 1; rowPos < csv.length; rowPos++) {
        // データチェック
        ret = check(csv[rowPos], rowPos, stErr);
        // DB存在チェック
        if (ret) {
            ret = dbCheck(csv[rowPos], rowPos, stErr);
        }
        // DB更新
        if (ret) {
            ret = dbUpdate(csv[rowPos], rowPos, stErr, updateCount);
        }
    }

    // 正常値の返却
    // 挿入件数
    stMsg.append(MessageManager.getMessage("TOMS.MASTER.MAINTENANCE.PROCESSPART.LIST.LABEL.ENTRYNUM", String(updateCount.newCount)));
    // 更新件数
    stMsg.append(MessageManager.getMessage("TOMS.MASTER.MAINTENANCE.PROCESSPART.LIST.LABEL.UPDATENUM", String(updateCount.updateCount)));
    // 削除件数
    stMsg.append(MessageManager.getMessage("TOMS.MASTER.MAINTENANCE.PROCESSPART.LIST.LABEL.DELETENUM", String(updateCount.deleteCount)));

    var stringErr = stErr.toString();
    var stringMsg = stMsg.toString();
    response.sendMessageBodyString(ImJson.toJSONString([{
        "errorMessage": stringErr,
        "successMessage": stringMsg
    }]));
}

/**
 * チェック
 * @param csvRowData csvの行データ.(IN)
 * @param rowPos 行番号.(IN)
 * @param stErr エラーメッセージパラメータ.(OUT)
 */
function check(csvRowData, rowPos, stErr) {
    var ret = true;

    var ope = csvRowData[0];
    var sRowPos = String(rowPos);
    var cellPos = null;

    // 列数チェック
    var columnCnt = 12;
    if (csvRowData.length != columnCnt) {
        if (csvRowData.length > columnCnt) {
            stErr.append(MessageManager.getMessage("TOMS.MASTER.MAINTENANCE.PROCESSPART.LIST.LABEL.MESSAGE.ERROR.COLUMN1",sRowPos));
        } else if (csvRowData.length < columnCnt) {
            stErr.append(MessageManager.getMessage("TOMS.MASTER.MAINTENANCE.PROCESSPART.LIST.LABEL.MESSAGE.ERROR.COLUMN2",sRowPos));
        }
        ret = false;
        return ret;
    }

    // --------------------
    //  0 更新区分
    // --------------------
    // データチェック
    if (isBlank(ope)) {
        stErr.append(MessageManager.getMessage("TOMS.MASTER.MAINTENANCE.PROCESSPART.LIST.LABEL.MESSAGE.ERROR.UPDATEDIVISION", sRowPos));
        ret = false;
    }    
    if (ope != "I" && ope != "U" && ope != "D") {
        stErr.append(MessageManager.getMessage("TOMS.MASTER.MAINTENANCE.MATERIAL.LIST.LABEL.MESSAGE.ERROR.UPDATEDIVISION_FORMAT", sRowPos));
        ret = false;
    }
    // --------------------
    //  1 加工部位コード
    // --------------------
    cellPos = 1;
    // 必須チェック
    if (!CsvCheker.required(csvRowData[cellPos], rowPos, cellPos, processPartCode, stErr)) {
        ret = false;
    } else {
        // 挿入、更新の場合
        if (ope == "I" || ope == "U") {
            // 半角英数字チェック
            if (!CsvCheker.isAlphanumeric(csvRowData[cellPos], rowPos, cellPos, processPartCode, stErr)) {
                ret = false;
            }
            // 文字数チェック
            if (!CsvCheker.maxLength(csvRowData[cellPos], 16, rowPos, cellPos, processPartCode, stErr)) {
                ret = false;
            }
        }
    }
    // --------------------
    //  2 加工位置コード
    // --------------------
    cellPos = 2;
    // 必須チェック
    if (!CsvCheker.required(csvRowData[cellPos], rowPos, cellPos, processPositionCode, stErr)) {
        ret = false;
    } else {
        // 挿入、更新の場合
        if (ope == "I" || ope == "U") {
            // 半角英数字チェック
            if (!CsvCheker.isAlphanumeric(csvRowData[cellPos], rowPos, cellPos, processPositionCode, stErr)) {
                ret = false;
            }
            // 文字数チェック
            if (!CsvCheker.maxLength(csvRowData[cellPos], 16, rowPos, cellPos, processPositionCode, stErr)) {
                ret = false;
            }
        }
    }
    // --------------------
    //  3 親商品形態コード
    // --------------------
     cellPos = 3;
   // 必須チェック
    if (!CsvCheker.required(csvRowData[cellPos], rowPos, cellPos, parentCommodityShapeCode, stErr)) {
        ret = false;
    } else {
        // 挿入、更新の場合
        if (ope == "I" || ope == "U") {
            // 半角英数字チェック
            if (!CsvCheker.isAlphanumeric(csvRowData[cellPos], rowPos, cellPos, parentCommodityShapeCode, stErr)) {
                ret = false;
            }
            // 文字数チェック
            if (!CsvCheker.maxLength(csvRowData[cellPos], 16, rowPos, cellPos, parentCommodityShapeCode, stErr)) {
                ret = false;
            }
            // 親商品形態コードチェック
            if (!CsvCheker.isParentCommodityPrefix(csvRowData[cellPos],rowPos, cellPos, parentCommodityShapeCode, stErr)) {
                ret = false;
            }
        }
    }
    // --------------------
    //  4 商品形態コード
    // --------------------
    cellPos = 4;
    // 必須チェック
    if (!CsvCheker.required(csvRowData[cellPos], rowPos, cellPos, commodityShapeCode, stErr)) {
        ret = false;
    } else {
        // 挿入、更新の場合
        if (ope == "I" || ope == "U") {
            // 半角英数字チェック
            if (!CsvCheker.isAlphanumeric(csvRowData[cellPos], rowPos, cellPos, commodityShapeCode, stErr)) {
                ret = false;
            }
            // 文字数チェック
            if (!CsvCheker.maxLength(csvRowData[cellPos], 16, rowPos, cellPos, commodityShapeCode, stErr)) {
                ret = false;
            }
            // 商品形態コードチェック
            if (!CsvCheker.isCommodityPrefix(csvRowData[cellPos], rowPos, cellPos, commodityShapeCode, stErr)) {
                ret = false;
            }
        }
    }
    // --------------------
    //  5 素材コード
    // --------------------
    cellPos = 5;
    // 必須チェック
    if (!CsvCheker.required(csvRowData[cellPos], rowPos, cellPos, materialCode, stErr)) {
        ret = false;
    } else {
        // 挿入、更新の場合
        if (ope == "I" || ope == "U") {
            // 半角英数字チェック
            if (!CsvCheker.isAlphanumeric(csvRowData[cellPos], rowPos, cellPos, materialCode, stErr)) {
                ret = false;
            }
            // 文字数チェック
            if (!CsvCheker.maxLength(csvRowData[cellPos], 16, rowPos, cellPos, materialCode, stErr)) {
                ret = false;
            }
        }
    }
    // --------------------
    //  6 加工部位名称
    // --------------------
    cellPos = 6;
    // 挿入、更新の場合
    if (ope == "I" || ope == "U") {
        // 必須チェック
        if (!CsvCheker.required(csvRowData[cellPos], rowPos, cellPos, processPartName, stErr)) {
            ret = false;
        } else {
            // 文字数チェック
            if (!CsvCheker.maxLength(csvRowData[cellPos], 30, rowPos, cellPos, processPartName, stErr)) {
                ret = false;
            }
        }
    }
    // --------------------
    //  7 加工位置名称
    // --------------------
    cellPos = 7;
    // 挿入、更新の場合
    if (ope == "I" || ope == "U") {
        // 必須チェック　加工位置コードが99以外の場合、必須
    	if(csvRowData[2] !='P2999' && isBlank(csvRowData[cellPos])){
            stErr.append(MessageManager.getMessage("TOMS.MASTER.MAINTENANCE.PROCESSPART.LIST.LABEL.MESSAGE.ERROR.POSITION_P2999.NOEREQUIRE", sRowPos));
    		ret = false;
//    	}
//        if (!CsvCheker.required(csvRowData[cellPos], rowPos, cellPos, processPositionName, stErr)) {
//            ret = false;
        } else {
            // 文字数チェック
            if (!CsvCheker.maxLength(csvRowData[cellPos], 30, rowPos, cellPos, processPositionName, stErr)) {
                ret = false;
            }
        }
    }
    // --------------------
    //  8 表示順_部位
    // --------------------
    cellPos = 8;
    // 挿入、更新の場合
    if (ope == "I" || ope == "U") {
        // 半角数値チェック
        if (!CsvCheker.isNum(csvRowData[cellPos], rowPos, cellPos, displayOrderPart, stErr)) {
            ret = false;
        }
        // 桁数チェック
        if (!CsvCheker.maxLength(csvRowData[cellPos], 8, rowPos, cellPos, displayOrderPart, stErr)) {
            ret = false;
        }
    }
    // --------------------
    //  9 表示順_位置
    // --------------------
    cellPos = 9;
    // 挿入、更新の場合
    if (ope == "I" || ope == "U") {
        // 半角数値チェック
        if (!CsvCheker.isNum(csvRowData[cellPos], rowPos, cellPos, displayOrderPosition, stErr)) {
            ret = false;
        }
        // 桁数チェック
        if (!CsvCheker.maxLength(csvRowData[cellPos], 8, rowPos, cellPos, displayOrderPosition, stErr)) {
            ret = false;
        }
    }
    // --------------------
    //  10 JDEコード_部位
    // --------------------
//    cellPos = 10;
//    // 挿入、更新の場合
//    if (ope == "I" || ope == "U") {
//        // 必須チェック
//        if (!CsvCheker.required(csvRowData[cellPos], rowPos, cellPos, jdeCodePart, stErr)) {
//            ret = false;
//        } else {
//            // 半角英数字チェック
//            if (!CsvCheker.isAlphanumeric(csvRowData[cellPos], rowPos, cellPos, jdeCodePart, stErr)) {
//                ret = false;
//            }
//            // 文字数チェック
//            if (!CsvCheker.maxLength(csvRowData[cellPos], 8, rowPos, cellPos, jdeCodePart, stErr)) {
//                ret = false;
//            }
//        }
//    }
    // --------------------
    //  11 JDEコード_位置
    // --------------------
//    cellPos = 11;
//    // 挿入、更新の場合
//    if (ope == "I" || ope == "U") {
//        // 必須チェック
//        if (!CsvCheker.required(csvRowData[cellPos], rowPos, cellPos, jdeCodePosition, stErr)) {
//            ret = false;
//        } else {
//            // 半角英数字チェック
//            if (!CsvCheker.isAlphanumeric(csvRowData[cellPos], rowPos, cellPos, jdeCodePosition, stErr)) {
//                ret = false;
//            }
//            // 文字数チェック
//            if (!CsvCheker.maxLength(csvRowData[cellPos], 8, rowPos, cellPos, jdeCodePosition, stErr)) {
//                ret = false;
//            }
//        }
//    }
    // --------------------
    //  10 運用開始日
    // --------------------
    cellPos = 10;
    // 必須チェック
    if (!CsvCheker.required(csvRowData[cellPos], rowPos, cellPos, appliedStartDate, stErr)) {
        ret = false;
    } else {
        // 挿入、更新の場合
        if (ope == "I" || ope == "U") {
            // 日付チェック
            if (!CsvCheker.isDate(csvRowData[cellPos], rowPos, cellPos, appliedStartDate, stErr)) {
                ret = false;
            }
        }
    }
    // --------------------
    //  11 削除フラグ
    // --------------------
    cellPos = 11;
    // 挿入の場合
    if (ope == "I") {
        // データチェック
        if (csvRowData[cellPos] != "0") {
            stErr.append(MessageManager.getMessage("TOMS.MASTER.MAINTENANCE.PROCESSPART.LIST.LABEL.MESSAGE.ERROR.DEL_FLAG", sRowPos));
            ret = false;
        }
    }
    // 挿入、更新の場合
    else if (ope == "I" || ope == "U") {
        // データチェック
        if (csvRowData[cellPos] != "0" && csvRowData[cellPos] != "1") {
            stErr.append(MessageManager.getMessage("TOMS.MASTER.MAINTENANCE.MATERIAL.LIST.LABEL.MESSAGE.ERROR.DEL_FLAG_FORMAT", sRowPos));
            ret = false;
        }
    }

    return ret;
}

/*
 * DBによるデータ有無チェック
 * @param csvRowData csvの行データ.(IN)
 * @param rowPos 行番号.(IN)
 * @param stErr エラーメッセージパラメータ.(OUT)
 */
function dbCheck(csvRowData, rowPos, stErr) {
    var ret = true;
    var ope = csvRowData[0];
    var sRowPos = String(rowPos);
    var cellPos = null;

    // 加工部位マスタのキー検索（加工部位コード、加工位置コード、親商品形態コード、商品形態コード、素材コード、適用開始日）
    var resultProcessPart = MasterMain.getProcessPartByPk(csvRowData[1], csvRowData[2], csvRowData[3], csvRowData[4], csvRowData[5], csvRowData[10]);

    // 挿入の場合
    if (ope == "I" || ope == "U") {
        // 加工部位コードの内部コードチェック
        cellPos = 1;
        var resultProcessPartCd = MasterMain.checkCodeMaster("04", "01", csvRowData[cellPos]);
        if (resultProcessPartCd.countRow == 0) {
            // 存在しない場合
            stErr.append(MessageManager.getMessage("TOMS.MASTER.MAINTENANCE.PROCESSPART.LIST.LABEL.MESSAGE.ERROR.CODEMASTER.NOTINLINE", sRowPos, String(cellPos + 1), processPartCode));
            ret = false;
        }
        // 加工位置コードの内部コードチェック
        cellPos = 2;
        var resultProcessPositionCd = MasterMain.checkCodeMaster("05", "01", csvRowData[cellPos]);
        if (resultProcessPositionCd.countRow == 0) {
            // 存在しない場合
            stErr.append(MessageManager.getMessage("TOMS.MASTER.MAINTENANCE.PROCESSPART.LIST.LABEL.MESSAGE.ERROR.CODEMASTER.NOTINLINE", sRowPos, String(cellPos + 1), processPositionCode));
            ret = false;
        }
        //親商品形態コードの内部コードチェック
        cellPos = 3;
        var result = MasterMain.checkCodeMaster("01", "01", csvRowData[cellPos]);
        if (result.countRow == 0) {
            // 存在しない場合
            stErr.append(MessageManager.getMessage("TOMS.MASTER.MAINTENANCE.PROCESSPART.LIST.LABEL.MESSAGE.ERROR.CODEMASTER.NOTINLINE", sRowPos, String(cellPos + 1), parentCommodityShapeCode));
            ret = false;
        }        
        
        //商品形態コードの内部コードチェック
        cellPos = 4;
         result = MasterMain.checkCodeMaster("02", "01", csvRowData[cellPos]);
        if (result.countRow == 0) {
            // 存在しない場合
            stErr.append(MessageManager.getMessage("TOMS.MASTER.MAINTENANCE.PROCESSPART.LIST.LABEL.MESSAGE.ERROR.CODEMASTER.NOTINLINE", sRowPos, String(cellPos + 1), commodityShapeCode));
            ret = false;
        }        
        //素材コードの内部コードチェック
        cellPos = 5;
         result = MasterMain.checkCodeMaster("03", "01", csvRowData[cellPos]);
        if (result.countRow == 0) {
            // 存在しない場合
            stErr.append(MessageManager.getMessage("TOMS.MASTER.MAINTENANCE.PROCESSPART.LIST.LABEL.MESSAGE.ERROR.CODEMASTER.NOTINLINE", sRowPos, String(cellPos + 1), materialCode));
            ret = false;
        }        
//        // JDEコード_部位の内部コードチェック
//        cellPos = 10;
//        var resultJdeCdPart = MasterMain.checkCodeMaster("04", "02", csvRowData[cellPos]);
//        if (resultJdeCdPart.countRow == 0) {
//            // 存在しない場合
//            stErr.append(MessageManager.getMessage("TOMS.MASTER.MAINTENANCE.PROCESSPART.LIST.LABEL.MESSAGE.ERROR.CODEMASTER.NOTINLINE", sRowPos, String(cellPos + 1), jdeCodePart));
//            ret = false;
//        }
//        // JDEコード_位置の内部コードチェック
//        cellPos = 11;
//        var resultJdeCdPosition = MasterMain.checkCodeMaster("05", "02", csvRowData[cellPos]);
//        if (resultJdeCdPosition.countRow == 0) {
//            // 存在しない場合
//            stErr.append(MessageManager.getMessage("TOMS.MASTER.MAINTENANCE.PROCESSPART.LIST.LABEL.MESSAGE.ERROR.CODEMASTER.NOTINLINE", sRowPos, String(cellPos + 1), jdeCodePosition));
//            ret = false;
//        }

        

        // 親商品形態コード、商品形態コード、素材コードの存在チェック
        var resultMaterial = MasterMain.getMaterial(csvRowData[5],csvRowData[3], csvRowData[4]);
        if (resultMaterial.countRow == 0) {
            // 存在しない場合
            stErr.append(MessageManager.getMessage("TOMS.MASTER.MAINTENANCE.PROCESSPART.LIST.LABEL.MESSAGE.ERROR.DATANOTEXIST.MATERIAL", sRowPos, csvRowData[5].trim(), csvRowData[3].trim(), csvRowData[4].trim()));
            ret = false;
        }
        
    }
    if(ope=="I"){
        // 加工部位マスタの存在チェック
        if (resultProcessPart.countRow > 0) {
            stErr.append(MessageManager.getMessage("TOMS.MASTER.MAINTENANCE.PROCESSPART.LIST.LABEL.MESSAGE.ERROR.DATAEXIST", sRowPos, csvRowData[1].trim(), csvRowData[2].trim(), csvRowData[3].trim(), csvRowData[4].trim(), csvRowData[5].trim(), csvRowData[10].trim()));
            ret = false;
        }    	
    } else {
        // 更新、削除の場合
        // 存在チェック
        if (resultProcessPart.countRow < 1) {
            stErr.append(MessageManager.getMessage("TOMS.MASTER.MAINTENANCE.PROCESSPART.LIST.LABEL.MESSAGE.ERROR.DATANOTEXIST", sRowPos, csvRowData[1].trim(), csvRowData[2].trim(), csvRowData[3].trim(), csvRowData[4].trim(), csvRowData[5].trim(), csvRowData[10].trim()));
            ret = false;
        }
        // 複数存在チェック
        if (resultProcessPart.countRow > 1) {
            stErr.append(MessageManager.getMessage("TOMS.MASTER.MAINTENANCE.PROCESSPART.LIST.LABEL.MESSAGE.ERROR.DUPLICATE", sRowPos, csvRowData[1].trim(), csvRowData[2].trim(), csvRowData[3].trim(), csvRowData[4].trim(), csvRowData[5].trim(), csvRowData[10].trim()));
            ret = false;
        }
    }

    return ret;
}

/**
 * DB更新
 * 
 * @param csvRowData csvの行データ.(IN)
 * @param rowPos 行番号.(IN)
 * @param stErr エラーメッセージパラメータ.(OUT)
 * @param updateCount (OUT)
 */
function dbUpdate(csvRowData, rowPos, stErr, counts) {

    var ret = true;
    var newCount = counts.newCount;
    var updateCount = counts.updateCount;
    var deleteCount = counts.deleteCount;

    var ope = csvRowData[0];
    var sRowPos = String(rowPos);
    var result;

    // CSVの行データからDB更新用データ作成
    var entity = createEntity(csvRowData);
    var condition = "TRIM(mky57appc1) = ? "
                  + " AND TRIM(mky57appc2) = ? "
                  + " AND TRIM(mky57apcsc) = ? "
                  + " AND TRIM(mky57acsc) = ? "
                  + " AND TRIM(mky57amtc) = ? "
                  + " AND mkeftj = ? ";
    var params = [
            DbParameter.string(entity["mky57appc1"]),
            DbParameter.string(entity["mky57appc2"]),
            DbParameter.string(entity["mky57apcsc"]),
            DbParameter.string(entity["mky57acsc"]),
            DbParameter.string(entity["mky57amtc"]),
            DbParameter.number(entity["mkeftj"])
    ];

    Transaction.begin();
    var masterTable = 'F57A5120';
    if (ope == "I") {           //挿入
        result = MasterMain.insertToMasterTable(masterTable, entity);
        newCount++;
    } else if (ope =="U") {     //更新
        result = MasterMain.updateToMasterTable(masterTable, entity, condition, params);
        updateCount++;
    } else if  (ope =="D") {    //削除
        result = MasterMain.removeFromMasterTable(masterTable, condition, params);
        deleteCount++;
    }
    if (!result.error && result.countRow != 1) {
        Transaction.rollback();
        stErr.append(MessageManager.getMessage("TOMS.MASTER.MAINTENANCE.PROCESSPART.LIST.LABEL.MESSAGE.ERROR.ABNORMAL", sRowPos));
        return false;
    }
    if (result.error) {
        Transaction.rollback();
        stErr.append(MessageManager.getMessage("TOMS.MASTER.MAINTENANCE.PROCESSPART.LIST.LABEL.MESSAGE.ERROR.DB"));
        stErr.append(MessageManager.getMessage("TOMS.MASTER.MAINTENANCE.PROCESSPART.LIST.LABEL.MESSAGE.CSVLINE", sRowPos));
        return false;
    }
    Transaction.commit();

    counts.newCount = newCount;
    counts.updateCount = updateCount;
    counts.deleteCount = deleteCount;

    return true;
}

/**
 * DB更新用データ作成
 * 
 * @param csvRowData csvの行データ.
 */
function createEntity(csvRowData) {

    var userContext = Contexts.getUserContext();
    var now = new Date();

    // 変数初期化
    var mky57appc1 = null;	// 加工部位コード
    var mky57appc2 = null;	// 加工位置コード
    var mky57apcsc = null;	// 親商品形態コード
    var mky57acsc = null;	// 商品形態コード
    var mky57amtc = null;	// 素材コード
    var mkdl01 = null;		// 加工部位名称
    var mkdl02 = null;		// 加工位置名称
    var mky57adop1 = null;	// 表示順_部位
    var mky57adop2 = null;	// 表示順_位置
    var mky57ajcp1 = null;	// JDEコード_部位
    var mky57ajcp2 = null;	// JDEコード_位置
    var mkeftj = null;		// 適用開始日
    var mkexdj = cmnUtil.convertDateToJulia(new Date(MessageManager.getMessage("TOMS.COMMON.CONSTANT.ENDDATE")));    // 適用終了日
    var mky57adflg = null;	// 削除フラグ

    var mkuser = userContext.userProfile.userCd;     // ユーザID
    var mkpid = MessageManager.getMessage("TOMS.COMMON.CONSTANT.PROGRAM.ID");    // プログラムID
    var mkupmj = cmnUtil.convertDateToJulia(now);    // 更新日付
    var mkupmt = cmnUtil.getTime(now);               // 更新時刻

    // 加工部位コード
    if (!isBlank(cmnUtil.getData(csvRowData[1], 0))) {
        mky57appc1 = cmnUtil.getData(csvRowData[1], 0);
    }
    // 加工位置コード
    if(!isBlank(cmnUtil.getData(csvRowData[2], 0))){
        mky57appc2 = cmnUtil.getData(csvRowData[2], 0);
    }
    // 親商品形態コード
    if (!isBlank(cmnUtil.getData(csvRowData[3], 0))) {
        mky57apcsc = cmnUtil.getData(csvRowData[3], 0);
    }
    // 商品形態コード
    if (!isBlank(cmnUtil.getData(csvRowData[4], 0))) {
        mky57acsc = cmnUtil.getData(csvRowData[4], 0);
    }
    // 素材コード
    if (!isBlank(cmnUtil.getData(csvRowData[5], 0))) {
        mky57amtc = cmnUtil.getData(csvRowData[5], 0);
    }
    // 加工部位名称
    if (!isBlank(cmnUtil.getData(csvRowData[6], 0))) {
        mkdl01 = cmnUtil.getData(csvRowData[6], 0);
    }
    // 加工位置名称
    if (!isBlank(cmnUtil.getData(csvRowData[7], 0))) {
        mkdl02 = cmnUtil.getData(csvRowData[7], 0);
    }
	if(mky57appc2=="P2999" && isBlank(mkdl02)){
		//加工位置コードが99で加工位置名称がblankの場合、全角スペースをセットする
		mkdl02 ="　";
	}

// 表示順_部位
    if(!isBlank(cmnUtil.getData(csvRowData[8], 1))){
        mky57adop1 = cmnUtil.getData(csvRowData[8], 1);
    }
    // 表示順_位置
    if(!isBlank(cmnUtil.getData(csvRowData[9], 1))){
        mky57adop2 = cmnUtil.getData(csvRowData[9], 1);
    }
//    // JDEコード_部位
//    if(!isBlank(cmnUtil.getData(csvRowData[10], 0))){
//        mky57ajcp1 = cmnUtil.getData(csvRowData[10], 0);
//    }
//    // JDEコード_位置
//    if(!isBlank(cmnUtil.getData(csvRowData[11], 0))){
//        mky57ajcp2 = cmnUtil.getData(csvRowData[11], 0);
//    }
    // 適用開始日
    if(!isBlank(csvRowData[10])){
        mkeftj = cmnUtil.convertDateToJulia(new Date(csvRowData[10]));
    }
    // 削除フラグ
    if(!isBlank(cmnUtil.getData(csvRowData[11], 1))){
        mky57adflg = cmnUtil.getData(csvRowData[11], 1);
    }

    var entity = {
        mky57appc1 : mky57appc1,
        mky57appc2 : mky57appc2,
        mky57apcsc : mky57apcsc,
        mky57acsc : mky57acsc,
        mky57amtc : mky57amtc,
        mkdl01 : mkdl01,
        mkdl02 : mkdl02,
        mky57adop1 : mky57adop1,
        mky57adop2 : mky57adop2,
//    	mky57ajcp1 : mky57ajcp1,
//    	mky57ajcp2 : mky57ajcp2,
        mky57ajcp1 : "　",
        mky57ajcp2 : "　",
        mkeftj : mkeftj,
        mkexdj : mkexdj,
        mky57adflg : mky57adflg,
        mkuser : mkuser,
        mkpid : mkpid,
        mkupmj : mkupmj,
        mkupmt : mkupmt 
    };

    return entity;
}

/**
 * エラー処理
 * 
 * @param response　レスポンス
 * @param stErr エラーメッセージパラメータ.
 */
function doError(response, stErr) {
        stErr.insert(0, MessageManager.getMessage("TOMS.MASTER.MAINTENANCE.PROCESSPART.LIST.LABEL.ENTRY.ERROR"));
        var stringErr = stErr.toString();
        response.sendMessageBodyString(ImJson.toJSONString([{
            "errorMessage": stringErr,
            "successMessage": ""
        }]));
}
