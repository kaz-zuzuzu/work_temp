SELECT
    *
FROM
(
    SELECT
        base.*
      , ROWNUM AS RN
    FROM
    (
        SELECT DISTINCT
            TRIM(IM.IMITM) AS IMITM
            ,TRIM(IM.IMLITM) AS IMLITM
            ,TRIM(IM.IMDSC1) AS IMDSC1
            ,TRIM(IM.IMDSC2) AS IMDSC2
        FROM
            F4101 IM INNER JOIN F4016 TU
            ON IM.IMITM = TU.TUITM
            AND TU.TUEFTJ <= FC_JDI9902_TO_JULIAN(SYSDATE)
            AND TU.TUEXDJ >= FC_JDI9902_TO_JULIAN(SYSDATE)
        WHERE
            TRIM(IM.IMLITM) LIKE '05S01%'
        /*IF imlitm != null*/
            AND TRIM(IM.IMLITM) = /*imlitm*/'TISTS01'
            /*END*/
            /*IF imdsc1 != null*/
            AND TRIM(IM.IMDSC1) like /*imdsc1*/'%TEST%'
            /*END*/
            /*IF imdsc2 != null*/
            AND TRIM(IM.IMDSC2) like /*imdsc2*/'%TEST%'
            /*END*/
        ORDER BY
            IMITM
    ) base
     /*IF end != null*/
        WHERE ROWNUM <= /*end*/'10' 
     /*END*/
)
/*IF start != null*/
WHERE RN >= /*start*/'1' 
/*END*/