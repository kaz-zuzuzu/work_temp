SELECT 
 *
FROM
 (
SELECT
  TRIM(MKY57APPC1) AS MKY57APPC1
  , TRIM(MKY57APPC2) AS MKY57APPC2
  , TRIM(MKY57APCSC) AS MKY57APCSC
  , TRIM(MKY57ACSC) AS MKY57ACSC
  , TRIM(MKY57AMTC) AS MKY57AMTC
  , TRIM(MKDL01) AS MKDL01
  , NVL(TRIM(MKDL02), ' ') AS MKDL02
  , MKY57ADOP1
  , MKY57ADOP2
  , TRIM(MKY57AJCP1) AS MKY57AJCP1
  , TRIM(MKY57AJCP2) AS MKY57AJCP2
  ,TO_CHAR(FC_JDI9902_TO_DATE(MKEFTJ), 'YYYY/MM/DD') AS MKEFTJ
  ,TO_CHAR(FC_JDI9902_TO_DATE(MKEXDJ), 'YYYY/MM/DD') AS MKEXDJ
  , MKY57ADFLG
  , MKURCD
  , MKURDT
  , MKURAT
  , MKURAB
  , MKURRF
  , TRIM(MKUSER) AS MKUSER
  , TRIM(MKPID) AS MKPID
  , MKJOBN
  ,TO_CHAR(FC_JDI9902_TO_DATE(MKUPMJ), 'YYYY/MM/DD') AS MKUPMJ
  , MKUPMT 
  , ROWNUM AS RN
FROM
(
SELECT
  MKY57APPC1
  , MKY57APPC2
  , MKY57APCSC
  , MKY57ACSC
  , MKY57AMTC
  , MKDL01
  , MKDL02
  , MKY57ADOP1
  , MKY57ADOP2
  , MKY57AJCP1
  , MKY57AJCP2
  , MKEFTJ
  , MKEXDJ
  , MKY57ADFLG
  , MKURCD
  , MKURDT
  , MKURAT
  , MKURAB
  , MKURRF
  , MKUSER
  , MKPID
  , MKJOBN
  , MKUPMJ
  , MKUPMT 
FROM
  F57A5120 
/*BEGIN*/
WHERE
	/*IF mky57appc1 !=null */
  AND TRIM(MKY57APPC1) = /*mky57appc1*/''
	/*END*/
	/*IF mky57appc2 !=null */
  AND TRIM(MKY57APPC2) = /*mky57appc2*/''
	/*END*/
	/*IF mky57apcsc !=null */
  AND TRIM(MKY57APCSC) = /*mky57apcsc*/''
	/*END*/
	/*IF mky57acsc !=null */
  AND TRIM(MKY57ACSC) = /*mky57acsc*/''
	/*END*/
	/*IF mky57amtc !=null */
  AND TRIM(MKY57AMTC) = /*mky57amtc*/''
	/*END*/
	/*IF mkdl01 !=null */
  AND MKDL01 LIKE /*mkdl01*/''
	/*END*/
	/*IF mkdl02 !=null */
  AND MKDL02 LIKE /*mkdl02*/''
	/*END*/

	/*IF mky57adop1 !=null */
  AND TRIM(MKY57ADOP1) = /*mky57adop1*/''
	/*END*/
	/*IF mky57adop2 !=null */
  AND TRIM(MKY57ADOP2) = /*mky57adop2*/''
	/*END*/
	/*IF mky57ajcp1 !=null */
  AND TRIM(MKY57AJCP1) = /*mky57ajcp1*/''
	/*END*/
	/*IF mky57ajcp2 !=null */
  AND TRIM(MKY57AJCP2) = /*mky57ajcp2*/''
	/*END*/

	/*IF mkeftj !=null */
  AND MKEFTJ >= /*mkeftj*/''
	/*END*/
	/*IF mkeftj2 !=null */
  AND MKEFTJ <= /*mkeftj2*/''
	/*END*/
	/*IF mky57adflg !=null */
  AND MKY57ADFLG = /*mky57adflg*/''
	/*END*/
/*END*/
ORDER BY
  MKY57APPC1
  , MKY57APPC2
  , MKY57APCSC
  , MKY57ACSC
  , MKY57AMTC
  , MKEFTJ DESC
 ) base 
     /*IF end != null*/
        WHERE ROWNUM <= /*end*/'30' 
     /*END*/
)
/*IF start != null*/
WHERE RN >= /*start*/'1' 
/*END*/
