SELECT DISTINCT
    BASE_QR.IMLITM                               AS IMLITM --品目No
    , BASE_QR.IMDSC1                            AS IMDSC1 --記述１
    , BASE_QR.DRDL01_CL                      AS DRDL01_CL --カラー名
    , BASE_QR.IMLITM_S                         AS IMLITM_S --サイズコード
    , IF.IFAQTY      AS LIPQOH --在庫数量
FROM
(
SELECT        
      NVL(IMBASE.IMLITM,TQP.TQY57BLITM)                   AS IMLITM --品目No
      ,NVL(IMBASE.IMITM,TQP.TQP_IMITM)                    AS IMITM
      ,NVL(IMBASE.IMDSC1,TQP.TQP_IMDSC1)                  AS IMDSC1 --記述１
      ,NVL(IMBASE.DRDL01_CL,TQP.TQP_DRDL01_CL)            AS DRDL01_CL --カラー名
      ,NVL(IMBASE.IMLITM_S,TQP.TQP_IMLITM_S)              AS IMLITM_S --サイズコード
      ,NVL(IMBASE.LIPQOH,0)                               AS LIPQOH --在庫数量
      ,FC_JDI9902_TO_JULIAN(MIN(TQP.TPY57BRDD1))          AS TPY57BRDD1 --直近入荷予定日
FROM 
    (
        SELECT
              IM.IMLITM                                 AS IMLITM --品目No
              , IM.IMITM                                 AS IMITM
              , TRIM(IM.IMDSC1)                   AS IMDSC1 --記述１
              , TRIM(DR_CL.DRDL01)            AS DRDL01_CL --カラー名
              , SUBSTR(IM.IMLITM, 11, 2)     AS IMLITM_S --サイズコード
              , SUM(LI.LIPQOH)                      AS LIPQOH --在庫数量
        FROM
               -- 【トランザクションテーブル】 ---------------------
               F41021 LI --品目保管場所
               INNER JOIN F4100 LM --ロケーションマスタ
                   ON LI.LIMCU   = LM.LMMCU
                   AND LI.LILOCN  = LM.LMLOCN
               -------- 別注品購買業者、商品名、商品略名、商品分類1・2
               INNER JOIN F4101 IM --品目マスタ
                   ON LI.LIITM = IM.IMITM
                   -- 廃番フラグ(カテゴリ・コード7)が'1'のデータは表示しない
                   AND IM.IMSRP7 <> '1'
               -------- カラー名 -----------------------------
               LEFT OUTER JOIN F0005 DR_CL
                   ON TRIM(SUBSTR(IM.IMLITM, 8, 3)) = TRIM(DR_CL.DRKY)
                   AND DR_CL.DRSY                = '41F '
                   AND DR_CL.DRRT                = DECODE(TRIM(SUBSTR(IM.IMLITM, 1, 2)), '01', '1C', '2C')
        WHERE
            SUBSTR(IM.IMLITM, 11, 2) IS NOT NULL
        /*IF stockPositionCode != null*/
            AND LI.LIMCU = LPAD(/*stockPositionCode*/'1000', 12)
        /*END*/
        /*IF stockCode == "3000" */
            AND SUBSTR(IM.IMLITM, 11, 2) <> '  '
        /*END*/
        /*IF storePositionCode != null*/
            AND DECODE(LENGTH(TRIM(LI.LILOCN)), 15, SUBSTR(LI.LILOCN, 1, 3), TRIM(LI.LILOCN)) = /*storePositionCode*/'001'
        /*END*/
        /*IF stockCode != "1000" && storePositionCode == null && stockCategory != null*/
            AND LM.LMBIN = RPAD(/*stockCategory*/'900', 8)
        /*END*/
        /*IF stockCode == "1000" && storePositionCode == null*/
            AND (DECODE(LENGTH(TRIM(LI.LILOCN)), 15, SUBSTR(TRIM(LI.LILOCN), 1, 3), TRIM(LI.LILOCN)) <> '200'
                OR DECODE(LENGTH(TRIM(LI.LILOCN)), 15, SUBSTR(TRIM(LI.LILOCN), 1, 3), TRIM(LI.LILOCN)) <> '201'
                OR DECODE(LENGTH(TRIM(LI.LILOCN)), 15, SUBSTR(TRIM(LI.LILOCN), 1, 3), TRIM(LI.LILOCN)) <> '202')
        /*END*/
        /*IF stockCode != "1000" && storePositionCode == null && stockCategory != null*/
            AND LM.LMBIN = RPAD(/*stockCategory*/'900', 8)
        /*END*/
        /*IF stockCode == "1000" && storePositionCode == null && stockCategory == null*/
            AND LM.LMKZON = RPAD('1', 6)
        /*END*/
        /*IF stockCode == "1000" && storePositionCode == null && stockCategory != null*/
            AND LM.LMKZON <> RPAD('1', 6)
            AND LM.LMBIN = RPAD(/*stockCategory*/'900', 8)
        /*END*/
        /*IF manufacturerCode != null*/
            AND SUBSTR(IM.IMLITM, 1, 2) = /*manufacturerCode*/'01'
        /*END*/
        /*IF productCodes != null*/
            AND SUBSTR(IM.IMLITM, 3, 5) in /*productCodes*/('00001', '00169')
        /*END*/
        /*IF addtionNo != null*/
            AND TRIM(SUBSTR(IM.IMLITM, 13, 2)) IS NOT NULL
        /*END*/
        /*IF addtionNo == null*/
            AND TRIM(SUBSTR(IM.IMLITM, 13, 2)) IS NULL
        /*END*/
        
        GROUP BY
        IM.IMLITM --品目No
        , IM.IMITM
        , IM.IMDSC1 --記述１
        , TRIM(DR_CL.DRDL01) 
        , SUBSTR(IM.IMLITM, 11, 2) 
    ) IMBASE
   -------- 入荷予定明細、 入荷予定見出し-----------------------------
   FULL OUTER JOIN 
     ( SELECT 
          TQ.TQY57BLITM    AS TQY57BLITM --品番
          ,IM.IMITM        AS TQP_IMITM --品番
          , TQ.TQY57BQTYA   AS TQY57BQTYA --入荷予定数
          , TP.TPY57BRDD1   AS TPY57BRDD1 --入荷予定日
          ,TRIM(IM.IMDSC1)         AS TQP_IMDSC1 --記述１
          ,TRIM(DR_CL.DRDL01)      AS TQP_DRDL01_CL --カラー名
          ,SUBSTR(IM.IMLITM,11,2)  AS TQP_IMLITM_S --サイズコード
       FROM
          F57B0020 TQ
   INNER JOIN F57B0010 TP
        ON TQ.TQY57BRCNO = TP.TPY57BRCNO
        AND TP.TPY57BOSTS  < '499'
--       AND TP.TPY57BRDD1 >= TRUNC(SYSDATE)
        AND TQ.TQY57BUREC > 0
        /*IF stockPositionCode != null*/
           AND TP.TPY57BRMCU = LPAD(/*stockPositionCode*/'1000', 12)
        /*END*/
-- 画面引数：在庫場所が必要
-- 216は在庫場所＝1000の時のみ設定可能
        /*IF stockCode == "1000" */
            AND (TP.TPY57BRLCN <> RPAD('216', 20)
                OR   TP.TPY57BRLCN = RPAD(' ', 20))
        /*END*/
        /*IF stockCode != "1000" */
            AND TP.TPY57BRLCN = RPAD(' ', 20)
        /*END*/
   INNER JOIN F4101 IM
      ON TQ.TQY57BLITM = IM.IMLITM
   -------- カラー名 -----------------------------
   LEFT OUTER JOIN F0005 DR_CL
      ON TRIM(SUBSTR(IM.IMLITM,8,3)) = TRIM(DR_CL.DRKY)
     AND DR_CL.DRSY                             = '41F '
     AND DR_CL.DRRT                             = DECODE(TRIM(SUBSTR(IM.IMLITM,1,2)),'01','1C','2C')
        WHERE
            SUBSTR(IM.IMLITM, 11, 2) IS NOT NULL
        /*IF stockCode == "3000" */
            AND SUBSTR(IM.IMLITM, 11, 2) <> '  '
        /*END*/
        /*IF manufacturerCode != null*/
            AND SUBSTR(IM.IMLITM, 1, 2) = /*manufacturerCode*/'01'
        /*END*/
        /*IF productCodes != null*/
            AND SUBSTR(IM.IMLITM, 3, 5) in /*productCodes*/('00001', '00169')
        /*END*/
        /*IF addtionNo != null*/
            AND TRIM(SUBSTR(IM.IMLITM, 13, 2)) IS NOT NULL
        /*END*/
        /*IF addtionNo == null*/
            AND TRIM(SUBSTR(IM.IMLITM, 13, 2)) IS NULL
        /*END*/
   ) TQP
   ON IMBASE.IMLITM = TQP.TQY57BLITM
GROUP BY NVL(IMBASE.IMLITM,TQP.TQY57BLITM)
   ,NVL(IMBASE.IMITM,TQP.TQP_IMITM)
   ,NVL(IMBASE.IMDSC1,TQP.TQP_IMDSC1)
   ,NVL(IMBASE.DRDL01_CL,TQP.TQP_DRDL01_CL)
   ,NVL(IMBASE.IMLITM_S,TQP.TQP_IMLITM_S)
   ,NVL(IMBASE.LIPQOH,0)
) BASE_QR
LEFT OUTER JOIN F57A3190 IF
    ON BASE_QR.IMLITM = IF.IFLITM
    AND BASE_QR.IMITM = IF.IFITM
    AND IF.IFEV04      = '1'
ORDER BY
IMLITM