/**
 * 加工方法見積アップロード処理
 */
var $bind ={};
load("toms/common/mastermaintenance");
//1 加工方法コード
var processMethodCd = MessageManager.getMessage('TOMS.MASTER.MAINTENANCE.PROCESSMETHOD_HEADER.LABEL.PROCESS_METHOD_CODE');
//2 親商品形態コード
var parentCommodityCd = MessageManager.getMessage('TOMS.MASTER.MAINTENANCE.COMMODITYSHAPE.LABEL.PARENT_COMMODITY_SHAPE_CODE');
//3 商品形態コード
var commodityCd = MessageManager.getMessage('TOMS.MASTER.MAINTENANCE.COMMODITYSHAPE.LABEL.COMMODITY_SHAPE_CODE');
//4 素材コード
var materialCd = MessageManager.getMessage('TOMS.MASTER.MAINTENANCE.MATERIAL.LABEL.MATERIAL_CODE');
//5 加工部位コード
var partCd = MessageManager.getMessage('TOMS.MASTER.MAINTENANCE.PROCESSPART.LABEL.PROCESSPART_CODE');
//6 加工位置コード
var positionCd = MessageManager.getMessage('TOMS.MASTER.MAINTENANCE.PROCESSPART.LABEL.PROCESSPART_POSITION_CODE');
//7 加工方法区分
var processMethodType =MessageManager.getMessage('TOMS.MASTER.MAINTENANCE.PROCESSMETHOD_HEADER.LABEL.PROCESS_METHOD_TPYE');
//8 加工方法明細区分
var processMethodDetailType =MessageManager.getMessage('TOMS.MASTER.MAINTENANCE.PROCESSMETHOD_HEADER.LABEL.PROCESS_METHOD_DETAIL_TPYE');

//9 第1階層名称
var name1 = MessageManager.getMessage('TOMS.MASTER.MAINTENANCE.PROCESSMETHOD_DETAIL.LABEL.PROCESS_METHOD_NAME1');
//10 第1階層表示順
var order1 =MessageManager.getMessage('TOMS.MASTER.MAINTENANCE.PROCESSMETHOD_DETAIL.LABEL.DISPLAY_ORDER1');
//11 第1階層JDEコード
var jde1 =MessageManager.getMessage('TOMS.MASTER.MAINTENANCE.PROCESSMETHOD_DETAIL.LABEL.JDE_CODE1');
//12 第1階層グループ名称
var gName1 =MessageManager.getMessage('TOMS.MASTER.MAINTENANCE.PROCESSMETHOD_DETAIL.LABEL.GROUP_NAME1');

//13 第2階層名称
var name2 = MessageManager.getMessage('TOMS.MASTER.MAINTENANCE.PROCESSMETHOD_DETAIL.LABEL.PROCESS_METHOD_NAME2');
//14 第2階層表示順
var order2 =MessageManager.getMessage('TOMS.MASTER.MAINTENANCE.PROCESSMETHOD_DETAIL.LABEL.DISPLAY_ORDER2');
//15 第2階層JDEコード
var jde2 =MessageManager.getMessage('TOMS.MASTER.MAINTENANCE.PROCESSMETHOD_DETAIL.LABEL.JDE_CODE2');
//16 第2階層グループ名称
var gName2 =MessageManager.getMessage('TOMS.MASTER.MAINTENANCE.PROCESSMETHOD_DETAIL.LABEL.GROUP_NAME2');

//17 第3階層名称
var name3 =MessageManager.getMessage('TOMS.MASTER.MAINTENANCE.PROCESSMETHOD_DETAIL.LABEL.PROCESS_METHOD_NAME3');
//18 第3階層表示順
var order3 =MessageManager.getMessage('TOMS.MASTER.MAINTENANCE.PROCESSMETHOD_DETAIL.LABEL.DISPLAY_ORDER3');
//19 第3階層JDEコード
var jde3 =MessageManager.getMessage('TOMS.MASTER.MAINTENANCE.PROCESSMETHOD_DETAIL.LABEL.JDE_CODE3');
//20 第3階層グループ名称
var gName3 =MessageManager.getMessage('TOMS.MASTER.MAINTENANCE.PROCESSMETHOD_DETAIL.LABEL.GROUP_NAME3');

//21 柄サイズ_縦（mm）
var sizeHeight = MessageManager.getMessage('TOMS.MASTER.MAINTENANCE.PROCESSMETHOD_DETAIL.LABEL.PATTERN_SIZE_HEIGHT');
//22 柄サイズ_横（mm）
var sizeWidth = MessageManager.getMessage('TOMS.MASTER.MAINTENANCE.PROCESSMETHOD_DETAIL.LABEL.PATTERN_SIZE_WIDTH');
//23 適用開始日
var startDate = MessageManager.getMessage('TOMS.MASTER.MAINTENANCE.COMMODITYSHAPE.LABEL.APPLIED_START_DATE');
//24 削除フラグ
var delFlg = MessageManager.getMessage('TOMS.MASTER.MAINTENANCE.COMMODITYSHAPE.LABEL.DELETE_FLG');

/**
 * CSVアップロード初期処理.
 * @param request リクエストパラメータ.
 */
function init(request) {

    load("toms/common/csv/CsvUtil");
    load("toms/common/csv/CsvCheker");
    load("toms/common/cmnUtil");

    var response = Web.getHTTPResponse();
    response.setContentType("text/plain; charset=utf-8");
    var csv = []; // csv二次元配列
    var stErr = new java.lang.StringBuilder(); // エラーメッセージ
    var stMsg = new java.lang.StringBuilder(); // 成功メッセージ
    var updateCount = { newCount: 0, updateCount: 0, deleteCount: 0};
    var ret = true;

    // ファイルロード csv二次元ファイル化
    if (!CsvUtil.load2Csv(request, csv, stErr)) {
        doError(response, stErr);
        return;
    }
    // CSVデータ有無チェック
    if (csv.length < 2) {
        // CSVファイルにデータ行が存在しない場合はエラー
        stErr.append(MessageManager.getMessage("TOMS.MASTER.MAINTENANCE.CSVUPLOAD.MESSAGE.ERROR.CSVNODATA"));
        doError(response, stErr);
        return;
    }
    // CSVデータの行数分繰り返す（先頭行はヘッダ行のため次の行から始める）
    for (var rowPos = 1; rowPos < csv.length; rowPos++) {
        // データチェック
        ret = check(csv[rowPos], rowPos, stErr);
        // DB存在チェック
        if (ret) {
            ret = dbCheck(csv[rowPos], rowPos, stErr);
        }
        // DB更新
        if (ret) {
            ret = dbUpdate(csv[rowPos], rowPos, stErr, updateCount);
        }
    }

    // 正常値の返却
    // 挿入件数
    stMsg.append(MessageManager.getMessage("TOMS.MASTER.MAINTENANCE.CSVUPLOAD.LIST.LABEL.ENTRYNUM", String(updateCount.newCount)));
    // 更新件数
    stMsg.append(MessageManager.getMessage("TOMS.MASTER.MAINTENANCE.CSVUPLOAD.LIST.LABEL.UPDATENUM", String(updateCount.updateCount)));
    // 削除件数
    stMsg.append(MessageManager.getMessage("TOMS.MASTER.MAINTENANCE.CSVUPLOAD.LIST.LABEL.DELETENUM", String(updateCount.deleteCount)));

    var stringErr = stErr.toString();
    var stringMsg = stMsg.toString();
    response.sendMessageBodyString(ImJson.toJSONString([{
        "errorMessage": stringErr,
        "successMessage": stringMsg
    }]));
}

/**
 * バリデーションチェック
 * @param csvRowData csvの行データ.(IN)
 * @param rowPos 行番号.(IN)
 * @param stErr エラーメッセージパラメータ.(OUT)
 */
function check(csvRowData, rowPos, stErr){
    var ret = true;
    var ope = csvRowData[0];//更新区分
    var sRowPos = String(rowPos);
    var cellPos = null;

     // 列数チェック
    var columnCnt = 25;
    if (csvRowData.length != columnCnt) {
        if (csvRowData.length > columnCnt) {
            stErr.append(MessageManager.getMessage("TOMS.MASTER.MAINTENANCE.CSVUPLOAD.MESSAGE.ERROR.COLUMN1",sRowPos));
        } else if (csvRowData.length < columnCnt) {
            stErr.append(MessageManager.getMessage("TOMS.MASTER.MAINTENANCE.CSVUPLOAD.MESSAGE.ERROR.COLUMN2",sRowPos));
        }
        ret = false;
        return ret;
    }
    
    // --------------------
    //  0 更新区分
    // --------------------
    // データチェック
    if (isBlank(ope)) {
        stErr.append(MessageManager.getMessage("TOMS.MASTER.MAINTENANCE.CSVUPLOAD.LIST.LABEL.MESSAGE.ERROR.UPDATEDIVISION", sRowPos));
        ret = false;
    }    
    if (ope != "I" && ope != "U" && ope != "D") {
        stErr.append(MessageManager.getMessage("TOMS.MASTER.MAINTENANCE.CSVUPLOAD.LIST.LABEL.MESSAGE.ERROR.UPDATEDIVISION_FORMAT", sRowPos));
        ret = false;
    }


    // --------------------
    // 1 加工方法コード
    // --------------------
    cellPos = 1;
    // 必須チェック
    if (!CsvCheker.required(csvRowData[cellPos], rowPos, cellPos, processMethodCd, stErr)) {
        ret = false;
    } else {
        // 挿入、更新の場合
        if (ope == "I" || ope == "U") {
            // 半角英数字チェック
            if (!CsvCheker.isAlphanumeric(csvRowData[cellPos], rowPos, cellPos, processMethodCd, stErr)) {
                ret = false;
            }
            // 桁数チェック
            if (!CsvCheker.maxLength(csvRowData[cellPos], 16, rowPos, cellPos, processMethodCd, stErr)) {
                ret = false;
            }
        }
    }
    // --------------------
    // 2 親商品形態コード
    // --------------------	
    cellPos = 2;
    // 挿入、更新の場合
    if (ope == "I" || ope == "U") {    // 必須チェック
	    if (!CsvCheker.required(csvRowData[cellPos], rowPos, cellPos, parentCommodityCd, stErr)) {
	        ret = false;
	    } else {
            // 半角英数字チェック
            if (!CsvCheker.isAlphanumeric(csvRowData[cellPos], rowPos, cellPos, parentCommodityCd, stErr)) {
                ret = false;
            }
            // 桁数チェック
            if (!CsvCheker.maxLength(csvRowData[cellPos], 16, rowPos, cellPos, parentCommodityCd, stErr)) {
                ret = false;
            }
            // 親商品形態コードチェック
            if (!CsvCheker.isParentCommodityPrefix(csvRowData[cellPos],rowPos, cellPos, parentCommodityCd, stErr)) {
                ret = false;
            }
	    }
    }
    // --------------------
    // 3 商品形態コード
    // --------------------
	cellPos = 3;
    // 挿入、更新の場合
	if (ope == "I" || ope == "U") {
	    // 必須チェック
	    if (!CsvCheker.required(csvRowData[cellPos], rowPos, cellPos, commodityCd, stErr)) {
	        ret = false;
	    } else {
            // 半角英数字チェック
            if (!CsvCheker.isAlphanumeric(csvRowData[cellPos], rowPos, cellPos, commodityCd, stErr)) {
                ret = false;
            }
            // 桁数チェック
            if (!CsvCheker.maxLength(csvRowData[cellPos], 16, rowPos, cellPos, commodityCd, stErr)) {
                ret = false;
            }
            // 商品形態コードチェック
            if (!CsvCheker.isCommodityPrefix(csvRowData[cellPos], rowPos, cellPos, commodityCd, stErr)) {
                ret = false;
            }
        }
    }
    // --------------------
    // 4 素材コード
    // --------------------
	cellPos = 4;
    // 挿入、更新の場合
    if (ope == "I" || ope == "U") {
    	// 必須チェック
	    if (!CsvCheker.required(csvRowData[cellPos], rowPos, cellPos, materialCd, stErr)) {
	        ret = false;
	    } else {
            // 半角英数字チェック
            if (!CsvCheker.isAlphanumeric(csvRowData[cellPos], rowPos, cellPos, materialCd, stErr)) {
                ret = false;
            }
            // 桁数チェック
            if (!CsvCheker.maxLength(csvRowData[cellPos], 16, rowPos, cellPos, materialCd, stErr)) {
                ret = false;
            }
        }
    }
    // --------------------
    // 5 加工部位コード
    // --------------------
    cellPos = 5;
    // 挿入、更新の場合
    if (ope == "I" || ope == "U") {
    	// 必須チェック
	    if (!CsvCheker.required(csvRowData[cellPos], rowPos, cellPos, partCd, stErr)) {
	        ret = false;
	    } else {
            // 半角英数字チェック
            if (!CsvCheker.isAlphanumeric(csvRowData[cellPos], rowPos, cellPos, partCd, stErr)) {
                ret = false;
            }
            // 桁数チェック
            if (!CsvCheker.maxLength(csvRowData[cellPos], 16, rowPos, cellPos, partCd, stErr)) {
                ret = false;
            }
        }
    }
    // --------------------
    // 6 加工位置コード
    // --------------------
    cellPos = 6;
    // 挿入、更新の場合
    if (ope == "I" || ope == "U") {
    	// 必須チェック
	    if (!CsvCheker.required(csvRowData[cellPos], rowPos, cellPos, positionCd, stErr)) {
	        ret = false;
	    } else {
            // 半角英数字チェック
            if (!CsvCheker.isAlphanumeric(csvRowData[cellPos], rowPos, cellPos, positionCd, stErr)) {
                ret = false;
            }
            // 桁数チェック
            if (!CsvCheker.maxLength(csvRowData[cellPos], 16, rowPos, cellPos, positionCd, stErr)) {
                ret = false;
            }
        }
    }
    // --------------------
    // 7 加工方法区分
    // --------------------
    cellPos = 7;
    // 挿入、更新の場合
    if (ope == "I" || ope == "U") {
    	// 必須チェック
	    if (!CsvCheker.required(csvRowData[cellPos], rowPos, cellPos, processMethodType, stErr)) {
	        ret = false;
	    } else {
            // 半角英数字チェック
            if (!CsvCheker.isAlphanumeric(csvRowData[cellPos], rowPos, cellPos, processMethodType, stErr)) {
                ret = false;
            }
            // 桁数チェック
            if (!CsvCheker.maxLength(csvRowData[cellPos], 2, rowPos, cellPos, processMethodType, stErr)) {
                ret = false;
            }
        }
    }

    // --------------------
    // 8 加工方法明細区分
    // --------------------
    cellPos = 8;
    // 挿入、更新の場合
    if (ope == "I" || ope == "U") {
    	// 必須チェック
	    if (!CsvCheker.required(csvRowData[cellPos], rowPos, cellPos, processMethodDetailType, stErr)) {
	        ret = false;
	    } else {
            // 半角英数字チェック
            if (!CsvCheker.isAlphanumeric(csvRowData[cellPos], rowPos, cellPos, processMethodDetailType, stErr)) {
                ret = false;
            }
            // 桁数チェック
            if (!CsvCheker.maxLength(csvRowData[cellPos], 2, rowPos, cellPos, processMethodDetailType, stErr)) {
                ret = false;
            }
        }
    }
    // --------------------
    // 9 第1階層名称
    // --------------------
    cellPos = 9;
    // 挿入、更新の場合
    if (ope == "I" || ope == "U") {
        // 必須チェック
        if (!CsvCheker.required(csvRowData[cellPos], rowPos, cellPos, name1, stErr)) {
            ret = false;
        } else {
            // 文字数チェック
            if (!CsvCheker.maxLength(csvRowData[cellPos], 30, rowPos, cellPos, name1, stErr)) {
                ret = false;
            }
        }
    }
    // --------------------
    // 10 第1階層表示順
    // --------------------
    cellPos = 10;
    // 挿入、更新の場合
    if (ope == "I" || ope == "U") {
        // 半角数値チェック
        if (!CsvCheker.isNum(csvRowData[cellPos], rowPos, cellPos, order1, stErr)) {
            ret = false;
        }
        // 桁数チェック
        if (!CsvCheker.maxLength(csvRowData[cellPos], 8, rowPos, cellPos, order1, stErr)) {
            ret = false;
        }
    }
    // --------------------
    // 11 第1階層JDEコード
    // --------------------
	cellPos = 11;
    // 必須チェック
    if (!CsvCheker.required(csvRowData[cellPos], rowPos, cellPos, jde1, stErr)) {
        ret = false;
    } else {
        // 挿入、更新の場合
        if (ope == "I" || ope == "U") {
            // 半角英数字チェック
            if (!CsvCheker.isAlphanumeric(csvRowData[cellPos], rowPos, cellPos, jde1, stErr)) {
                ret = false;
            }
            // 文字数チェック
            if (!CsvCheker.maxLength(csvRowData[cellPos], 8, rowPos, cellPos, jde1, stErr)) {
                ret = false;
            }
        }
    }
    // --------------------
    // 12 第1階層グループ名称
    // --------------------
    cellPos = 12;
    // 挿入、更新の場合
    if (ope == "I" || ope == "U") {
        // 桁数チェック
        if (!CsvCheker.maxLength(csvRowData[cellPos], 20, rowPos, cellPos, gName1, stErr)) {
            ret = false;
        }
    }
    // --------------------
    // 13 第2階層名称
    // --------------------
        cellPos = 13;
        // 挿入、更新の場合
        if (ope == "I" || ope == "U") {
            // 必須チェック
            if (!CsvCheker.required(csvRowData[cellPos], rowPos, cellPos, name2, stErr)) {
                ret = false;
            } else {
                // 文字数チェック
                if (!CsvCheker.maxLength(csvRowData[cellPos], 30, rowPos, cellPos, name2, stErr)) {
                    ret = false;
                }
            }
        }
    // --------------------
    // 14 第2階層表示順
    // --------------------
    cellPos = 14;
    // 挿入、更新の場合
    if (ope == "I" || ope == "U") {
        // 半角数値チェック
        if (!CsvCheker.isNum(csvRowData[cellPos], rowPos, cellPos, order2, stErr)) {
            ret = false;
        }
        // 桁数チェック
        if (!CsvCheker.maxLength(csvRowData[cellPos], 8, rowPos, cellPos, order2, stErr)) {
            ret = false;
        }
    }
    // --------------------
    // 15 第2階層JDEコード
    // --------------------
    cellPos = 15;
    // 必須チェック
    if (!CsvCheker.required(csvRowData[cellPos], rowPos, cellPos, jde2, stErr)) {
        ret = false;
    } else {
        // 挿入、更新の場合
        if (ope == "I" || ope == "U") {
            // 半角英数字チェック
            if (!CsvCheker.isAlphanumeric(csvRowData[cellPos], rowPos, cellPos, jde2, stErr)) {
                ret = false;
            }
            // 文字数チェック
            if (!CsvCheker.maxLength(csvRowData[cellPos], 8, rowPos, cellPos, jde2, stErr)) {
                ret = false;
            }
        }
    }
    // --------------------
    // 16 第2階層グループ名称
    // --------------------
    cellPos = 16;
    // 挿入、更新の場合
    if (ope == "I" || ope == "U") {
        // 桁数チェック
        if (!CsvCheker.maxLength(csvRowData[cellPos], 20, rowPos, cellPos, gName2, stErr)) {
            ret = false;
        }
    }
    // --------------------
    // 17 第3階層名称
    // --------------------
    cellPos = 17;
    // 挿入、更新の場合
    if (ope == "I" || ope == "U") {
        // 必須チェック
        if (!CsvCheker.required(csvRowData[cellPos], rowPos, cellPos, name3, stErr)) {
            ret = false;
        } else {
            // 文字数チェック
            if (!CsvCheker.maxLength(csvRowData[cellPos], 30, rowPos, cellPos, name3, stErr)) {
                ret = false;
            }
        }
    }

    // --------------------
    // 18 第3階層表示順
    // --------------------
    cellPos = 18;
    // 挿入、更新の場合
    if (ope == "I" || ope == "U") {
        // 半角数値チェック
        if (!CsvCheker.isNum(csvRowData[cellPos], rowPos, cellPos, order3, stErr)) {
            ret = false;
        }
        // 桁数チェック
        if (!CsvCheker.maxLength(csvRowData[cellPos], 8, rowPos, cellPos, order3, stErr)) {
            ret = false;
        }
    }

    // --------------------
    // 19 第3階層JDEコード
    // --------------------
    cellPos = 19;
    // 必須チェック
    if (!CsvCheker.required(csvRowData[cellPos], rowPos, cellPos, jde3, stErr)) {
        ret = false;
    } else {
        // 挿入、更新の場合
        if (ope == "I" || ope == "U") {
            // 半角英数字チェック
            if (!CsvCheker.isAlphanumeric(csvRowData[cellPos], rowPos, cellPos, jde3, stErr)) {
                ret = false;
            }
            // 文字数チェック
            if (!CsvCheker.maxLength(csvRowData[cellPos], 8, rowPos, cellPos, jde3, stErr)) {
                ret = false;
            }
        }
    }
    // --------------------
    // 20 第3階層グループ名称
    // --------------------
    cellPos = 20;
    // 挿入、更新の場合
    if (ope == "I" || ope == "U") {
        // 桁数チェック
        if (!CsvCheker.maxLength(csvRowData[cellPos], 20, rowPos, cellPos, gName3, stErr)) {
            ret = false;
        }
    }
    // --------------------
    // 21 柄サイズ_縦（mm）
    // --------------------
    cellPos = 21;
    // 挿入、更新の場合
    if (ope == "I" || ope == "U") {
    	//相関チェック　加工方法区分が転写の場合は必須
    	if(csvRowData[7] =="2" && isBlank(csvRowData[cellPos])) {
    		stErr.append(MessageManager.getMessage('TOMS.COMMON.MAINTENANCE.CSVUPLOAD.MESSAGE.ERROR.PATTERNSIZE_HEIGHT_REQUIRE',String(rowPos)));
    		ret = false;
    	}

        // 半角数値チェック
        if (!CsvCheker.isNum(csvRowData[cellPos], rowPos, cellPos, sizeHeight, stErr)) {
            ret = false;
        }
        // 桁数チェック
        if (!CsvCheker.maxLength(csvRowData[cellPos], 8, rowPos, cellPos, sizeHeight, stErr)) {
            ret = false;
        }
    }
    // --------------------
    // 22 柄サイズ_横（mm）
    // --------------------
    cellPos = 22;
    // 挿入、更新の場合
    if (ope == "I" || ope == "U") {
    	//相関チェック　加工方法区分が転写の場合は必須
    	if(csvRowData[7] =="2" && isBlank(csvRowData[cellPos])) {
    		stErr.append(MessageManager.getMessage('TOMS.COMMON.MAINTENANCE.CSVUPLOAD.MESSAGE.ERROR.PATTERNSIZE_WIDTH_REQUIRE',String(rowPos)));
    		ret = false;
    	}
        // 半角数値チェック
        if (!CsvCheker.isNum(csvRowData[cellPos], rowPos, cellPos, sizeWidth, stErr)) {
            ret = false;
        }
        // 桁数チェック
        if (!CsvCheker.maxLength(csvRowData[cellPos], 8, rowPos, cellPos, sizeWidth, stErr)) {
            ret = false;
        }
    }
    // --------------------
    // 23 適用開始日
    // --------------------
    cellPos = 23;
    // 必須チェック
    if (!CsvCheker.required(csvRowData[cellPos], rowPos, cellPos, startDate, stErr)) {
        ret = false;
    } else {
        // 挿入、更新の場合
        if (ope == "I" || ope == "U") {
            // 日付チェック
            if (!CsvCheker.isDate(csvRowData[cellPos], rowPos, cellPos, startDate, stErr)) {
                ret = false;
            }
        }
    }
    // --------------------
    // 24 削除フラグ
    // --------------------
    cellPos = 24;
    // 挿入の場合
    if (ope == "I") {
        // データチェック
        if (csvRowData[cellPos] != "0") {
            stErr.append(MessageManager.getMessage("TOMS.MASTER.MAINTENANCE.CSVUPLOAD.LIST.LABEL.MESSAGE.ERROR.DEL_FLAG", sRowPos));
            ret = false;
        }
    }
    // 挿入、更新の場合
    else if (ope == "I" || ope == "U") {
        // データチェック
        if (csvRowData[cellPos] != "0" && csvRowData[cellPos] != "1") {
            stErr.append(MessageManager.getMessage("TOMS.MASTER.MAINTENANCE.CSVUPLOAD.LIST.LABEL.MESSAGE.ERROR.DEL_FLAG_FORMAT", sRowPos));
            ret = false;
        }
    }

    return ret;
	
}

/*
 * DBによるデータ有無チェック
 * @param csvRowData csvの行データ.(IN)
 * @param rowPos 行番号.(IN)
 * @param stErr エラーメッセージパラメータ.(OUT)
 */
function dbCheck(csvRowData, rowPos, stErr) {
    var ret = true;
    var ope = csvRowData[0];
    var sRowPos = String(rowPos);
    var cellPos = null;
    var result =null;
    //加工明細マスタのキー検索（加工方法コード、JDEコード１、JDEコード２、JDEコード３、適用開始日）
    var uniqResult = MasterMain.getProcessMethodDetailByKey(csvRowData[1],csvRowData[11],csvRowData[15],csvRowData[19],csvRowData[23],csvRowData[2],csvRowData[3],csvRowData[4],csvRowData[5],csvRowData[6],csvRowData[7]);
    if (ope == "I" || ope == "U") {
		//親商品形態コードの内部コードチェック
	    cellPos = 2;
	    result = MasterMain.checkCodeMaster("01", "01", csvRowData[cellPos]);
	    if (result.countRow == 0) {
	        // 存在しない場合
	        stErr.append(MessageManager.getMessage("TOMS.MASTER.MAINTENANCE.CSVUPLOAD.LIST.LABEL.MESSAGE.ERROR.CODEMASTER.NOTINLINE", sRowPos, String(cellPos + 1), parentCommodityCd));
	        ret = false;
	    }
	    //商品形態コードの内部コードチェック
	    cellPos = 3;
	    result = MasterMain.checkCodeMaster("02", "01", csvRowData[cellPos]);
	    if (result.countRow == 0) {
	        // 存在しない場合
	        stErr.append(MessageManager.getMessage("TOMS.MASTER.MAINTENANCE.CSVUPLOAD.LIST.LABEL.MESSAGE.ERROR.CODEMASTER.NOTINLINE", sRowPos, String(cellPos + 1), commodityCd));
	        ret = false;
	    }
	    //素材コードの内部コードチェック
	    cellPos = 4;
	    result = MasterMain.checkCodeMaster("03", "01", csvRowData[cellPos]);
	    if (result.countRow == 0) {
	        // 存在しない場合
	        stErr.append(MessageManager.getMessage("TOMS.MASTER.MAINTENANCE.CSVUPLOAD.LIST.LABEL.MESSAGE.ERROR.CODEMASTER.NOTINLINE", sRowPos, String(cellPos + 1), materialCd));
	        ret = false;
	    }
	    //加工部位コードの内部コードチェック
	     cellPos = 5;
	    result = MasterMain.checkCodeMaster("04", "01", csvRowData[cellPos]);
	    if (result.countRow == 0) {
	        // 存在しない場合
	        stErr.append(MessageManager.getMessage("TOMS.MASTER.MAINTENANCE.CSVUPLOAD.LIST.LABEL.MESSAGE.ERROR.CODEMASTER.NOTINLINE", sRowPos, String(cellPos + 1), partCd));
	        ret = false;
	    }
	   	//加工位置コードの内部コードチェック
	     cellPos = 6;
	    result = MasterMain.checkCodeMaster("05", "01", csvRowData[cellPos]);
	    if (result.countRow == 0) {
	        // 存在しない場合
	        stErr.append(MessageManager.getMessage("TOMS.MASTER.MAINTENANCE.CSVUPLOAD.LIST.LABEL.MESSAGE.ERROR.CODEMASTER.NOTINLINE", sRowPos, String(cellPos + 1), positionCd));
	        ret = false;
	    }
	    

	    //加工方法区分のコードチェック
	    cellPos = 7
	    var checkResult = MasterMain.checkProcessMethodType(csvRowData[cellPos]);
	    if(!checkResult){
	        stErr.append(MessageManager.getMessage("TOMS.MASTER.MAINTENANCE.CSVUPLOAD.LIST.LABEL.MESSAGE.ERROR.PROCESSMETHODTYPE.NOTINLINE", sRowPos, String(cellPos + 1)));
	    	ret = false;
	    	
	    };

	    //加工方法明細区分のコードチェック
	    cellPos = 8
	    checkResult = MasterMain.checkProcessMethodDetailType(csvRowData[cellPos]);
	    if(!checkResult){
	        stErr.append(MessageManager.getMessage("TOMS.MASTER.MAINTENANCE.CSVUPLOAD.LIST.LABEL.MESSAGE.ERROR.PROCESSMETHODDETAILTYPE.NOTINLINE", sRowPos, String(cellPos + 1)));
	    	ret = false;
	    	
	    };	    

//	    //加工方法区分の内部コードチェック
//	     cellPos = 7;
//	    result = MasterMain.checkCodeMaster("06", "01", csvRowData[cellPos]);
//	    if (result.countRow == 0) {
//	        // 存在しない場合
//	        stErr.append(MessageManager.getMessage("TOMS.MASTER.MAINTENANCE.CSVUPLOAD.LIST.LABEL.MESSAGE.ERROR.CODEMASTER.NOTINLINE", sRowPos, String(cellPos + 1), processMethodType));
//	        ret = false;
//	    }
//	    //加工方法明細区分の内部コードチェック
//	     cellPos = 8;
//	    //result = MasterMain.checkCodeMaster("07", "01", csvRowData[cellPos]);
//	    result = MasterMain.checkCodeMasterMethodDetail("07", "01", csvRowData[cellPos],csvRowData[7]);
//	    if (result.countRow == 0) {
//	        // 存在しない場合
//	        stErr.append(MessageManager.getMessage("TOMS.MASTER.MAINTENANCE.CSVUPLOAD.LIST.LABEL.MESSAGE.ERROR.CODEMASTER.NOTINLINE", sRowPos, String(cellPos + 1), processMethodDetailType));
//	        ret = false;
//	    }
	    //第1階層JDEコード
	     cellPos = 11;
	    result = MasterMain.checkCodeMasterMethodDetail("07", "02", csvRowData[cellPos],csvRowData[7]);
	    if (result.countRow == 0) {
	        // 存在しない場合
	        stErr.append(MessageManager.getMessage("TOMS.MASTER.MAINTENANCE.CSVUPLOAD.LIST.LABEL.MESSAGE.ERROR.CODEMASTER.NOTINLINE", sRowPos, String(cellPos + 1), jde1));
	        ret = false;
	    }
		//第2階層JDEコード
	     cellPos = 15;
		    result = MasterMain.checkCodeMasterMethodDetail("07", "02", csvRowData[cellPos],csvRowData[7]);
	    if (result.countRow == 0) {
	        // 存在しない場合
	        stErr.append(MessageManager.getMessage("TOMS.MASTER.MAINTENANCE.CSVUPLOAD.LIST.LABEL.MESSAGE.ERROR.CODEMASTER.NOTINLINE", sRowPos, String(cellPos + 1), jde2));
	        ret = false;
	    }
		//第3階層JDEコード
	     cellPos = 19;
		    result = MasterMain.checkCodeMasterMethodDetail("07", "02", csvRowData[cellPos],csvRowData[7]);
	    if (result.countRow == 0) {
	        // 存在しない場合
	        stErr.append(MessageManager.getMessage("TOMS.MASTER.MAINTENANCE.CSVUPLOAD.LIST.LABEL.MESSAGE.ERROR.CODEMASTER.NOTINLINE", sRowPos, String(cellPos + 1), jde3));
	        ret = false;
	    }
	    //加工ヘッダ存在チェック
	    result = MasterMain.getProcessMethodHeaderByKey(csvRowData[1],csvRowData[2],csvRowData[3],csvRowData[4],csvRowData[5],csvRowData[6],csvRowData[7],"");
        if (result.countRow == 0) {
            // 存在しない場合
            stErr.append(MessageManager.getMessage("TOMS.MASTER.MAINTENANCE.CSVUPLOAD.MESSAGE.ERROR.DATANOTEXIST.PROCESSMETHODHEADER_CHECK", sRowPos, csvRowData[1].trim()));
            ret = false;
        }
    }

    if(ope=="I"){
    	//加工明細マスタの存在チェック
    	if(uniqResult.countRow >0){
            stErr.append(MessageManager.getMessage("TOMS.MASTER.MAINTENANCE.CSVUPLOAD.MESSAGE.ERROR.PROCESSMETHOD_DETAIL.DATAEXIST", sRowPos, csvRowData[1].trim(), csvRowData[11].trim(), csvRowData[15].trim(), csvRowData[19].trim(), csvRowData[23].trim(), csvRowData[2].trim(), csvRowData[3].trim(), csvRowData[4].trim(), csvRowData[5].trim(), csvRowData[6].trim(), csvRowData[7].trim()));
            ret = false;
    	}
    	
    }else{
        // 更新、削除の場合
        // 存在チェック
        if (uniqResult.countRow < 1) {
            stErr.append(MessageManager.getMessage("TOMS.MASTER.MAINTENANCE.CSVUPLOAD.MESSAGE.ERROR.PROCESSMETHOD_DETAIL.DATANOTEXIST", sRowPos, csvRowData[1].trim(),csvRowData[11].trim(), csvRowData[15].trim(), csvRowData[19].trim(), csvRowData[23].trim(), csvRowData[2].trim(), csvRowData[3].trim(), csvRowData[4].trim(), csvRowData[5].trim(), csvRowData[6].trim(), csvRowData[7].trim()));
            ret = false;
        }
//        // 複数存在チェック
//        if (uniqResult.countRow > 1) {
//            stErr.append(MessageManager.getMessage("TOMS.MASTER.MAINTENANCE.PROCESSPART.LIST.LABEL.MESSAGE.ERROR.DUPLICATE", sRowPos, csvRowData[1].trim(), csvRowData[2].trim(), csvRowData[3].trim(), csvRowData[4].trim(), csvRowData[5].trim(), csvRowData[12].trim()));
//            ret = false;
//        }
    }
    return ret;
}

/**
 * DB更新
 * 
 * @param csvRowData csvの行データ.(IN)
 * @param rowPos 行番号.(IN)
 * @param stErr エラーメッセージパラメータ.(OUT)
 * @param updateCount (OUT)
 */
function dbUpdate(csvRowData, rowPos, stErr, counts) {

    var ret = true;
    var newCount = counts.newCount;
    var updateCount = counts.updateCount;
    var deleteCount = counts.deleteCount;

    var ope = csvRowData[0];
    var sRowPos = String(rowPos);
    var result;

    // CSVの行データからDB更新用データ作成
    var entity = createEntity(csvRowData);
    var condition = "TRIM(mny57apmc) = ? "
                  + " AND TRIM(mny57ajc1) = ? "
                  + " AND TRIM(mny57ajc2) = ? "
                  + " AND TRIM(mny57ajc3) = ? "
                  + " AND mneftj = ? ";
    var params = [
            DbParameter.string(entity["mny57apmc"]),
            DbParameter.string(entity["mny57ajc1"]),
            DbParameter.string(entity["mny57ajc2"]),
            DbParameter.string(entity["mny57ajc3"]),
            DbParameter.number(entity["mneftj"])
    ];
    Transaction.begin();
    var masterTable = 'F57A5141';
    if (ope == "I") {           //挿入
        result = MasterMain.insertToMasterTable(masterTable, entity);
        newCount++;
    } else if (ope =="U") {     //更新
        result = MasterMain.updateToMasterTable(masterTable, entity, condition, params);
        updateCount++;
    } else if  (ope =="D") {    //削除
        result = MasterMain.removeFromMasterTable(masterTable, condition, params);
        deleteCount++;
    }
    if (!result.error && result.countRow != 1) {
        Transaction.rollback();
        stErr.append(MessageManager.getMessage("TOMS.MASTER.MAINTENANCE.CSVUPLOAD.LIST.LABEL.MESSAGE.ERROR.ABNORMAL", sRowPos));
        return false;
    }
    if (result.error) {
        Transaction.rollback();
        stErr.append(MessageManager.getMessage("TOMS.MASTER.MAINTENANCE.CSVUPLOAD.LIST.LABEL.MESSAGE.ERROR.DB"));
        stErr.append(MessageManager.getMessage("TOMS.MASTER.MAINTENANCE.CSVUPLOAD.LIST.LABEL.MESSAGE.CSVLINE", sRowPos));
        return false;
    }
    Transaction.commit();

    counts.newCount = newCount;
    counts.updateCount = updateCount;
    counts.deleteCount = deleteCount;

    return true;
}
	
/**
 * DB更新用データ作成
 * 
 * @param csvRowData csvの行データ.
 */
function createEntity(csvRowData) {

    var userContext = Contexts.getUserContext();
    var now = new Date();

 	var mny57apmc = null; //加工方法コード1
	var mny57apcsc =null;//親商品形態コード2
	var mny57acsc = null;//商品形態コード3
	var mny57amtc = null; //素材コード4
	var mny57appc1 = null; //加工部位コード5
	var mny57appc2 = null; //加工位置コード6
	var mny57apmt =null;//加工方法区分7
	var mny57apmdt =null;//加工方法明細区分8

	var mny57apmn1 = null; //第1階層名称9
	var mny57ado1 =null;//第1階層表示順10
	var mny57ajc1 = null;//第1階層JDEコード11
	var mny57agn1 = null; //第1階層グループ名称12

	var mny57apmn2 = null; //第2階層名称13
	var mny57ado2 =null;//第2階層表示順14
	var mny57ajc2 = null;//第2階層JDEコード15
	var mny57agn2 = null; //第2階層グループ名称16

	var mny57apmn3 = null; //第3階層名称17
	var mny57ado3 =null;//第3階層表示順18
	var mny57ajc3 = null;//第3階層JDEコード19
	var mny57agn3 = null; //第3階層グループ名称20

	var mny57apsh =null;//柄サイズ 縦21
	var mny57apsw =null;//柄サイズ 横22
	

	var mneftj =null;//適用開始日23
	var mny57adflg = null //削除フラグ24
	var mnexdj = cmnUtil.convertDateToJulia(new Date(MessageManager.getMessage("TOMS.COMMON.CONSTANT.ENDDATE")));    // 適用終了日
	var mnuser = userContext.userProfile.userCd; //ユーザID
    var mnpid = MessageManager.getMessage("TOMS.COMMON.CONSTANT.PROGRAM.ID");    // プログラムID
	var mnupmj = cmnUtil.convertDateToJulia(now);  //更新日付
	var mnupmt = cmnUtil.getTime(now);  //更新時刻
	var mny57ahflg =0;//非表示フラグ
	
	//加工方法コード1
    if(!isBlank(cmnUtil.getData(csvRowData[1], 0))){
    	mny57apmc = cmnUtil.getData(csvRowData[1], 0);
    }
	//親商品形態コード2
    if(!isBlank(cmnUtil.getData(csvRowData[2], 0))){
    	mny57apcsc = cmnUtil.getData(csvRowData[2], 0);
    }
	//商品形態コード3
    if(!isBlank(cmnUtil.getData(csvRowData[3], 0))){
    	mny57acsc = cmnUtil.getData(csvRowData[3], 0);
    }
    //素材コード4
    if(!isBlank(cmnUtil.getData(csvRowData[4], 0))){
    	mny57amtc = cmnUtil.getData(csvRowData[4], 0);
    }
	//加工部位コード5
    if(!isBlank(cmnUtil.getData(csvRowData[5], 0))){
    	mny57appc1 = cmnUtil.getData(csvRowData[5], 0);
    }
	//加工位置コード6
    if(!isBlank(cmnUtil.getData(csvRowData[6], 0))){
    	mny57appc2 = cmnUtil.getData(csvRowData[6], 0);
    }
	//加工方法区分7
    if(!isBlank(cmnUtil.getData(csvRowData[7], 0))){
    	mny57apmt = cmnUtil.getData(csvRowData[7], 0);
    }
	//加工方法明細区分8
    if(!isBlank(cmnUtil.getData(csvRowData[8], 0))){
    	mny57apmdt = cmnUtil.getData(csvRowData[8], 0);
    }
    
	//第1階層名称9
    if(!isBlank(cmnUtil.getData(csvRowData[9], 0))){
    	mny57apmn1 = cmnUtil.getData(csvRowData[9], 0);
    }
	//第1階層表示順10
    if(!isBlank(cmnUtil.getData(csvRowData[10], 1))){
    	mny57ado1 = cmnUtil.getData(csvRowData[10], 1);
    }
	//第1階層JDEコード11
    if(!isBlank(cmnUtil.getData(csvRowData[11], 0))){
    	mny57ajc1 = cmnUtil.getData(csvRowData[11], 0);
    }
	//第1階層グループ名称12
    if(!isBlank(cmnUtil.getData(csvRowData[12], 0))){
    	mny57agn1 = cmnUtil.getData(csvRowData[12], 0);
    }

	//第2階層名称13
    if(!isBlank(cmnUtil.getData(csvRowData[13], 0))){
    	mny57apmn2 = cmnUtil.getData(csvRowData[13], 0);
    }
	//第2階層表示順14
    if(!isBlank(cmnUtil.getData(csvRowData[14], 1))){
    	mny57ado2 = cmnUtil.getData(csvRowData[14], 1);
    }
	//第2階層JDEコード15
    if(!isBlank(cmnUtil.getData(csvRowData[15], 0))){
    	mny57ajc2 = cmnUtil.getData(csvRowData[15], 0);
    }
	//第2階層グループ名称16
    if(!isBlank(cmnUtil.getData(csvRowData[16], 0))){
    	mny57agn2 = cmnUtil.getData(csvRowData[16], 0);
    }
	//第3階層名称17
    if(!isBlank(cmnUtil.getData(csvRowData[17], 0))){
    	mny57apmn3 = cmnUtil.getData(csvRowData[17], 0);
    }
	//第3階層表示順18
    if(!isBlank(cmnUtil.getData(csvRowData[18], 1))){
    	mny57ado3 = cmnUtil.getData(csvRowData[18], 1);
    }
	//第3階層JDEコード19
    if(!isBlank(cmnUtil.getData(csvRowData[19], 0))){
    	mny57ajc3 = cmnUtil.getData(csvRowData[19], 0);
    }
	//第3階層グループ名称20
    if(!isBlank(cmnUtil.getData(csvRowData[20], 0))){
    	mny57agn3 = cmnUtil.getData(csvRowData[20], 0);
    }

	//柄サイズ_縦21
    if(!isBlank(cmnUtil.getData(csvRowData[21], 1))){
    	mny57apsh = cmnUtil.getData(csvRowData[21], 1);
    }
	//柄サイズ_横22
    if(!isBlank(cmnUtil.getData(csvRowData[22], 1))){
    	mny57apsw = cmnUtil.getData(csvRowData[22], 1);
    }
	//適用開始日23
    if(!isBlank(csvRowData[23])){
    	mneftj = cmnUtil.convertDateToJulia(new Date(csvRowData[23]));
    }
    
    //削除フラグ24
    if(!isBlank(cmnUtil.getData(csvRowData[24], 1))){
    	mny57adflg = cmnUtil.getData(csvRowData[24], 1);
    }

    var entity ={
    	mny57apmc : mny57apmc,
	mny57apmt : mny57apmt,
    mny57apmn1 : mny57apmn1,
    mny57apmn2 : mny57apmn2,
    mny57apmn3 : mny57apmn3,
    mny57ajc1 : mny57ajc1,
    mny57ajc2 : mny57ajc2,
    mny57ajc3 : mny57ajc3,
    mny57agn1 : mny57agn1,
    mny57agn2 : mny57agn2,
    mny57agn3 : mny57agn3,
    mny57ado1 : mny57ado1,
    mny57ado2 : mny57ado2,
    mny57ado3 : mny57ado3,
    mny57apsh : mny57apsh,
    mny57apsw : mny57apsw,
    mny57ahflg : mny57ahflg,
    mneftj : mneftj,
	mnuser : mnuser,
	mnpid : mnpid,
	mnupmj : mnupmj,
	mnupmt : mnupmt,
	mny57apcsc : mny57apcsc,
	mny57acsc : mny57acsc,
	mny57amtc : mny57amtc,
	mny57appc1 : mny57appc1,
	mny57appc2 : mny57appc2,
	mny57apmdt : mny57apmdt,
    mny57adflg:mny57adflg
    };
    return entity;
}

/**
 * エラー処理
 * 
 * @param response　レスポンス
 * @param stErr エラーメッセージパラメータ.
 */
function doError(response, stErr) {
        stErr.insert(0, MessageManager.getMessage("TOMS.MASTER.MAINTENANCE.CSVUPLOAD.LIST.LABEL.ENTRY.ERROR"));
        var stringErr = stErr.toString();
        response.sendMessageBodyString(ImJson.toJSONString([{
            "errorMessage": stringErr,
            "successMessage": ""
        }]));
}
