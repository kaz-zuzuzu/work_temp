/**
 * 加工方法商品関連付けマスタメンテナンス一覧
 *
 **/

 var $bind ={};
 
 var $data={};
 load("toms/common/common");
 

/**
 * 初期表示
 * @param request リクエストパラメータ
 */
function init(request){

	$bind.dialogMessages="";

	$data = {
		pageNum : isBlank(request.pageNum) ? '1' : request.pageNum,
		rowNum  : isBlank(request.rowNum) ? '30' : request.rowNum,
		rowList : isBlank(request.rowList) ? '30, 50, 100' : request.rowList
	};

	//検索条件設定
	// 加工方法ヘッダからの検索パラメータとヘッダー表示情報
	$bind.mmy57apmc = isBlank(request.mmy57apmc) ? "":request.mmy57apmc; //加工方法コード 加工方法ヘッダ一覧からの遷移時
	$bind.mmdl01 = isBlank(request.mmdl01) ? "":request.mmdl01; //加工方法名称
	$bind.mmy57amtc = isBlank(request.mmy57amtc) ? "":request.mmy57amtc; //素材コード
	$bind.mmy57apcsc = isBlank(request.mmy57apcsc) ? "":request.mmy57apcsc; //親商品形態コード
	$bind.mmy57acsc = isBlank(request.mmy57acsc) ? "":request.mmy57acsc; //商品形態コード
	$bind.mmy57appc1 = isBlank(request.mmy57appc1) ? "":request.mmy57appc1; //加工部位コード
	$bind.mmy57appc2 = isBlank(request.mmy57appc2) ? "":request.mmy57appc2; //加工位置コード
	$bind.mmy57asrt = isBlank(request.mmy57asrt) ? "":request.mmy57asrt; //特記事項区分
	$bind.mmy57apmt = isBlank(request.mmy57apmt) ? "":request.mmy57apmt; //加工方法区分
	$bind.mmy57apmdt = isBlank(request.mmy57apmdt) ? "":request.mmy57apmdt; //加工方法明細区分
	$bind.mmy57ada = isBlank(request.mmy57ada) ? "":request.mmy57ada; //階層数
	$bind.mmy57adflg = isBlank(request.mmy57adflg) ? "" :request.mmy57adflg;//削除フラグ
	$bind.mmeftj = isBlank(request.mmeftj) ? "":request.mmeftj;//適用開始日
	$bind.mmeftj2 = isBlank(request.mmeftj2) ? "":request.mmeftj2;//適用開始日
	$bind.mmexdj = isBlank(request.mmexdj) ? "":request.mmexdj;//適用終了日

	$bind.mpy57apmc = isBlank(request.mmy57apmc) ? request.mpy57apmc:request.mmy57apmc; //加工方法コード　本機能での受け渡し用	

	//ダウrンロード用検索条件

	var csvObj;
	if (request.csvFlag == "1") {
		csvObj ={
			mpy57apmc: isBlank(request.mpy57apmc) ? "":request.mpy57apmc, //加工方法コード
			mpy57acc 		: isBlank(request.mpy57acc) ? "":request.mpy57acc, //商品コード
			mpy57adflg 	: isBlank(request.mpy57adflg) ? "" :request.mpy57adflg,//削除フラグ
			mpeftj 		: isBlank(request.mpeftj) ? "":request.mpeftj,//適用開始日
			mpeftj2 	: isBlank(request.mpeftj2) ? "":request.mpeftj2,//適用開始日
			mpexdj 		: isBlank(request.mpexdj) ? "":request.mpexdj//適用終了日		
		};
	
       outputCSV(csvObj);
	}
	
	$bind.checked1 = true; 	
	$bind.checked2 = false;
	$bind.checked3 	=false;
	
	//画面項目
	$bind.select_notdelete=MessageManager.getMessage('TOMS.COMMON.DELETE.SELECT.NOTDELETE');
	$bind.select_delete=MessageManager.getMessage('TOMS.COMMON.DELETE.SELECT.DELETE');
	$bind.select_all=MessageManager.getMessage('TOMS.COMMON.DELETE.SELECT.ALL');

	$bind.message_disp=MessageManager.getMessage('TOMS.COMMON.DISPFLAG.ONLY');
	$bind.message_notdisp=MessageManager.getMessage('TOMS.COMMON.DISPFLAG.NOT_DISP');
	$bind.message_alldisp=MessageManager.getMessage('TOMS.COMMON.DISPFLAG.ALL_DISP');
	
	$bind.control_notcontrol=MessageManager.getMessage('TOMS.COMMON.CONTROL.SELECT.NOTCONTROL');
	$bind.control_control=MessageManager.getMessage('TOMS.COMMON.CONTROL.SELECT.CONTROL');
	$bind.control_all=MessageManager.getMessage('TOMS.COMMON.CONTROL.SELECT.ALL');


  $bind.dialogMessages = ({
    addConfirmTitle: MessageManager.getMessage('TOMS.COMMON.DIALOG.CONFIRM.TITLE'),
    addConfirmMessage: MessageManager.getMessage('TOMS.COMMON.DIALOG.CONFIRM.MESSAGE')
  }).toSource();

}

/**
 * 加工方法商品関連付けマスタメンテナンスのCSV出力処理
 * 
 * @param　リクエストパラメータ
 * 
 */
function outputCSV(param){
    load("toms/common/processMethod");
	var result = ProcessMethod.getProcessMethodCommodityList(param, false, null,null);
	var outputContent = "";
	if (!result.error) {
		outputContent = outputCSVHeader();
    	for(var i = 0; i < result.countRow; i++) {
    		outputContent += outputCSVRow(result.data[i]);
    	}
    	var strDate = DateTimeFormatter.format("yyyyMMdd_HHmmss", new Date());
    	var strUserName = Contexts.getUserContext().userProfile.userName;
    	var fileName = MessageManager.getMessage('TOMS.MASTER.MAINTENANCE.PROCESSMETHOD_COMMODITY.DETAIL.INPUT.TITLE') + '_' + strDate + '_' + strUserName + '.csv';
    	Module.download.send(Unicode.to(outputContent, 'MS932'), fileName, MessageManager.getMessage('TOMS.COMMON.MIME.CSV'));
	} else {
		error(result.errorMessage);
	}
}

/**
 * 加工方法商品関連付けマスタメンテナンスのCSVヘッダ部分出力処理。
 */
function outputCSVHeader() {
	var outputHeader = common.convert(MessageManager.getMessage('TOMS.COMMON.CSV.UPDATE.DIVIDE'), true)
	  + common.convert(MessageManager.getMessage('TOMS.MASTER.MAINTENANCE.PROCESSMETHOD_HEADER.LABEL.PROCESS_METHOD_CODE'), true)
	  + common.convert(MessageManager.getMessage('TOMS.MASTER.MAINTENANCE.COMMODITYSHAPE.LABEL.PARENT_COMMODITY_SHAPE_CODE'), true)
	  + common.convert(MessageManager.getMessage('TOMS.MASTER.MAINTENANCE.COMMODITYSHAPE.LABEL.COMMODITY_SHAPE_CODE'), true)
	  + common.convert(MessageManager.getMessage('TOMS.MASTER.MAINTENANCE.MATERIAL.LABEL.MATERIAL_CODE'), true)
	  + common.convert(MessageManager.getMessage('TOMS.MASTER.MAINTENANCE.PROCESSPART.LABEL.PROCESSPART_CODE'), true)
	  + common.convert(MessageManager.getMessage('TOMS.MASTER.MAINTENANCE.PROCESSPART.LABEL.PROCESSPART_POSITION_CODE'), true)
	  + common.convert(MessageManager.getMessage('TOMS.MASTER.MAINTENANCE.PROCESSMETHOD_HEADER.LABEL.PROCESS_METHOD_TPYE'), true)
	  + common.convert(MessageManager.getMessage('TOMS.MASTER.MAINTENANCE.PROCESSMETHOD_HEADER.LABEL.PROCESS_METHOD_DETAIL_TPYE'), true)
	  + common.convert(MessageManager.getMessage('TOMS.MASTER.MAINTENANCE.PROCESSMETHOD_COMMODITY.LABEL.COMMODITY_CODE'), true)
	  + common.convert(MessageManager.getMessage('TOMS.MASTER.MAINTENANCE.COMMODITYSHAPE.LABEL.APPLIED_START_DATE'), true)
	  + common.convert(MessageManager.getMessage('TOMS.MASTER.MAINTENANCE.COMMODITYSHAPE.LABEL.DELETE_FLG'), false)

	  return outputHeader;

}

/**
 * 加工方法商品関連付けマスタメンテナンスのCSVファイルの行を出力する処理
 * 
 * @param record DBから検索した行のデータ
 */
function outputCSVRow(record) {
	var result =  MessageManager.getMessage('TOMS.COMMON.CSV.SPLIT')
		    + common.convert(record["mpy57apmc"], true)
			+ common.convert(record["mpy57apcsc"], true)
			+ common.convert(record["mpy57acsc"], true)
			+ common.convert(record["mpy57amtc"], true)
			+ common.convert(record["mpy57appc1"], true)
			+ common.convert(record["mpy57appc2"], true)
			+ common.convert(record["mpy57apmt"], true)
			+ common.convert(record["mpy57apmdt"], true)
			+ common.convert(record["mpy57acc"], true)
			+ common.convert(record["mpeftj"], true)
			+ common.convert(record["mpy57adflg"]+"", false)
	return result;
	
}

function error(message) {
  Transfer.toErrorPage({
    title: MessageManager.getMessage('TOMS.COMMON.ERROR.PAGE.TITLE'),
    message: MessageManager.getMessage('TOMS.COMMON.ERROR.MESSAGE.SYSTEM'),
    detail: [MessageManager.getMessage('TOMS.MASTER.MAINTENANCE.PROCESSMETHOD_COMMODITY.LIST.LABEL.MESSAGE.ERROR'), message],
    returnUrl: 'toms/process_method_h/list/input', // 戻り先 URL
    returnUrlLabel: MessageManager.getMessage('TOMS.MASTER.MAINTENANCE.PROCESSMETHOD_COMMODITY.LIST.LABEL.RETURN.LINK.NAME'),
    parameter: {
    }
  });
}
