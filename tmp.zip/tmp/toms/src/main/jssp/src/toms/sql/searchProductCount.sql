SELECT
    COUNT(*) AS ROWCOUNT
FROM
(
	SELECT
		TRIM(IMLITM) AS IMLITM,
		IMITM,
		TRIM(IMDSC1) AS IMDSC1,
		TRIM(IMDSC2) AS IMDSC2
		FROM F4101
	/*BEGIN*/
	WHERE
		/*IF productCode != null*/
		TRIM(IMLITM) = /*productCode*/'%productCode%'
		/*END*/
		/*IF description1 != null*/
		AND TRIM(IMDSC1) like /*description1*/'%description1%'
		/*END*/
		/*IF description2 != null*/
		AND TRIM(IMDSC2) like /*description2*/'%description2%'
		/*END*/
	/*END*/
)
