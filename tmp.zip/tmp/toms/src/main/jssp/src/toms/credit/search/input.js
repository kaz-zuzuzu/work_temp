/**
 * バインド変数.
 */
var $bind = {};

/**
 * 初期表示.
 * @param request リクエストパラメータ.
 */
function init(request) {

	load("toms/common/master");
	
	// 上位組織のセレクトボックスの値を初期化.
	setSuperOrganizationData();
	// 組織のセレクトボックスの値を初期化.
	setOrganizationData();
	// 担当者のセレクトボックスの値を初期化
	setChargePersonData();
 
  // 与信超過のセレクトボックスの値を初期化.
  $bind.creditAmountOverSelectList = [{
      label : '全て',
      value : 'all',
      selected : true // 選択状態を設定する
    }, {
      label : '超過のみ',
      value : '0001'
    }];
  
  // 取引先種別
  $bind.searchExchangeTargetTypeList = [{//すべて、掛顧客、COD顧客
      label : '全て',
      value : ' ',
      selected : true // 選択状態を設定する
    }, {
      label : '掛顧客',
      value : 'Z'
    }, {
        label : 'COD顧客',
        value : 'Y'
  }];
  
  
  
  // 組織のプルダウンに表示されるのトップメッセージを初期化.
  // JavaScriptで利用するためオブジェクトの内容をそのまま渡します.
  $bind.organizationLabel = ({
	    selectTopMessage: MessageManager.getMessage('TOMS.COMMON.SELECT.LABEL.ORGANIZATION')
	  }).toSource();
}

/**
 * 上位組織情報を設定する処理
 * 
 */
function setSuperOrganizationData() {
	var result = TomsMaster.getSuperOrganizationList();
	if (!result.error) {
    	// 上位組織	 
    	$bind.superOrganizationSelectList = result.data;
	}
}

/**
 * 組織情報を設定する処理
 * 
 */
function setOrganizationData() {
	var result = TomsMaster.getOrganizationListByCode(' ');
	if (!result.error) {
    	// 組織	 
    	$bind.organizationSelectList = result.data;
	}
}

/**
 * 担当者情報を設定する処理
 */
function setChargePersonData(){
    var result = TomsMaster.getSalesChargePersonList(null);
    if(!result.error) {
        $bind.chargePersonSelectList = result.data;
    }
}

/**
 * 検索処理.
 * 
 * SSJSでリクエストパラメータの検証を行う場合は、
 * validateアノテーションでバリデーションファイルを指定します。
 * 検証はsearch関数の処理に入る前に実施されます。
 * バリデーションエラーをハンドリングしたい場合は、
 * onerrorアノテーションで関数名を指定することでエラー時の処理を追加することができます。
 * 
 * @param request リクエストパラメータ.
 * @validate toms/credit/search/search_validator#init
 * @onerror handleErrors
 */
function search(request) {

	// セッションに検索条件を設定する
    var obj = new Object();
    obj.workPlace = request.workPlace;
    obj.organization = request.organization;
    obj.exchangeTarget = request.exchangeTarget;
    obj.chargePerson = request.chargePerson;
    obj.retiredEmployee = request.retiredEmployee;
    obj.creditAmountOver = request.creditAmountOver;
    obj.debtAmount = request.debtAmount;
    obj.creditMaxAmount = request.creditMaxAmount;
    
    Client.set("creditManager", obj);
}

/**
 * validateアノテーションで指定したバリデーションを実行した結果、
 * エラーだった場合に呼び出される処理.
 * 
 * @param request リクエストパラメータ.
 * @param validationErrors バリデーションエラー.
 */
function handleErrors(request, validationErrors) {
  // なにも処理しない.
}

