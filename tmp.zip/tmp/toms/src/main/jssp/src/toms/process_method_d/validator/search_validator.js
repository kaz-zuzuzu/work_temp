/**
 * 加工方法明細マスタメンテナンス検索画面用validation設定
 */

 var init ={
		'search_mny57apmn1':{//第一階層名称
	 	caption:'TOMS.MASTER.MAINTENANCE.PROCESSMETHOD_DETAIL.LABEL.PROCESS_METHOD_NAME1',
		maxlength: 30
 		},	
		'search_mny57agn1':{//第一階層グループ名称
	 	caption:'TOMS.MASTER.MAINTENANCE.PROCESSMETHOD_DETAIL.LABEL.GROUP_NAME1',
		maxlength: 20
 		},	
		'search_mny57ado1':{//第一階層表示順
	 	caption:'TOMS.MASTER.MAINTENANCE.PROCESSMETHOD_DETAIL.LABEL.DISPLAY_ORDER1',
		numeric: true,
		maxlength: 8
 		},	
		'search_mny57ajc1':{//第一階層JDEコード
	 	caption:'TOMS.MASTER.MAINTENANCE.PROCESSMETHOD_DETAIL.LABEL.PROCESS_METHOD_NAME1',
		alphanumeric: true,
		maxlength: 8
 		},	
		'search_mny57apmn2':{//第2階層名称
	 	caption:'TOMS.MASTER.MAINTENANCE.PROCESSMETHOD_DETAIL.LABEL.PROCESS_METHOD_NAME2',
		maxlength: 30
 		},	
		'search_mny57agn2':{//第2階層グループ名称
	 	caption:'TOMS.MASTER.MAINTENANCE.PROCESSMETHOD_DETAIL.LABEL.GROUP_NAME2',
		maxlength: 20
 		},	
		'search_mny57ado2':{//第2階層表示順
	 	caption:'TOMS.MASTER.MAINTENANCE.PROCESSMETHOD_DETAIL.LABEL.DISPLAY_ORDER2',
		numeric: true,
		maxlength: 8
 		},	
		'search_mny57ajc2':{//第2階層JDEコード
	 	caption:'TOMS.MASTER.MAINTENANCE.PROCESSMETHOD_DETAIL.LABEL.PROCESS_METHOD_NAME2',
		alphanumeric: true,
		maxlength: 8
 		},	
		'search_mny57apmn3':{//第3階層名称
	 	caption:'TOMS.MASTER.MAINTENANCE.PROCESSMETHOD_DETAIL.LABEL.PROCESS_METHOD_NAME3',
		maxlength: 30
 		},	
		'search_mny57agn3':{//第3階層グループ名称
	 	caption:'TOMS.MASTER.MAINTENANCE.PROCESSMETHOD_DETAIL.LABEL.GROUP_NAME3',
		maxlength: 20
 		},	
		'search_mny57ado3':{//第3階層表示順
	 	caption:'TOMS.MASTER.MAINTENANCE.PROCESSMETHOD_DETAIL.LABEL.DISPLAY_ORDER3',
		numeric: true,
		maxlength: 8
 		},	
		'search_mny57ajc3':{//第3階層JDEコード
	 	caption:'TOMS.MASTER.MAINTENANCE.PROCESSMETHOD_DETAIL.LABEL.PROCESS_METHOD_NAME3',
		alphanumeric: true,
		maxlength: 8
 		},	
		'search_mny57apmn4':{//第4階層名称
	 	caption:'TOMS.MASTER.MAINTENANCE.PROCESSMETHOD_DETAIL.LABEL.PROCESS_METHOD_NAME4',
		maxlength: 30
 		},	
		'search_mny57agn4':{//第4階層グループ名称
	 	caption:'TOMS.MASTER.MAINTENANCE.PROCESSMETHOD_DETAIL.LABEL.GROUP_NAME4',
		maxlength: 20
 		},	
		'search_mny57ado4':{//第4階層表示順
	 	caption:'TOMS.MASTER.MAINTENANCE.PROCESSMETHOD_DETAIL.LABEL.DISPLAY_ORDER4',
		numeric: true,
		maxlength: 8
 		},	
		'search_mny57ajc4':{//第4階層JDEコード
	 	caption:'TOMS.MASTER.MAINTENANCE.PROCESSMETHOD_DETAIL.LABEL.PROCESS_METHOD_NAME4',
		alphanumeric: true,
		maxlength: 8
 		},	

 		//有効開始日 
	 	'search_mneftj':{
	 	caption:'TOMS.MASTER.MAINTENANCE.COMMODITYSHAPE.LABEL.APPLIED_START_DATE',
		date: true,
	    maxlength: 10
	 	}, 
 		//有効開始日2 
	 	'search_mneftj2':{
	 	caption:'TOMS.MASTER.MAINTENANCE.COMMODITYSHAPE.LABEL.APPLIED_START_DATE',
		date: true,
	    maxlength: 10
	 	}, 
	 	//有効終了日 
	 	'search_mnexdj':{
	 	caption:'TOMS.MASTER.MAINTENANCE.COMMODITYSHAPE.LABEL.APPLIED_END_DATE',
		date: true,
	    maxlength: 10
	 	}
 }