/**
 * 請求書照会詳細画面データ取得
 */

function getList(request){

	var page = (request == undefined) ? 1: request.page;
	var rows = (request == undefined ) ? 1500 : request.rowNum;

	var searchCondition = request.extension.searchCondition;
	
	load("toms/common/master");
	

	var result = TomsMaster.getRequestBillDetailCount(searchCondition.exchangeTargetCode, searchCondition.requestNo, searchCondition.searchCloseDate);
	if(result.error){
		return createErrorResult(MessageManager.getMessage('TOMS.BILL.LIST.LABEL.MESSAGE.ERROR'));
	}
	var total = result.data[0].rowcount;
	if(total ==0){
		return createResult(1,0,null);
	}
	
	page = Math.min(page, Math.ceil(total / rows));
	var start = (rows * (page -1)) + 1;//<Number
	var end = start + rows - 1;
	result = TomsMaster.getRequestBillDetail(searchCondition.exchangeTargetCode, searchCondition.requestNo, searchCondition.searchCloseDate,start, end, true);
	if (result.error) {
		return createErrorResult(MessageManager.getMessage('TOMS.BILL.LIST.LABEL.MESSAGE.ERROR'));
	}
	return createResult(page, total ,result.data);
}



function createResult(page, total, data){
	return{
		page : page == null? 1: page,
		total : total == null ? 0 :total,
		data : data == null ? [] :data
	}
}

function createErrorResult(message, details){
	return{
		error : true,
		errorMessage : message,
		detailMessages : details
	}
}