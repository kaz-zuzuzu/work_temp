/**
* staticオブジェクトの作成 
 */ 
load('toms/common/cmnUtil');
 var _SHARED_DB_KEY ="toms-web-dev";
function ProcessMethod(){};


/**
 * 加工方法ヘッダーマスタ一覧取得処理
 *
 **/
ProcessMethod.getHeaderList = function(params, countFlag ,paramStart, paramEnd ){
	var db = new SharedDatabase(_SHARED_DB_KEY);
	var mmy57apmc = isBlank(params.mmy57apmc) ? null : DbParameter.string(params.mmy57apmc);//加工方法コード
	var mmy57apcsc = isBlank(params.mmy57apcsc) ? null : DbParameter.string(params.mmy57apcsc);//親商品形態コード
	var mmy57acsc = isBlank(params.mmy57acsc) ? null : DbParameter.string(params.mmy57acsc);//商品形態コード
	var mmy57amtc = isBlank(params.mmy57amtc) ? null : DbParameter.string(params.mmy57amtc);//素材コード
	var mmy57appc1 = isBlank(params.mmy57appc1) ? null : DbParameter.string(params.mmy57appc1);//加工部位コード
	var mmy57appc2 = isBlank(params.mmy57appc2) ? null : DbParameter.string(params.mmy57appc2);//加工位置コード
	var mmy57ada = isBlank(params.mmy57ada) ? null : DbParameter.number(Number(params.mmy57ada));//階層数
	var mmy57asrt = isBlank(params.mmy57asrt) ? null : DbParameter.string(params.mmy57asrt);//特記事項
    var mmy57apmt=null; //加工方法区分
	if(!isBlank(params.mmy57apmt)){
		var aryData = params.mmy57apmt.split(',');
		mmy57apmt = [];
		for(var i=0; i < aryData.length; i++) {
			mmy57apmt.push(DbParameter.string(aryData[i]));
		}
	}
	var mmy57apmdt = isBlank(params.mmy57apmdt) ? null : DbParameter.string(params.mmy57apmdt);//加工方法明細区分
	var mmdl01 = isBlank(params.mmdl01) ? null : DbParameter.string("%"+params.mmdl01+"%");//加工方法名称
	var mmy57adflg = isBlank(params.mmy57adflg) ? null : DbParameter.number(Number(params.mmy57adflg));//削除フラグ
	var mmeftj = isBlank(params.mmeftj) ? null : DbParameter.number(cmnUtil.convertDateToJulia(new Date(params.mmeftj))); //適用開始日
	var mmeftj2 = isBlank(params.mmeftj2) ? null : DbParameter.number(cmnUtil.convertDateToJulia(new Date(params.mmeftj2))); //適用開始日
	var mmexdj = isBlank(params.mmexdj) ? null : DbParameter.number(cmnUtil.convertDateToJulia(new Date(params.mmexdj))); //適用終了日
	var result;
	if(countFlag){
		var objParam = {
		mmy57apmc : mmy57apmc,
		mmy57apcsc : mmy57apcsc,
		mmy57acsc : mmy57acsc,
		mmy57amtc : mmy57amtc,
		mmy57appc1 : mmy57appc1,
		mmy57appc2 : mmy57appc2,
		mmy57ada : mmy57ada,
		mmy57asrt : mmy57asrt,
		mmy57apmt : mmy57apmt,
		mmy57apmdt : mmy57apmdt,
		mmdl01 : mmdl01,
		mmy57adflg : mmy57adflg,
		mmeftj : mmeftj,
		mmeftj2 : mmeftj2,
		mmexdj : mmexdj
	};

	result = db.executeByTemplate('toms/sql/getProcessHeaderListCount', objParam);
				
	}else{
		var start = isBlank(paramStart) ? null : DbParameter.number(paramStart);
		var end =  isBlank(paramEnd) ? null : DbParameter.number(paramEnd);

		var objParam = {
			mmy57apmc : mmy57apmc,
			mmy57apcsc : mmy57apcsc,
			mmy57acsc : mmy57acsc,
			mmy57amtc : mmy57amtc,
			mmy57appc1 : mmy57appc1,
			mmy57appc2 : mmy57appc2,
			mmy57ada : mmy57ada,
			mmy57asrt : mmy57asrt,
			mmy57apmt : mmy57apmt,
			mmy57apmdt : mmy57apmdt,
			mmdl01 : mmdl01,
			mmy57adflg : mmy57adflg,
			mmeftj : mmeftj,
			mmeftj2 : mmeftj2,
			mmexdj : mmexdj,
			start : start,
			end : end
		};
				result = db.executeByTemplate('toms/sql/getProcessHeaderList', objParam);
	}
	return result;
}


/**
 * 加工方法明細マスタ一覧取得処理
 *
 **/
ProcessMethod.getDetailList = function(params, countFlag ,paramStart, paramEnd ){

	var db = new SharedDatabase(_SHARED_DB_KEY);
	//加工方法ヘッダーの検索キー
	var mny57apmc = isBlank(params.mny57apmc) ? null : DbParameter.string(params.mny57apmc);//加工方法コード

//	var mny57apcsc = isBlank(params.mny57apcsc) ? null : DbParameter.string(params.mny57apcsc);//親商品形態コード
//	var mny57acsc = isBlank(params.mny57acsc) ? null : DbParameter.string(params.mny57acsc);//商品形態コード
//	var mny57amtc = isBlank(params.mny57amtc) ? null : DbParameter.string(params.mny57amtc);//素材コード
//	var mny57appc1 = isBlank(params.mny57appc1) ? null : DbParameter.string(params.mny57appc1);//加工部位コード
//	var mny57appc2 = isBlank(params.mny57appc2) ? null : DbParameter.string(params.mny57appc2);//加工位置コード
//	var mny57ada = isBlank(params.mny57ada) ? null : DbParameter.number(Number(params.mny57ada));//階層数
//	var mny57asrt = isBlank(params.mny57asrt) ? null : DbParameter.string(params.mny57asrt);//特記事項
//    var mny57apmt=null; //加工方法区分
//	if(!isBlank(params.mny57apmt)){
//		var aryData = params.mny57apmt.split(',');
//		mny57apmt = [];
//		for(var i=0; i < aryData.length; i++) {
//			mny57apmt.push(DbParameter.string(aryData[i]));
//		}
//	}
//	var mny57apmdt = isBlank(params.mny57apmdt) ? null : DbParameter.string(params.mny57apmdt);//加工方法明細区分
//	var mndl01 = isBlank(params.mndl01) ? null : DbParameter.string("%"+params.mndl01+"%");//加工方法名称
	var mny57adflg = isBlank(params.mny57adflg) ? null : DbParameter.number(Number(params.mny57adflg));//削除フラグ
	
	var mneftj = isBlank(params.mneftj) ? null : DbParameter.number(cmnUtil.convertDateToJulia(new Date(params.mneftj))); //適用開始日
	var mneftj2 = isBlank(params.mneftj2) ? null : DbParameter.number(cmnUtil.convertDateToJulia(new Date(params.mneftj2))); //適用開始日
	var mnexdj = isBlank(params.mnexdj) ? null : DbParameter.number(cmnUtil.convertDateToJulia(new Date(params.mnexdj))); //適用終了日

    var mny57apmn1 = isBlank(params.mny57apmn1) ? null : DbParameter.string("%"+params.mny57apmn1+"%");//第1階層名称
    var mny57ado1  = isBlank(params.mny57ado1) ? null : DbParameter.number(Number(params.mny57ado1));//第1階層表示順
    var mny57ajc1  = isBlank(params.mny57ajc1) ? null : DbParameter.string(params.mny57ajc1);//第1階層JDEコード
    var mny57agn1  = isBlank(params.mny57agn1) ? null : DbParameter.string("%"+params.mny57agn1+"%");//第1階層グループ名称

    var mny57apmn2 = isBlank(params.mny57apmn2) ? null : DbParameter.string("%"+params.mny57apmn2+"%");//第2階層名称
    var mny57ado2  = isBlank(params.mny57ado2) ? null : DbParameter.number(Number(params.mny57ado2));//第2階層表示順
    var mny57ajc2  = isBlank(params.mny57ajc2) ? null : DbParameter.string(params.mny57ajc2);//第2階層JDEコード
    var mny57agn2  = isBlank(params.mny57agn2) ? null : DbParameter.string("%"+params.mny57agn2+"%");//第2階層グループ名称

    var mny57apmn3 = isBlank(params.mny57apmn3) ? null : DbParameter.string("%"+params.mny57apmn3+"%");//第3階層名称
    var mny57ado3  = isBlank(params.mny57ado3) ? null : DbParameter.number(Number(params.mny57ado3));//第3階層表示順
    var mny57ajc3  = isBlank(params.mny57ajc3) ? null : DbParameter.string(params.mny57ajc3);//第3階層JDEコード
    var mny57agn3  = isBlank(params.mny57agn3) ? null : DbParameter.string("%"+params.mny57agn3+"%");//第3階層グループ名称

    var mny57apmn4 = isBlank(params.mny57apmn4) ? null : DbParameter.string("%"+params.mny57apmn4+"%");//第4階層名称
    var mny57ado4  = isBlank(params.mny57ado4) ? null : DbParameter.number(Number(params.mny57ado4));//第4階層表示順
    var mny57ajc4  = isBlank(params.mny57ajc4) ? null : DbParameter.string(params.mny57ajc4);//第4階層JDEコード
    var mny57agn4  = isBlank(params.mny57agn4) ? null : DbParameter.string("%"+params.mny57agn4+"%");//第4階層グループ名称


	var result;
	if(countFlag){
		var objParam = {
		mny57apmc : mny57apmc,
		mny57apmn1 : mny57apmn1,
		mny57ado1 : mny57ado1,
		mny57ajc1 : mny57ajc1,
		mny57agn1 : mny57agn1,

		mny57apmn2 : mny57apmn2,
		mny57ado2 : mny57ado2,
		mny57ajc2 : mny57ajc2,
		mny57agn2 : mny57agn2,

		mny57apmn3 : mny57apmn3,
		mny57ado3 : mny57ado3,
		mny57ajc3 : mny57ajc3,
		mny57agn3 : mny57agn3,

		mny57apmn4 : mny57apmn4,
		mny57ado4 : mny57ado4,
		mny57ajc4 : mny57ajc4,
		mny57agn4 : mny57agn4,

		mny57adflg : mny57adflg,
		mneftj : mneftj,
		mneftj2 : mneftj2,
		mnexdj : mnexdj
	};

	result = db.executeByTemplate('toms/sql/getProcessDetailListCount', objParam);
				
	}else{
		var start = isBlank(paramStart) ? null : DbParameter.number(paramStart);
		var end =  isBlank(paramEnd) ? null : DbParameter.number(paramEnd);

		var objParam = {
			mny57apmc : mny57apmc,
//			mny57apcsc : mny57apcsc,
//			mny57acsc : mny57acsc,
//			mny57amtc : mny57amtc,
//			mny57appc1 : mny57appc1,
//			mny57appc2 : mny57appc2,
//			mny57ada : mny57ada,
//			mny57asrt : mny57asrt,
//			mny57apmt : mny57apmt,
//			mny57apmdt : mny57apmdt,
//			mndl01 : mndl01,

			mny57apmn1 : mny57apmn1,
			mny57ado1 : mny57ado1,
			mny57ajc1 : mny57ajc1,
			mny57agn1 : mny57agn1,

			mny57apmn2 : mny57apmn2,
			mny57ado2 : mny57ado2,
			mny57ajc2 : mny57ajc2,
			mny57agn2 : mny57agn2,

			mny57apmn3 : mny57apmn3,
			mny57ado3 : mny57ado3,
			mny57ajc3 : mny57ajc3,
			mny57agn3 : mny57agn3,

			mny57apmn4 : mny57apmn4,
			mny57ado4 : mny57ado4,
			mny57ajc4 : mny57ajc4,
			mny57agn4 : mny57agn4,

			mny57adflg : mny57adflg,


			mneftj : mneftj,
			mneftj2 : mneftj2,
			mnexdj : mnexdj,
			start : start,
			end : end
		};
				result = db.executeByTemplate('toms/sql/getProcessDetailList', objParam);
	}
	return result;
}




/**
 * 加工方法商品関連付けマスタ一覧取得処理
 *
 **/
ProcessMethod.getProcessMethodCommodityList = function(params, countFlag ,paramStart, paramEnd ){
	var db = new SharedDatabase(_SHARED_DB_KEY);
	//加工方法商品関連付けの検索キー
	var mpy57apmc = isBlank(params.mpy57apmc) ? null : DbParameter.string(params.mpy57apmc);//加工方法コード
	var mpy57acc = isBlank(params.mpy57acc) ? null : DbParameter.string(params.mpy57acc);//商品コード
	var mpy57adflg = isBlank(params.mpy57adflg) ? null : DbParameter.number(Number(params.mpy57adflg));//削除フラグ
	var mpeftj = isBlank(params.mpeftj) ? null : DbParameter.number(cmnUtil.convertDateToJulia(new Date(params.mpeftj))); //適用開始日
	var mpeftj2 = isBlank(params.mpeftj2) ? null : DbParameter.number(cmnUtil.convertDateToJulia(new Date(params.mpeftj2))); //適用開始日
	
	var result;
	if(countFlag){
		var objParam = {
			mpy57apmc :mpy57apmc,
			mpy57acc : mpy57acc,
			mpy57adflg : mpy57adflg,
			mpeftj : mpeftj,
			mpeftj2 : mpeftj2
		}
		
			result = db.executeByTemplate('toms/sql/getProcessMethodCommodityListCount', objParam);
			
	}else{
		
		var start = isBlank(paramStart) ? null : DbParameter.number(paramStart);
		var end =  isBlank(paramEnd) ? null : DbParameter.number(paramEnd);			

		var objParam = {
			mpy57apmc :mpy57apmc,
			mpy57acc : mpy57acc,
			mpy57adflg : mpy57adflg,
			mpeftj : mpeftj,
			mpeftj2 : mpeftj2,
			start : start,
			end : end
		}
	
			result = db.executeByTemplate('toms/sql/getProcessMethodCommodityList', objParam);
	}

	return result;
}

/**
 * 加工方法明細情報取得処理（STEP２）
 */

ProcessMethod.getDetailAllList = function(params, countFlag ,paramStart, paramEnd ){
	
	var db = new SharedDatabase(_SHARED_DB_KEY);
	//加工方法ヘッダーの検索キー
	var mny57apmc = isBlank(params.mny57apmc) ? null : DbParameter.string(params.mny57apmc);//加工方法コード

	var mndl01 = isBlank(params.mndl01) ? null : DbParameter.string("%"+params.mndl01+"%");//加工方法名称
	var mny57apcsc = isBlank(params.mny57apcsc) ? null : DbParameter.string(params.mny57apcsc);//親商品形態コード
	var mny57apcscName = isBlank(params.mny57apcscName) ? null : DbParameter.string("%"+params.mny57apcscName+"%");//親商品形態名称
	var mny57acsc = isBlank(params.mny57acsc) ? null : DbParameter.string(params.mny57acsc);//商品形態コード
	var mny57acscName = isBlank(params.mny57acscName) ? null : DbParameter.string("%"+params.mny57acscName+"%");//商品形態名称
	var mny57amtc = isBlank(params.mny57amtc) ? null : DbParameter.string(params.mny57amtc);//素材コード
	var mny57amtcName = isBlank(params.mny57amtcName) ? null : DbParameter.string("%"+params.mny57amtcName+"%");//原材料名
	var mny57appc1 = isBlank(params.mny57appc1) ? null : DbParameter.string(params.mny57appc1);//加工部位コード
	var mny57appc1Name = isBlank(params.mny57appc1Name) ? null : DbParameter.string("%"+params.mny57appc1Name+"%");//加工部位名称
	var mny57appc2 = isBlank(params.mny57appc2) ? null : DbParameter.string(params.mny57appc2);//加工位置コード
	var mny57appc2Name = isBlank(params.mny57appc2Name) ? null : DbParameter.string("%"+params.mny57appc2Name+"%");//加工位置名称
    var mny57apmt=null; //加工方法区分
	if(!isBlank(params.mny57apmt)){
		var aryData = params.mny57apmt.split(',');
		mny57apmt = [];
		for(var i=0; i < aryData.length; i++) {
			mny57apmt.push(DbParameter.string(aryData[i]));
		}
	}
	var mny57apmdt = null//加工方法明細区分
	if(!isBlank(params.mny57apmdt)){
		var aryData = params.mny57apmdt.split(',');
		mny57apmdt = [];
		for(var i=0; i < aryData.length; i++) {
			mny57apmdt.push(DbParameter.string(aryData[i]));
		}
	}
	var mny57adflg = isBlank(params.mny57adflg) ? null : DbParameter.number(Number(params.mny57adflg));//削除フラグ
	
	var mneftj = isBlank(params.mneftj) ? null : DbParameter.number(cmnUtil.convertDateToJulia(new Date(params.mneftj))); //適用開始日
	var mneftj2 = isBlank(params.mneftj2) ? null : DbParameter.number(cmnUtil.convertDateToJulia(new Date(params.mneftj2))); //適用開始日
	var mnexdj = isBlank(params.mnexdj) ? null : DbParameter.number(cmnUtil.convertDateToJulia(new Date(params.mnexdj))); //適用終了日

    var mny57apmn1 = isBlank(params.mny57apmn1) ? null : DbParameter.string("%"+params.mny57apmn1+"%");//第1階層名称
    var mny57ado1  = isBlank(params.mny57ado1) ? null : DbParameter.number(Number(params.mny57ado1));//第1階層表示順
    var mny57ajc1  = isBlank(params.mny57ajc1) ? null : DbParameter.string(params.mny57ajc1);//第1階層JDEコード
    var mny57agn1  = isBlank(params.mny57agn1) ? null : DbParameter.string("%"+params.mny57agn1+"%");//第1階層グループ名称

    var mny57apmn2 = isBlank(params.mny57apmn2) ? null : DbParameter.string("%"+params.mny57apmn2+"%");//第2階層名称
    var mny57ado2  = isBlank(params.mny57ado2) ? null : DbParameter.number(Number(params.mny57ado2));//第2階層表示順
    var mny57ajc2  = isBlank(params.mny57ajc2) ? null : DbParameter.string(params.mny57ajc2);//第2階層JDEコード
    var mny57agn2  = isBlank(params.mny57agn2) ? null : DbParameter.string("%"+params.mny57agn2+"%");//第2階層グループ名称

    var mny57apmn3 = isBlank(params.mny57apmn3) ? null : DbParameter.string("%"+params.mny57apmn3+"%");//第3階層名称
    var mny57ado3  = isBlank(params.mny57ado3) ? null : DbParameter.number(Number(params.mny57ado3));//第3階層表示順
    var mny57ajc3  = isBlank(params.mny57ajc3) ? null : DbParameter.string(params.mny57ajc3);//第3階層JDEコード
    var mny57agn3  = isBlank(params.mny57agn3) ? null : DbParameter.string("%"+params.mny57agn3+"%");//第3階層グループ名称

	var result;
	if(countFlag){
		var objParam = {
		                mny57apmc :mny57apmc,
			mndl01: mndl01,
		mny57apcsc : mny57apcsc,
		mny57apcscName : mny57apcscName,
		mny57acsc : mny57acsc,
		mny57acscName : mny57acscName,
		mny57amtc : mny57amtc,
		mny57amtcName : mny57amtcName,
		mny57appc1 : mny57appc1,
		mny57appc1Name : mny57appc1Name,
		mny57appc2: mny57appc2,
		mny57appc2Name : mny57appc2Name,
		mny57apmt : mny57apmt,
		mny57apmdt: mny57apmdt,

		mny57apmn1 : mny57apmn1,
		mny57ado1 : mny57ado1,
		mny57ajc1 : mny57ajc1,
		mny57agn1 : mny57agn1,

		mny57apmn2 : mny57apmn2,
		mny57ado2 : mny57ado2,
		mny57ajc2 : mny57ajc2,
		mny57agn2 : mny57agn2,

		mny57apmn3 : mny57apmn3,
		mny57ado3 : mny57ado3,
		mny57ajc3 : mny57ajc3,
		mny57agn3 : mny57agn3,

		mny57adflg : mny57adflg,
		mneftj : mneftj,
		mneftj2 : mneftj2,
		mnexdj : mnexdj
	};

	result = db.executeByTemplate('toms/sql/getProcessDetailAllListCount', objParam);
	}else{
		var start = isBlank(paramStart) ? null : DbParameter.number(paramStart);
		var end =  isBlank(paramEnd) ? null : DbParameter.number(paramEnd);

		var objParam = {
            mny57apmc :mny57apmc,
			mndl01: mndl01,
		mny57apcsc : mny57apcsc,
		mny57apcscName : mny57apcscName,
		mny57acsc : mny57acsc,
		mny57acscName : mny57acscName,
		mny57amtc : mny57amtc,
		mny57amtcName : mny57amtcName,
		mny57appc1 : mny57appc1,
		mny57appc1Name : mny57appc1Name,
		mny57appc2: mny57appc2,
		mny57appc2Name : mny57appc2Name,
		mny57apmt : mny57apmt,
		mny57apmdt: mny57apmdt,


		mny57apmn1 : mny57apmn1,
		mny57ado1 : mny57ado1,
		mny57ajc1 : mny57ajc1,
		mny57agn1 : mny57agn1,

		mny57apmn2 : mny57apmn2,
		mny57ado2 : mny57ado2,
		mny57ajc2 : mny57ajc2,
		mny57agn2 : mny57agn2,

		mny57apmn3 : mny57apmn3,
		mny57ado3 : mny57ado3,
		mny57ajc3 : mny57ajc3,
		mny57agn3 : mny57agn3,

		mny57adflg : mny57adflg,
		mneftj : mneftj,
		mneftj2 : mneftj2,
		mnexdj : mnexdj,
			start : start,
			end : end
		};
				result = db.executeByTemplate('toms/sql/getProcessDetailAllList', objParam);
	}
	return result;
}



/**
 * 加工方法商品関連付けマスタ一覧取得処理(STEP2)
 *
 **/
ProcessMethod.getProcessMethodCommodityAllList = function(params, countFlag ,paramStart, paramEnd ){
	var db = new SharedDatabase(_SHARED_DB_KEY);
	//加工方法ヘッダーの検索キー
	var mpy57apmc = isBlank(params.mpy57apmc) ? null : DbParameter.string(params.mpy57apmc);//加工方法コード

	var mpdl01 = isBlank(params.mpdl01) ? null : DbParameter.string("%"+params.mpdl01+"%");//加工方法名称
	var mpy57apcsc = isBlank(params.mpy57apcsc) ? null : DbParameter.string(params.mpy57apcsc);//親商品形態コード
	var mpy57apcscName = isBlank(params.mpy57apcscName) ? null : DbParameter.string("%"+params.mpy57apcscName+"%");//親商品形態名称
	var mpy57acsc = isBlank(params.mpy57acsc) ? null : DbParameter.string(params.mpy57acsc);//商品形態コード
	var mpy57acscName = isBlank(params.mpy57acscName) ? null : DbParameter.string("%"+params.mpy57acscName+"%");//商品形態名称
	var mpy57amtc = isBlank(params.mpy57amtc) ? null : DbParameter.string(params.mpy57amtc);//素材コード
	var mpy57amtcName = isBlank(params.mpy57amtcName) ? null : DbParameter.string("%"+params.mpy57amtcName+"%");//原材料名
	var mpy57appc1 = isBlank(params.mpy57appc1) ? null : DbParameter.string(params.mpy57appc1);//加工部位コード
	var mpy57appc1Name = isBlank(params.mpy57appc1Name) ? null : DbParameter.string("%"+params.mpy57appc1Name+"%");//加工部位名称
	var mpy57appc2 = isBlank(params.mpy57appc2) ? null : DbParameter.string(params.mpy57appc2);//加工位置コード
	var mpy57appc2Name = isBlank(params.mpy57appc2Name) ? null : DbParameter.string("%"+params.mpy57appc2Name+"%");//加工位置名称
    var mpy57apmt=null; //加工方法区分
	if(!isBlank(params.mpy57apmt)){
		var aryData = params.mpy57apmt.split(',');
		mpy57apmt = [];
		for(var i=0; i < aryData.length; i++) {
			mpy57apmt.push(DbParameter.string(aryData[i]));
		}
	}
	var mpy57apmdt = null//加工方法明細区分
	if(!isBlank(params.mpy57apmdt)){
		var aryData = params.mpy57apmdt.split(',');
		mpy57apmdt = [];
		for(var i=0; i < aryData.length; i++) {
			mpy57apmdt.push(DbParameter.string(aryData[i]));
		}
	}
	var mpy57adflg = isBlank(params.mpy57adflg) ? null : DbParameter.number(Number(params.mpy57adflg));//削除フラグ

	
	var mpeftj = isBlank(params.mpeftj) ? null : DbParameter.number(cmnUtil.convertDateToJulia(new Date(params.mpeftj))); //適用開始日
	var mpeftj2 = isBlank(params.mpeftj2) ? null : DbParameter.number(cmnUtil.convertDateToJulia(new Date(params.mpeftj2))); //適用開始日
	var mpexdj = isBlank(params.mpexdj) ? null : DbParameter.number(cmnUtil.convertDateToJulia(new Date(params.mpexdj))); //適用終了日

    var mpy57acc  = isBlank(params.mpy57acc) ? null : DbParameter.string(params.mpy57acc);//商品コード


	var result;
	if(countFlag){
		var objParam = {
		mpy57apmc :mpy57apmc,
		mpdl01: mpdl01,
		mpy57apcsc : mpy57apcsc,
		mpy57apcscName : mpy57apcscName,
		mpy57acsc : mpy57acsc,
		mpy57acscName : mpy57acscName,
		mpy57amtc : mpy57amtc,
		mpy57amtcName : mpy57amtcName,
		mpy57appc1 : mpy57appc1,
		mpy57appc1Name : mpy57appc1Name,
		mpy57appc2: mpy57appc2,
		mpy57appc2Name : mpy57appc2Name,
		mpy57apmt : mpy57apmt,
		mpy57apmdt: mpy57apmdt,

		mpy57acc : mpy57acc,

		mpy57adflg : mpy57adflg,
		mpeftj : mpeftj,
		mpeftj2 : mpeftj2,
		mpexdj : mpexdj
	};

	result = db.executeByTemplate('toms/sql/getProcessMethodCommodityAllListCount', objParam);
				
	}else{
		var start = isBlank(paramStart) ? null : DbParameter.number(paramStart);
		var end =  isBlank(paramEnd) ? null : DbParameter.number(paramEnd);

		var objParam = {
            mpy57apmc :mpy57apmc,
			mpdl01: mpdl01,
		mpy57apcsc : mpy57apcsc,
		mpy57apcscName : mpy57apcscName,
		mpy57acsc : mpy57acsc,
		mpy57acscName : mpy57acscName,
		mpy57amtc : mpy57amtc,
		mpy57amtcName : mpy57amtcName,
		mpy57appc1 : mpy57appc1,
		mpy57appc1Name : mpy57appc1Name,
		mpy57appc2: mpy57appc2,
		mpy57appc2Name : mpy57appc2Name,
		mpy57apmt : mpy57apmt,
		mpy57apmdt: mpy57apmdt,
		mpy57acc : mpy57acc,
		mpy57adflg : mpy57adflg,
		mpeftj : mpeftj,
		mpeftj2 : mpeftj2,
		mpexdj : mpexdj,
			start : start,
			end : end
		};
				result = db.executeByTemplate('toms/sql/getProcessMethodCommodityAllList', objParam);
	}
	return result;
}