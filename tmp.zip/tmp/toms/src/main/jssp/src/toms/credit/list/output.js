/**
 * バインド変数.
 */
var $bind = {};

var $data = {};


/**
 * 初期表示.
 * @param request リクエストパラメータ.
 */
function init(request) {
	
    var organization            = request.organization;				// 組織 
    	if(organization == ' ') { organization = null;}
    var searchExchangeTargetType = request.searchExchangeTargetType; //取引先種別
    	if(searchExchangeTargetType == ' ') { searchExchangeTargetType = null;}
    var searchExchangeTargetId  = request.searchExchangeTargetId;	// 取引先コード 
    var exchangeTargetKn        = request.exchangeTargetKn;			// 取引先カナ 
    var chargePerson            = request.chargePerson;				// 担当者コード
    	if(isUndefined(chargePerson) || chargePerson == " " ) { 
    		chargePerson = null;
    	}
    var chargePersonText        = request.chargePersonText;			// 担当者カナ 
    	if(isUndefined(chargePersonText) || chargePersonText == "") {
    		chargePersonText = null;
    	}
    var creditAmountOver        = request.creditAmountOver;			// 与信超過 

	setData(organization,
			searchExchangeTargetType,
			searchExchangeTargetId,
			exchangeTargetKn,
			chargePerson,
			chargePersonText,
			creditAmountOver);
	
	// 検索条件（画面表示用）
    // .上位組織
    $bind.superOrganizationNm = request.superOrganizationNm;
    // .組織
    $bind.organizationNm = request.organizationNm;
    // .取引先種別
    $bind.searchExchangeTargetTypeNm = request.searchExchangeTargetTypeNm;    
    // .取引先コード
    $bind.searchExchangeTargetId = searchExchangeTargetId;
    // .取引先カナ
    $bind.exchangeTargetKn = exchangeTargetKn;
    // 担当者(リスト)
    $bind.chargePersonNm = request.chargePersonNm;
    // 担当者カナ
    $bind.chargePersonText = request.chargePersonText;
    // 与信超過
    $bind.creditAmountOverNm = request.creditAmountOverNm;

    // ページング
	$data = {
		rowNum  : 50,
		rowList : [50, 100, 150]
	};
}

/**
 * データ設定
 * @param organization            組織
 * @param searchExchangeTargetType  取引先種別
 * @param searchExchangeTargetId  取引先コード
 * @param exchangeTargetKn        取引先カナ
 * @param chargePerson            担当者コード
 * @param chargePersonText        担当者カナ
 * @param creditAmountOver        与信超過
 */
function setData(organization,
			searchExchangeTargetType,
			searchExchangeTargetId,
			exchangeTargetKn,
			chargePerson,
			chargePersonText,
			creditAmountOver){

	load("toms/common/master");

	var result = TomsMaster.geCreditList(
		organization,
		searchExchangeTargetType,
		searchExchangeTargetId,
		exchangeTargetKn,
		chargePerson,
		chargePersonText,
		creditAmountOver);
	var rsltData = [];
	if (!result.error) {
		$bind.listData = result.data;
	}
	//Debug.browse(result.data);
}

/**
 * validateアノテーションで指定したバリデーションを実行した結果、
 * エラーだった場合に呼び出される処理.
 * 
 * @param request リクエストパラメータ.
 * @param validationErrors バリデーションエラー.
 */
function handleErrors(request, validationErrors) {
  // なにも処理しない.
}
