    SELECT MN.MNY57APMC
           ,MN.MNY57APMN1
           ,MN.MNY57ADO1
           ,MN.MNY57AJC1
           ,MN.MNY57AGN1
           ,MN.MNY57APMN2
           ,MN.MNY57ADO2
           ,MN.MNY57AJC2
           ,MN.MNY57AGN2
           ,MN.MNY57APMN3
           ,MN.MNY57ADO3
           ,MN.MNY57AJC3
           ,MN.MNY57AGN3
           ,MN.MNY57APMN4
           ,MN.MNY57ADO4
           ,MN.MNY57AJC4
           ,MN.MNY57AGN4
           ,MN.MNY57APMN5
           ,MN.MNY57ADO5
           ,MN.MNY57AJC5
           ,MN.MNY57AGN5
           ,MN.MNY57AHFLG
           ,MN.MNEFTJ
           ,MN.MNEXDJ
           ,MN.MNY57ADFLG
           ,MN.MNURCD
           ,MN.MNURDT
           ,MN.MNURAT
           ,MN.MNURAB
           ,MN.MNURRF
           ,MN.MNUSER
           ,MN.MNPID
           ,MN.MNJOBN
           ,MN.MNUPMJ
           ,MN.MNUPMT
           ,MN.MNY57APSH
           ,MN.MNY57APSW
           ,MN.MNY57APCSC
           ,MN.MNY57ACSC
           ,MN.MNY57AMTC
           ,MN.MNY57APPC1
           ,MN.MNY57APPC2
           ,MN.MNY57APMT
           ,MN.MNY57APMDT
      FROM F57A5141 MN
   /*BEGIN*/
     WHERE
     /*IF mny57apcsc !=null */
       AND TRIM(MN.MNY57APCSC) = /*mny57apcsc*/
     /*END*/
     /*IF mny57acsc !=null */
       AND TRIM(MN.MNY57ACSC) = /*mny57acsc*/
     /*END*/
     /*IF mny57amtc !=null */
       AND TRIM(MN.MNY57AMTC) = /*mny57amtc*/
     /*END*/
     /*IF mny57appc1 !=null */
       AND TRIM(MN.MNY57APPC1) = /*mny57appc1*/
     /*END*/
     /*IF mny57appc2 !=null */
       AND TRIM(MN.MNY57APPC2) = /*mny57appc2*/
     /*END*/
     /*IF mny57apmt !=null */
       AND TRIM(MN.MNY57APMT) = /*mny57apmt*/
     /*END*/
     /*IF mny57apmdt !=null */
       AND TRIM(MN.MNY57APMDT) = /*mny57apmdt*/
     /*END*/
     /*IF mny57ajc1 !=null */
       AND TRIM(MN.MNY57AJC1) = /*mny57ajc1*/
     /*END*/
     /*IF mny57ajc2 !=null */
       AND TRIM(MN.MNY57AJC2) = /*mny57ajc2*/
     /*END*/
     /*IF mny57ajc3 !=null */
       AND TRIM(MN.MNY57AJC3) = /*mny57ajc3*/
     /*END*/
   /*END*/
