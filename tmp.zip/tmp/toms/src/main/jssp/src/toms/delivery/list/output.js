/**
 * バインド変数.
 */
var $bind = {};

var $data = {};

load("toms/common/delivery");
load("toms/common/common");

var splitComma = MessageManager.getMessage('TOMS.COMMON.COMMA');

/**
 * 初期表示.
 * @param request リクエストパラメータ.
 */
function init(request) {
	$data = {
		pageNum : isBlank(request.pageNum) ? '1' : request.pageNum,
		rowNum  : isBlank(request.rowNum) ? '30' : request.rowNum,
		rowList : isBlank(request.rowList) ? '30, 50, 100' : request.rowList
	};

	// CSV出力処理の場合
	if (request.screenId == "outputCSV") {
		var stockPositionList = request.csv_stockPositionList;	// 在庫場所
		var superOrganization = request.csv_superOrganization;	// 上位組織
		var organization = request.csv_organization;			// 組織
		var receiveOrderNo = request.csv_receiveOrderNo;		// オーダーNo
		var orderTypeList = request.csv_orderTypeList;			// オーダータイプ
		var instructNo = request.csv_instructNo;				// 出荷予定番号
		var destination = request.csv_destination;				// 納入先
		var exchangeTarget = request.csv_exchangeTarget;		// 取引先カナ
		var deliveryDateFrom = request.csv_deliveryDateFrom;	// 出庫日付開始日
		var deliveryDateTo = request.csv_deliveryDateTo;		// 出庫日付終了日
		
		outputCSV(stockPositionList, organization, receiveOrderNo, orderTypeList, instructNo, destination, exchangeTarget, deliveryDateFrom, deliveryDateTo);
	} else {
		$bind.stockPositionList = request.stockPositionList;		//在庫場所
		$bind.superOrganization = request.superOrganization;		//上位組織
		$bind.superOrganizationNm = request.superOrganizationNm;	//上位組織名称
		$bind.organization = request.organization;					//組織
		$bind.organizationNm = request.organizationNm;				//組織名称
		$bind.receiveOrderNo = request.receiveOrderNo;				//オーダーNo
		$bind.orderTypeList = request.orderTypeList;				//オーダータイプ
		$bind.orderTypeListNm = request.orderTypeListNm;			//オーダータイプ名称
		$bind.instructNo = request.instructNo;						//出荷予定番号
		$bind.destination = request.destination;					//納入先
		$bind.exchangeTarget = request.exchangeTarget;				//取引先カナ
		$bind.deliveryDateFrom = request.deliveryDateFrom;			//出庫日付開始日
		$bind.deliveryDateTo = request.deliveryDateTo;				//出庫日付終了日
		$bind.frontToSymbol = (isBlank(request.deliveryDateFrom) && isBlank(request.deliveryDateTo) ) ? "" :MessageManager.getMessage('TOMS.COMMON.FROMTO.SYMBOL');
		
		// 出庫一覧の「ファイル出力」ボタン押下時の確認ダイアログのメッセージを初期化.
		// JavaScriptで利用するためオブジェクトの内容をそのまま渡します.
		$bind.dialogMessages = ({
			addConfirmTitle: MessageManager.getMessage('TOMS.COMMON.DIALOG.CONFIRM.TITLE'),
			addConfirmMessage: MessageManager.getMessage('TOMS.COMMON.DIALOG.CONFIRM.MESSAGE.COMMA')
		}).toSource();
	}
}

function outputCSV(stockPositionList, organization, receiveOrderNo, orderTypeList, instructNo, destination, exchangeTarget, deliveryDateFrom, deliveryDateTo) {
	var result = Delivery.getDeliveryItemList(stockPositionList, organization, receiveOrderNo, orderTypeList, instructNo, destination, exchangeTarget, deliveryDateFrom, deliveryDateTo);
	var outputContent = "";
	if (!result.error) {
		outputContent = outputCSVHeader();
		for (var i = 0; i < result.countRow; i++) {
			outputContent += outputCSVRow(result.data[i]);
		}
		var strDateTime = DateTimeFormatter.format("yyyyMMddHHmmss", new Date());
		var fileName = MessageManager.getMessage('TOMS.DELIVERY.SEARCH.OUTPUT.TITLE') + '_' + strDateTime + '.csv';
		Module.download.send(Unicode.to(outputContent, 'MS932'), fileName, MessageManager.getMessage('TOMS.COMMON.MIME.CSV'));
	} else {
		errorcsv(result.errorMessage);
	}
}

/**
 * 出庫一覧のCSVヘッダ部分出力処理.
 */
function outputCSVHeader() {
    var outputHeader = common.convertWithSplit(MessageManager.getMessage('TOMS.DELIVERY.SEARCH.INPUT.DELIVERY.DATE'), splitComma, true)					// 出庫日付
                       + common.convertWithSplit(MessageManager.getMessage('TOMS.DELIVERY.LIST.OUTPUT.PROCESSED_OR_NOTPROCESSED'), splitComma, true)	// 加工/無地区分
                       + common.convertWithSplit(MessageManager.getMessage('TOMS.DELIVERY.SEARCH.INPUT.INSTRUCT_NO'), splitComma, true)   				// 出荷予定番号
                       + common.convertWithSplit(MessageManager.getMessage('TOMS.DELIVERY.SEARCH.INPUT.RECEIVEORDER.NO'), splitComma, true)  			// オーダーNo
                       + common.convertWithSplit(MessageManager.getMessage('TOMS.DELIVERY.SEARCH.INPUT.ORDERTYPE'), splitComma, true)  					// オーダータイプ
                       + common.convertWithSplit(MessageManager.getMessage('TOMS.DELIVERY.LIST.OUTPUT.EXCHANGETARGET'), splitComma, true)  					// 取引先
                       + common.convertWithSplit(MessageManager.getMessage('TOMS.DELIVERY.SEARCH.INPUT.DELIVERY_DESTINATION'), splitComma, true)  		// 納入先
                       + common.convertWithSplit(MessageManager.getMessage('TOMS.DELIVERY.LIST.OUTPUT.SHIPPINGCOMPANY'), splitComma, true)  			// 運送会社
                       + common.convertWithSplit(MessageManager.getMessage('TOMS.DELIVERY.LIST.OUTPUT.NUMBER_OF_PROVEN'), splitComma, true)  			// 実績数
                       + common.convertWithSplit(MessageManager.getMessage('TOMS.DELIVERY.LIST.OUTPUT.PIECES'), splitComma, true)  						// 個口数
                       + common.convertWithSplit(MessageManager.getMessage('TOMS.DELIVERY.LIST.OUTPUT.BLAND.NAME'), splitComma, true)  						// 柄名
                       + common.convertWithSplit(MessageManager.getMessage('TOMS.DELIVERY.LIST.OUTPUT.ORDERNUMBER_OF_SALESCONTACT'), splitComma, true)	// 販売先発注番号
                       + common.convertWithSplit(MessageManager.getMessage('TOMS.DELIVERY.LIST.OUTPUT.STATUS'), splitComma, false)  					// 状況
	return outputHeader;
}

/**
 * 出庫一覧のCSVファイルの行を出力する処理.
 * 
 * @param record DBから検索した行のデータ.
 */
function outputCSVRow(record) {
    var tfsoqs = new String(record["tfsoqs"]).replace( /,/g, "" );		// ⇒実績数にカンマがある場合は削除
    var tdy57cyk = new String(record["tdy57cyk"]).replace( /,/g, "" );	// ⇒個口数にカンマがある場合は削除
    var result = common.convertWithSplit(record["tdaddj"], splitComma, true)		// 出庫日付
                 + common.convertWithSplit(record["tadcto2"], splitComma, true)		// 加工/無地区分
                 + common.convertWithSplit(record["tdy57ashpn"], splitComma, true)	// 出荷予定番号
                 + common.convertWithSplit(record["tddoco"], splitComma, true)		// オーダーNo
                 + common.convertWithSplit(record["tddcto"], splitComma, true)		// オーダータイプ
                 + common.convertWithSplit(record["abalph"], splitComma, true)		// 取引先
                 + common.convertWithSplit(record["tdalph"], splitComma, true)		// 納入先
                 + common.convertWithSplit(record["drdl"], splitComma, true)		// 運送会社
                 + common.convertWithSplit(tfsoqs, splitComma, true)				// 実績数
                 + common.convertWithSplit(tdy57cyk, splitComma, true)				// 個口数
                 + common.convertWithSplit(record["tdy57ahrmk"], splitComma, true)	// 柄名
                 + common.convertWithSplit(record["tdvr01"], splitComma, true)		// 販売先発注番号
                 + common.convertWithSplit(record["tdy57ashps"], splitComma, false)	// 状況
    return result;
}

/**
 * エラー画面へ遷移の処理.
 */
function error(message) {
  Transfer.toErrorPage({
    title: MessageManager.getMessage('TOMS.COMMON.ERROR.PAGE.TITLE'),
    message: MessageManager.getMessage('TOMS.COMMON.ERROR.MESSAGE.SYSTEM'),
    detail: [MessageManager.getMessage('TOMS.DELIVERY.LIST.LABEL.MESSAGE.ERROR'), message],
    returnUrl: 'toms/delivery/search/input', // 戻り先 URL
    returnUrlLabel: MessageManager.getMessage('TOMS.DELIVERY.LIST.LABEL.RETURN.LINK.NAME'),
    parameter: {
    }
  });
}

// エラーページ
function errorcsv(message) {
  Transfer.toErrorPage({
    title: MessageManager.getMessage('TOMS.COMMON.ERROR.PAGE.TITLE'),
    message: MessageManager.getMessage('TOMS.COMMON.ERROR.MESSAGE.SYSTEM'),
    detail: [MessageManager.getMessage('TOMS.DELIVERY.LIST.LABEL.CSV.MESSAGE.ERROR'), message],
    returnUrl: 'toms/delivery/list/output', // 戻り先 URL
    returnUrlLabel: MessageManager.getMessage('TOMS.DELIVERY.LIST.LABEL.CSV.RETURN.LINK.NAME'),
    parameter: {
    }
  });
}
