/**
 * 検索画面validation設定
 */
var init = {
  'manufacturer': { // バリデーション対象のformのname属性を指定する.
    caption: 'TOMS.STOCK.SEARCH.INPUT.MANUFACTURER', // キャプションのメッセージキーを指定する. 
    required: true, // 必須チェック
    alphanumeric: true, // 数字チェック
    minlength: 2,
    maxlength: 2
  },
  'productCode': { // バリデーション対象のformのname属性を指定する.
	  caption: 'TOMS.STOCK.SEARCH.INPUT.PRODUCT.ITEM', // キャプションのメッセージキーを指定する. 
	  required: true, // 必須チェック
	  alphanumeric: true, // 数字チェック
	  minlength: 5,
	  maxlength: 5
   }
};