/**
 * 入力画面validation設定
 */
var init = {

  // 支払人No
  'mapyr': { // バリデーション対象のformのname属性を指定する.
    caption: 'TOMS.PAYMENT.DETAIL.LABEL.MAPYR', // キャプションのメッセージキーを指定する. 
    required: true,
	numeric: true,
	maxlength: 8
  },
  //通貨コード
  'macrcd': { // バリデーション対象のformのname属性を指定する.
    caption: 'TOMS.PAYMENT.DETAIL.LABEL.MACRCD', // キャプションのメッセージキーを指定する. 
    required: true,
	maxlength: 3
  },
  //閾値（円）
  'may56cathr': { // バリデーション対象のformのname属性を指定する.
    caption: 'TOMS.PAYMENT.DETAIL.LABEL.MAY56CATHR', // キャプションのメッセージキーを指定する. 
    required: true,
    decimal: true,
    digits: [15,2]
  },
  //受取 割合（％）
  'may56crper': { // バリデーション対象のformのname属性を指定する.
    caption: 'TOMS.PAYMENT.DETAIL.LABEL.MAY56CRPER', // キャプションのメッセージキーを指定する. 
    //required: true,
    decimal: true,
    digits: [9,3]
  },
  //受取 金額
  'may56carec': { // バリデーション対象のformのname属性を指定する.
    caption: 'TOMS.PAYMENT.DETAIL.LABEL.MAY56CAREC', // キャプションのメッセージキーを指定する. 
    //required: true,
    decimal: true,
    digits: [15,2]
  }, 
  //取引 区分1
  'may56cryi1': { // バリデーション対象のformのname属性を指定する.
    caption: 'TOMS.PAYMENT.DETAIL.LABEL.MAY56CRYI1', // キャプションのメッセージキーを指定する. 
    required: true
  }, 
  //取引 条件1
  'may56ctra1': { // バリデーション対象のformのname属性を指定する.
    caption: 'TOMS.PAYMENT.DETAIL.LABEL.MAY56CTRA1', // キャプションのメッセージキーを指定する. 
    required: true,
    alphanumeric: true,
	maxlength: 3
  }, 
  //取引 区分2
  'may56cryi2': { // バリデーション対象のformのname属性を指定する.
    caption: 'TOMS.PAYMENT.DETAIL.LABEL.MAY56CRYI2'// キャプションのメッセージキーを指定する. 
  },
  //支払 条件2 支払 条件1をコピーするためチェック不要
  //'may56ctra2': { // バリデーション対象のformのname属性を指定する.
  //  caption: 'TOMS.PAYMENT.DETAIL.LABEL.MAY56CTRA2', // キャプションのメッセージキーを指定する. 
  //	maxlength: 3
  //},  
  //超過受取 割合（％）
  'may56cerpe': { // バリデーション対象のformのname属性を指定する.
    caption: 'TOMS.PAYMENT.DETAIL.LABEL.MAY56CERPE', // キャプションのメッセージキーを指定する. 
	decimal: true,
    digits: [9,3]
  },
  //超過受取 金額
  'may56ceare': { // バリデーション対象のformのname属性を指定する.
    caption: 'TOMS.PAYMENT.DETAIL.LABEL.MAY56CEARE', // キャプションのメッセージキーを指定する. 
	decimal: true,
    digits: [15,2]
  },
  //超過取引 区分1
  'may56cery1': { // バリデーション対象のformのname属性を指定する.
    caption: 'TOMS.PAYMENT.DETAIL.LABEL.MAY56CERY1' // キャプションのメッセージキーを指定する. 
  },
  //超過取引 条件1 支払 条件1をコピーするためチェック不要
  //'may56cetr1': { // バリデーション対象のformのname属性を指定する.
  //  caption: 'TOMS.PAYMENT.DETAIL.LABEL.MAY56CETR1', // キャプションのメッセージキーを指定する. 
  //  maxlength: 3
  //},  
  //超過取引 区分2
  'may56cery2': { // バリデーション対象のformのname属性を指定する.
    caption: 'TOMS.PAYMENT.DETAIL.LABEL.MAY56CERY2' // キャプションのメッセージキーを指定する. 
  },
  //超過支払 条件2 支払 条件1をコピーするためチェック不要
  //'may56cetr2': { // バリデーション対象のformのname属性を指定する.
  //  caption: 'TOMS.PAYMENT.DETAIL.LABEL.MAY56CETR2', // キャプションのメッセージキーを指定する. 
  //  maxlength: 3
  //}
  //支払条件
  'maurrf': { // バリデーション対象のformのname属性を指定する.
    caption: 'TOMS.PAYMENT.DETAIL.LABEL.PAYMENTCONDITION', // キャプションのメッセージキーを指定する. 
    maxlength: 15
  }
};

var del = {
	  // 支払人No
	  'mapyr': { // バリデーション対象のformのname属性を指定する.
	    caption: 'TOMS.PAYMENT.DETAIL.LABEL.MAPYR', // キャプションのメッセージキーを指定する. 
	    required: true,
		numeric: true,
		maxlength: 8
	  }  
};
