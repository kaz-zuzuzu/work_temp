/**
 * 加工部位マスタメンテナンス一覧
 *
 **/

 var $bind ={};
 
 var $data={};
 load("toms/common/common");
 

/**
 * 初期表示
 * @param request リクエストパラメータ
 */
function init(request){
	
	$bind.dialogMessages="";

	$data = {
		pageNum : isBlank(request.pageNum) ? '1' : request.pageNum,
		rowNum  : isBlank(request.rowNum) ? '30' : request.rowNum,
		rowList : isBlank(request.rowList) ? '30, 50, 100' : request.rowList
	};

	//検索条件設定
	$bind.mky57appc1 = isBlank(request.search_mky57appc1) ? "":request.search_mky57appc1; //加工部位コード
	$bind.mky57appc2 = isBlank(request.search_mky57appc2) ? "":request.search_mky57appc2; //加工位置コード
	$bind.mky57apcsc = isBlank(request.search_mky57apcsc) ? "":request.search_mky57apcsc; //親商品形態コード
	$bind.mky57acsc = isBlank(request.search_mky57acsc) ? "":request.search_mky57acsc; //商品形態コード
	$bind.mky57amtc = isBlank(request.search_mky57amtc) ? "":request.search_mky57amtc; //素材コード
	$bind.mkdl01 = isBlank(request.search_mkdl01) ? "":request.search_mkdl01; //加工部位名称
	$bind.mkdl02 = isBlank(request.search_mkdl02) ? "":request.search_mkdl02; //加工位置名称
	$bind.mky57adop1 = isBlank(request.search_mky57adop1) ? "":request.search_mky57adop1; //表示順 部位
	$bind.mky57adop2 = isBlank(request.search_mky57adop2) ? "":request.search_mky57adop2; //表示順 位置
	$bind.mky57ajcp1 = isBlank(request.search_mky57ajcp1) ? "":request.search_mky57ajcp1; //JDEコード 部位
	$bind.mky57ajcp2 = isBlank(request.search_mky57ajcp2) ? "":request.search_mky57ajcp2; //JDEコード 位置
	$bind.mky57adflg = isBlank(request.search_mky57adflg) ? "" :request.search_mky57adflg;//削除フラグ
	$bind.mkeftj = isBlank(request.search_mkeftj) ? "":request.search_mkeftj;//適用開始日
	$bind.mkeftj2 = isBlank(request.search_mkeftj2) ? "":request.search_mkeftj2;//適用開始日
	$bind.mkexdj = isBlank(request.search_mkexdj) ? "":request.search_mkexdj;//適用終了日
	
	//ダウrンロード用検索条件

	var csvObj;
	if (request.csvFlag == "1") {
		csvObj ={
			mky57appc1 	: isBlank(request.mky57appc1) ? "":request.mky57appc1, //加工部位コード
			mky57appc2 	: isBlank(request.mky57appc2) ? "":request.mky57appc2, //加工位置コード
			mky57apcsc 	: isBlank(request.mky57apcsc) ? "":request.mky57apcsc, //親商品形態コード
			mky57acsc 	: isBlank(request.mky57acsc) ? "":request.mky57acsc, //商品形態コード
			mky57amtc 	: isBlank(request.mky57amtc) ? "":request.mky57amtc, //素材コード
			mkdl01 		: isBlank(request.mkdl01) ? "":request.mkdl01, //加工部位名称
			mkdl02 		: isBlank(request.mkdl02) ? "":request.mkdl02, //加工位置名称
			mky57adop1 	: isBlank(request.mky57adop1) ? "":request.mky57adop1, //表示順 部位
			mky57adop2 	: isBlank(request.mky57adop2) ? "":request.mky57adop2, //表示順 位置
			mky57ajcp1 	: isBlank(request.mky57ajcp1) ? "":request.mky57ajcp1, //JDEコード 部位
			mky57ajcp2 	: isBlank(request.mky57ajcp2) ? "":request.mky57ajcp2, //JDEコード　位置
			mky57adflg 	: isBlank(request.mky57adflg) ? "":request.mky57adflg, //削除フラグ
			mkeftj 		: isBlank(request.mkeftj) ? "":request.mkeftj,//適用開始日
			mkeftj2 	: isBlank(request.mkeftj2) ? "":request.mkeftj2,//適用開始日
			mkexdj 		: isBlank(request.mkexdj) ? "":request.mkexdj//適用終了日
		};
	
        outputCSV(csvObj);
	}
	
	$bind.checked1 = true; 	
	$bind.checked2 = false;
	$bind.checked3 	=false;

	//画面項目
	$bind.select_notdelete=MessageManager.getMessage('TOMS.COMMON.DELETE.SELECT.NOTDELETE');
	$bind.select_delete=MessageManager.getMessage('TOMS.COMMON.DELETE.SELECT.DELETE');
	$bind.select_all=MessageManager.getMessage('TOMS.COMMON.DELETE.SELECT.ALL');

	$bind.control_notcontrol=MessageManager.getMessage('TOMS.COMMON.CONTROL.SELECT.NOTCONTROL');
	$bind.control_control=MessageManager.getMessage('TOMS.COMMON.CONTROL.SELECT.CONTROL');
	$bind.control_all=MessageManager.getMessage('TOMS.COMMON.CONTROL.SELECT.ALL');


  $bind.dialogMessages = ({
    addConfirmTitle: MessageManager.getMessage('TOMS.COMMON.DIALOG.CONFIRM.TITLE'),
    addConfirmMessage: MessageManager.getMessage('TOMS.COMMON.DIALOG.CONFIRM.MESSAGE')
  }).toSource();

}

/**
 * 加工部位マスタメンテナンスのCSV出力処理
 * 
 * @param　リクエストパラメータ
 * 
 */
function outputCSV(param){
    load("toms/common/processPart");
	var result = ProcessPart.getProcessPartList(param, false, null,null);
	var outputContent = "";
	if (!result.error) {
		outputContent = outputCSVHeader();
    	for(var i = 0; i < result.countRow; i++) {
    		outputContent += outputCSVRow(result.data[i]);
    	}
    	var strDate = DateTimeFormatter.format("yyyyMMdd_HHmmss", new Date());
    	var strUserName = Contexts.getUserContext().userProfile.userName;
    	var fileName = MessageManager.getMessage('TOMS.MASTER.MAINTENANCE.PROCESSPART.DETAIL.INPUT.TITLE') + '_' + strDate + '_' + strUserName + '.csv';
    	Module.download.send(Unicode.to(outputContent, 'MS932'), fileName, MessageManager.getMessage('TOMS.COMMON.MIME.CSV'));
	} else {
		error(result.errorMessage);
	}
}

/**
 * 加工部位マスタメンテナンスのCSVヘッダ部分出力処理。
 */
function outputCSVHeader() {
	var outputHeader = common.convert(MessageManager.getMessage('TOMS.COMMON.CSV.UPDATE.DIVIDE'), true)
	  + common.convert(MessageManager.getMessage('TOMS.MASTER.MAINTENANCE.PROCESSPART.LABEL.PROCESSPART_CODE'), true)
	  + common.convert(MessageManager.getMessage('TOMS.MASTER.MAINTENANCE.PROCESSPART.LABEL.PROCESSPART_POSITION_CODE'), true)
	  + common.convert(MessageManager.getMessage('TOMS.MASTER.MAINTENANCE.COMMODITYSHAPE.LABEL.PARENT_COMMODITY_SHAPE_CODE'), true)
	  + common.convert(MessageManager.getMessage('TOMS.MASTER.MAINTENANCE.COMMODITYSHAPE.LABEL.COMMODITY_SHAPE_CODE'), true)
	  + common.convert(MessageManager.getMessage('TOMS.MASTER.MAINTENANCE.MATERIAL.LABEL.MATERIAL_CODE'), true)
	  + common.convert(MessageManager.getMessage('TOMS.MASTER.MAINTENANCE.PROCESSPART.LABEL.PROCESSPART_NAME'), true)
	  + common.convert(MessageManager.getMessage('TOMS.MASTER.MAINTENANCE.PROCESSPART.LABEL.PROCESSPART_POSITION_NAME'), true)
	  + common.convert(MessageManager.getMessage('TOMS.MASTER.MAINTENANCE.PROCESSPART.LABEL.PROCESSPART_DISPLAY_PART'), true)
	  + common.convert(MessageManager.getMessage('TOMS.MASTER.MAINTENANCE.PROCESSPART.LABEL.PROCESSPART_DISPLAY_POSITION'), true)
//	  + common.convert(MessageManager.getMessage('TOMS.MASTER.MAINTENANCE.PROCESSPART.LABEL.PROCESSPART_JDECODE_PART'), true)
//	  + common.convert(MessageManager.getMessage('TOMS.MASTER.MAINTENANCE.PROCESSPART.LABEL.PROCESSPART_JDECODE_POSITION'), true)
	  + common.convert(MessageManager.getMessage('TOMS.MASTER.MAINTENANCE.COMMODITYSHAPE.LABEL.APPLIED_START_DATE'), true)
	  + common.convert(MessageManager.getMessage('TOMS.MASTER.MAINTENANCE.COMMODITYSHAPE.LABEL.DELETE_FLG'), false);
//	  + common.convert(MessageManager.getMessage('TOMS.MASTER.MAINTENANCE.COMMODITYSHAPE.LABEL.APPLIED_END_DATE'), true)
//	  + common.convert(MessageManager.getMessage('TOMS.MASTER.MAINTENANCE.LIST.INPUT.USER'), true)
//	  + common.convert(MessageManager.getMessage('TOMS.MASTER.MAINTENANCE.LIST.INPUT.PID'), true)
//	  + common.convert(MessageManager.getMessage('TOMS.MASTER.MAINTENANCE.LIST.INPUT.UPMJ'), true)
//	  + common.convert(MessageManager.getMessage('TOMS.MASTER.MAINTENANCE.LIST.INPUT.UPMT'), true)
	return outputHeader;

}

/**
 * 加工部位マスタメンテナンスのCSVファイルの行を出力する処理
 * 
 * @param record DBから検索した行のデータ
 */
function outputCSVRow(record) {
	var result =  MessageManager.getMessage('TOMS.COMMON.CSV.SPLIT')
		    + common.convert(record["mky57appc1"], true)
			+ common.convert(record["mky57appc2"], true)
			+ common.convert(record["mky57apcsc"], true)
			+ common.convert(record["mky57acsc"], true)
			+ common.convert(record["mky57amtc"], true)
			+ common.convert(record["mkdl01"], true)
			+ common.convert(record["mkdl02"], true)
			+ common.convert(record["mky57adop1"], true)
			+ common.convert(record["mky57adop2"], true)
//			+ common.convert(record["mky57ajcp1"], true)
//			+ common.convert(record["mky57ajcp2"], true)
			+ common.convert(record["mkeftj"], true)
			+ common.convert(record["mky57adflg"]+"", false);
//			+ common.convert(record["mlexdj"], true)
//			+ common.convert(record["mluser"], true)
//			+ common.convert(record["mlpid"], true)
//			+ common.convert(record["mlupmj"], true)
//			+ common.convert(record["mlupmt"], true)

	return result;
	
}

function error(message) {
  Transfer.toErrorPage({
    title: MessageManager.getMessage('TOMS.COMMON.ERROR.PAGE.TITLE'),
    message: MessageManager.getMessage('TOMS.COMMON.ERROR.MESSAGE.SYSTEM'),
    detail: [MessageManager.getMessage('TOMS.MASTER.MAINTENANCE.PROCESSPART.LIST.LABEL.MESSAGE.ERROR'), message],
    returnUrl: 'toms/commodity_shape/list/input', // 戻り先 URL
    returnUrlLabel: MessageManager.getMessage('TOMS.MASTER.MAINTENANCE.PROCESSPART.LIST.LABEL.RETURN.LINK.NAME'),
    parameter: {
    }
  });
}