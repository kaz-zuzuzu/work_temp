/**
 * バインド変数.
 */
var $bind = {};

var $data = {};
	
load('toms/common/common');
	
	
/**
 * 初期表示
 * @param request リクエストパラメータ
 */
function init(request) {
	load("toms/common/master");
	$data = {
		rowNum  : 30,
		rowList : [30, 50, 100]
	};
	
	$bind.malitm = request.malitm;
    $bind.maan8 = request.maan8;
    $bind.macpgp = request.macpgp;
    $bind.maeftj = request.maeftj;
	if (request.csvFlag == "1") {
        outputCSV($bind.malitm, $bind.maan8, $bind.macpgp, $bind.maeftj);
	}

  // CSV出力ボタン押下時の確認ダイアログのメッセージを初期化.
  // JavaScriptで利用するためオブジェクトの内容をそのまま渡します.
  $bind.dialogMessages = ({
    addConfirmTitle: MessageManager.getMessage('TOMS.COMMON.DIALOG.CONFIRM.TITLE'),
    addConfirmMessage: MessageManager.getMessage('TOMS.COMMON.DIALOG.CONFIRM.MESSAGE')
  }).toSource();
}


/**
 * 販売単価マスタメンテナンスのCSV出力処理
 * 
 * @param malitm 第2品目番号
 * @param maan8 住所番号
 * @param macpgp 顧客価格グループ
 * @param maeftj 有効開始日付
 */
function outputCSV(malitm, maan8, macpgp, maeftj) {
	var result = TomsMaster.getSalesList(malitm, maan8, macpgp, maeftj, null, null, false);
	var outputContent = "";
	if (!result.error) {
		outputContent = outputCSVHeader();
    	for(var i = 0; i < result.countRow; i++) {
    		outputContent += outputCSVRow(result.data[i]);
    	}
    	var strDate = DateTimeFormatter.format("yyyyMMdd", new Date());
    	var strUserName = Contexts.getUserContext().userProfile.userName;
    	var fileName = MessageManager.getMessage('TOMS.MASTER.MAINTENANCE.SALES.LIST.INPUT.FILENAME') + '_' + strDate + '_' + strUserName + '.csv';
    	Module.download.send(Unicode.to(outputContent, 'MS932'), fileName, MessageManager.getMessage('TOMS.COMMON.MIME.CSV'));
	} else {
		error(result.errorMessage);
	}
}


/**
 * 販売単価マスタメンテナンスのCSVヘッダ部分出力処理。
 */
function outputCSVHeader() {
	var outputHeader = common.convert(MessageManager.getMessage('TOMS.COMMON.CSV.UPDATE.DIVIDE'), true)
	              + common.convert(MessageManager.getMessage('TOMS.MASTER.MAINTENANCE.SALES.DETAIL.INPUT.MAITM'), true)
				  + common.convert(MessageManager.getMessage('TOMS.MASTER.MAINTENANCE.SALES.DETAIL.INPUT.MALITM'), true)
				  //+ common.convert(MessageManager.getMessage('TOMS.MASTER.MAINTENANCE.SALES.DETAIL.INPUT.MAMCU'), true)
				  //+ common.convert(MessageManager.getMessage('TOMS.MASTER.MAINTENANCE.SALES.DETAIL.INPUT.MALOCN'), true)
				  //+ common.convert(MessageManager.getMessage('TOMS.MASTER.MAINTENANCE.SALES.DETAIL.INPUT.MALOTN'), true)
				  + common.convert(MessageManager.getMessage('TOMS.MASTER.MAINTENANCE.SALES.DETAIL.INPUT.MAAN8'), true)
				  + common.convert(MessageManager.getMessage('TOMS.MASTER.MAINTENANCE.SALES.DETAIL.INPUT.MACPGP'), true)
				  //+ common.convert(MessageManager.getMessage('TOMS.MASTER.MAINTENANCE.SALES.DETAIL.INPUT.MAPRGR'), true)
				  + common.convert(MessageManager.getMessage('TOMS.MASTER.MAINTENANCE.SALES.DETAIL.INPUT.MAUORG'), true)
				  + common.convert(MessageManager.getMessage('TOMS.MASTER.MAINTENANCE.SALES.DETAIL.INPUT.MACRCD'), true)
				  //+ common.convert(MessageManager.getMessage('TOMS.MASTER.MAINTENANCE.SALES.DETAIL.INPUT.MAUOM'), true)
				  + common.convert(MessageManager.getMessage('TOMS.MASTER.MAINTENANCE.SALES.DETAIL.INPUT.MAEFTJ'), true)
				  + common.convert(MessageManager.getMessage('TOMS.MASTER.MAINTENANCE.SALES.DETAIL.INPUT.MAUPRC'), false);
	return outputHeader;
}

/**
 * 販売単価マスタメンテナンスのCSVファイルの行を出力する処理
 * 
 * @param record DBから検索した行のデータ
 */
function outputCSVRow(record) {
	var strSplit =MessageManager.getMessage('TOMS.COMMON.CSV.SPLIT'); 
	var result =  strSplit
		    + common.convert(record["maitm"], true)
			+ common.convert(record["malitm"], true)
			//+ common.convert(record["mamcu"], true)
			//+ common.convert(record["malocn"], true)
			//+ common.convert(record["malotn"], true)
			+ common.convert(record["maan8"], true)
			+ common.convert(record["macpgp"], true)
			//+ common.convert(record["maprgr"], true)
			+ common.convert(record["mauorg"], true)
			+ common.convert(record["macrcd"], true)
			//+ common.convert(record["mauom"], true)
			+ common.convert(record["maeftj"], true)
			+ common.convert(record["mauprc"], false);
	return result;
	
}

function error(message) {
  Transfer.toErrorPage({
    title: MessageManager.getMessage('TOMS.COMMON.ERROR.PAGE.TITLE'),
    message: MessageManager.getMessage('TOMS.COMMON.ERROR.MESSAGE.SYSTEM'),
    detail: [MessageManager.getMessage('TOMS.MASTER.MAINTENANCE.SALES.LIST.LABEL.MESSAGE.ERROR'), message],
    returnUrl: 'toms/sales/list/input', // 戻り先 URL
    returnUrlLabel: MessageManager.getMessage('TOMS.MASTER.MAINTENANCE.SALES.LIST.LABEL.RETURN.LINK.NAME'),
    parameter: {
    }
  });
}

