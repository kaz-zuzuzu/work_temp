var $data = {};

/**
 * 初期表示
 * @param request リクエストパラメータ
 */
function init(request) {

	$data = {
		rowNum  : 10,
		rowList : [10, 20, 30]
	};
}
