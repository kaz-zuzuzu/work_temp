/**
 * 加工方法明細マスタメンテナンス登録・更新画面
 *
 * src /src/toms/process_method_d/detail/input.js
 * 
 **/
var $bind ={};

function init(request){

	$bind.flag ="0"; //新規、更新フラグ　新規：0　更新：1　
	if(!isBlank(request.updateFlag)){
		$bind.flag = request.updateFlag;
	}
	$bind.inputFlg = "false";
	var endDate=MessageManager.getMessage('TOMS.COMMON.CONSTANT.ENDDATE');
	$bind.beforeUrl = isBlank(request.beforeUrl) ? "toms/process_method_d/list/input": request.beforeUrl;
	
        //ヘッダ情報
	$bind.mmy57apmc = isBlank(request.mmy57apmc) ? request.mny57apmc:request.mmy57apmc;//加工方法コード
	$bind.mmy57apcsc = request.mmy57apcsc;//親商品形態コード
	$bind.mmy57apcscName = request.mmy57apcscName;//親商品形態名称
	$bind.mmy57acsc = request.mmy57acsc;//商品形態コード
	$bind.mmy57acscName = request.mmy57acscName;//商品形態名称
	$bind.mmy57amtc = request.mmy57amtc;//素材コード 
	$bind.mmy57amtcName = request.mmy57amtcName;//原材料名
	
	$bind.mmy57appc1 = request.mmy57appc1;//加工方法部位コード
	$bind.mmy57appc1Name = request.mmy57appc1Name;//加工方法部位名称
	$bind.mmy57appc2 = request.mmy57appc2;//加工方法位置コード
	$bind.mmy57appc2Name = request.mmy57appc2Name;//加工方法位置名称
	$bind.mmy57apmt = request.mmy57apmt;//加工方法区分
	$bind.mmy57apmdt = request.mmy57apmdt;//加工方法明細区分
	$bind.mmdl01 = request.mmdl01;//加工方法名称
	
	$bind.mny57apmc= request.mny57apmc;//加工方法コード
	$bind.mny57apmt = isBlank(request.mny57apmt) ? request.mmy57apmt : request.mny57apmt ;//加工方法区分
	$bind.require ="";
	//加工方法区分が転写:２の時　柄サイズの縦横は必須とする
	if(!isBlank($bind.mny57apmt) && $bind.mny57apmt=="2"){
		$bind.require ="imui-required";
	}

	if($bind.flag=="1"){

		$bind.inputFlg ="true";
		//画面タイトル
		$bind.title = MessageManager.getMessage('TOMS.MASTER.MAINTENANCE.PROCESSMETHOD_DETAIL.DETAIL.INPUT.UPDATE.TITLE');
		//更新時、前画面から設定値を受け取る
		//明細情報
		$bind.mny57ado1 = request.mny57ado1;
		$bind.mny57ado2 = request.mny57ado2;
		$bind.mny57ado3 = request.mny57ado3;
		$bind.mny57agn1 = request.mny57agn1;
		$bind.mny57agn2 = request.mny57agn2;
		$bind.mny57agn3 = request.mny57agn3;
		$bind.mny57ajc1 = request.mny57ajc1;
		$bind.mny57ajc2 = request.mny57ajc2;
		$bind.mny57ajc3 = request.mny57ajc3;
		$bind.mny57apmn1 = request.mny57apmn1;
		$bind.mny57apmn2 = request.mny57apmn2;
		$bind.mny57apmn3 = request.mny57apmn3	;
		

		$bind.mny57apsh = request.mny57apsh;
		$bind.mny57apsw = request.mny57apsw;
		$bind.mneftj = request.mneftj;
	}else{
		//新規登録時
		$bind.title = MessageManager.getMessage('TOMS.MASTER.MAINTENANCE.PROCESSMETHOD_DETAIL.DETAIL.INPUT.ENTRY.TITLE');
	}

	//非表示フラグのリスト生成
	var selectedFlg ="false";
	if(!isBlank($bind.mny57ahflg) && $bind.mny57ahflg=="1"){
		selectedFlg ="true";
	}
	
	var ahflgList =[
            	{ label : MessageManager.getMessage('TOMS.COMMON.DISPFLAG.ONLY'),
            		value: "0"
            	},
            	{ label : MessageManager.getMessage('TOMS.COMMON.DISPFLAG.NOT_DISP'),
            		value: "1",
            		selected : selectedFlg
            	}	
        	];
	$bind.mny57ahflgList = ahflgList;
   
	$bind.mmexdj = endDate;//適用終了日
	$bind.gadgetTitle = MessageManager.getMessage('TOMS.MASTER.MAINTENANCE.PROCESSMETHOD_HEADER.LABEL.INFOMATION');
	//転写時の柄サイズ入力チェック用メッセージ
	$bind.validateHeightMsg =MessageManager.getMessage('TOMS.COMMON.MAINTENANCE.AJAX.ERROR.MASTER.PATTERNSIZE_HEIGHT_REQUIRE');
	$bind.validateWidthMsg =MessageManager.getMessage('TOMS.COMMON.MAINTENANCE.AJAX.ERROR.MASTER.PATTERNSIZE_WIDTH_REQUIRE');
    $bind.dialogMessages = ({
        entryTitle: MessageManager.getMessage('TOMS.COMMON.ENTRY'),
        entryMessage: MessageManager.getMessage('TOMS.MASTER.MAINTENANCE.PROCESSMETHOD_DETAIL.DETAIL.INPUT.ENTRY.MESSAGE'),
        updateTitle: MessageManager.getMessage('TOMS.COMMON.UPDATE'),
        updateMessage: MessageManager.getMessage('TOMS.MASTER.MAINTENANCE.PROCESSMETHOD_DETAIL.DETAIL.INPUT.UPDATE.MESSAGE'),
        deleteTitle: MessageManager.getMessage('TOMS.COMMON.DELETE'),
        deleteMessage: MessageManager.getMessage('TOMS.MASTER.MAINTENANCE.PROCESSMETHOD_DETAIL.DETAIL.INPUT.DELETE.MESSAGE')
      }).toSource();
    
}