SELECT
    COUNT(*) AS ROWCOUNT
FROM
(
    SELECT 
       MLY57AMTC
        ,MLY57APCSC
        ,MLY57ACSC 
        ,MLDL01    
        ,MLPCT1    
        ,MLSNN     
        ,MLY57AJDC 
        ,MLY57AMFLG
        ,MLEFTJ    
        ,MLEXDJ    
        ,MLY57ADFLG
        ,MLY57ABSC 
        ,MLURCD
        ,MLURDT
        ,MLURAT
        ,MLURAB
        ,MLURRF
        ,MLUSER
        ,MLPID
        ,MLJOBN
        ,MLUPMJ
        ,MLUPMT
    FROM
        F57A5130
/*BEGIN*/
    WHERE
        /*IF mly57amtc != null*/
        AND  TRIM(MLY57AMTC) = /*mly57amtc*/'TEST'
        /*END*/
        /*IF mly57apcsc != null*/
        AND  TRIM(MLY57APCSC) = /*mly57apcsc*/'TEST'
        /*END*/
        /*IF mly57acsc != null*/
        AND  TRIM(MLY57ACSC) = /*mly57acsc*/'TEST'
        /*END*/
        /*IF mldl01 != null*/
        AND  MLDL01 LIKE  /*mldl01*/'%3%'
        /*END*/
        
        /*IF mlpct1 != null*/
        AND  MLPCT1 = /*mlpct1*/'TEST'
        /*END*/
        /*IF mly57ajdc != null*/
        AND  TRIM(MLY57AJDC) = /*mly57ajdc*/'TEST'
        /*END*/
        /*IF mly57ajdc != null*/
        AND  TRIM(MLY57AJDC) = /*mly57ajdc*/'TEST'
        /*END*/
        /*IF mly57adflg != null*/
        AND  MLY57ADFLG = /*mly57adflg*/'TEST'
        /*END*/
        /*IF mly57amflg != null*/
        AND  MLY57AMFLG = /*mly57amflg*/'TEST'
        /*END*/
        /*IF mleftj != null*/
        AND  MLEFTJ >= /*mleftj*/'116032'
        /*END*/
        /*IF mleftj2 != null*/
        AND  MLEFTJ <= /*mleftj2*/'116032'
        /*END*/

        /*IF mly57absc != null*/
        AND  TRIM(MLY57ABSC) = /*mly57absc*/'TEST'
        /*END*/
    /*END*/
        ORDER BY MLY57AMTC, MLY57APCSC, MLY57ACSC, MLEFTJ DESC
    
)
