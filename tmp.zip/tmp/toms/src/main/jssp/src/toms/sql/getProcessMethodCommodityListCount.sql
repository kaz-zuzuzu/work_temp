SELECT
    COUNT(*) AS ROWCOUNT
FROM
(
SELECT
  MPY57APMC
  , MPY57ACC
  , MPEFTJ
  , MPEXDJ
  , MPY57ADFLG
  , MPURCD
  , MPURDT
  , MPURAT
  , MPURAB
  , MPURRF
  , MPUSER
  , MPPID
  , MPJOBN
  , MPUPMJ
  , MPUPMT
  , MPY57APCSC
  , MPY57ACSC
  , MPY57AMTC
  , MPY57APPC1
  , MPY57APPC2
  , MPY57APMT
  , MPY57APMDT 
FROM
  F57A5160 
    /*BEGIN*/
        WHERE
        /*IF mpy57apmc !=null */
          AND TRIM(MPY57APMC) = /*mpy57apmc*/'1'
        /*END*/
        /*IF mpy57acc !=null */
          AND TRIM(MPY57ACC) = /*mpy57acc*/'1'
        /*END*/
        /*IF mpeftj !=null */
          AND MPEFTJ >= /*mpeftj*/'116061'
        /*END*/
        /*IF mpeftj2 !=null */
          AND MPEFTJ <= /*mpeftj2*/'116067'
        /*END*/
        /*IF mpy57adflg !=null */
          AND MPY57ADFLG = /*mpy57adflg*/'0'
        /*END*/
    /*END*/
	ORDER BY
  MPY57APMC 
  , MPY57ACC 
  , MPEFTJ DESC

)
