SELECT
    COUNT(*) AS ROWCOUNT
FROM
(
SELECT
  MRY57APCSC
  , MRY57ACSC
  , MRY57AMTC
  , MRY57APPC1
  , MRY57APPC2
  , MRY57APMT
  , MRY57APMDT
  , MRY57APMD1
  , MRY57APMD2
  , MRY57APMD3
  , MRY57APDJT
  , MRUORG
  , MRY57ACSJ
  , MRY57AMJC
  , MRY57APPA
  , MRY57APPO
  , MRY57ALSKU
  , MREFTJ
  , MREXDJ
  , MRY57ADFLG
  , MRURCD
  , MRURDT
  , MRURAB
  , MRURRF
  , MRUSER
  , MRJOBN
  , MRUPMJ
  , MRUPMT
  , MRY57AOA 
FROM
      F57A5180 mr --加工明細コード管理マスタ
 INNER JOIN 
    (
    SELECT
    
    MNY57APCSC
  , MNY57ACSC
  , MNY57AMTC
  , MNY57APPC1
  , MNY57APPC2
  , MNY57APMT
  , MNY57APMDT 
  , MNY57AJC1
  , MNY57AJC2
  , MNY57AJC3
  
    FROM 
     F57A5141 --加工方法明細マスタ
/*IF mny57apmn1 != null || mny57apmn2 != null || mny57apmn3 != null*/
    WHERE 
/*END*/
/*IF mny57apmn1 != null*/
            TRIM(MNY57APMN1) LIKE /*mny57apmn1*/'%%'
/*END*/
/*IF mny57apmn1 == null && mny57apmn2 != null*/
            
            TRIM(MNY57APMN2) LIKE /*mny57apmn2*/'%%'
/*END*/
/*IF mny57apmn1 != null  &&  mny57apmn2 != null*/
            
            AND TRIM(MNY57APMN2) LIKE /*mny57apmn2*/'%%'
/*END*/
/*IF mny57apmn1 == null && mny57apmn2 == null && mny57apmn3 != null*/
            TRIM(MNY57APMN3) LIKE /*mny57apmn3*/'%%'
/*END*/
/*IF (mny57apmn1 != null || mny57apmn2 != null ) && mny57apmn3 != null*/
            AND TRIM(MNY57APMN3) LIKE /*mny57apmn3*/'%%'
/*END*/
            
    GROUP BY 
    MNY57APCSC
  , MNY57ACSC
  , MNY57AMTC
  , MNY57APPC1
  , MNY57APPC2
  , MNY57APMT
  , MNY57APMDT 
  , MNY57AJC1
  , MNY57AJC2
  , MNY57AJC3 
    ) d
    ON mr.MRY57APCSC = d.MNY57APCSC
   AND mr.MRY57ACSC = d.MNY57ACSC
   AND mr.MRY57AMTC = d.MNY57AMTC
   AND mr.MRY57APPC1 = d.MNY57APPC1
   AND mr.MRY57APPC2 = d.MNY57APPC2
   AND mr.MRY57APMT = d.MNY57APMT
   AND mr.MRY57APMDT = d.MNY57APMDT
   AND mr.MRY57APMD1 = d.MNY57AJC1
   AND mr.MRY57APMD2 = d.MNY57AJC2
   AND mr.MRY57APMD3 = d.MNY57AJC3
      
 INNER JOIN 
    (
    SELECT
        MKY57APPC1,
        MKY57APPC2,
        MKY57APCSC,
        MKY57ACSC,
        MKY57AMTC
    FROM 
        F57A5120 --部位マスタ
        /*IF mkdl01 != null || mkdl02 != null*/
    WHERE 
        /*END*/
        /*IF mkdl01 != null*/
          TRIM(MKDL01) LIKE /*mkdl01*/'%%'
        /*END*/
        /*IF mkdl01 != null && mkdl02 != null*/
          AND TRIM(MKDL02) LIKE /*mkdl02*/'%%'
        /*END*/
        /*IF mkdl01 == null && mkdl02 != null*/
          TRIM(MKDL02) LIKE /*mkdl02*/'%%'
        /*END*/
          
          GROUP BY 
        MKY57APPC1,
        MKY57APPC2,
        MKY57APCSC,
        MKY57ACSC,
        MKY57AMTC       
    ) bui
  ON mr.MRY57AMTC = bui.MKY57AMTC
 and mr.MRY57APCSC = bui.MKY57APCSC
 and mr.MRY57ACSC = bui.MKY57ACSC
 and mr.MRY57APPC1 = bui.MKY57APPC1
 and mr.MRY57APPC2 = bui.MKY57APPC2

 INNER JOIN 
    (
    SELECT
        MLY57AMTC,
        MLY57APCSC,
        MLY57ACSC
    FROM 
        F57A5130 --素材マスタ
/*IF mldl01 != null*/
        WHERE         
          TRIM(MLDL01) LIKE /*mldl01*/'%%'
/*END*/
    GROUP BY 
        MLY57AMTC,
        MLY57APCSC,
        MLY57ACSC
      ) sozai
  ON mr.MRY57AMTC = sozai.MLY57AMTC
 and mr.MRY57APCSC = sozai.MLY57APCSC
 and mr.MRY57ACSC = sozai.MLY57ACSC
 
 INNER JOIN
     (
    SELECT 
        MJY57ACSC
      , MJY57APCSC
     FROM
        F57A5110 --商品形態マスタ（親商品形態名称用）
     WHERE
        MJY57ACSC = MJY57APCSC
     /*IF mry57apcscName != null*/
     AND TRIM(MJDL01) LIKE /*mry57apcscName*/'%%'
     /*END*/
     GROUP BY 
        MJY57ACSC
      , MJY57APCSC
    ) oya
    ON mr.MRY57APCSC = oya.MJY57ACSC
    
 INNER JOIN
     (
    SELECT 
        MJY57ACSC
      , MJY57APCSC
     FROM
        F57A5110 --商品形態マスタ（商品形態名称用）
     WHERE
        MJY57ACSC <> MJY57APCSC
     /*IF mry57acscName != null*/
     AND TRIM(MJDL01) LIKE /*mry57acscName*/'%%'
     /*END*/
     GROUP BY 
        MJY57ACSC
      , MJY57APCSC
    ) ko
    ON mr.MRY57ACSC = ko.MJY57ACSC
    and mr.MRY57APCSC = ko.MJY57APCSC
 INNER JOIN
   (
    SELECT
        IMLITM
     FROM
        F4101 --品目マスタ
     /*IF mry57alskuName != null*/
     WHERE TRIM(IMDSC1) LIKE /*mry57alskuName*/'%BPT%'
     /*END*/
    GROUP BY
        IMLITM
   ) IM
   ON mr.MRY57ALSKU = IM.IMLITM
    /*BEGIN*/
      WHERE
        /*IF mry57apmd1 != null*/
          AND TRIM(mr.MRY57APMD1) = /*mry57apmd1*/''
        /*END*/
        /*IF mry57apmd2 != null*/
          AND TRIM(mr.MRY57APMD2) = /*mry57apmd2*/''
        /*END*/
        /*IF mry57apmd3 != null*/
          AND TRIM(mr.MRY57APMD3) = /*mry57apmd3*/''
        /*END*/
        /*IF mry57apdjt != null*/
          AND TRIM(mr.MRY57APDJT) IN /*mry57apdjt*/('1','2','3')
        /*END*/
        /*IF mruorg != null*/
          AND TRIM(mr.MRUORG) = /*mruorg*/''
        /*END*/
        /*IF mry57alsku != null*/
          AND TRIM(mr.MRY57ALSKU) = /*mry57alsku*/''
        /*END*/
        /*IF mry57aoa != null*/
          AND TRIM(mr.MRY57AOA) = /*mry57aoa*/''
        /*END*/
        /*IF mreftj_from != null*/
          AND mr.MREFTJ >= /*mreftj_from*/''
        /*END*/
        /*IF mreftj_to != null*/
          AND mr.MREFTJ <= /*mreftj_to*/''
        /*END*/
        /*IF mry57adflg != null*/
          AND mr.MRY57ADFLG = /*mry57adflg*/''
        /*END*/
        /*IF mry57apcsc != null*/
          AND TRIM(mr.MRY57APCSC) = /*mry57apcsc*/''
        /*END*/
        /*IF mry57acsc != null*/
          AND TRIM(mr.MRY57ACSC) = /*mry57acsc*/''
        /*END*/
        /*IF mry57amtc != null*/
          AND TRIM(mr.MRY57AMTC) = /*mry57amtc*/''
        /*END*/
        /*IF mry57appc1 != null*/
          AND TRIM(mr.MRY57APPC1) = /*mry57appc1*/''
        /*END*/
        /*IF mry57appc2 != null*/
          AND TRIM(mr.MRY57APPC2) = /*mry57appc2*/''
        /*END*/ 
        /*IF mry57apmt != null*/
          AND TRIM(mr.MRY57APMT) IN /*mry57apmt*/('1','2','3')
        /*END*/
        /*IF mry57apmdt != null*/
          AND TRIM(mr.MRY57APMDT) IN /*mry57apmdt*/('0','1')
        /*END*/
        /*END*/
        ORDER BY
                MRY57APCSC
  , MRY57ACSC
  , MRY57AMTC
  , MRY57APPC1
  , MRY57APPC2
  , MRY57APMT
  , MRY57APMDT
  , MRY57APMD1
  , MRY57APMD2
  , MRY57APMD3
  , MRY57APDJT
  , MRUORG
  , MREFTJ DESC 
)
