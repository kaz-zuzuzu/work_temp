var $data;

/**
 * 初期表示
 * @param request リクエストパラメータ
 */
	
function init(request) {
	$data = ImJson.toJSONString(getList(request)); 
}

function getList(request) {

	// 表示条件を設定（表示ページ、件数など）
	let page = request.page == undefined ? 1 : request.page;
	let rows = request.rowNum == undefined ? 15 : Module.number.toInt(request.rowNum);
	
	// 検索条件の状況に応じて条件を設定する
	var param = request.extension;
	if (!param || !param.searchCondition) {
    	return  {
                		page  : page,
                		total : rows,
                		data  : []
    				};
	}
	
	//検索条件の設定
	var mpy57apmc = isBlank(param.searchCondition.mpy57apmc) ? null : param.searchCondition.mpy57apmc;//加工方法コード
    var mpy57acc = isBlank(param.searchCondition.mpy57acc) ? null : param.searchCondition.mpy57acc;//商品コード
	var mpeftj = isBlank(param.searchCondition.mpeftj) ? null :param.searchCondition.mpeftj ;//適用開始日
	var mpeftj2 = isBlank(param.searchCondition.mpeftj2) ? null :param.searchCondition.mpeftj2 ;//適用開始日
	var mpy57adflg = isBlank(param.searchCondition.mpy57adflg) ? null : param.searchCondition.mpy57adflg ;//削除フラグ

	var objParams = {
		mpy57apmc : mpy57apmc,
		mpy57acc : mpy57acc,
		mpeftj : mpeftj,
		mpeftj2 : mpeftj2,
		mpy57adflg : mpy57adflg
		
	}

	//加工方法商品関連付けマスタの件数取得
	var resultCount = getProcessMethodCommodityListCount(objParams);
	// 全体の件数を設定（件数の母数）
	var listCount = 0;
	if (!resultCount.error) {
		listCount = resultCount.data[0]['rowcount'];
	} else {
		Debug.write(resultCount.errorMessage);
	}

	// ページ番号設定:リクエストパラメータのページ番号、最大ページ番号のうち小さい方の番号を設定
	page = Math.min(page, Math.ceil(listCount / rows)); 
	
	// 指定範囲の加工方法明細情報を取得
	var start = rows * (page - 1) + 1;
	var end = start + rows - 1;

	//加工方法商品関連付けマスタの一覧取得
	var result = getProcessMethodCommodityList(objParams, start, end);
	var resultData =[];
	if(!result.error){
		resultData = result.data;
	}else{
		Debug.write(result.errorMessage);
	}

	var json = {
		page  : page,
		total : listCount,
		data  : resultData
	};
	
	return json;

	
	}

/**
 * 加工方法商品関連付け一覧件数取得
 */	
function getProcessMethodCommodityListCount(objParams){
    load("toms/common/processMethod");
    var result = ProcessMethod.getProcessMethodCommodityList(objParams, true,"","");
    return result;
}

/**
 * 加工方法商品関連付け一覧データ取得
 */
function getProcessMethodCommodityList(objParams, start , end){
    load("toms/common/processMethod");
    var result = ProcessMethod.getProcessMethodCommodityList(objParams, false,start,end);
    return result;
	
}

function createResult(page, total, data){
	return {
		page : page == null ? 1 : page,
		total : total == null ? 0 : total,
		data : data == null ? [] : data
	};
}


/**
 * エラーオブジェクト生成
 */
function createErrorResult(message, details){
	return {
		error : true,
		errorMessage : message,
		detailMessages : details

	}
}
