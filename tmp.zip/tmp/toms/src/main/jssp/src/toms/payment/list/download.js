/**
 * 入金パターンマスタCSV出力処理
 * 
 * @param request　リクエストパラメータ
 * 
 */


load('toms/common/common');

var comma =  MessageManager.getMessage('TOMS.COMMON.CSV.SPLIT');	// カンマセパレータ
var nl = MessageManager.getMessage('TOMS.COMMON.NEWLINE');		// 行末改行

function init(request) {

	//ダウンロード時の検索条件取得先

	var mapyrFrom = request.csv_search_mapyrFrom;	//支払人No from
	var mapyrTo = request.csv_search_mapyrTo;		//支払人No to

	// データ取得
	var result = getData(mapyrFrom, mapyrTo);

	// csv作成
	var csv = createCsv(result);
	
    var strDate = DateTimeFormatter.format("yyyyMMdd", new Date());
    var strUserName = Contexts.getUserContext().userProfile.userName;
    var fileName = MessageManager.getMessage('TOMS.PAYMENT.SEARCH.INPUT.TITLE') + '_' + strDate + '_' + strUserName + '.csv';

    // ﾀﾞｳﾝロード
	Module.download.send(Unicode.to(csv, 'MS932'), fileName, MessageManager.getMessage('TOMS.COMMON.MIME.CSV'));

}

/**
 * データ取得
 */
function getData(mapyrFrom, mapyrTo) {
	
	load("toms/common/master");
	var result = TomsMaster.getPaymentPtnList(
			mapyrFrom,
			mapyrTo, 
			null,
			null,
			true);
	return result;
}

/**
 * csv変換
 */
function createCsv(result) {
	
	var sb = new java.lang.StringBuilder();

	// ヘッダー 作成
	var head = createHeaderCsv();
	sb.append(head);

	// エラー時
	if(result.error) {
		return sb.toString();
	}
	result.data.forEach(function(e) {
		sb.append(comma);
		sb.append(convert(e.mapyr)).append(comma);
		sb.append(convert(e.macrcd)).append(comma);
		sb.append(convert(e.may56cathr)).append(comma);
		sb.append(convert(e.may56crper)).append(comma);
		sb.append(convert(e.may56carec)).append(comma);
		sb.append(convert(e.may56cryi1)).append(comma);
		sb.append(convert(e.may56ctra1)).append(comma);
		sb.append(convert(e.may56cryi2)).append(comma);
		sb.append(convert(e.may56ctra2)).append(comma);
		sb.append(convert(e.may56cerpe)).append(comma);
		sb.append(convert(e.may56ceare)).append(comma);
		sb.append(convert(e.may56cery1)).append(comma);
		sb.append(convert(e.may56cetr1)).append(comma);
		sb.append(convert(e.may56cery2)).append(comma);
		sb.append(convert(e.may56cetr2)).append(comma);
		// 支払条件
		sb.append(convert(e.maurrf)).append(nl);
    });

    return sb.toString();
}

/**
 * CSVヘッダ作成処理
 */
function createHeaderCsv(){
	var outputHeader = common.convert(MessageManager.getMessage('TOMS.COMMON.CSV.UPDATE.DIVIDE'), true)
      + common.convert(MessageManager.getMessage('TOMS.PAYMENT.DETAIL.LABEL.MAPYR'), true)
	  + common.convert(MessageManager.getMessage('TOMS.PAYMENT.LIST.LABEL.MACRCD'), true)
	  + common.convert(MessageManager.getMessage('TOMS.PAYMENT.LIST.LABEL.MAY56CATHR'), true)
	  + common.convert(MessageManager.getMessage('TOMS.PAYMENT.LIST.LABEL.MAY56CRPER'), true)
	  + common.convert(MessageManager.getMessage('TOMS.PAYMENT.LIST.LABEL.MAY56CAREC'), true)
	  + common.convert(MessageManager.getMessage('TOMS.PAYMENT.LIST.LABEL.MAY56CRYI1'), true)
	  + common.convert(MessageManager.getMessage('TOMS.PAYMENT.LIST.LABEL.MAY56CTRA1'), true)
	  + common.convert(MessageManager.getMessage('TOMS.PAYMENT.LIST.LABEL.MAY56CRYI2'), true)
	  + common.convert(MessageManager.getMessage('TOMS.PAYMENT.LIST.LABEL.MAY56CTRA2'), true)
	  + common.convert(MessageManager.getMessage('TOMS.PAYMENT.LIST.LABEL.MAY56CERPE'), true)
	  + common.convert(MessageManager.getMessage('TOMS.PAYMENT.LIST.LABEL.MAY56CEARE'), true)
	  + common.convert(MessageManager.getMessage('TOMS.PAYMENT.LIST.LABEL.MAY56CERY1'), true)
	  + common.convert(MessageManager.getMessage('TOMS.PAYMENT.LIST.LABEL.MAY56CETR1'), true)
	  + common.convert(MessageManager.getMessage('TOMS.PAYMENT.LIST.LABEL.MAY56CERY2'), true)
	  + common.convert(MessageManager.getMessage('TOMS.PAYMENT.LIST.LABEL.MAY56CETR2'), true)
	  // 支払条件
	  + common.convert(MessageManager.getMessage('TOMS.PAYMENT.LIST.LABEL.PAYMENTCONDITION'), false)

	  return outputHeader;
}

/**
 * null　→　空文字
 * 数値方　→ 文字列
 */
function convert(s) {
	if(isNull(s)) {
		return "";
	} else if (typeof s == 'number') {
		return String(s);
	}
	return s;
}
