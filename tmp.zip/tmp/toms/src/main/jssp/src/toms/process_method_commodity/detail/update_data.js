/**
 * 加工方法商品関連付けマスタ設定更新処理群
 * 
 * toms\src\main\jssp\src\toms\process_method_commodity\detail\update_data.js
 * 
 */

load('toms/common/common');
load('toms/common/cmnUtil');
load('toms/common/mastermaintenance');
var _SHARED_DB_KEY = "toms-web-dev";

function init(request){
	
	var searchInfo = setData(request);
	var entity = createEntity(request);
	var msg;
	var result;
	
	//更新用SQL
	var condition =" TRIM(mpy57apmc) =?"+ 
							" AND TRIM(mpy57acc) =? " +
							" AND TRIM(mpy57adflg) =0 " +
							" AND mpeftj =? ";
							
	//更新用キー
	var params = [
		   DbParameter.string(entity['mpy57apmc']),
		   DbParameter.string(entity['mpy57acc']),
		   DbParameter.number(entity['mpeftj'])
	];
	
	//------------------------------------
	//新規登録時
	//------------------------------------
	if(request.operateFlag=="0"){
	/*重複チェック*/
		result = _dbCheck(entity['mpy57apmc'],entity['mpy57acc'],entity['mpeftj']);
    	if(result.error){
    		Debug.write(result)
            // SELECTが失敗した場合
        	msg = MessageManager.getMessage('TOMS.COMMON.MAINTENANCE.AJAX.ERROR.INSERT.MESSAGE', MessageManager.getMessage('TOMS.MASTER.MAINTENANCE.PROCESSMETHOD_COMMODITY.DETAIL.INPUT.TITLE'));
        	common.sendErrorResult(msg, "");
    	}
    	if(result.countRow !=0){
    		Debug.write(result)
    		// 既に登録済みの場合
        	msg = MessageManager.getMessage('TOMS.COMMON.MAINTENANCE.AJAX.ERROR.INSERT.MESSAGE', MessageManager.getMessage('TOMS.MASTER.MAINTENANCE.PROCESSMETHOD_COMMODITY.DETAIL.INPUT.TITLE'));
        	common.sendErrorResult(msg, MessageManager.getMessage('TOMS.COMMON.MAINTENANCE.AJAX.ERROR.INSERT.NOTNEWDATA.MESSAGE'));
    	}
    	
	/*商品コードマスタ存在チェック*/
		result = _dbCheckCommodity(entity['mpy57acc']);
    	if(result.error){
            // SELECTが失敗した場合
        	msg = MessageManager.getMessage('TOMS.COMMON.MAINTENANCE.AJAX.ERROR.INSERT.MESSAGE', MessageManager.getMessage('TOMS.MASTER.MAINTENANCE.PROCESSMETHOD_COMMODITY.DETAIL.INPUT.TITLE'));
        	common.sendErrorResult(msg, "");
    	}
    	if(result.countRow ==0){
    		// 存在しない場合
        	msg = MessageManager.getMessage('TOMS.COMMON.MAINTENANCE.AJAX.ERROR.INSERT.MESSAGE', MessageManager.getMessage('TOMS.MASTER.MAINTENANCE.PROCESSMETHOD_COMMODITY.DETAIL.INPUT.TITLE'));
        	common.sendErrorResult(msg, MessageManager.getMessage('TOMS.COMMON.MAINTENANCE.AJAX.ERROR.CODEMASTER.NOTINLINE.MESSAGE',MessageManager.getMessage('TOMS.MASTER.MAINTENANCE.PROCESSMETHOD_COMMODITY.LABEL.COMMODITY_CODE')));
    	}    	
  	


    	//登録実行
    	result = insertToF57A5160(entity);
        if (result.error) {
            // 処理が失敗した場合
        	msg = MessageManager.getMessage('TOMS.COMMON.MAINTENANCE.AJAX.ERROR.INSERT.MESSAGE', MessageManager.getMessage('TOMS.MASTER.MAINTENANCE.PROCESSMETHOD_COMMODITY.DETAIL.INPUT.TITLE'));
        	common.sendErrorResult(msg, "");
        }
        
        // 処理が成功した場合
        msg = MessageManager.getMessage('TOMS.COMMON.MAINTENANCE.AJAX.SUCCESS.INSERT.MESSAGE', MessageManager.getMessage('TOMS.MASTER.MAINTENANCE.PROCESSMETHOD_COMMODITY.DETAIL.INPUT.TITLE'));
        common.sendResultParameter(msg,searchInfo);
        
	//------------------------------------
	//更新時
	//------------------------------------
	}else if(request.operateFlag=="1"){


    	//更新処理
		result = updateToF57A5160(entity, condition, params);
        if (result.error) {
            // 処理が失敗した場合
        	msg = MessageManager.getMessage('TOMS.COMMON.MAINTENANCE.AJAX.ERROR.UPDATE.MESSAGE', MessageManager.getMessage('TOMS.MASTER.MAINTENANCE.PROCESSMETHOD_COMMODITY.DETAIL.INPUT.TITLE'));
        	common.sendErrorResult(msg, "");
        }
        if (result.countRow != 1) {
            // 対象データが存在しない場合
        	msg = MessageManager.getMessage('TOMS.COMMON.MAINTENANCE.AJAX.ERROR.UPDATE.MESSAGE', MessageManager.getMessage('TOMS.MASTER.MAINTENANCE.PROCESSMETHOD_COMMODITY.DETAIL.INPUT.TITLE'));
        	common.sendErrorResult(msg, MessageManager.getMessage('TOMS.COMMON.MAINTENANCE.AJAX.ERROR.UPDATE.NODATA.MESSAGE'));
        }
        // 処理が成功した場合
        msg = MessageManager.getMessage('TOMS.COMMON.MAINTENANCE.AJAX.SUCCESS.UPDATE.MESSAGE', MessageManager.getMessage('TOMS.MASTER.MAINTENANCE.PROCESSMETHOD_COMMODITY.DETAIL.INPUT.TITLE'));
        common.sendResultParameter(msg,searchInfo);

//------------------------------------
//削除時
//------------------------------------
	}else if(request.operateFlag=="2"){
    	/*
    	 * DB存在チェック
    	 */
		result = removeFromF57A5160(condition, params);
	    if (result.error) {
	        // 処理が失敗した場合
        	msg = MessageManager.getMessage('TOMS.COMMON.MAINTENANCE.AJAX.ERROR.DELETE.MESSAGE', MessageManager.getMessage('TOMS.MASTER.MAINTENANCE.PROCESSMETHOD_COMMODITY.DETAIL.INPUT.TITLE'));
        	common.sendErrorResult(msg, "");
	    }
        if(result.countRow != 1){
	    	// 処理件数が１件でない場合
        	msg = MessageManager.getMessage('TOMS.COMMON.MAINTENANCE.AJAX.ERROR.DELETE.MESSAGE', MessageManager.getMessage('TOMS.MASTER.MAINTENANCE.PROCESSMETHOD_COMMODITY.DETAIL.INPUT.TITLE'));
        	common.sendErrorResult(msg, MessageManager.getMessage('TOMS.COMMON.MAINTENANCE.AJAX.ERROR.DELETE.NODATA.MESSAGE'));
	    }
	    // 処理が成功した場合
        msg = MessageManager.getMessage('TOMS.COMMON.MAINTENANCE.AJAX.SUCCESS.DELETE.MESSAGE', MessageManager.getMessage('TOMS.MASTER.MAINTENANCE.PROCESSMETHOD_COMMODITY.DETAIL.INPUT.TITLE'));
        common.sendResultParameter(msg,searchInfo);	
	}
}


/**
 * DBへの登録オブジェクト生成処理
 */
function createEntity(request){
	
	var userContext = Contexts.getUserContext();
	var now = new Date();
	
	//変数初期化
	//変数初期化
	var mpy57apmc = null; //加工方法コード
	
	var mpy57acc = null; //商品コード
	var mpeftj =null;//適用開始日
	
	//ヘッダ情報
	var mpy57apcsc= null;//親商品形態コード
	var mpy57acsc= null;//商品形態コード
	var mpy57amtc= null;//素材コード
	var mpy57appc1= null;//加工部位コード
	var mpy57appc2= null;//加工位置コード
	var mpy57apmt= null;//加工方法区分
	var mpy57apmdt= null;//加工方法明細区分	
	var mpuser = userContext.userProfile.userCd; //ユーザID
    var mppid = "TOMS-WEB"; //プログラムID
	var mpupmj = cmnUtil.convertDateToJulia(now);  //更新日付
	var mpupmt = cmnUtil.getTime(now);  //更新時刻
	
	//加工方法コード
    if(!isBlank(request.mmy57apmc)){
    	mpy57apmc = request.mmy57apmc;
    }
    
	//商品コード
    if(!isBlank(request.mpy57acc)){
    	mpy57acc = request.mpy57acc;
    }
	//適用開始日
    if(!isBlank(request.mpeftj)){
    	mpeftj = cmnUtil.convertDateToJulia(new Date(request.mpeftj));
    }
    
    //ヘッダーからの設定
    //加工方法区分 登録時に必要
    if(!isBlank(request.mmy57apmt)){
    	mpy57apmt = request.mmy57apmt;
    }
    //親商品形態コード
    if(!isBlank(request.mmy57apcsc)){
    	mpy57apcsc = request.mmy57apcsc;
    }
    //商品形態コード
    if(!isBlank(request.mmy57acsc)){
    	mpy57acsc = request.mmy57acsc;
    }
    //素材コード
    if(!isBlank(request.mmy57amtc)){
    	mpy57amtc = request.mmy57amtc;
    }
    //加工部位コード
    if(!isBlank(request.mmy57appc1)){
    	mpy57appc1 = request.mmy57appc1;
    }
    //加工位置コード
    if(!isBlank(request.mmy57appc2)){
    	mpy57appc2 = request.mmy57appc2;
    }
    //加工明細区分
    if(!isBlank(request.mmy57apmdt)){
    	mpy57apmdt = request.mmy57apmdt;
    }         


    var entity ={
    	mpy57apmc : mpy57apmc,
    	mpy57apmt : mpy57apmt,
    	mpy57acc : mpy57acc,
        mpeftj : mpeftj,
        mpuser : mpuser,
        mppid : mppid,
        mpupmj : mpupmj,
        mpupmt : mpupmt,
        mpy57apcsc : mpy57apcsc,
        mpy57acsc : mpy57acsc,
        mpy57amtc : mpy57amtc,
        mpy57appc1 : mpy57appc1,
        mpy57appc2 : mpy57appc2,
        mpy57apmdt : mpy57apmdt
    };
    return entity;
}

/*データ存在チェック（加工方法商品関連付け）*/

function _dbCheck(mpy57apmc,mpy57acc,mpeftj){
	var db = new SharedDatabase(_SHARED_DB_KEY);
	var params = [];

	var sql ="";
	sql += " SELECT * FROM F57A5160 ";
	sql +="     WHERE ";
	sql +="              TRIM(MPY57APMC) = ? ";
	sql +="          AND TRIM(MPY57ACC) = ? ";
	  params.push(DbParameter.string(mpy57apmc));
	  params.push(DbParameter.string(mpy57acc));
	  
	if(!isBlank(mpeftj)){
		sql += "          AND MPEFTJ = ? ";
		  params.push(DbParameter.number(mpeftj));
	}


	var result = db.execute(sql, params);
	return result;
}

	/*データ存在チェック(商品マスタ)*/

function _dbCheckCommodity(mpy57acc){
	var db = new SharedDatabase(_SHARED_DB_KEY);
	var params = [];

	var sql ="";
	sql += " SELECT * FROM F4101 ";
	sql +="     WHERE ";
	sql +="              TRIM(IMLITM) = ? ";
	sql +="          AND TRIM(IMSRP8) = '1' ";

  params.push(DbParameter.string("01"+mpy57acc));
	var result = db.execute(sql, params);
	return result;
}

/**
 * 登録処理
 */
function insertToF57A5160(entity){
	var database = new SharedDatabase(_SHARED_DB_KEY);
	var ret = Transaction.begin(function(){
		entity.mpy57adflg=0;//削除フラグ追加
		entity.mpexdj = cmnUtil.convertDateToJulia(new Date(MessageManager.getMessage('TOMS.COMMON.CONSTANT.ENDDATE')));
		var result = database.insert('F57A5160', entity);
		if(result.error || result.countRow !=1){
			Transaction.rollback();
		}
		return result;
	})
	return ret.data;
}
function updateToF57A5160(entity, condition, params) {
	var database = new SharedDatabase(_SHARED_DB_KEY);
	var ret = Transaction.begin(function(){
		var result = database.update('F57A5160', entity, condition, params);
		if(result.error || result.countRow !=1){
			Transaction.rollback();
		}
			return result;
	})
	return ret.data;
}
function removeFromF57A5160(condition, params) {
	var database = new SharedDatabase(_SHARED_DB_KEY);
	var ret = Transaction.begin(function(){
		var entity ={
			mpy57adflg : 1
			};
		var result = database.update('F57A5160',entity,  condition, params);
		if(result.error || result.countRow !=1){
			Transaction.rollback();
		}
		return result;
	})
	return ret.data;
}

// ヘッダー情報設定
function setData(request){
	var mmy57apmc = isBlank(request.mpy57apmc) ? "": request.mpy57apmc; //加工方法コード 
	var mmy57apcsc = isBlank(request.mmy57apcsc) ? "": request.mmy57apcsc; //親商品形態コード
	var mmy57acsc = isBlank(request.mmy57acsc) ? "": request.mmy57acsc; //商品形態コード
	var mmy57amtc = isBlank(request.mmy57amtc) ? "": request.mmy57amtc; //素材コード
	var mmy57appc1 = isBlank(request.mmy57appc1) ? "": request.mmy57appc1; //加工部位コード
	var mmy57appc2 = isBlank(request.mmy57appc2) ? "": request.mmy57appc2; //加工位置コード
	var mmy57apmt = isBlank(request.mmy57apmt) ? "": request.mmy57apmt; //加工方法区分
	var mmy57apmdt = isBlank(request.mmy57apmdt) ? "": request.mmy57apmdt; //加工方法明細区分
	var mmdl01 = isBlank(request.mmdl01) ? "": request.mmdl01; //加工方法名称
	
	var seachObj ={
		mmy57apmc:mmy57apmc,
	mmy57apcsc : mmy57apcsc,
	mmy57acsc : mmy57acsc,
	mmy57amtc : mmy57amtc,
	mmy57amtc : mmy57amtc,
	mmy57appc1 : mmy57appc1,
	mmy57appc2 : mmy57appc2,
	mmy57apmt : mmy57apmt,
	mmy57apmdt : mmy57apmdt,
	mmdl01 : mmdl01
	}

	return seachObj;

}

