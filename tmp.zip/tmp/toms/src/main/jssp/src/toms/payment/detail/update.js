/**
 * バインド変数.
 */
var $bind = {};
var $data;
load('toms/common/cmnUtil');
load('toms/common/common');


/**
 * 初期表示.
 * @param request リクエストパラメータ.
 */
function init(request) {
	
    var response = Web.getHTTPResponse();
    response.setContentType('application/json; charset=utf-8');

	var operation = request.operation;
	var operation2 = request.operation2;
	var stErr = new java.lang.StringBuilder(); // エラー文言
	$bind.operation = operation;
	$bind.mapyrFrom = request.mapyrFrom;
	$bind.mapyrTo = request.mapyrTo;
	var mapyrFrom = request.mapyrFrom;
	var mapyrTo = request.mapyrTo;

	var userContext = Contexts.getUserContext();
	var mauser = userContext.userProfile.userCd; // ユーザー ID
	var mapid  = MessageManager.getMessage('TOMS.COMMON.CONSTANT.PROGRAM.ID');    			// プログラム ID
	var majobn = null;      				// ワーク ステーションID
	var now = new Date();
	var maupmj = cmnUtil.convertDateToJulia(now);	// 更新 日付
	var maupmt = cmnUtil.getTime(now);    			// 更新 時刻
	var msg;
	var checkErrTitileMsg;
	var st;
	
	if(operation2 == "new" || operation2 == "new2"){
		checkErrTitileMsg = MessageManager.getMessage('TOMS.COMMON.MAINTENANCE.AJAX.ERROR.INSERT.MESSAGE', MessageManager.getMessage('TOMS.PAYMENT.LIST.INPUT.FILENAME'));
	}else if(operation2 == "update"){
		checkErrTitileMsg = MessageManager.getMessage('TOMS.COMMON.MAINTENANCE.AJAX.ERROR.UPDATE.MESSAGE', MessageManager.getMessage('TOMS.PAYMENT.LIST.INPUT.FILENAME'));
	}else{
		checkErrTitileMsg = MessageManager.getMessage('TOMS.COMMON.MAINTENANCE.AJAX.ERROR.DELETE.MESSAGE', MessageManager.getMessage('TOMS.PAYMENT.LIST.INPUT.FILENAME'));
	}

	// ページング
	$data = {
		rowNum  : 12,
		rowList : [50, 100, 150]
	};

	// dbチェック
	if(!dbCheck(request, stErr)) {
		st = stErr.toString();
    	msg = checkErrTitileMsg;
    	common.sendErrorResult(msg, st);
	}
	
	// 新規作成
	if(operation2 == "new" || operation2 == "new2") {
		var ret = doInsert(request, stErr, mauser, mapid, majobn, maupmj, maupmt);
		if(ret == false) {
			// 失敗時　 自画面へ遷移
			st = stErr.toString();
	    	msg = checkErrTitileMsg;
	    	common.sendErrorResult(msg, st);
		}
		// 成功時　一覧画面 へ遷移
        msg = MessageManager.getMessage('TOMS.COMMON.MAINTENANCE.AJAX.SUCCESS.INSERT.MESSAGE', MessageManager.getMessage('TOMS.PAYMENT.LIST.INPUT.FILENAME'));
        common.sendResult(msg,{mapyrFrom: mapyrFrom,
        											mapyrTo: mapyrTo,
        											operation: operation,
        											operation2: operation2});
	// 更新
	} else if(operation2 == "update") {
		var ret = doUpdate(request, stErr, mauser, mapid, majobn, maupmj, maupmt);
		if(ret == false) {
			// 失敗時　 自画面へ遷移
			st = stErr.toString();
	    	msg = checkErrTitileMsg;
	    	common.sendErrorResult(msg, st);
		} else {
			//　成功時　一覧画面 へ遷移
        msg = MessageManager.getMessage('TOMS.COMMON.MAINTENANCE.AJAX.SUCCESS.UPDATE.MESSAGE', MessageManager.getMessage('TOMS.PAYMENT.LIST.INPUT.FILENAME'));
        common.sendResult(msg,{mapyrFrom: mapyrFrom,
        											mapyrTo: mapyrTo,
        											operation: operation,
        											operation2: operation2});
        }
	// 削除
	} else {
		var ret = doDelete(request, stErr);
		if(ret == false) {
			// 失敗時　 自画面へ遷移
			st = stErr.toString();
	    	msg = checkErrTitileMsg;
	    	common.sendErrorResult(msg, st);
	    } else {
			//　成功時　一覧画面 へ遷移
        msg = MessageManager.getMessage('TOMS.COMMON.MAINTENANCE.AJAX.SUCCESS.DELETE.MESSAGE', MessageManager.getMessage('TOMS.PAYMENT.LIST.INPUT.FILENAME'));
        common.sendResult(msg,{mapyrFrom: mapyrFrom,
        											mapyrTo: mapyrTo,
        											operation: operation,
        											operation2: operation2});
		}
	}
}

/*
 * DBによるデータ有無チェック
 * @param request　リクエスト
 * @param stErr エラーメッセージパラメータ.(OUT)
 */
function dbCheck(request, stErr) {

	var result;
	var dbPram = [1];
	var ret = true;
	var db = new SharedDatabase("toms-web-dev");

	// 支払人No 入金パターンマスタ重複チェック
	var ope = request.operation2;
	var pram =  request.mapyr;
	dbPram[0] = DbParameter.string(pram);
	result = db.select('select mapyr from F56C1030 where mapyr = ?', dbPram, 0);

	// 挿入の場合
	if(ope == "new" || ope == "new2"  ) {
		if(result.countRow > 0 ) {
			//stErr.append("データが重複しています。 支払人No=" + pram + "");
			stErr.append( 
				MessageManager.getMessage('TOMS.PAYMENT.DETAIL.MESSAGE.UPDATE.DUPLICATED',pram));//OK
				ret = false;
		}
	// 更新、削除の場合
	} else {
		if(result.countRow < 1 ) {
			//stErr.append("入金パターンマスタにデータが存在しません。 支払人No=" + pram + "");
			stErr.append(
				MessageManager.getMessage('TOMS.PAYMENT.DETAIL.MESSAGE.UPDATE.NOTEXIST', pram));
				ret = false;
		}
	}

	// 削除の場合　以降チェックなし
	if(ope == "D") {
		return ret;
	}

	// 支払 条件1 7 f0014
	pram = request.may56ctra1;
	if( pram != null && pram != "" ) {
		dbPram[0] = DbParameter.string(pram);
		result = db.select('select pnptc from f0014 where pnptc = ?', dbPram, 0);
		if(result.countRow < 1 ) {
			stErr.append(
				//stErr.append("<p>支払 条件1は支払条件マスタにデータが存在しません。 支払 条件1=" + pram + "</p>");
				MessageManager.getMessage('TOMS.PAYMENT.DETAIL.MESSAGE.UPDATE.MAY56CTRA1', pram));//OK
			ret = false;
		}
	}

	// 支払 条件2 9 支払 条件1をコピーするためチェック不要
	// 超過支払 条件1 13 支払 条件1をコピーするためチェック不要
	// 超過支払 条件2 15 支払 条件1をコピーするためチェック不要

	return ret;
}

/**
 * 挿入
 */
function doInsert(request, stErr, mauser, mapid, majobn, maupmj, maupmt) {
	
	Transaction.begin();
	var result = new SharedDatabase("toms-web-dev").insert('F56C1030',
					{
							mapyr : Number(request.mapyr),
							macrcd : request.macrcd,
							may56cathr : (request.may56cathr == "" ? null : Number(request.may56cathr)),
							may56crper : (request.may56crper*1000 == "" ? null : Number(request.may56crper)*1000),
							may56carec : (request.may56carec == "" ? null : Number(request.may56carec)),
							may56cryi1 : request.may56cryi1,
							may56ctra1 : request.may56ctra1,
							may56cryi2 : request.may56cryi2,
							may56ctra2 : request.may56ctra2,
							may56cerpe : (request.may56cerpe*1000 == "" ? null : Number(request.may56cerpe)*1000),
							may56ceare : (request.may56ceare == "" ? null : Number(request.may56ceare)),
							may56cery1 : request.may56cery1,
							may56cetr1 : request.may56cetr1,
							may56cery2 : request.may56cery2,
							may56cetr2 : request.may56cetr2,
							// 支払条件
							maurrf : request.maurrf,
							mauser : mauser,	
							mapid  : mapid,		
							maupmj : maupmj,	
							maupmt : maupmt		
					}
														);

	if(!result.error && result.countRow != 1) {
		//$bind.msg = "処理数が異常でした。処理件数:" + result.countRow + "件(1件が正常)";
		stErr.append(
			MessageManager.getMessage('TOMS.PAYMENT.DETAIL.MESSAGE.UPDATE.PROCESSNUM', result.countRow));//OK
			Transaction.rollback();
	    return false;
	}

	if(result.error) {
		stErr.append(result.errorMessage);
	    Transaction.rollback();
	    return false;
	}
	Transaction.commit();
	//$bind.msg = "正常に挿入しました。";
	stErr.append( MessageManager.getMessage('TOMS.PAYMENT.DETAIL.MESSAGE.UPDATE.DATAINSERT.SUCCESS'));//OK
	return true;
}

/**
 * 更新
 */
function doUpdate(request, stErr, mauser, mapid, majobn, maupmj, maupmt) {
	var may56ceare = request.may56ceare;
	var nmay56ceare = Number(request.may56ceare);
	var a = (isNull(request.may56ceare) ? null : Number(request.may56ceare));
	var a1 = (request.may56ceare == "" ? null : Number(request.may56ceare));
	Transaction.begin();
	var result =new SharedDatabase('toms-web-dev').update('F56C1030', 
			{
					macrcd : request.macrcd,
																
					may56cathr : (request.may56cathr == "" ? null : Number(request.may56cathr)),
					may56crper : (request.may56crper*1000 == "" ? null : Number(request.may56crper)*1000),
					may56carec : (request.may56carec == "" ? null : Number(request.may56carec)),
																
					may56cryi1 : request.may56cryi1,
					may56ctra1 : request.may56ctra1,
					may56cryi2 : request.may56cryi2,
					may56ctra2 : request.may56ctra2,
					may56cerpe : (request.may56cerpe*1000 == "" ? null : Number(request.may56cerpe)*1000),
					may56ceare : (request.may56ceare == "" ? null : Number(request.may56ceare)),
					may56cery1 : request.may56cery1,
					may56cetr1 : request.may56cetr1,
					may56cery2 : request.may56cery2,
					may56cetr2 : request.may56cetr2,
                    // 支払条件
                    maurrf : request.maurrf,
					mauser : mauser,	// TODO
					mapid  : mapid,		// TODO
					//dmajobn : majobn,	// TODO
					maupmj : maupmj,	// TODO
					maupmt : maupmt		// TODO
			},
		'mapyr = ?', 
		[DbParameter.string(request.mapyr)]);
		if(!result.error && result.countRow != 1) {
		//$bind.msg = "処理数が異常でした。処理件数:" + result.countRow + "件(1件が正常)";
		stErr.append(
				MessageManager.getMessage('TOMS.PAYMENT.DETAIL.MESSAGE.UPDATE.PROCESSNUM', result.countRow));//OK
		Transaction.rollback();
		return false;
}

	if(result.error) {
		$bind.msg = result.errorMessage;
	    Transaction.rollback();
	    return false;
	}
	Transaction.commit();
	//$bind.msg = "正常に更新しました。";
	stErr.append(MessageManager.getMessage('TOMS.PAYMENT.DETAIL.MESSAGE.UPDATE.DATAEDIT.SUCCESS'));//OK
	return true;
}

/**
 * 削除
 */
function doDelete(request, stErr) {
	Transaction.begin();
	var result =new SharedDatabase('toms-web-dev').remove ('F56C1030', 'mapyr = ?', [DbParameter.string(request.mapyr)]);
	if(result.countRow != 1) {
		//stErr.append("処理数が異常でした。処理件数:" + result.countRow + "件(1件が正常)");
		stErr.append(
			MessageManager.getMessage('TOMS.PAYMENT.DETAIL.MESSAGE.UPDATE.PROCESSNUM', result.countRow));//OK
	    Transaction.rollback();
	    return false;
	}

	if(result.error) {
		$bind.msg = result.errorMessage;
	    Transaction.rollback();
	    return false;
	}
	Transaction.commit();
	//stErr.append("正常に削除しました。");
	stErr.append( MessageManager.getMessage('TOMS.PAYMENT.DETAIL.MESSAGE.UPDATE.DELETE.SUCCESS'));//OK
	return true;
}

