SELECT
    MGAN8
	,MGY57ASPCD
	,MGRNO
FROM
  F57A5070
/*BEGIN*/
WHERE
	/*IF mgan8 != null*/
	    MGAN8 = /*mgan8*/'0'
	/*END*/
	/*IF mgy57aspcd != null*/
	AND
	    MGY57ASPCD = /*mgy57aspcd*/'0'
	/*END*/
	/*IF mgrno != null*/
	AND
	    MGRNO = /*mgrno*/'0'
	/*END*/
/*END*/