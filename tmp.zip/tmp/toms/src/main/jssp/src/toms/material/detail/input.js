/**
 * 素材マスタメンテナンス登録・更新画面
 *
 * src /src/toms/material/detail/input.js
 * 
 **/
var $bind ={};


function init(request){

	$bind.flag ="0"; //新規、更新フラグ　新規：0　更新：1　
	if(!isBlank(request.updateFlag)){
		$bind.flag = request.updateFlag;
	}
	$bind.inputFlg = "false";
	var endDate=MessageManager.getMessage('TOMS.COMMON.CONSTANT.ENDDATE');

	if($bind.flag=="1"){
		$bind.inputFlg ="true";
		//画面タイトル
		$bind.title = MessageManager.getMessage('TOMS.MASTER.MAINTENANCE.MATERIAL.DETAIL.INPUT.UPDATE.TITLE');
		//更新時、前画面から設定値を受け取る
        $bind.mly57amtc = request.mly57amtc;//素材コード
        $bind.mldl01 = request.mldl01;//原材料
        $bind.mly57acsc = request.mly57acsc;//商品形態コード
        $bind.mly57apcsc = request.mly57apcsc;//親商品形態コード
        $bind.mlpct1 = request.mlpct1;//パーセント
        $bind.mlsnn = request.mlsnn;//表示順
        $bind.mly57ajdc = request.mly57ajdc;//JDEコード
        $bind.mly57amflg = request.mly57amflg;//たたみ袋制御フラグ
        $bind.mly57absc = request.mly57absc;//たたみ袋SKUコード
        $bind.mleftj = request.mleftj;//適用開始日


	}else{
		//新規登録時
		$bind.title = MessageManager.getMessage('TOMS.MASTER.MAINTENANCE.MATERIAL.DETAIL.INPUT.ENTRY.TITLE');
	}

	$bind.mlexdj = endDate;//適用終了日
	var selectedFlg = false;
	if(!isBlank($bind.mly57amflg) && $bind.mly57amflg=="1"){
		selectedFlg = true;
	}

	$bind.matControlList  = [
	                         {label : "OFF",
	                        	 value:"0"
	                        },{
	                        	label : "ON",
	                        	value:"1",
	                        	selected : selectedFlg
	                        }];
    $bind.dialogMessages = ({
        entryTitle: MessageManager.getMessage('TOMS.COMMON.ENTRY'),
        entryMessage: MessageManager.getMessage('TOMS.MASTER.MAINTENANCE.MATERIAL.DETAIL.INPUT.ENTRY.MESSAGE'),
        updateTitle: MessageManager.getMessage('TOMS.COMMON.UPDATE'),
        updateMessage: MessageManager.getMessage('TOMS.MASTER.MAINTENANCE.MATERIAL.DETAIL.INPUT.UPDATE.MESSAGE'),
        deleteTitle: MessageManager.getMessage('TOMS.COMMON.DELETE'),
        deleteMessage: MessageManager.getMessage('TOMS.MASTER.MAINTENANCE.MATERIAL.DETAIL.INPUT.DELETE.MESSAGE')
      }).toSource();

      $bind.selected = true;

}