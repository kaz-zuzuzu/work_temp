/**
 * バインド変数.
 */
var $bind = {};

/**
 * 初期表示.
 * @param request リクエストパラメータ.
 */
function init(request) {

	// テキストボックスの初期値を設定
	$bind.productNo = MessageManager.getMessage("TOMS.MULTISEARCH.LABEL.INPUT.PRODUCT.FIVE.LENGTH");
	$bind.exchangeNmKn = MessageManager.getMessage("TOMS.MULTISEARCH.LABEL.INPUT.HALFWIDTH.KATAKANA");

}

