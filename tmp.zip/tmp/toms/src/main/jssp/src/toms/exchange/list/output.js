/**
 * バインド変数.
 */
var $bind = {};

//検索結果を返却するオブジェクトの初期化を行う
$bind.exchangeTargetData = [];

load("toms/common/master");
load('toms/common/common');

var splitComma = MessageManager.getMessage('TOMS.COMMON.COMMA');

/**
 * 初期表示.
 * @param request リクエストパラメータ.
 */
function init(request) {

//    var STOPKOZACD = "700,800";  // 分類2: 業務停止口座・長期未稼働口座
    var STOPKOZACD = "070,080";  // 分類1: 業務停止口座・長期未稼働口座
    var TANTOSYA_TEXT = "text";  // 「担当者ラジオボックス」　(select:プルダウン　text:テキスト）
    var MAX_COUNT = 1500;        // 一覧最大表示件数

    //　検索条件（検索用）
    var searchExchangeTargetId = request.searchExchangeTargetId;
    var exchangeCategoryCd = request.exchangeCategory;
    var superOrganizationCd = request.superOrganization;
    var organizationCd = request.organization;
    var bunrui1Cd = request.bunrui1;
    var notinBunrui1Cd = null;
    var bunrui2Cd = request.bunrui2;
    var searchBunrui2Cd = bunrui2Cd;
    var stopKozaFlg = request.stopKozaFlg;
    if (stopKozaFlg != null && stopKozaFlg != "") {
        if (searchBunrui2Cd != null && searchBunrui2Cd != "" && searchBunrui2Cd != " ") {
            searchBunrui2Cd = searchBunrui2Cd + "," + STOPKOZACD;
        }
        $bind.stopKozaFlgNm = MessageManager.getMessage('TOMS.EXCHANGE.SEARCH.INPUT.SUSPENSION.BUSSINESS');
    } else {
    	notinBunrui1Cd = STOPKOZACD;
    }
    // 担当者
    var chargePersonRadio = request.chargePersonRadio;
    var chargePersonText = request.chargePersonText;
    var chargePersonCd = null;
    var searchChargePersonNm = null;
    var chargePersonNm = null;
    if (chargePersonRadio == TANTOSYA_TEXT) {
        searchChargePersonNm = request.chargePersonText;
        chargePersonNm = searchChargePersonNm;
    } else {
        chargePersonCd = request.chargePerson;
        if (chargePersonCd != null && chargePersonCd != "" && chargePersonCd != " ") {
             chargePersonNm = request.chargePersonNm;
         }
    }
 
    var todoufukenCd = request.todoufuken;
    var exchangeTargetKn = request.exchangeTargetKn;
    var phone = request.phone;
    var fax = request.fax;
    if (!isBlank(phone)) {
    	var telNo = phone.replace(/-/g, "");
    }
    if (!isBlank(fax)) {
    	var faxNo = fax.replace(/-/g, "");
    }
    
    if (request.screenId == "outputCSV") {
    	outputCSV(request.csv_searchExchangeTargetId, request.csv_exchangeCategoryCd, request.csv_organizationCd, request.csv_bunrui1Cd, request.csv_notinBunrui1Cd, request.csv_bunrui2Cd, request.csv_chargePersonCd, request.csv_chargePersonNm, request.csv_todoufukenCd, request.csv_exchangeTargetKn, request.csv_phone, request.csv_fax);
    }else{
    
    	// 検索条件（画面表示用）
    	// .取引種別
    	$bind.exchangeCategoryNm = request.exchangeCategoryNm;
    	// 取引種別コード
    	$bind.exchangeCategoryCd = exchangeCategoryCd;
    	// .上位組織
    	$bind.superOrganizationNm = request.superOrganizationNm;
    	// .上位組織コード
    	$bind.superOrganizationCd = superOrganizationCd;
    	// .組織
    	$bind.organizationNm = request.organizationNm;
    	// .組織コード
    	$bind.organizationCd = organizationCd;
    	// .分類１
    	$bind.bunrui1Nm = request.bunrui1Nm;
    	// .分類1コード
    	$bind.bunrui1Cd = bunrui1Cd;
    	// .分類２
    	$bind.bunrui2Nm = request.bunrui2Nm;
    	// .分類２コード
    	$bind.bunrui2Cd = bunrui2Cd;
    	// 担当者
    	$bind.chargePersonNm = chargePersonNm;
    	// 担当者コード
    	$bind.chargePersonCd = chargePersonCd;
    	// .都道府県
    	$bind.todoufukenNm = request.todoufukenNm;
    	// .都道府県コード
    	$bind.todoufukenCd = todoufukenCd;
    	//.取引先コード
    	$bind.searchExchangeTargetId = searchExchangeTargetId;
    	//.取引先カナ
    	$bind.exchangeTargetKn = exchangeTargetKn;
    	//.電話番号
    	$bind.phone = phone;
        //.notin分類1
        $bind.notinBunrui1Cd = notinBunrui1Cd;

    	//.FAX番号
    	$bind.fax = fax;
    	//.区切り文字（スラッシュ）検索条件表示用：TEL FAX
    	$bind.telAndFax = " ";
    	var slashTel = isBlank(phone) ? " - " : phone;
    	var slash = " / ";
    	var slashFax = isBlank(fax) ? " - " : fax;
    	if(!isBlank(phone) ||  !isBlank(fax)){
        $bind.telAndFax = slashTel + slash + slashFax;
    	}
    	// 取引先一覧の件数を取得する 
    	var resultCount = getExchangeTargetListCount(searchExchangeTargetId, exchangeCategoryCd, organizationCd, bunrui1Cd, notinBunrui1Cd, searchBunrui2Cd, chargePersonCd, searchChargePersonNm, todoufukenCd, exchangeTargetKn, telNo, faxNo);
    	var cntMessage = "表示件数：　" + resultCount + "件　／　検索結果：　" + resultCount + "件";
    	if (resultCount > MAX_COUNT) {
    		cntMessage = "表示件数：　" + MAX_COUNT + "件　／　検索結果：　" + resultCount + "件";
    	}
    	$bind.cntMessage = cntMessage;
    
    	// 取引先一覧を取得する 
    	if (resultCount > 0) {
    		getExchangeTargetList(searchExchangeTargetId, exchangeCategoryCd, organizationCd, bunrui1Cd, notinBunrui1Cd, searchBunrui2Cd, chargePersonCd, searchChargePersonNm, todoufukenCd, exchangeTargetKn, telNo, faxNo);
    		//CSV出力のため、initで加工された値を画面検索時の直後で取得
    		$bind.csv_searchExchangeTargetId = searchExchangeTargetId;
    		$bind.csv_exchangeCategoryCd = exchangeCategoryCd;
    		$bind.csv_organizationCd = organizationCd;
    		$bind.csv_bunrui1Cd = bunrui1Cd;
    		$bind.csv_notinBunrui1Cd = notinBunrui1Cd;
    		$bind.csv_bunrui2Cd = searchBunrui2Cd;
    		$bind.csv_chargePersonCd = chargePersonCd;
    		$bind.csv_chargePersonNm = searchChargePersonNm;
    		$bind.csv_todoufukenCd = todoufukenCd;
    		$bind.csv_exchangeTargetKn = exchangeTargetKn;
    		$bind.csv_phone = telNo;
    		$bind.csv_fax = faxNo;
    	}
    
    	// 特価有無の「有り」リンク押下時の確認ダイアログのメッセージを初期化.
    	// JavaScriptで利用するためオブジェクトの内容をそのまま渡します.
    	$bind.dialogMessages = ({
    		addConfirmTitle: MessageManager.getMessage('TOMS.COMMON.DIALOG.CONFIRM.TITLE'),
    		addConfirmMessage: MessageManager.getMessage('TOMS.COMMON.DIALOG.CONFIRM.MESSAGE.COMMA')
    	}).toSource();
    }
}
/**
 * 取引先一覧を取得する
 */
function getExchangeTargetList(exchangeTargetId, exchangeCategoryCd, organizationCd, bunrui1Cd, notinBunrui1Cd, bunrui2Cd, chargePersonCd, chargePersonNm, todoufukenCd, exchangeTargetKn, telNo, faxNo) {
    var result = TomsMaster.getExchangeTargetList(exchangeTargetId, exchangeCategoryCd, organizationCd, bunrui1Cd, notinBunrui1Cd, bunrui2Cd, chargePersonCd, chargePersonNm, todoufukenCd, exchangeTargetKn, telNo, faxNo, false);
    if (!result.error) {
        $bind.exchangeTargetData = result.data;
    } else {
        error(result.errorMessage);
    }
}
  
/**
 * 取引先一覧の件数を取得する
 */
function getExchangeTargetListCount(exchangeTargetId, exchangeCategoryCd, organizationCd, bunrui1Cd, notinBunrui1Cd, bunrui2Cd, chargePersonCd, chargePersonNm, todoufukenCd, exchangeTargetKn, telNo, faxNo) {
    var resultCount = 0;
    var result = TomsMaster.getExchangeTargetList(exchangeTargetId, exchangeCategoryCd, organizationCd, bunrui1Cd, notinBunrui1Cd, bunrui2Cd, chargePersonCd, chargePersonNm, todoufukenCd, exchangeTargetKn, telNo, faxNo, true);
    if (!result.error) {
    	resultCount = result.data[0]['cnt'];
    } else {
        error(result.errorMessage);
    }
    return resultCount;
}

/**
 * 取引先一覧のCSV出力処理.
 * 
 *
 */
function outputCSV(searchExchangeTargetId, exchangeCategoryCd, organizationCd, bunrui1Cd, notinBunrui1Cd, bunrui2Cd, chargePersonCd, chargePersonNm, todoufukenCd, exchangeTargetKn, telNo, faxNo) {
    var result = TomsMaster.getExchangeTargetList(searchExchangeTargetId, exchangeCategoryCd, organizationCd, bunrui1Cd, notinBunrui1Cd, bunrui2Cd, chargePersonCd, chargePersonNm, todoufukenCd, exchangeTargetKn, telNo, faxNo, false);
    var outputContent = "";
    if (!result.error) {
        outputContent = outputCSVHeader();
        for (var i = 0; i < result.countRow; i++) {
            outputContent += outputCSVRow(result.data[i]);
        }
        var strDateTime = DateTimeFormatter.format("yyyyMMddHHmmss", new Date());
        var fileName = MessageManager.getMessage('TOMS.EXCHANGE.LIST.LABEL.TITTLE') + '_' + strDateTime + '.csv';
        Module.download.send(Unicode.to(outputContent, 'MS932'), fileName, MessageManager.getMessage('TOMS.COMMON.MIME.CSV'));
    } else {
        errorcsv(result.errorMessage);
    }
}

/**
 * 取引先一覧のCSVヘッダ部分出力処理.
 */
function outputCSVHeader() {
    var outputHeader = common.convertWithSplit(MessageManager.getMessage('TOMS.EXCHANGE.LIST.LABEL.EXCHANGETARGET.CODE'), splitComma, true)		// 取引先コード
                       + common.convertWithSplit(MessageManager.getMessage('TOMS.EXCHANGE.LIST.LABEL.EXCHANGETARGET.NAME'), splitComma, true)	// 取引先名
                       + common.convertWithSplit(MessageManager.getMessage('TOMS.EXCHANGE.LIST.LABEL.EXCHANGETARGET.KANA'), splitComma, true)   // 取引先カナ
                       + common.convertWithSplit(MessageManager.getMessage('TOMS.EXCHANGE.LIST.LABEL.ADDRNO'), splitComma, true)  				//　住所番号
                       + common.convertWithSplit(MessageManager.getMessage('TOMS.EXCHANGE.LIST.LABEL.ADDR1'), splitComma, true)  				//　住所1
                       + common.convertWithSplit(MessageManager.getMessage('TOMS.EXCHANGE.LIST.LABEL.ADDR2'), splitComma, true)  				//　住所2
                       + common.convertWithSplit(MessageManager.getMessage('TOMS.EXCHANGE.LIST.LABEL.ADDR3'), splitComma, true)  				//　住所3
                       + common.convertWithSplit(MessageManager.getMessage('TOMS.EXCHANGE.LIST.LABEL.ADDR4'), splitComma, true)  				//　住所4
                       + common.convertWithSplit(MessageManager.getMessage('TOMS.EXCHANGE.LIST.LABEL.PHONE'), splitComma, true)  				//　電話番号
                       + common.convertWithSplit(MessageManager.getMessage('TOMS.EXCHANGE.LIST.LABEL.FAX'), splitComma, true)  					//　FAX番号
                       + common.convertWithSplit(MessageManager.getMessage('TOMS.EXCHANGE.LIST.LABEL.PRICERANK'), splitComma, true)  			//　価格ランク
                       + common.convertWithSplit(MessageManager.getMessage('TOMS.EXCHANGE.LIST.LABEL.SALEPRICE'), splitComma, true)  			//　特価有無
                       + common.convertWithSplit(MessageManager.getMessage('TOMS.EXCHANGE.LIST.LABEL.NOTICE'), splitComma, true)  				//　特記事項
                       + common.convertWithSplit(MessageManager.getMessage('TOMS.EXCHANGE.LIST.LABEL.CREDITALLOWEDLIMIT'), splitComma, true)  	//　与信限度額
                       + common.convertWithSplit(MessageManager.getMessage('TOMS.EXCHANGE.LIST.LABEL.PAYMENTTERMS'), splitComma, true)  		//　取引条件
                       + common.convertWithSplit(MessageManager.getMessage('TOMS.EXCHANGE.LIST.LABEL.FACTORING'), splitComma, true)  			//　ファクタリング有無
                       + common.convertWithSplit(MessageManager.getMessage('TOMS.EXCHANGE.LIST.LABEL.PAYMENTCONDITION'), splitComma, true)  	//　支払条件
                       + common.convertWithSplit(MessageManager.getMessage('TOMS.EXCHANGE.LIST.LABEL.CATEGORY1'), splitComma, true)  			//　分類1
                       + common.convertWithSplit(MessageManager.getMessage('TOMS.EXCHANGE.LIST.LABEL.CATEGORY2'), splitComma, true)  			//　分類2
                       + common.convertWithSplit(MessageManager.getMessage('TOMS.EXCHANGE.LIST.LABEL.CATEGORY3'), splitComma, true)  			//　分類3
                       + common.convertWithSplit(MessageManager.getMessage('TOMS.EXCHANGE.LIST.LABEL.SUPERORGANIZATION'), splitComma, true)  	//　上位組織
                       + common.convertWithSplit(MessageManager.getMessage('TOMS.EXCHANGE.LIST.LABEL.ORGANIZATION'), splitComma, true)  		//　組織
                       + common.convertWithSplit(MessageManager.getMessage('TOMS.EXCHANGE.LIST.LABEL.CHARGEPERSON'), splitComma, true)  		//　営業担当者
                       + common.convertWithSplit(MessageManager.getMessage('TOMS.EXCHANGE.LIST.LABEL.SEARCHTYPE'), splitComma, true)  			//　検索タイプ
                       + common.convertWithSplit(MessageManager.getMessage('TOMS.EXCHANGE.LIST.LABEL.SEARCHTYPE.NAME'), splitComma, false)      // 検索タイプ名
	return outputHeader;
}
	/**
 * 取引先一覧のCSVファイルの行を出力する処理.
 * 
 * @param record DBから検索した行のデータ.
 */
function outputCSVRow(record) {
	var yoshin = new String(record["yoshingendogaku"]).replace( /,/g, "" );
    var result = common.convertWithSplit(record["torihikisakicd"], splitComma, true)		// 取引先コード
    			+ common.convertWithSplit(record["torihikisakimei"], splitComma, true)		// 取引先名
    			+ common.convertWithSplit(record["torihikisakikana"], splitComma, true)		// 取引先カナ
    			+ common.convertWithSplit(record["yuubinbangou"], splitComma, true)			// 住所番号
    			+ common.convertWithSplit(record["jyusyo1"], splitComma, true)				// 住所1
    			+ common.convertWithSplit(record["jyusyo2"], splitComma, true)				//　住所2
    			+ common.convertWithSplit(record["jyusyo3"], splitComma, true)				//　住所3
    			+ common.convertWithSplit(record["jyusyo4"], splitComma, true)				//　住所4
    			+ common.convertWithSplit(record["phone"], splitComma, true)				//　電話番号
    			+ common.convertWithSplit(record["fax"], splitComma, true)					// FAX番号
    			+ common.convertWithSplit(record["kakakurankmei"], splitComma, true)		// 価格ランク
    			+ common.convertWithSplit(record["tokukaumu"], splitComma, true)			// 特価有無
    			+ common.convertWithSplit(record["tokukijikou"], splitComma, true)			// 特記事項
    			+ common.convertWithSplit(yoshin, splitComma, true)							// 与信限度額
    			+ common.convertWithSplit(record["torihikijyouken"], splitComma, true)		// 取引条件
    			+ common.convertWithSplit(record["factoringumu"], splitComma, true)			// ファクタリング有無
    			+ common.convertWithSplit(record["shiharaijouken"], splitComma, true)		// 支払条件
    			+ common.convertWithSplit(record["bunrui1mei"], splitComma, true)			// 分類1
    			+ common.convertWithSplit(record["bunrui2mei"], splitComma, true)			// 分類2
    			+ common.convertWithSplit(record["bunrui3mei"], splitComma, true)			// 分類3
    			+ common.convertWithSplit(record["jigyosyomei"], splitComma, true)			// 上位組織
    			+ common.convertWithSplit(record["sosikimei"], splitComma, true)			// 組織
    			+ common.convertWithSplit(record["eigyoutantousyamei"], splitComma, true)	// 営業担当者
    			+ common.convertWithSplit(record["searchtypecd"], splitComma, true)			// 検索タイプ
    			+ common.convertWithSplit(record["searchtypemei"], splitComma, false)		// 検索タイプ名
    return result;
}

/**
 * エラー画面へ遷移の処理.
 */
function error(message) {
  Transfer.toErrorPage({
    title: MessageManager.getMessage('TOMS.COMMON.ERROR.PAGE.TITLE'),
    message: MessageManager.getMessage('TOMS.COMMON.ERROR.MESSAGE.SYSTEM'),
    detail: [MessageManager.getMessage('TOMS.EXCHANGE.LIST.LABEL.MESSAGE.ERROR'), message],
    returnUrl: 'toms/exchange/search/input', // 戻り先 URL
    returnUrlLabel: MessageManager.getMessage('TOMS.EXCHANGE.LIST.LABEL.RETURN.LINK.NAME'),
    parameter: {
    }
  });
}

// エラーページ
function errorcsv(message) {
  Transfer.toErrorPage({
    title: MessageManager.getMessage('TOMS.COMMON.ERROR.PAGE.TITLE'),
    message: MessageManager.getMessage('TOMS.COMMON.ERROR.MESSAGE.SYSTEM'),
    detail: [MessageManager.getMessage('TOMS.EXCHANGE.LIST.LABEL.CSV.MESSAGE.ERROR'), message],
    returnUrl: 'toms/exchange/list/output', // 戻り先 URL
    returnUrlLabel: MessageManager.getMessage('TOMS.EXCHANGE.LIST.LABEL.CSV.RETURN.LINK.NAME'),
    parameter: {
    }
  });
}
