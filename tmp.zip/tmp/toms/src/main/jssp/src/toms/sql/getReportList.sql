SELECT
    *
FROM
(
    SELECT
        TRIM(MFPID1) AS MFPID1
          ,TRIM(MFUSER1) AS MFUSER1
          ,TRIM(MFEV01) AS MFEV01
          ,TRIM(MFACTNTYP) AS MFACTNTYP
          ,TRIM(MFPDES) AS MFPDES
          ,TRIM(MFSRC) AS MFSRC
          ,TRIM(MFY57CEV01) AS MFY57CEV01
          ,TRIM(MFY57CEV02) AS MFY57CEV02
          ,TRIM(MFY57CEV03) AS MFY57CEV03
          ,TO_CHAR(FC_JDI9902_TO_DATE(MFY57CDT1), 'YYYY/MM/DD') AS MFY57CDT1
          ,TO_CHAR(FC_JDI9902_TO_DATE(MFY57CDT2), 'YYYY/MM/DD') AS MFY57CDT2
          ,TO_CHAR(FC_JDI9902_TO_DATE(MFY57CDT3), 'YYYY/MM/DD') AS MFY57CDT3
          ,MFY57CURA1
          ,MFY57CURA2
          ,MFY57CURA3
          ,MFY57CAMT1
          ,MFY57CAMT2
          ,MFY57CAMT3
          ,TRIM(MFY57CDL01) AS MFY57CDL01
          ,TRIM(MFY57CDL02) AS MFY57CDL02
          ,TRIM(MFY57CDL03) AS MFY57CDL03
          ,TRIM(MFURRF) AS MFURRF
          ,TRIM(MFURCD) AS MFURCD
          ,TO_CHAR(FC_JDI9902_TO_DATE(MFURDT), 'YYYY/MM/DD') AS MFURDT
          ,MFURAT
          ,MFURAB
          ,TRIM(MFUSER) AS MFUSER
          ,TRIM(MFPID) AS MFPID
          ,TRIM(MFJOBN) AS MFJOBN
          ,TO_CHAR(FC_JDI9902_TO_DATE(MFUPMJ), 'YYYY/MM/DD') AS MFUPMJ
          ,MFUPMT
        ,ROWNUM AS RN
    FROM
    (
        SELECT
           MFPID1
            ,MFUSER1
            ,MFEV01
            ,MFACTNTYP
            ,MFPDES
            ,MFSRC
            ,MFY57CEV01
            ,MFY57CEV02
            ,MFY57CEV03
            ,MFY57CDT1
            ,MFY57CDT2
            ,MFY57CDT3
            ,MFY57CURA1
            ,MFY57CURA2
            ,MFY57CURA3
            ,MFY57CAMT1
            ,MFY57CAMT2
            ,MFY57CAMT3
            ,MFY57CDL01
            ,MFY57CDL02
            ,MFY57CDL03
            ,MFURRF
            ,MFURCD
            ,MFURAB
            ,MFURAT
            ,MFURDT
            ,MFUSER
            ,MFPID
            ,MFJOBN
            ,MFUPMJ
            ,MFUPMT
        FROM
          F57C1050
        /*BEGIN*/
        WHERE
            /*IF mfpid1 != null*/
            TRIM(MFPID1) = /*mfpid1*/'010015200102'
            /*END*/
            /*IF mfuser1 != null*/
            AND TRIM(MFUSER1) = /*mfuser1*/'31'
            /*END*/
        /*END*/
        ORDER BY
            MFPID1
            ,MFUSER1
    ) base
     /*IF end != null*/
        WHERE ROWNUM <= /*end*/'30' 
     /*END*/
)
/*IF start != null*/
WHERE RN >= /*start*/'1' 
/*END*/