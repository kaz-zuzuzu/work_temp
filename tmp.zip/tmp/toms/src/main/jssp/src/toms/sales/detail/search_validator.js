/**
 * 検索画面validation設定
 */
var init = {
  'maitm': { // 略式品目番号
    caption: 'TOMS.MASTER.MAINTENANCE.SALES.DETAIL.INPUT.MAITM', // キャプションのメッセージキーを指定する. 
    required: true, // 必須チェック
    numeric: true, // 数字チェック
    maxlength: 8
  },
  'malitm': { // 第2品目番号：品目コード
    caption: 'TOMS.MASTER.MAINTENANCE.SALES.DETAIL.INPUT.MALITM', // キャプションのメッセージキーを指定する. 
    required: true, // 必須チェック
    alphanumeric: true, // 英数字チェック
    maxlength: 25
  },
  'maan8':{ // 取引先コード
    caption:'TOMS.MASTER.MAINTENANCE.SALES.DETAIL.INPUT.MAAN8',
    numeric: true,
    maxlength:8
  },
  'macpgp':{ // ランクコード
    caption:'TOMS.MASTER.MAINTENANCE.SALES.DETAIL.INPUT.MACPGP',
    alphanumeric: true,
    maxlength:8
  },
  'mauorg': { // 数量
    caption: 'TOMS.MASTER.MAINTENANCE.SALES.DETAIL.INPUT.MAUORG', // キャプションのメッセージキーを指定する. 
    required: true, // 必須チェック
    numeric: true, // 数字チェック
    maxlength: 15
  },
  'macrcd':{ // 通貨コード
    caption:'TOMS.MASTER.MAINTENANCE.SALES.DETAIL.INPUT.MACRCD',
    alphanumeric: true,
    maxlength:3
  },
  'mauprc': { // 単価
    caption: 'TOMS.MASTER.MAINTENANCE.SALES.DETAIL.INPUT.MAUPRC', // キャプションのメッセージキーを指定する. 
    required: true, // 必須チェック
    numeric: true, // 数字チェック
    maxlength: 15
  },
  'maeftj': { // 有効開始日付
	  caption: 'TOMS.MASTER.MAINTENANCE.SALES.DETAIL.INPUT.MAEFTJ', // キャプションのメッセージキーを指定する. 
	  required: true, // 必須チェック
	  date: true, // 日付チェック
	  maxlength: 10
   }
};