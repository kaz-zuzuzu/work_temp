/**
 * 商品形態マスタメンテナンス登録・更新画面
 *
 * src /src/toms/commodity_shape/detail/input.js
 * 
 **/
var $bind ={};


function init(request){
	
	$bind.flag = "0"; //新規、更新フラグ　新規：0　更新：1　
	if(!isBlank(request.updateFlag)){
		$bind.flag = request.updateFlag;
	}
	$bind.checked =false; //削除フラグのチェックフラグ
	$bind.inputFlg = "false";
	$bind.parentFlg1=false;
	$bind.parentFlg2=false;
	$bind.oyakoFlg="0";

	var endDate=MessageManager.getMessage('TOMS.COMMON.CONSTANT.ENDDATE');

	//画面タイトル
	if($bind.flag=="1"){
		$bind.title = MessageManager.getMessage('TOMS.MASTER.MAINTENANCE.COMMODITYSHAPE.DETAIL.INPUT.UPDATE.TITLE');
		//運用開始・終了日の相関チェックメッセージ
		$bind.validateDateMsg  = MessageManager.getMessage('TOMS.COMMON.MAINTENANCE.AJAX.ERROR.ENDDATE_BETWEEN.MESSAGE');
	}else{
		$bind.title = MessageManager.getMessage('TOMS.MASTER.MAINTENANCE.COMMODITYSHAPE.DETAIL.INPUT.ENTRY.TITLE');
		//運用開始・終了日の相関チェックメッセージ
		$bind.validateDateMsg  = MessageManager.getMessage('TOMS.COMMON.MAINTENANCE.AJAX.ERROR.STARTDATE_BETWEEN.MESSAGE');
	}
	$bind.validateCodeMsg =  MessageManager.getMessage('TOMS.COMMON.MAINTENANCE.AJAX.ERROR.COMMODITY_SHAPE_CODE.SAME.MESSAGE');
	$bind.label_commodity_shape=MessageManager.getMessage('TOMS.MASTER.MAINTENANCE.COMMODITYSHAPE.LABEL.COMMODITY_SHAPE');
	$bind.label_commodity_shape_detail=MessageManager.getMessage('TOMS.MASTER.MAINTENANCE.COMMODITYSHAPE.LABEL.COMMODITY_SHAPE_DETAIL');
	$bind.mjy57adflg="";
	if($bind.flag=="1"){
    	$bind.inputFlg = "true";
    	$bind.mjy57acsc = request.mjy57acsc;
    	$bind.mjy57apcsc = request.mjy57apcsc;
    	if($bind.mjy57acsc == $bind.mjy57apcsc){
    		$bind.parentFlg1=true;
    		$bind.oyakoFlg="1";
    	}else{
    		$bind.parentFlg2=true;
    	}
	
    	$bind.mjdl01 = request.mjdl01;
    	$bind.mjsnn = request.mjsnn;
    	$bind.mjy57ajdt = request.mjy57ajdt;
    	$bind.mjy57ajdc = request.mjy57ajdc;
    	$bind.mjeftj = request.mjeftj;
//    	$bind.mjexdj = request.mjexdj;
    	$bind.mjy57adflg =isBlank(request.mjy57adflg) ? "": request.mjy57adflg ;
	}
	$bind.mjexdj = endDate;
   
    $bind.dialogMessages = ({
        entryTitle: MessageManager.getMessage('TOMS.COMMON.ENTRY'),
        entryMessage: MessageManager.getMessage('TOMS.MASTER.MAINTENANCE.COMMODITYSHAPE.DETAIL.INPUT.ENTRY.MESSAGE'),
        updateTitle: MessageManager.getMessage('TOMS.COMMON.UPDATE'),
        updateMessage: MessageManager.getMessage('TOMS.MASTER.MAINTENANCE.COMMODITYSHAPE.DETAIL.INPUT.UPDATE.MESSAGE'),
        deleteTitle: MessageManager.getMessage('TOMS.COMMON.DELETE'),
        deleteMessage: MessageManager.getMessage('TOMS.MASTER.MAINTENANCE.COMMODITYSHAPE.DETAIL.INPUT.DELETE.MESSAGE')
      }).toSource();
}