/**
 * ボディ非推奨管理マスタメンテナンス一覧
 *
 **/
// バインド変数
var $bind = {};
var $data = {};
load("toms/common/common");

/**
 * 初期表示
 * @param request リクエストパラメータ
 */
function init(request) {
    var csvObj;
    // ***** 初期表示処理 or 検索処理 *****
    //--------------------
    // 共通部品ヘッダー情報取得用のパラメータ取得
    //--------------------
    $bind.mmy57apmc = isBlank(request.mmy57apmc) ? "" : request.mmy57apmc ;//加工方法コード
    $bind.mmyeftj = isBlank(request.mmyeftj) ? "" : request.mmyeftj;//適用開始日（加工方法ヘッダ）

    if (request.csvFlag != "1") {
        $bind.dialogMessages="";
        
        $bind.beforeUrl = request.beforeUrl;
        
        $data = {
            pageNum : isBlank(request.pageNum) ? '1' : request.pageNum,
            rowNum  : isBlank(request.rowNum) ? '30' : request.rowNum,
            rowList : isBlank(request.rowList) ? '30, 50, 100' : request.rowList
        };
        
        //--------------------
        // 加工方法区分生成
        //--------------------
        var processMethodData = MessageManager.getMessage('TOMS.MASTER.MAINTENANCE.PROCESS_METHOD_DATA');
        var splitData = processMethodData.split(',');
        // 加工方法区分のチェックボックスオブジェクト格納用
        var processMethodList = [];
        // チェックされている要素の情報を配列で取得
        var arrMqy57apmt = request.getParameters("search_mqy57apmt");
        // チェックされている値を格納する配列
        var checkedList = [];
        for (var i = 0; i < splitData.length; i++) {
            var checkFlg = "false";
            var data = splitData[i].split(':');
            // プロパティから取得した加工方法区分と、チェックされているデータが一致したら「checked：true」とする
            for (var key in arrMqy57apmt) {
                var value = arrMqy57apmt[key].getValue();
                if (!isBlank(value)) {
                    if (value == data[0]) {
                        checkFlg = "true";
                        checkedList.push(value);
                    }
                }
            }
            var listObj = {
                        label : data[1],
                        value : data[0],
                        checked : checkFlg
            };
            processMethodList.push(listObj);
        }
        $bind.processMethodList = processMethodList;
        
        //--------------------
        // 加工方法明細区分生成
        //--------------------
        var processMethodDetailData = MessageManager.getMessage('TOMS.MASTER.MAINTENANCE.PROCESS_METHOD_DETAIL_DATA');
        var splitDetailData = processMethodDetailData.split(',');
        // 加工方法明細区分のチェックボックスオブジェクト格納用
        var processMethodDetailList = [];
        // チェックされている要素の情報を配列で取得
        var arrMqy57apmdt = request.getParameters("search_mqy57apmdt");
        // チェックされている値を格納する配列
        var checkedDetailList = [];
        
        for (var i = 0; i < splitDetailData.length; i++) {
            var checkFlg = "false";
            var data = splitDetailData[i].split(':');
            // プロパティから取得した加工方法区分と、チェックされているデータが一致したら「checked：true」とする
            for (var key in arrMqy57apmdt) {
                var value = arrMqy57apmdt[key].getValue();
                if (!isBlank(value)) {
                    if (value == data[0]) {
                        checkFlg = "true";
                        checkedDetailList.push(value);
                    }
                }
            }
            var listObj = {
                        label : data[1],
                        value : data[0],
                        checked : checkFlg
            }
            processMethodDetailList.push(listObj);
        }
        $bind.processMethodDetailList = processMethodDetailList;
        
        // ***** 検索条件設定（画面表示およびCSV出力用） *****
        $bind.mqy57apcsc = isBlank(request.search_mqy57apcsc) ? "" : request.search_mqy57apcsc;             // 親商品形態コード
        $bind.mqy57apcscName = isBlank(request.search_mqy57apcscName) ? "" : request.search_mqy57apcscName; // 親商品形態名称
        $bind.mqy57acsc = isBlank(request.search_mqy57acsc) ? "" : request.search_mqy57acsc;                // 商品形態コード
        $bind.mqy57acscName = isBlank(request.search_mqy57acscName) ? "" : request.search_mqy57acscName;    // 商品形態名称
        $bind.mqy57amtc = isBlank(request.search_mqy57amtc) ? "" : request.search_mqy57amtc;                // 素材コード
        $bind.mldl01 = isBlank(request.search_mldl01) ? "" : request.search_mldl01;                         // 原材料名称
        $bind.mqy57appc1 = isBlank(request.search_mqy57appc1) ? "" : request.search_mqy57appc1;             // 加工部位コード
        $bind.mkdl01 = isBlank(request.search_mkdl01) ? "" : request.search_mkdl01;                         // 加工部位名称
        $bind.mqy57appc2 = isBlank(request.search_mqy57appc2) ? "" : request.search_mqy57appc2;             // 加工位置コード
        $bind.mkdl02 = isBlank(request.search_mkdl02) ? "" : request.search_mkdl02;                         // 加工位置名称
        $bind.mqy57apmt = isBlank(request.search_mqy57apmt) ? "" : checkedList.join(",");                   // 加工方法区分
        $bind.mqy57apmdt = isBlank(request.search_mqy57apmdt) ? "" : checkedDetailList.join(",");           // 加工方法明細区分
        $bind.mqy57apmd1 = isBlank(request.search_mqy57apmd1) ? "" : request.search_mqy57apmd1;             // 加工方法明細第1階層コード
        $bind.mny57apmn1 = isBlank(request.search_mny57apmn1) ? "" : request.search_mny57apmn1;             // 加工方法明細第1階層名称
        $bind.mqy57apmd2 = isBlank(request.search_mqy57apmd2) ? "" : request.search_mqy57apmd2;             // 加工方法明細第2階層コード
        $bind.mny57apmn2 = isBlank(request.search_mny57apmn2) ? "" : request.search_mny57apmn2;             // 加工方法明細第2階層名称
        $bind.mqy57apmd3 = isBlank(request.search_mqy57apmd3) ? "" : request.search_mqy57apmd3;             // 加工方法明細第3階層コード
        $bind.mny57apmn3 = isBlank(request.search_mny57apmn3) ? "" : request.search_mny57apmn3;             // 加工方法明細第3階層名称
        $bind.mqy57aitcd = isBlank(request.search_mqy57aitcd) ? "" : request.search_mqy57aitcd;             // 商品コード
        $bind.mqy57aitcdName = isBlank(request.search_mqy57aitcdName) ? "" : request.search_mqy57aitcdName; // 商品名称
        $bind.mqy57asc = isBlank(request.search_mqy57asc) ? "" : request.search_mqy57asc;                   // サイズコード
        $bind.mqy57ascName = isBlank(request.search_mqy57ascName) ? "" : request.search_mqy57ascName;       // サイズ名称
        // 非推奨区分（初期表示時は「01：警告」とする）
        if (((!request.search_mqy57anrt) && (request.search_mqy57anrt != "")) ||
            (request.search_mqy57anrt == "01")) {
            $bind.mqy57anrt = "01";
            $bind.checked_warning = true;
        } else if (request.search_mqy57anrt == "02") {
            $bind.mqy57anrt = "02";
            $bind.checked_error = true;
        } else if (request.search_mqy57anrt == "") {
            $bind.mqy57anrt = "";
            $bind.checked_all = true;
        }
        // 削除フラグ（初期表示時は「0：未削除」とする）
        if (((!request.search_mqy57adflg) && (request.search_mqy57adflg != "")) ||
            (request.search_mqy57adflg == "0")) {
            $bind.mqy57adflg = "0";
            $bind.checked_notdelete = true;
        } else if (request.search_mqy57adflg == "1") {
            $bind.mqy57adflg = "1";
            $bind.checked_delete = true;
        } else if (request.search_mqy57adflg == "") {
            $bind.mqy57adflg = "";
            $bind.checked_both = true;
        }
        $bind.mqeftj_from = isBlank(request.search_mqeftj_from) ? "" : request.search_mqeftj_from;          // 適用開始日From
        $bind.mqeftj_to = isBlank(request.search_mqeftj_to) ? "" : request.search_mqeftj_to;                // 適用開始日To
        
        // 非推奨区分用ラジオボタンのラベル設定
        $bind.select_warning = MessageManager.getMessage('TOMS.MASTER.MAINTENANCE.BODY_NOT_RECOMMENDED.NOT_RECOMMENDED_DIVIDE.WARNING');
        $bind.select_error = MessageManager.getMessage('TOMS.MASTER.MAINTENANCE.BODY_NOT_RECOMMENDED.NOT_RECOMMENDED_DIVIDE.ERROR');
        $bind.select_all = MessageManager.getMessage('TOMS.COMMON.DELETE.SELECT.ALL');
        
        // 削除フラグ用ラジオボタンのラベル設定
        $bind.select_notdelete = MessageManager.getMessage('TOMS.COMMON.DELETE.SELECT.NOTDELETE');
        $bind.select_delete = MessageManager.getMessage('TOMS.COMMON.DELETE.SELECT.DELETE');
        $bind.select_both = MessageManager.getMessage('TOMS.COMMON.DELETE.SELECT.ALL');
        
        // 「ファイル出力」ボタン押下時の確認ダイアログのメッセージを初期化.
        // JavaScriptで利用するためオブジェクトの内容をそのまま渡します.
        $bind.dialogMessages = ({
            addConfirmTitle: MessageManager.getMessage('TOMS.COMMON.DIALOG.CONFIRM.TITLE'),
            addConfirmMessage: MessageManager.getMessage('TOMS.COMMON.DIALOG.CONFIRM.MESSAGE')
        }).toSource();
    }
    // ***** ファイル出力 *****
    else if (request.csvFlag == "1") {
        // ファイル出力用検索条件取得
        csvObj = {
            mqy57apcsc : isBlank(request.csv_mqy57apcsc) ? "" : request.csv_mqy57apcsc,             // 親商品形態コード
            mqy57apcscName : isBlank(request.csv_mqy57apcscName) ? "" : request.csv_mqy57apcscName, // 親商品形態名称
            mqy57acsc : isBlank(request.csv_mqy57acsc) ? "" : request.csv_mqy57acsc,                // 商品形態コード
            mqy57acscName : isBlank(request.csv_mqy57acscName) ? "" : request.csv_mqy57acscName,    // 商品形態名称
            mqy57amtc : isBlank(request.csv_mqy57amtc) ? "" : request.csv_mqy57amtc,                // 素材コード
            mldl01 : isBlank(request.csv_mldl01) ? "" : request.csv_mldl01,                         // 原材料名称
            mqy57appc1 : isBlank(request.csv_mqy57appc1) ? "" : request.csv_mqy57appc1,             // 加工部位コード
            mkdl01 : isBlank(request.csv_mkdl01) ? "" : request.csv_mkdl01,                         // 加工部位名称
            mqy57appc2 : isBlank(request.csv_mqy57appc2) ? "" : request.csv_mqy57appc2,             // 加工位置コード
            mkdl02 : isBlank(request.csv_mkdl02) ? "" : request.csv_mkdl02,                         // 加工位置名称
            mqy57apmt : isBlank(request.csv_mqy57apmt) ? "" : request.csv_mqy57apmt,                // 加工方法区分
            mqy57apmdt : isBlank(request.csv_mqy57apmdt) ? "" : request.csv_mqy57apmdt,             // 加工方法明細区分
            mqy57apmd1 : isBlank(request.csv_mqy57apmd1) ? "" : request.csv_mqy57apmd1,             // 加工方法明細第1階層コード
            mny57apmn1 : isBlank(request.csv_mny57apmn1) ? "" : request.csv_mny57apmn1,             // 加工方法明細第1階層名称
            mqy57apmd2 : isBlank(request.csv_mqy57apmd2) ? "" : request.csv_mqy57apmd2,             // 加工方法明細第2階層コード
            mny57apmn2 : isBlank(request.csv_mny57apmn2) ? "" : request.csv_mny57apmn2,             // 加工方法明細第2階層名称
            mqy57apmd3 : isBlank(request.csv_mqy57apmd3) ? "" : request.csv_mqy57apmd3,             // 加工方法明細第3階層コード
            mny57apmn3 : isBlank(request.csv_mny57apmn3) ? "" : request.csv_mny57apmn3,             // 加工方法明細第3階層名称
            mqy57aitcd : isBlank(request.csv_mqy57aitcd) ? "" : request.csv_mqy57aitcd,             // 商品コード
            mqy57aitcdName : isBlank(request.csv_mqy57aitcdName) ? "" : request.csv_mqy57aitcdName, // 商品名称
            mqy57asc : isBlank(request.csv_mqy57asc) ? "" : request.csv_mqy57asc,                   // サイズコード
            mqy57ascName : isBlank(request.csv_mqy57ascName) ? "" : request.csv_mqy57ascName,       // サイズ名称
            mqy57anrt : isBlank(request.csv_mqy57anrt) ? "" : request.csv_mqy57anrt,                // 非推奨区分
            mqy57adflg : isBlank(request.csv_mqy57adflg) ? "" : request.csv_mqy57adflg,             // 削除フラグ
            mqeftj_from : isBlank(request.csv_mqeftj_from) ? "" : request.csv_mqeftj_from,          // 適用開始日From
            mqeftj_to : isBlank(request.csv_mqeftj_to) ? "" : request.csv_mqeftj_to                 // 適用開始日To
        };
        outputCSV(csvObj);
    }
}

/**
 * ボディ非推奨管理マスタメンテナンスのCSV出力処理
 * 
 * @param リクエストパラメータ
 * 
 */
function outputCSV(param){
    load("toms/common/bodyNotRecommended");
    var result = BodyNotRecommended.getBodyNotRecommendedList(param, false, null, null);
    
    var outputContent = "";
    if (!result.error) {
        outputContent = outputCSVHeader();
        for(var i = 0; i < result.countRow; i++) {
            outputContent += outputCSVRow(result.data[i]);
        }
        var strDate = DateTimeFormatter.format("yyyyMMdd_HHmmss", new Date());
        var strUserName = Contexts.getUserContext().userProfile.userName;
        var fileName = MessageManager.getMessage('TOMS.MASTER.MAINTENANCE.BODY_NOT_RECOMMENDED.CSV.FILE.NAME') + '_' + strDate + '_' + strUserName + '.csv';
        Module.download.send(Unicode.to(outputContent, 'MS932'), fileName, MessageManager.getMessage('TOMS.COMMON.MIME.CSV'));
    } else {
        error(result.errorMessage);
    }
}

/**
 * ボディ非推奨管理マスタメンテナンスのCSVヘッダ部分出力処理。
 */
function outputCSVHeader() {
    var outputHeader = common.convert(MessageManager.getMessage('TOMS.COMMON.CSV.UPDATE.DIVIDE'), true)                                                // 更新区分
                + common.convert(MessageManager.getMessage("TOMS.MASTER.MAINTENANCE.COMMODITYSHAPE.LABEL.PARENT_COMMODITY_SHAPE_CODE"), true)          // 親商品形態コード
                + common.convert(MessageManager.getMessage("TOMS.MASTER.MAINTENANCE.COMMODITYSHAPE.LABEL.COMMODITY_SHAPE_CODE"), true)                 // 商品形態コード
                + common.convert(MessageManager.getMessage("TOMS.MASTER.MAINTENANCE.MATERIAL.LABEL.MATERIAL_CODE"), true)                              // 素材コード
                + common.convert(MessageManager.getMessage("TOMS.MASTER.MAINTENANCE.PROCESSPART.LABEL.PROCESSPART_CODE"), true)                        // 加工部位コード
                + common.convert(MessageManager.getMessage("TOMS.MASTER.MAINTENANCE.PROCESSPART.LABEL.PROCESSPART_POSITION_CODE"), true)               // 加工位置コード
                + common.convert(MessageManager.getMessage("TOMS.MASTER.MAINTENANCE.PROCESSMETHOD_HEADER.LABEL.PROCESS_METHOD_TPYE"), true)            // 加工方法区分
                + common.convert(MessageManager.getMessage("TOMS.MASTER.MAINTENANCE.PROCESSMETHOD_HEADER.LABEL.PROCESS_METHOD_DETAIL_TPYE"), true)     // 加工方法明細区分
                + common.convert(MessageManager.getMessage("TOMS.MASTER.MAINTENANCE.BODY_NOT_RECOMMENDED.PROCESS_DETAIL_FIRST_HIERARCHY_CODE"), true)  // 加工方法明細第1階層コード
                + common.convert(MessageManager.getMessage("TOMS.MASTER.MAINTENANCE.BODY_NOT_RECOMMENDED.PROCESS_DETAIL_SECOND_HIERARCHY_CODE"), true) // 加工方法明細第2階層コード
                + common.convert(MessageManager.getMessage("TOMS.MASTER.MAINTENANCE.BODY_NOT_RECOMMENDED.PROCESS_DETAIL_THIRD_HIERARCHY_CODE"), true)  // 加工方法明細第3階層コード
                + common.convert(MessageManager.getMessage("TOMS.MASTER.MAINTENANCE.PROCESSMETHOD_COMMODITY.LABEL.COMMODITY_CODE"), true)              // 商品コード
                + common.convert(MessageManager.getMessage("TOMS.MASTER.MAINTENANCE.BODY_NOT_RECOMMENDED.SIZE_CODE"), true)                            // サイズコード
                + common.convert(MessageManager.getMessage("TOMS.MASTER.MAINTENANCE.BODY_NOT_RECOMMENDED.NOT_RECOMMENDED_DIVIDE"), true)               // 非推奨区分
                + common.convert(MessageManager.getMessage("TOMS.MASTER.MAINTENANCE.COMMODITYSHAPE.LABEL.APPLIED_START_DATE"), true)                   // 適用開始日
                + common.convert(MessageManager.getMessage("TOMS.MASTER.MAINTENANCE.COMMODITYSHAPE.LABEL.DELETE_FLG"), false);                         // 削除フラグ
    
    return outputHeader;
}

/**
 * ボディ非推奨管理マスタメンテナンスのCSVファイルの行を出力する処理
 * 
 * @param record DBから検索した行のデータ
 */
function outputCSVRow(record) {
    var result =  MessageManager.getMessage('TOMS.COMMON.CSV.SPLIT')
                + common.convert(record["mqy57apcsc"], true)   // 親商品形態コード
                + common.convert(record["mqy57acsc"], true)    // 商品形態コード
                + common.convert(record["mqy57amtc"], true)    // 素材コード
                + common.convert(record["mqy57appc1"], true)   // 加工部位コード
                + common.convert(record["mqy57appc2"], true)   // 加工位置コード
                + common.convert(record["mqy57apmt"], true)    // 加工方法区分
                + common.convert(record["mqy57apmdt"], true)   // 加工方法明細区分
                + common.convert(record["mqy57apmd1"], true)   // 加工方法明細第1階層コード
                + common.convert(record["mqy57apmd2"], true)   // 加工方法明細第2階層コード
                + common.convert(record["mqy57apmd3"], true)   // 加工方法明細第3階層コード
                + common.convert(record["mqy57aitcd"], true)   // 商品コード
                + common.convert(record["mqy57asc"], true)     // サイズコード
                + common.convert(record["mqy57anrt"], true)    // 非推奨区分
                + common.convert(record["mqeftj"], true)       // 適用開始日
                + common.convert(record["mqy57adflg"] + "", false); // 削除フラグ
    
    return result;
}

function error(message) {
    Transfer.toErrorPage({
        title: MessageManager.getMessage('TOMS.COMMON.ERROR.PAGE.TITLE'),
        message: MessageManager.getMessage('TOMS.COMMON.ERROR.MESSAGE.SYSTEM'),
        detail: [MessageManager.getMessage('TOMS.MASTER.MAINTENANCE.BODY_NOT_RECOMMENDED.LIST.LABEL.MESSAGE.ERROR'), message],
        returnUrl: 'toms/body_not_recommended/list/input', // 戻り先 URL
        returnUrlLabel: MessageManager.getMessage('TOMS.MASTER.MAINTENANCE.BODY_NOT_RECOMMENDED.LIST.LABEL.RETURN.LINK.NAME'),
        parameter: {
        }
    });
}
