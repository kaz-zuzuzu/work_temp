var $data;

/**
 * 加工明細コード管理初期表示
 * @param request リクエストパラメータ
 */
    
function init(request) {
    $data = ImJson.toJSONString(getList(request)); 
}

function getList(request) {
    // 表示条件を設定（表示ページ、件数など）
    let page = request.page == undefined ? 1 : request.page;
    let rows = request.rowNum == undefined ? 30 : Module.number.toInt(request.rowNum);
    
    // 検索条件の状況に応じて条件を設定する
    var param = request.extension;
    if (!param || !param.searchCondition) {
        return  {
                        page  : page,
                        total : rows,
                        data  : []
                    };
    }
    
    // 検索条件の設定
    var mry57apcsc = isBlank(param.searchCondition.mry57apcsc) ? null : param.searchCondition.mry57apcsc;             // 親商品形態コード
    var mry57apcscName = isBlank(param.searchCondition.mry57apcscName) ? null : param.searchCondition.mry57apcscName; // 親商品形態名称
    var mry57acsc = isBlank(param.searchCondition.mry57acsc) ? null : param.searchCondition.mry57acsc;                // 商品形態コード
    var mry57acscName = isBlank(param.searchCondition.mry57acscName) ? null : param.searchCondition.mry57acscName;    // 商品形態名称
    var mry57amtc = isBlank(param.searchCondition.mry57amtc) ? null : param.searchCondition.mry57amtc;                // 素材コード
    var mldl01 = isBlank(param.searchCondition.mldl01) ? null : param.searchCondition.mldl01;                         // 原材料名称
    var mry57appc1 = isBlank(param.searchCondition.mry57appc1) ? null : param.searchCondition.mry57appc1;             // 加工部位コード
    var mkdl01 = isBlank(param.searchCondition.mkdl01) ? null : param.searchCondition.mkdl01;                         // 加工部位名称
    var mry57appc2 = isBlank(param.searchCondition.mry57appc2) ? null : param.searchCondition.mry57appc2;             // 加工位置コード
    var mkdl02 = isBlank(param.searchCondition.mkdl02) ? null : param.searchCondition.mkdl02;                         // 加工位置名称
    var mry57apmt = isBlank(param.searchCondition.mry57apmt) ? null : param.searchCondition.mry57apmt;                // 加工方法区分
    var mry57apmdt = isBlank(param.searchCondition.mry57apmdt) ? null : param.searchCondition.mry57apmdt;             // 加工方法明細区分
    var mry57apmd1 = isBlank(param.searchCondition.mry57apmd1) ? null : param.searchCondition.mry57apmd1;             // 加工方法明細第1階層コード
    var mny57apmn1 = isBlank(param.searchCondition.mny57apmn1) ? null : param.searchCondition.mny57apmn1;             // 加工方法明細第1階層名称
    var mry57apmd2 = isBlank(param.searchCondition.mry57apmd2) ? null : param.searchCondition.mry57apmd2;             // 加工方法明細第2階層コード
    var mny57apmn2 = isBlank(param.searchCondition.mny57apmn2) ? null : param.searchCondition.mny57apmn2;             // 加工方法明細第2階層名称
    var mry57apmd3 = isBlank(param.searchCondition.mry57apmd3) ? null : param.searchCondition.mry57apmd3;             // 加工方法明細第3階層コード
    var mny57apmn3 = isBlank(param.searchCondition.mny57apmn3) ? null : param.searchCondition.mny57apmn3;             // 加工方法明細第3階層名称
    var mry57apdjt = isBlank(param.searchCondition.mry57apdjt) ? null : param.searchCondition.mry57apdjt;             // 加工明細判定区分
    var mruorg = isBlank(param.searchCondition.mruorg) ? null : param.searchCondition.mruorg;                         // 数量
    var mry57alsku = isBlank(param.searchCondition.mry57alsku) ? null : param.searchCondition.mry57alsku;             // 紐づけSKUコード
    var mry57alskuName = isBlank(param.searchCondition.mry57alskuName) ? null : param.searchCondition.mry57alskuName; // 紐づけSKU名称
    var mry57aoa = isBlank(param.searchCondition.mry57aoa) ? null : param.searchCondition.mry57aoa;                   // 注文枚数
    var mry57adflg = isBlank(param.searchCondition.mry57adflg) ? null : param.searchCondition.mry57adflg;             // 削除フラグ
    var mreftj_from = isBlank(param.searchCondition.mreftj_from) ? null : param.searchCondition.mreftj_from;          // 適用開始日From
    var mreftj_to = isBlank(param.searchCondition.mreftj_to) ? null : param.searchCondition.mreftj_to;                // 適用開始日To
    
    var objParams = {
        mry57apcsc : mry57apcsc,
        mry57apcscName : mry57apcscName,
        mry57acsc : mry57acsc,
        mry57acscName : mry57acscName,
        mry57amtc : mry57amtc,
        mldl01 : mldl01,
        mry57appc1 : mry57appc1,
        mkdl01 : mkdl01,
        mry57appc2 : mry57appc2,
        mkdl02 : mkdl02,
        mry57apmt : mry57apmt,
        mry57apmdt : mry57apmdt,
        mry57apmd1 : mry57apmd1,
        mny57apmn1 : mny57apmn1,
        mry57apmd2 : mry57apmd2,
        mny57apmn2 : mny57apmn2,
        mry57apmd3 : mry57apmd3,
        mny57apmn3 : mny57apmn3,
        mry57apdjt : mry57apdjt,
        mruorg : mruorg,
        mry57alsku : mry57alsku,
        mry57alskuName : mry57alskuName,
        mry57aoa : mry57aoa,
        mry57adflg : mry57adflg,
        mreftj_from : mreftj_from,
        mreftj_to : mreftj_to
    }
    // 加工明細コード管理マスタの件数取得
    var resultCount = getProcessDetailCodeListCount(objParams);

    // 全体の件数を設定（件数の母数）
    var listCount = 0;
    if (!resultCount.error) {
        listCount = resultCount.data[0]['rowcount'];
    } else {
        Debug.write(resultCount.errorMessage);
    }
    
    // ページ番号設定:リクエストパラメータのページ番号、最大ページ番号のうち小さい方の番号を設定
    page = Math.min(page, Math.ceil(listCount / rows)); 
    
    // 指定範囲の会社情報を取得
    var start = rows * (page - 1) + 1;
    var end = start + rows - 1;
    
    // 加工明細コード管理の一覧取得
    var result = getProcessDetailCodeList(objParams, start, end);
    var resultData = [];
    if (!result.error) {
        resultData = result.data;
    } else {
        Debug.write(result.errorMessage);
    }
    
    var json = {
        page  : page,
        total : listCount,
        data  : resultData
    };
    
    return json;
}

/**
 * 加工明細コード管理一覧件数取得
 */    
function getProcessDetailCodeListCount(objParams){
    load("toms/common/processDetailCode");
    var result = ProcessDetailCode.getList(objParams, true, null, null);
    
    return result;
}

/**
 * 加工明細コード管理一覧データ取得
 */
function getProcessDetailCodeList(objParams, start , end){
    load("toms/common/processDetailCode");
    var result = ProcessDetailCode.getList(objParams, false, start, end);
    return result;
}

/**
 * 検索結果一覧のページオブジェクト生成
 */
function createResult(page, total, data) {
    return {
        page : page == null ? 1 : page,
        total : total == null ? 0 : total,
        data : data == null ? [] : data
    };
}

/**
 * エラーオブジェクト生成
 */
function createErrorResult(message, details){
    return {
        error : true,
        errorMessage : message,
        detailMessages : details
    }
}
