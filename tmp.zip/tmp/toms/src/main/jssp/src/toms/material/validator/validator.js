/**
 * 素材マスタメンテナンスvalidation設定
 */

 var init={
	//素材コード
 	'mly57amtc':{
	caption:'TOMS.MASTER.MAINTENANCE.MATERIAL.LABEL.MATERIAL_CODE',
	required: true, //必須チェック
	alphanumeric: true,
    maxlength: 16
	},
	//商品形態コード
	 'mly57acsc':{
 	caption:'TOMS.MASTER.MAINTENANCE.COMMODITYSHAPE.LABEL.COMMODITY_SHAPE_CODE',
    required: true, // 必須チェック
	alphanumeric: true,
    maxlength: 16
 	},
	//親商品形態コード
 	'mly57apcsc':{
 	caption:'TOMS.MASTER.MAINTENANCE.COMMODITYSHAPE.LABEL.PARENT_COMMODITY_SHAPE_CODE',
    required: true, // 必須チェック
	alphanumeric: true,
    maxlength: 16
 	},
	//原材料名
 	 'mldl01':{//
 	caption:'TOMS.MASTER.MAINTENANCE.MATERIAL.LABEL.MATERIAL_NAME',
    required: true, // 必須チェック
    maxlength: 30
 	},
	//パーセント
 	'mlpct1':{
 	caption:'TOMS.MASTER.MAINTENANCE.MATERIAL.LABEL.PARCENT',
    numeric: true, // 数字チェック
    maxlength: 3
 	},
	//表示順
 	'mlsnn':{
 	caption:'TOMS.MASTER.MAINTENANCE.COMMODITYSHAPE.LABEL.DISPLAY_ORDER',
    numeric: true, // 数字チェック
    maxlength: 8
 	},
//	//JDEコード
// 	'mly57ajdc':{
// 	caption:'TOMS.MASTER.MAINTENANCE.COMMODITYSHAPE.LABEL.JDE_CODE',
//    required: true, // 必須チェック
//	alphanumeric: true,
//    maxlength: 8
// 	},
	//たたみ袋制御フラグ
 	'mly57amflg':{
 	caption:'TOMS.MASTER.MAINTENANCE.MATERIAL.LABEL.MAT_CONTROL_FLG',
    required: true // 必須チェック
 	}, 	
	//たたみ袋SKUコード
 	'mly57absc':{
 	caption:'TOMS.MASTER.MAINTENANCE.MATERIAL.LABEL.BAG_SKU_CODE',
 	required: true, //必須チェック
	alphanumeric: true,
    maxlength: 24
 	},	
 	//適用開始日
 	'mleftj':{
 	caption:'TOMS.MASTER.MAINTENANCE.COMMODITYSHAPE.LABEL.APPLIED_START_DATE',
    required: true, // 必須チェック
	date: true,
    maxlength: 10
 	}
 	}