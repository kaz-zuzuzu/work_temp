/**
 * 加工方法商品関連付けマスタメンテナンスvalidation設定
 */

 var init={
		//商品コード
	 	'mpy57acc':{
		caption:'TOMS.MASTER.MAINTENANCE.PROCESSMETHOD_COMMODITY.LABEL.COMMODITY_CODE',
		required: true, //必須チェック
		alphanumeric: true,
		maxlength: 5
		},
	 	//適用開始日
	 	'mpeftj':{
	 	caption:'TOMS.MASTER.MAINTENANCE.COMMODITYSHAPE.LABEL.APPLIED_START_DATE',
	    required: true, // 必須チェック
		date: true,
	    maxlength: 10
	 	}
}
 