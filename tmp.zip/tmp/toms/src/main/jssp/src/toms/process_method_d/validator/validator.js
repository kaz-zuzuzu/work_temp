/**
 * 加工方法明細マスタメンテナンスvalidation設定
 */

 var init={
		//第1階層名称
	 	'mny57apmn1':{
		caption:'TOMS.MASTER.MAINTENANCE.PROCESSMETHOD_DETAIL.LABEL.PROCESS_METHOD_NAME1',
		required: true, //必須チェック
	    maxlength: 30
		},
		//第1階層表示順
	 	'mny57ado1':{
	 	caption:'TOMS.MASTER.MAINTENANCE.PROCESSMETHOD_DETAIL.LABEL.DISPLAY_ORDER1',
		numeric: true,
	    maxlength: 8
	 	},
		//第1階層JDEコード
	 	'mny57ajc1':{
	 	caption:'TOMS.MASTER.MAINTENANCE.PROCESSMETHOD_DETAIL.LABEL.JDE_CODE1',
	    required: true, // 必須チェック
		alphanumeric: true,
	    maxlength: 8
	 	},
	 	//第1階層グループ名称
		 'mny57agn1':{
	 	caption:'TOMS.MASTER.MAINTENANCE.PROCESSMETHOD_DETAIL.LABEL.GROUP_NAME1',
	    maxlength: 20
	 	},
		//第2階層名称
	 	'mny57apmn2':{
		caption:'TOMS.MASTER.MAINTENANCE.PROCESSMETHOD_DETAIL.LABEL.PROCESS_METHOD_NAME2',
		required: true, //必須チェック
	    maxlength: 30
		},
		//第2階層表示順
	 	'mny57ado2':{
	 	caption:'TOMS.MASTER.MAINTENANCE.PROCESSMETHOD_DETAIL.LABEL.DISPLAY_ORDER2',
		numeric: true,
	    maxlength: 8
	 	},
		//第2階層JDEコード
	 	'mny57ajc2':{
	 	caption:'TOMS.MASTER.MAINTENANCE.PROCESSMETHOD_DETAIL.LABEL.JDE_CODE2',
	    required: true, // 必須チェック
		alphanumeric: true,
	    maxlength: 8
	 	},
	 	//第2階層グループ名称
		 'mny57agn2':{
	 	caption:'TOMS.MASTER.MAINTENANCE.PROCESSMETHOD_DETAIL.LABEL.GROUP_NAME2',
	    maxlength: 20
	 	},
		//第3階層名称
	 	'mny57apmn3':{
		caption:'TOMS.MASTER.MAINTENANCE.PROCESSMETHOD_DETAIL.LABEL.PROCESS_METHOD_NAME3',
		required: true, //必須チェック
	    maxlength: 30
		},
		//第3階層表示順
	 	'mny57ado3':{
	 	caption:'TOMS.MASTER.MAINTENANCE.PROCESSMETHOD_DETAIL.LABEL.DISPLAY_ORDER3',
		numeric: true,
	    maxlength: 8
	 	},
		//第3階層JDEコード
	 	'mny57ajc3':{
	 	caption:'TOMS.MASTER.MAINTENANCE.PROCESSMETHOD_DETAIL.LABEL.JDE_CODE3',
	    required: true, // 必須チェック
		alphanumeric: true,
	    maxlength: 8
	 	},
	 	//第3階層グループ名称
		 'mny57agn3':{
	 	caption:'TOMS.MASTER.MAINTENANCE.PROCESSMETHOD_DETAIL.LABEL.GROUP_NAME3',
	    maxlength: 20
	 	},

	 	//柄サイズ　縦
	 	'mny57apsh':{
		caption:'TOMS.MASTER.MAINTENANCE.PROCESSMETHOD_DETAIL.LABEL.PATTERN_SIZE_HEIGHT',
		numeric: true,
	    maxlength: 8
		},
	 	//柄サイズ　横
		 'mny57apsw':{
	 	caption:'TOMS.MASTER.MAINTENANCE.PROCESSMETHOD_DETAIL.LABEL.PATTERN_SIZE_WIDTH',
		numeric: true,
	    maxlength: 8
	 	},
	 	//適用開始日
	 	'mneftj':{
	 	caption:'TOMS.MASTER.MAINTENANCE.COMMODITYSHAPE.LABEL.APPLIED_START_DATE',
	    required: true, // 必須チェック
		date: true,
	    maxlength: 10
	 	}
}
 