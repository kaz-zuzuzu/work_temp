var $data;

/**
 * 初期表示
 * @param request リクエストパラメータ
 */
	
function init(request) {
	$data = ImJson.toJSONString(getList(request)); 
}

function getList(request) {

	// 表示条件を設定（表示ページ、件数など）
	let page = request.page == undefined ? 1 : request.page;
	let rows = request.rowNum == undefined ? 30 : Module.number.toInt(request.rowNum);
	
	// 検索条件の状況に応じて条件を設定する
	var param = request.extension;
	if (!param || !param.searchCondition) {
    	return  {
                		page  : page,
                		total : rows,
                		data  : []
    				};
	}
	
	//検索条件の設定
	var mly57amtc = isBlank(param.searchCondition.mly57amtc) ? null : param.searchCondition.mly57amtc;//素材コード
	var mldl01 = isBlank(param.searchCondition.mldl01) ? null : param.searchCondition.mldl01;//原材料名
	var mly57acsc = isBlank(param.searchCondition.mly57acsc) ? null : param.searchCondition.mly57acsc;//商品形態コード
	var mly57apcsc = isBlank(param.searchCondition.mly57apcsc) ? null : param.searchCondition.mly57apcsc ;//親商品形態コード
	var mlpct1 = isBlank(param.searchCondition.mlpct1) ? null : param.searchCondition.mlpct1;//パーセント
	var mly57ajdc = isBlank(param.searchCondition.mly57ajdc) ? null : param.searchCondition.mly57ajdc;//JDEコード
	var mly57adflg = isBlank(param.searchCondition.mly57adflg) ? null : param.searchCondition.mly57adflg;//削除フラグ
	var mly57amflg = isBlank(param.searchCondition.mly57amflg) ? null : param.searchCondition.mly57amflg;//たたみ袋制御フラグ
	var mly57absc = isBlank(param.searchCondition.mly57absc) ? null : param.searchCondition.mly57absc ;//たたみ袋SKUコード
	var mleftj = isBlank(param.searchCondition.mleftj) ? null :param.searchCondition.mleftj ;//提供開始日
	var mleftj2 = isBlank(param.searchCondition.mleftj2) ? null : param.searchCondition.mleftj2;//適用終了日
//	var mlexdj = isBlank(param.searchCondition.mlexdj) ? null : param.searchCondition.mlexdj;//適用終了日

	var objParams = {
		mly57amtc : mly57amtc,
    	mldl01 : mldl01,
    	mly57acsc : mly57acsc,
    	mly57apcsc : mly57apcsc,
    	mlpct1 : mlpct1,
    	mly57ajdc : mly57ajdc,
    	mly57adflg : mly57adflg,
    	mly57amflg : mly57amflg,
    	mly57absc : mly57absc,
    	mleftj : mleftj,
    	mleftj2 : mleftj2
	}
	//素材マスタの件数取得
	var resultCount = getMaterialListCount(objParams);
	// 全体の件数を設定（件数の母数）
	var listCount = 0;
	if (!resultCount.error) {
		listCount = resultCount.data[0]['rowcount'];
	} else {
		Debug.write(resultCount.errorMessage);
	}
	
	// ページ番号設定:リクエストパラメータのページ番号、最大ページ番号のうち小さい方の番号を設定
	page = Math.min(page, Math.ceil(listCount / rows)); 
	
	// 指定範囲の会社情報を取得
	var start = rows * (page - 1) + 1;
	var end = start + rows - 1;

	//素材マスタの一覧取得
	var result = getMaterialList(objParams, start, end);
	var resultData =[];
	if(!result.error){
		resultData = result.data;
	}else{
		Debug.write(result.errorMessage);
	}

	var json = {
		page  : page,
		total : listCount,
		data  : resultData
	};
	return json;
	}

/**
 * 素材一覧件数取得
 */	
function getMaterialListCount(objParams){
    load("toms/common/Material");
    var result = Material.getMaterialList(objParams, true,"","");
    return result;
}

/**
 * 素材一覧データ取得
 */
function getMaterialList(objParams, start , end){
    load("toms/common/Material");
    var result = Material.getMaterialList(objParams, false,start,end);
    return result;
	
}

function createResult(page, total, data){
	return {
		page : page == null ? 1 : page,
		total : total == null ? 0 : total,
		data : data == null ? [] : data
	};
}


/**
 * エラーオブジェクト生成
 */
function createErrorResult(message, details){
	return {
		error : true,
		errorMessage : message,
		detailMessages : details

	}
}
