/**
 * 加工方法ヘッダマスタメンテナンスvalidation設定
 */

 var init={
		//加工方法名称
	 	'mmdl01':{
		caption:'TOMS.MASTER.MAINTENANCE.PROCESSMETHOD_HEADER.LABEL.PROCESS_METHOD_NAME',
		required: true, //必須チェック
	    maxlength: 30
		},
		//親商品形態コード
	 	'mmy57apcsc':{
	 	caption:'TOMS.MASTER.MAINTENANCE.COMMODITYSHAPE.LABEL.PARENT_COMMODITY_SHAPE_CODE',
	    required: true, // 必須チェック
		alphanumeric: true,
	    maxlength: 16
	 	},
	 	//商品形態コード
		 'mmy57acsc':{
	 	caption:'TOMS.MASTER.MAINTENANCE.COMMODITYSHAPE.LABEL.COMMODITY_SHAPE_CODE',
	    required: true, // 必須チェック
		alphanumeric: true,
	    maxlength: 16
	 	},
	 	//素材コード
	 	'mmy57amtc':{
		caption:'TOMS.MASTER.MAINTENANCE.MATERIAL.LABEL.MATERIAL_CODE',
		required: true, //必須チェック
		alphanumeric: true,
	    maxlength: 16
		},
	 	//加工方法部位コード
		 'mmy57appc1':{
	 	caption:'TOMS.MASTER.MAINTENANCE.PROCESSPART.LABEL.PROCESSPART_CODE',
	    required: true, // 必須チェック
		alphanumeric: true,
	    maxlength: 16
	 	},
	 	//加工方法位置コード
	 	'mmy57appc2':{
		caption:'TOMS.MASTER.MAINTENANCE.PROCESSPART.LABEL.PROCESSPART_POSITION_CODE',
		required: true, //必須チェック
		alphanumeric: true,
	    maxlength: 16
		},
	 	//階層数
	 	'mmy57ada':{
		caption:'TOMS.MASTER.MAINTENANCE.PROCESSMETHOD_HEADER.LABEL.DEPTH_AMOUNT',
		required: true, //必須チェック
		numeric: true,
	    maxlength: 2
		},
		//加工方法区分
	 	'mmy57apmt':{
	 	caption:'TOMS.MASTER.MAINTENANCE.PROCESSMETHOD_HEADER.LABEL.PROCESS_METHOD_TPYE',
	    required: true // 必須チェック
	 	}, 	
	 	//適用開始日
	 	'mmeftj':{
	 	caption:'TOMS.MASTER.MAINTENANCE.COMMODITYSHAPE.LABEL.APPLIED_START_DATE',
	    required: true, // 必須チェック
		date: true,
	    maxlength: 10
	 	}
}
 