var $data;

/**
 * 初期表示
 * @param request リクエストパラメータ
 */
function init(request) {
	$data = ImJson.toJSONString(getList(request));
}

function getList(request) {
	// 表示条件を設定（表示ページ、件数など）
	let page = request.page == undefined ? 1 : request.page;
	let rows = request.rowNum == undefined ? 15 : Module.number.toInt(request.rowNum);

	// 検索条件の状況に応じて条件を設定する
	var param = request.extension;
	if (!param || !param.searchCondition) {
    	return  {
                		page  : page,
                		total : rows,
                		data  : []
    				};
    	}
	var stockPositionCode = param.searchCondition.stockPositionCode;
	var storePositionCode = param.searchCondition.storePositionCode;
	var stockCategory = param.searchCondition.stockCategory;
	var manufacturerProduct = param.searchCondition.manufacturerProduct;
	var manufacturerFlag = param.searchCondition.manufacturerFlag;
	var productCodes = param.searchCondition.productCodes;
	var addtionNo = param.searchCondition.addtionNo;
	var productCodeList = null;
	if (param.searchCondition.productCodes) {
		productCodeList = param.searchCondition.productCodes.split(",");
	}
	
	// 該当する会社情報の件数取得
	let resultCount = null;
	if (manufacturerFlag == "1") {
		resultCount = getDetailStockListCount(stockPositionCode, storePositionCode, stockCategory, manufacturerProduct, productCodeList, addtionNo);
	} else {
		resultCount = getDetailStockListCount(stockPositionCode, storePositionCode, stockCategory, null, productCodeList, addtionNo);
	}
	
	// 全体の件数を設定（件数の母数）
	var listCount = 0;
	if (!resultCount.error) {
		listCount = resultCount.data[0]['rowcount'];
	} else {
		Debug.write(resultCount.errorMessage);
	}

	// ページ番号設定:リクエストパラメータのページ番号、最大ページ番号のうち小さい方の番号を設定
	page = Math.min(page, Math.ceil(listCount / rows)); 
	
	// 指定範囲の会社情報を取得
	let start = rows * (page - 1) + 1;
	let end = start + rows - 1;

	var result = null;
    if (manufacturerFlag == "1") {
    	result = getDetailStockList(stockPositionCode, storePositionCode, stockCategory, manufacturerProduct, productCodeList, addtionNo, start, end);
	} else {
		result = getDetailStockList(stockPositionCode, storePositionCode, stockCategory, null, productCodeList, addtionNo, start, end);
	}
	var rsltData = [];
	if (!result.error) {
		rsltData = result.data;
	} else {
		Debug.write(result.errorMessage);
	}
	
	var json = {
		page  : page,
		total : listCount,
		data  : rsltData
	};
	return json;
}

/****************************************************************
 * 在庫詳細一覧の情報を取得する処理
 *****************************************************************/
function getDetailStockList(stockPositionCode, storePositionCode, stockCategory, manufacturerCode, productCodes, addtionNo, start, end) {
	load("toms/common/master");	
	var result = TomsMaster.getDetailStockList(stockPositionCode, storePositionCode, stockCategory, manufacturerCode, productCodes, addtionNo, start, end);
	return result;
}
/****************************************************************
 * 在庫詳細一覧の件数を取得する処理
 *****************************************************************/
function getDetailStockListCount(stockPositionCode, storePositionCode, stockCategory, manufacturerCode, productCodes, addtionNo) {
	load("toms/common/master");	
	var result = TomsMaster.getDetailStockListCount(stockPositionCode, storePositionCode, stockCategory, manufacturerCode, productCodes, addtionNo);
	return result;
}

