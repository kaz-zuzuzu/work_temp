SELECT
    *
FROM
(
    SELECT
          MGAN8
          ,TRIM(MGY57ASPCD) AS MGY57ASPCD
          ,MGRNO
          ,TRIM(MGDS01) AS MGDS01
          ,TRIM(MGFLAG) AS MGFLAG
          ,TRIM(MGEV01) AS MGEV01
          ,TRIM(MGEV02) AS MGEV02
          ,TRIM(MGEV03) AS MGEV03
          ,TO_CHAR(FC_JDI9902_TO_DATE(MGY57ADT1), 'YYYY/MM/DD') AS MGY57ADT1
          ,TO_CHAR(FC_JDI9902_TO_DATE(MGY57ADT2), 'YYYY/MM/DD') AS MGY57ADT2
          ,TO_CHAR(FC_JDI9902_TO_DATE(MGY57ADT3), 'YYYY/MM/DD') AS MGY57ADT3
          ,MGY57AURA1
	      ,MGY57AURA2
	      ,MGY57AURA3
	      ,MGY57AAMT1
	      ,MGY57AAMT2
	      ,MGY57AAMT3
          ,TRIM(MGY57ADL01) AS MGY57ADL01
          ,TRIM(MGY57ADL02) AS MGY57ADL02
          ,TRIM(MGY57ADL03) AS MGY57ADL03
          ,TRIM(MGURCD) AS MGURCD
          ,TO_CHAR(FC_JDI9902_TO_DATE(MGURDT), 'YYYY/MM/DD') AS MGURDT
          ,MGURAT
          ,MGURAB
          ,TRIM(MGURRF) AS MGURRF
          ,TRIM(MGUSER) AS MGUSER
          ,TRIM(MGPID) AS MGPID
          ,TRIM(MGJOBN) AS MGJOBN
          ,TO_CHAR(FC_JDI9902_TO_DATE(MGUPMJ), 'YYYY/MM/DD') AS MGUPMJ
          ,MGUPMT
        ,ROWNUM AS RN
    FROM
    (
        SELECT
            MGAN8
			,MGY57ASPCD
			,MGRNO
			,MGDS01
			,MGFLAG
			,MGEV01
			,MGEV02
			,MGEV03
			,MGY57ADT1
			,MGY57ADT2
			,MGY57ADT3
			,MGY57AURA1
			,MGY57AURA2
			,MGY57AURA3
			,MGY57AAMT1
			,MGY57AAMT2
			,MGY57AAMT3
			,MGY57ADL01
			,MGY57ADL02
			,MGY57ADL03
			,MGURCD
			,MGURDT
			,MGURAT
			,MGURAB
			,MGURRF
			,MGUSER
			,MGPID
			,MGJOBN
			,MGUPMJ
			,MGUPMT

        FROM
          F57A5070
        /*BEGIN*/
        WHERE
            /*IF mgan8 != null*/
            MGAN8 = /*mgan8*/'0'
            /*END*/
        /*END*/
        ORDER BY
            MGAN8
            ,MGY57ASPCD
            ,MGRNO
    ) base
     /*IF end != null*/
        WHERE ROWNUM <= /*end*/'30' 
     /*END*/
)
/*IF start != null*/
WHERE RN >= /*start*/'1' 
/*END*/