SELECT
    COUNT(*) AS ROWCOUNT

    FROM
(
		select 
			  TRIM(KO.MJY57ACSC) AS MJY57ACSC
			  ,TRIM(KO.MJDL01) AS MJDL01
			  ,TRIM(OYA.MJY57ACSC) AS MJY57APCSC
			  ,TRIM(OYA.MJDL01) AS MJDL01P 
		  from 
  ( 
    select
      MJY57ACSC
      , MJY57APCSC
      , MJDL01
      , dense_rank() over ( partition by MJY57ACSC ,MJY57APCSC order by MJEFTJ desc ) rnk 
    from
      F57A5110 a
    where
      mjy57adflg = 0 
      and MJEFTJ <= FC_JDI9902_TO_JULIAN(sysdate)
  ) ko,

  ( 
    select
      MJY57ACSC
      , MJY57APCSC
      , MJDL01
      , dense_rank() over ( partition by MJY57ACSC ,MJY57APCSC order by MJEFTJ desc ) rnk 
    from
      F57A5110 a
    where
      mjy57adflg = 0 
      and MJEFTJ <= FC_JDI9902_TO_JULIAN(sysdate)
  ) oya
		 where oya.RNK = 1
		   and ko.RNK  = 1
		   and ko.MJY57APCSC = oya.MJY57ACSC
		  and ko.MJY57APCSC <> ko.MJY57ACSC
           /*IF pCode1 !=null*/
           AND TRIM(ko.MJY57ACSC) =/*pCode1*/
           /*END*/
            /*IF pName1 != null*/
           AND ko.MJDL01 like /*pName1*/
           /*END*/
           /*IF pCode2 != null*/
            AND TRIM(oya.MJY57ACSC) = /*pCode2*/
           /*END*/
            /*IF pName2 != null*/
           AND oya.MJDL01 like /*pName2*/
           /*END*/
)

