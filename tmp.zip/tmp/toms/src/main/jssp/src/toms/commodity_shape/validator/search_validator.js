/**
 * 商品形態マスタメンテナンスvalidation設定
 */

 
 var init = {
	 	'search_mjy57acsc':{//商品形態コード
	 	caption:'TOMS.MASTER.MAINTENANCE.COMMODITYSHAPE.LABEL.COMMODITY_SHAPE_CODE',
		alphanumeric: true,
		maxlength: 16
	 	},
	 	'search_mjy57apcsc':{//親商品形態コード
	 	caption:'TOMS.MASTER.MAINTENANCE.COMMODITYSHAPE.LABEL.PARRENT_COMMODITY_SHAPE_CODE',
		alphanumeric: true,
	    maxlength: 16
	 	},
	 	'search_mjdl01':{//商品形態名称
	 	caption:'TOMS.MASTER.MAINTENANCE.COMMODITYSHAPE.LABEL.COMMODITY_SHAPE_NAME',
	    maxlength: 30
	 	},
	 	'search_mjy57ajdc':{//JDEコード 
	 	caption:'TOMS.MASTER.MAINTENANCE.COMMODITYSHAPE.LABEL.JDE_CODE',
		alphanumeric: true,
	    maxlength: 8
	 	}, 	
	 	'search_mjeftj':{//有効開始日 (FROM)
	 	caption:'TOMS.MASTER.MAINTENANCE.COMMODITYSHAPE.LABEL.APPLIED_START_DATE',
		date: true,
	    maxlength: 10
	 	}, 
	 	'search_mjeftj2':{//有効開始日 (TO)
	 	caption:'TOMS.MASTER.MAINTENANCE.COMMODITYSHAPE.LABEL.APPLIED_START_DATE',
		date: true,
	    maxlength: 10
	 	}, 	 	'search_mjexdj':{//有効終了日 
	 	caption:'TOMS.MASTER.MAINTENANCE.COMMODITYSHAPE.LABEL.APPLIED_END_DATE',
		date: true,
	    maxlength: 10
	 	}
	 }