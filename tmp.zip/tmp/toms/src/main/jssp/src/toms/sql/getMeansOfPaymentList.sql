select
 a.value,
 a.label
from (
select
 NULL as value,
 NULL as label
from
 dual
union
select
  trim(drky) as value,
  trim(drdl01) as label
from
  f0005
where
  drsy ='00'
  and drrt ='PY'
  and ( trim(drky) = 'E' or trim(drky) = 'R')
) a
order by
  a.value ASC NULLS FIRST