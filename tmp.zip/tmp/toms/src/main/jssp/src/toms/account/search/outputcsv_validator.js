/**
 * CSV出力画面validation設定
 */
var init = {
  'paymentDateFrom': { // バリデーション対象のformのname属性を指定する.
    caption: 'TOMS.ACCOUNT.SEARCH.INPUT.PAYMENT.DATE.FROM', // キャプションのメッセージキーを指定する. 
    required: true, // 必須チェック
    range: [1, 31]
  },
  'paymentDateTo': { // バリデーション対象のformのname属性を指定する.
	  caption: 'TOMS.ACCOUNT.SEARCH.INPUT.PAYMENT.DATE.TO', // キャプションのメッセージキーを指定する. 
	  required: true, // 必須チェック
	  range: [1, 31]
   }
};