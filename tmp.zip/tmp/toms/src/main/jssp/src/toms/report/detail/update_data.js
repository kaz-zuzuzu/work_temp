/**
 * 帳票設定更新処理群
 * 
 * toms\src\main\jssp\src\toms\report\detail\update_data.js
 * 
 */

load('toms/common/common');
load('toms/common/cmnUtil');
 
function init(request) {

	load("toms/common/master");

	var entity = createEntity(request);

	var condition = "TRIM(MFPID1) = ? " +
						" AND TRIM(MFUSER1) = ? " +
						" AND (MFEV01) = ? ";
                		
	var params = [
					   DbParameter.string(entity['mfpid1']),
					   DbParameter.string(entity['mfuser1']),
					   DbParameter.string(entity['mfev01'])
		             ];

//	if(!isBlank(entity['mfev01']) && " " !=entity['mfev01']){
//		condition += " AND TRIM(MFEV01) = ? ";
//		params.push(DbParameter.string(entity['mfev01']));
//	}


	var msg;
	var result=null;
	//新規登録
	if (request.oprateFlag == "1") {
		//登録時に登録済みか確認する
		result = dbCheck(entity['mfpid1'],entity['mfuser1'],entity['mfev01']);
		if(result.error){
            // SELECTが失敗した場合
        	msg = MessageManager.getMessage('TOMS.COMMON.MAINTENANCE.AJAX.ERROR.INSERT.MESSAGE', MessageManager.getMessage('TOMS.MASTER.MAINTENANCE.REPORT.LIST.INPUT.FILENAME'));
        	common.sendErrorResult(msg, "");
		}
		if(result.countRow !=0){
			// 既に登録済みの場合
        	msg = MessageManager.getMessage('TOMS.COMMON.MAINTENANCE.AJAX.ERROR.INSERT.MESSAGE', MessageManager.getMessage('TOMS.MASTER.MAINTENANCE.REPORT.LIST.INPUT.FILENAME'));
        	common.sendErrorResult(msg, MessageManager.getMessage('TOMS.COMMON.MAINTENANCE.AJAX.ERROR.INSERT.NOTNEWDATA.MESSAGE'));
		}
		//登録実行
        result = entry(entity);
        if (result.error) {
            // 処理が失敗した場合
        	msg = MessageManager.getMessage('TOMS.COMMON.MAINTENANCE.AJAX.ERROR.INSERT.MESSAGE', MessageManager.getMessage('TOMS.MASTER.MAINTENANCE.REPORT.LIST.INPUT.FILENAME'));
        	common.sendErrorResult(msg, "");
        }
        
        // 処理が成功した場合
        msg = MessageManager.getMessage('TOMS.COMMON.MAINTENANCE.AJAX.SUCCESS.INSERT.MESSAGE', MessageManager.getMessage('TOMS.MASTER.MAINTENANCE.REPORT.LIST.INPUT.FILENAME'));
        common.sendResult(msg,{organization: result.data});

	} else if (request.oprateFlag == "2") {
    //更新時
		result = update(entity, condition, params);
        if (result.error) {
            // 処理が失敗した場合
        	msg = MessageManager.getMessage('TOMS.COMMON.MAINTENANCE.AJAX.ERROR.UPDATE.MESSAGE', MessageManager.getMessage('TOMS.MASTER.MAINTENANCE.REPORT.LIST.INPUT.FILENAME'));
        	common.sendErrorResult(msg, "");
        }
        if (result.countRow != 1) {
            // 対象データが存在しない場合
        	msg = MessageManager.getMessage('TOMS.COMMON.MAINTENANCE.AJAX.ERROR.UPDATE.MESSAGE', MessageManager.getMessage('TOMS.MASTER.MAINTENANCE.REPORT.LIST.INPUT.FILENAME'));
        	common.sendErrorResult(msg, MessageManager.getMessage('TOMS.COMMON.MAINTENANCE.AJAX.ERROR.UPDATE.NODATA.MESSAGE'));
        }
        // 処理が成功した場合
        msg = MessageManager.getMessage('TOMS.COMMON.MAINTENANCE.AJAX.SUCCESS.UPDATE.MESSAGE', MessageManager.getMessage('TOMS.MASTER.MAINTENANCE.REPORT.LIST.INPUT.FILENAME'));
        common.sendResult(msg,{organization: result.data});
	} else if (request.oprateFlag == "3") {
		//削除時

		result = remove(condition, params);
	    if (result.error) {
	        // 処理が失敗した場合
        	msg = MessageManager.getMessage('TOMS.COMMON.MAINTENANCE.AJAX.ERROR.DELETE.MESSAGE', MessageManager.getMessage('TOMS.MASTER.MAINTENANCE.REPORT.LIST.INPUT.FILENAME'));
        	common.sendErrorResult(msg, "");
	    }
        if(result.countRow != 1){
	    	// 処理件数が１件でない場合
        	msg = MessageManager.getMessage('TOMS.COMMON.MAINTENANCE.AJAX.ERROR.DELETE.MESSAGE', MessageManager.getMessage('TOMS.MASTER.MAINTENANCE.REPORT.LIST.INPUT.FILENAME'));
        	common.sendErrorResult(msg, MessageManager.getMessage('TOMS.COMMON.MAINTENANCE.AJAX.ERROR.DELETE.NODATA.MESSAGE'));
	    }
	    // 処理が成功した場合
        msg = MessageManager.getMessage('TOMS.COMMON.MAINTENANCE.AJAX.SUCCESS.DELETE.MESSAGE', MessageManager.getMessage('TOMS.MASTER.MAINTENANCE.REPORT.LIST.INPUT.FILENAME'));
        common.sendResult(msg,{organization: result.data});
	}
}

function dbCheck(mfpid1, mfuser1,mfev01){
	return TomsMaster.getReportByPk(mfpid1, mfuser1,mfev01);
}

function entry(entity) {
	return TomsMaster.insertToF57C1050(entity);
}

function update(entity, condition, params) {
	return TomsMaster.updateToF57C1050(entity, condition, params);
}
function remove(condition, params) {
	return TomsMaster.removeFromF57C1050(condition, params);
}

function createEntity(request) {
	var userContext = Contexts.getUserContext();
	var now = new Date();
	// 数字のデータ型
	var mfy57cura1 = null;
	var mfupmj = cmnUtil.convertDateToJulia(now);
	var mfupmt = cmnUtil.getTime(now);

	// 文字列のデータ型
	var mfpid1 = null;
    var mfuser1 = null;
    var mfev01 = null;
    var mfactntyp = null;
    var mfpdes = null;
    var mfsrc = null;
    var mfy57cdl01 = null;
    var mfy57cdl02 = null;
    var mfy57cdl03 = null;
    var mfuser = userContext.userProfile.userCd;
    var mfpid = "TOMS-WEB";
    
    // 数字設定
    if (cmnUtil.getData(request.mfy57cura1, 1) != "")  {
    	mfy57cura1 = cmnUtil.getData(request.mfy57cura1, 1);
    }

	if (cmnUtil.getData(request.mfpid1, 0) != "")  {
		mfpid1 = cmnUtil.getData(request.mfpid1, 0);
    }
	if (cmnUtil.getData(request.mfuser1, 0) != "")  {
		mfuser1 = cmnUtil.getData(request.mfuser1, 0);
    }
	
	if (cmnUtil.getData(request.mfev01, 0) != "")  {
		mfev01 = cmnUtil.getData(request.mfev01, 0);
    } else {
    	mfev01 = ' ';
    }
	if (cmnUtil.getData(request.mfactntyp, 0) != "")  {
		mfactntyp = cmnUtil.getData(request.mfactntyp, 0);
    }
	if (cmnUtil.getData(request.mfpdes, 0) != "")  {
		mfpdes = cmnUtil.getData(request.mfpdes, 0);
    }
	if (cmnUtil.getData(request.mfsrc, 0) != "")  {
		mfsrc = cmnUtil.getData(request.mfsrc, 0);
    }
	if (cmnUtil.getData(request.mfy57cdl01, 0) != "")  {
		mfy57cdl01 = cmnUtil.getData(request.mfy57cdl01, 0);
    }
	if (cmnUtil.getData(request.mfy57cdl02, 0) != "")  {
		mfy57cdl02 = cmnUtil.getData(request.mfy57cdl02, 0);
    }

	if (cmnUtil.getData(request.mfy57cdl03, 0) != "")  {
		mfy57cdl03 = cmnUtil.getData(request.mfy57cdl03, 0);
    }
	
    
    var entity = {
                    mfpid1 : mfpid1,
                    mfuser1 : mfuser1,
                    mfev01 : mfev01,
                    mfy57cura1 : mfy57cura1,
                    mfactntyp : mfactntyp,
                    mfpdes : mfpdes,
                    mfsrc : mfsrc,
                    mfy57cdl01 : mfy57cdl01,
                    mfy57cdl02 : mfy57cdl02,
                    mfy57cdl03 : mfy57cdl03,
                    mfuser : mfuser,
                    mfpid : mfpid,
                    mfupmj : mfupmj,
                    mfupmt : mfupmt
            };
    return entity;
}

