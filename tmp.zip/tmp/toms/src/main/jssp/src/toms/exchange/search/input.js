/**
 * バインド変数.
 */
var $bind = {};
	
/**
 * 初期表示.
 * @param request リクエストパラメータ.
 */
function init(request) {
  load("toms/common/master");

  // 取引種別のセレクトボックスの値を初期化.
  setExchangeCategoryList();
  // 上位組織のセレクトボックスの値を初期化.
  setSuperOrganizationData();
  // 上位組織、組織のセレクトボックスの値を初期化.
  setOrganizationData();
  // 担当者のセレクトボックスの値を初期化
  setChargePersonData($bind.exchangeCategoryList[0].value);
  // 分類1のセレクトボックスの値を初期化.
  setCategory1SelectList();
  // 分類2のセレクトボックスの値を初期化.
  setCategory2SelectList();
  // 都道府県のセレクトボックスの値を初期化.
  setAreaSelectList(); 

  // 組織のプルダウンに表示されるのトップメッセージを初期化.
  // JavaScriptで利用するためオブジェクトの内容をそのまま渡します.
  $bind.organizationLabel = ({
        selectTopMessage: MessageManager.getMessage('TOMS.COMMON.SELECT.LABEL.ORGANIZATION')
      }).toSource();
   
   $bind.errorMessage = ({
	    checkMessage: MessageManager.getMessage('TOMS.EXCHANGE.SEARCH.INPUT.CHECK.ERROR.MESSAGE')
	  }).toSource();
}


/**
 * 上位組織情報を設定する処理
 * 
 */
function setSuperOrganizationData() {
    var result = TomsMaster.getSuperOrganizationList();
    if (!result.error) {
        // 上位組織     
        $bind.superOrganizationSelectList = result.data;
    }
}

/**
 * 組織情報を設定する処理
 * 
 */
function setOrganizationData() {
    var result = TomsMaster.getOrganizationListByCode(' ');
    if (!result.error) {
        // 組織     
        $bind.organizationSelectList = result.data;
    }
}
    
/**
 * 担当者リストを設定する処理
 * 
 */
function setChargePersonData(){
    var result = TomsMaster.getChargePersonList();
    if(!result.error) {
        $bind.chargePersonSelectList = result.data;
    }
}

/**
 * validateアノテーションで指定したバリデーションを実行した結果、
 * エラーだった場合に呼び出される処理.
 * 
 * @param request リクエストパラメータ.
 * @param validationErrors バリデーションエラー.
 */
function handleErrors(request, validationErrors) {
  // なにも処理しない.
}

/**
 * 取引種別リスト情報を設定する処理
 * 
 */
function setExchangeCategoryList() {
    var result = TomsMaster.getSearchTypeList();
    if (!result.error) {
	    // 取引種別リスト 
    	$bind.exchangeCategoryList = [];
    	var keyOrg = null;
    	var key   = null;
    	var label = null;
    	var value = null;
    	var defaultValue = null;
    	var x = 0;
    	for (var i=0; i<result.data.length; i++) {
    		key   = result.data[i].key;
    		if (key != keyOrg) {
    			if (x > 0) {
    				// 取引種別プルダウンに表示される1行目、最後行目以外の情報
        			$bind.exchangeCategoryList[x] = {value: value, label: label};
        		}
				label = result.data[i].label;
    			value = result.data[i].value;
    			keyOrg = key;
    			x++;	
    		} else {
    			value = value + "," + result.data[i].value;
    		}
    		if (i==0) {
    			defaultValue = result.data[i].value;
    		} else {
    			defaultValue = defaultValue + "," + result.data[i].value;
    		}
    	}
    	// 取引種別プルダウンに表示される1行目の情報
        $bind.exchangeCategoryList[0] = {value: defaultValue, label: MessageManager.getMessage('TOMS.EXCHANGE.SEARCH.INPUT.EXCHANGECATEGORY.OPTIONTOP')};
        // 取引種別プルダウンに表示される最後行目の情報
        $bind.exchangeCategoryList[x] = {value: value, label: label};
    }
}
    
/**
 * 分類１リスト情報を設定する処理
 * 
 */
function setCategory1SelectList() {
    var result = TomsMaster.getBunrui1List();
    if (!result.error) {
        // 分類１リスト     
        $bind.category1SelectList = result.data;
    }
}
    
/**
 * 分類２リスト情報を設定する処理
 * 
 */
function setCategory2SelectList() {
    var result = TomsMaster.getBunrui2List();
    if (!result.error) {
        // 分類２リスト     
        $bind.category2SelectList = result.data;
    }
}

/**
 * 担当者リスト情報を設定する処理
 * 
 * @exchangeCategoryCd 取引種別
 */

function setChargePersonData(exchangeCategoryCd) {
    var result = TomsMaster.getChargePersonList(exchangeCategoryCd, null);
    if (!result.error) {
        // 担当者リスト     
        $bind.chargePersonSelectList = result.data;
    }
}

/**
 * 都道府県リスト情報を設定する処理
 * 
 */
function setAreaSelectList() {
    var result = TomsMaster.getTodoufukenList();
    if (!result.error) {
        // 都道府県リスト
        $bind.areaSelectList = result.data;
    } 
}
