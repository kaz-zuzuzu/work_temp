/**
 * 検索画面validation設定
 */
var init = {
    'searchExchangeTargetId': { // バリデーション対象のformのname属性を指定する.
       caption: 'TOMS.EXCHANGE.SEARCH.INPUT.EXCHANGETARGET.CODE', // キャプションのメッセージキーを指定する. 
       numeric: true 
    },
    'exchangeTargetKn': { // バリデーション対象のformのname属性を指定する.
       caption: 'TOMS.EXCHANGE.SEARCH.INPUT.EXCHANGETARGET.KANA', // キャプションのメッセージキーを指定する. 
       regex: /^[ｧ-ﾝﾞﾟ]+$/  
    },
    'chargePersonText': { // バリデーション対象のformのname属性を指定する.
        caption: 'TOMS.EXCHANGE.SEARCH.INPUT.CHARGEPERSON', // キャプションのメッセージキーを指定する. 
        regex: /^[ｧ-ﾝﾞﾟ]+$/  
    },
    'phone': { // バリデーション対象のformのname属性を指定する.
        caption: 'TOMS.EXCHANGE.SEARCH.INPUT.PHONENUMBER', // キャプションのメッセージキーを指定する. 
        regex: /^[0-9|-]+$/
    },
    'fax': { // バリデーション対象のformのname属性を指定する.
    	caption: 'TOMS.EXCHANGE.SEARCH.INPUT.FAXNUMBER', // キャプションのメッセージキーを指定する. 
        regex: /^[0-9|-]+$/
    },
    'stopKozaFlg': { // バリデーション対象のformのname属性を指定する.
    	caption: 'TOMS.EXCHANGE.SEARCH.INPUT.SUSPENSION.BUSSINESS', // キャプションのメッセージキーを指定する. 
        alphanumeric: true
    }
};