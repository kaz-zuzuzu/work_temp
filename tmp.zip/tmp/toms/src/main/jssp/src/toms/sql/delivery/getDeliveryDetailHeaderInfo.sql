select 
    TO_CHAR(FC_JDI9902_TO_DATE(TD.TDADDJ),'FMYYYY/MM/DD') AS TDADDJ --出荷日付
  , RTRIM(TD.TDY57ASHPN)   as TDY57ASHPN     --出荷予定番号
  , TD.TDY57ASDCT          as TDY57ASDCT     --伝票タイプ
  , TD.TDDOCO              as TDDOCO         --オーダーNo.
  , TD.TDDCTO              as TDDCTO         --オーダータイプ
  , TD.TDY57CPCN                             --ピッキングNo
  , TRIM(AB.ABALPH)        as ABALPH         --取引先
  , AB.ABALP1              as ABALP1         --取引先ｶﾅ
  , AB.ABAN8               as ABAN8          --取引先コード
  , TRIM(WPT1.WPPH1)       as tel            --取引先電話番号
  , TRIM(WPF1.WPPH1)       as fax            --取引先FAX番号
  , TD.TDY57ABPSN                            --営業担当者コード
  , TRIM(WW_ABAN84.WWALPH) as WWALPH         --営業担当者
  , TRIM(TD.TDALPH)        as TDALPH         --納入先
  , DR_Y57CUBC.DRDL01      as DRDL           --運送会社
  , TRIM(TD.TDADDZ) || '　' ||TRIM(TD.TDADD1) || TRIM(TD.TDADD2) || TRIM(TD.TDADD3) as TDADD -- 納入先住所
    -----個口数----------------------------------------
  ,( SELECT sum(send.tay57cboxn) FROM  F57A0070 td1 
             INNER JOIN F57A0150 send
              ON td1.tdy57CPCN = send.tay57CPCN
              WHERE td1.tdy57ASHPN = TD.TDY57ASHPN
                  AND td1.tdy57asdct = TD.TDY57ASDCT
   )                       as TDY57CYK       --個口数
  , TRIM(TD.TDY57AHRMK)    as TDY57AHRMK     --柄名
  , TRIM(TD.TDVR01)        as TDVR01         --販売先発注番号
    -----送り状No----------------------------------------
  , replace((select
      wk_0150.tay57cokj 
        from
          ( 
            SELECT
              ta1.tay57cpcn
              , TO_CHAR(wmsys.wm_concat(ta1.tay57cokj)) as tay57cokj 
            FROM
              f57a0150 ta1
            GROUP BY
              ta1.tay57cpcn
             order by  ta1.tay57cpcn
          ) wk_0150

        WHERE wk_0150.tay57cpcn = TD.TDY57CPCN
    ) ,',',' / ')        as TAY57COKJ        --送り状No

from F57A0070 TD
----------販売先---------------------------
  INNER JOIN F0101 AB
   ON TD.TDAN8 = AB.ABAN8
    INNER JOIN F0111 WW -- 住所録（人名録） 
        ON AB.ABAN8  = WW.WWAN8
       AND WW.WWIDLN = 0
    INNER JOIN F03012 AI -- 顧客マスタ
        ON WW.WWAN8  = AI.AIAN8
       AND AI.AICO   = '00000'
       
       LEFT OUTER JOIN F0115 WPT1 -- 住所録 電話番号
          ON AB.ABAN8            = WPT1.WPAN8
         AND WW.WWIDLN = WPT1.WPIDLN
         AND WPT1.WPCNLN = 0
         AND TRIM(WPT1.WPPHTP) = 'TEL1'
       LEFT OUTER JOIN F0115 WPF1 -- 住所録 電話番号
          ON AB.ABAN8            = WPF1.WPAN8
         AND WW.WWIDLN = WPF1.WPIDLN
         AND WPF1.WPCNLN = 0
         AND TRIM(WPF1.WPPHTP) = 'FAX1'
     -------- 営業担当者 ---------------------------------
     LEFT OUTER JOIN F0111 WW_ABAN84
        ON AB.ABAN84 = WW_ABAN84.WWAN8
       AND WW_ABAN84.WWIDLN        = 0        
-------- 便種 ---------------------------------

  LEFT OUTER JOIN F0005 DR_Y57CUBC 
    ON RTRIM(LTRIM(TD.TDY57CUBC)) = RTRIM(LTRIM(DR_Y57CUBC.DRKY)) 
    AND DR_Y57CUBC.DRSY = '01' 
    AND DR_Y57CUBC.DRRT = '06'

/*BEGIN*/
WHERE
    /*IF denpyoType != null*/
    TD.TDY57ASDCT = /*denpyoType*/'IT'            --伝票タイプ
    /*END*/
    /*IF instructNo != null*/
    AND TD.TDY57ASHPN = /*instructNo*/15158366    --出荷予定番号
    /*END*/
-- Mod start 2016/01/26 TIS M.Watanabe #1041
--    AND TD.TDY57ASHPS IN ('590', '600', '999')    -- 出荷予定ステータス
--    AND TD.TDY57CSBP > '550'                      -- ステータス（バラピッキング用）
    AND TD.TDY57ASHPS >= '550'    -- 出荷予定ステータス
-- Mod end 2016/01/26 TIS M.Watanabe #1041
/*END*/