/**
 * 検索画面validation設定
 */
var init = {
	  
  // 取引先コード
  'searchExchangeTargetId': { // バリデーション対象のformのname属性を指定する.
    caption: 'TOMS.CREDIT.SEARCH.INPUT.EXCHANGETARGET.CODE', // キャプションのメッセージキーを指定する. 
	numeric: true
  },
  // 取引先カナ
  'exchangeTargetKn': { // バリデーション対象のformのname属性を指定する.
	  caption: 'TOMS.CREDIT.SEARCH.INPUT.EXCHANGETARGET.KANA', // キャプションのメッセージキーを指定する. 
	  regex: /^[\uFF65-\uFF9F|\x20]+$/
   }
   ,
   // 担当者カナ
  'chargePersonText': { // バリデーション対象のformのname属性を指定する.
	  caption: 'TOMS.CREDIT.SEARCH.INPUT.CHARGEPERSON.KANA', // キャプションのメッセージキーを指定する.
	  regex: /^[\uFF65-\uFF9F|\x20]+$/
   }
   
};