/**
 * 初期表示
 * @param request リクエストパラメータ
 */
function init(request) {
	
}
