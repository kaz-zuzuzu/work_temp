/**
 * 検索画面validation設定
 */
var init = {
	  // 支払人No From
	  'mapyrFrom': { // バリデーション対象のformのname属性を指定する.
	    caption: 'TOMS.PAYMENT.LIST.LABE.MAPYR.FROM', // キャプションのメッセージキーを指定する. 
		numeric: true,
		maxlength: 8
	  },
	  // 支払人No To
	  'mapyrTo': { // バリデーション対象のformのname属性を指定する.
		  caption: 'TOMS.PAYMENT.LIST.LABEL.MAPYR.TO', // キャプションのメッセージキーを指定する. 
		  numeric: true,
		  maxlength: 8
	   }
};