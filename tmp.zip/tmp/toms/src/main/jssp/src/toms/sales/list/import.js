/**
 * バインド変数.
 */
var $bind = {};

/**
 * 初期表示.
 * @param request リクエストパラメータ.
 */
function init(request) {

	load("toms/common/csv/CsvUtil");
	load("toms/common/csv/CsvCheker");
	load("toms/common/master");
	load("toms/common/cmnUtil");

    var response = Web.getHTTPResponse();
    response.setContentType('text/plain; charset=utf-8');
    var csv = []; // csv二次元配列
    var stErr = new java.lang.StringBuilder(); // エラー文言
    var updateCount = { newCount:0, updateCount:0, deleteCount:0};
    
    // ファイルロード csv二次元ファイル化
    if(!CsvUtil.load2Csv(request, csv, stErr)) {
    	doError(response, stErr);
	    return;
	}

	// チェック
	if(!check(csv, stErr)) {
		doError(response, stErr);
		return;
	}

	// DBによるチェック
	if(!dbCheck(csv, stErr)) {
		doError(response, stErr);
		return;
	}

	// DB更新
	if(!dbUpdate(csv, stErr, updateCount)) {
		doError(response, stErr);
		return;
	}

	// 正常値の返却
//	stErr.append("<p>登録に成功しました。</p>");
//	stErr.append("<p>挿入件数 " + updateCount.newCount + "件</p>");
//	stErr.append("<p>更新件数 " + updateCount.updateCount + "件</p>");
//	stErr.append("<p>削除件数 " + updateCount.deleteCount + "件</p>");

	stErr.append(MessageManager.getMessage('TOMS.MASTER.MAINTENANCE.SALES.LIST.LABEL.ENTRY'));
	stErr.append(MessageManager.getMessage('TOMS.MASTER.MAINTENANCE.SALES.LIST.LABEL.ENTRYNUM', String(updateCount.newCount)));
	stErr.append(MessageManager.getMessage('TOMS.MASTER.MAINTENANCE.SALES.LIST.LABEL.UPDATENUM', String(updateCount.updateCount)));
	stErr.append(MessageManager.getMessage('TOMS.MASTER.MAINTENANCE.SALES.LIST.LABEL.DELETENUM', String(updateCount.deleteCount)));

	
var st = stErr.toString();
    response.sendMessageBodyString(ImJson.toJSONString([{
        "message": st,
        "isError": "false"
    }]));
}

/**
 * チェック
 * @param csv csv二次元配列.(IN)
 * @param stErr エラーメッセージパラメータ.(OUT)
 */
function check(csv, stErr) {
	var rowLength = csv.length;	//行数	
	var ret = true;

	// CSVデータ無し
	if(rowLength < 2) {
//		stErr.append("<p>csvファイルにデータがありません。</p>");
		stErr.append(MessageManager.getMessage('TOMS.MASTER.MAINTENANCE.SALES.LIST.LABEL.MESSAGE.ERROR.CSVNODATA'));
		return false;
	}

	// 略式品目番号
	var maitm = MessageManager.getMessage('TOMS.MASTER.MAINTENANCE.SALES.DETAIL.INPUT.MAITM');
	// 第2品目番号
	var malitm = MessageManager.getMessage('TOMS.MASTER.MAINTENANCE.SALES.DETAIL.INPUT.MALITM');
	// オーダー/トランザクション数量
	var mauorg = MessageManager.getMessage('TOMS.MASTER.MAINTENANCE.SALES.DETAIL.INPUT.MAUORG');
	// 単価
	var mauprc = MessageManager.getMessage('TOMS.MASTER.MAINTENANCE.SALES.DETAIL.INPUT.MAUPRC');
	// 有効開始日付
	var maeftj = MessageManager.getMessage('TOMS.MASTER.MAINTENANCE.SALES.DETAIL.INPUT.MAEFTJ');

	for(var rowPos=1; rowPos<rowLength; rowPos++) {
		var row = csv[rowPos];
		var sRowPos = String(rowPos);

		// 列数チェック
//		if(row.length != 9) {
//			stErr.append("<p>" + rowPos + "行目は" + row.length + "列になっています。</p>");
//			ret = false;
//			continue;
//		}
		
		if(row.length != 9) {
			if(row.length > 9){
				stErr.append(MessageManager.getMessage('TOMS.MASTER.MAINTENANCE.SALES.LIST.LABEL.MESSAGE.ERROR.COLUMN1',sRowPos, String(row.length)));
			} else if(row.length < 9) {
				stErr.append(MessageManager.getMessage('TOMS.MASTER.MAINTENANCE.SALES.LIST.LABEL.MESSAGE.ERROR.COLUMN2',sRowPos, String(row.length)));
			}
			ret = false;
			continue;
		}

		// 登録区分　0
		if(row[0] != "I" && row[0] != "U" && row[0] != "D" ) {
//			stErr.append("<p>" + rowPos + "行目 1列　登録区分にはIかUかDを設定して下さい。</p>");
			stErr.append(MessageManager.getMessage('TOMS.MASTER.MAINTENANCE.SALES.LIST.LABEL.MESSAGE.ERROR.UPDATEDIVISION', sRowPos)); //OK
			ret = false;
		}

		// 略式品目番号
		// 必須
		//CsvCheker
		if(!CsvCheker.required(row[1], rowPos, 1, maitm, stErr)) {
			ret = false;
		}
		// 文字数
		if(!CsvCheker.maxLength(row[1], 8, rowPos, 1, maitm, stErr)) {
			ret = false;
		}
		// 数値
		if(!CsvCheker.isNum(row[1], rowPos, 1, maitm, stErr)) {
			ret = false;
		}
		// 第2品目番号
		// 必須
		//CsvCheker
		if(!CsvCheker.required(row[2], rowPos, 2, malitm, stErr)) {
			ret = false;
		}
		// 文字数
		if(!CsvCheker.maxLength(row[2], 25, rowPos, 2, malitm, stErr)) {
			ret = false;
		}

		// オーダー/トランザクション数量
		// 必須
		//CsvCheker
		if(!CsvCheker.required(row[5], rowPos, 5, mauorg, stErr)) {
			ret = false;
		}
		// 文字数
		if(!CsvCheker.maxLength(row[5], 15, rowPos, 5, mauorg, stErr)) {
			ret = false;
		}
		// 数値
		if(!CsvCheker.isNum(row[5], rowPos, 5, mauorg, stErr)) {
			ret = false;
		}
		// 有効開始日付
		// 必須
		//CsvCheker
		if(!CsvCheker.required(row[7], rowPos, 7, maeftj, stErr)) {
			ret = false;
		}
		// 文字数
		if(!CsvCheker.maxLength(row[7], 10, rowPos, 7, maeftj, stErr)) {
			ret = false;
		}
		// 日付
		if(!CsvCheker.isDate(row[7], rowPos, 7, maeftj, stErr)) {
			ret = false;
		}
		
		// 単価
		// 必須
		//CsvCheker
		if(!CsvCheker.required(row[8], rowPos, 8, mauprc, stErr)) {
			ret = false;
		}
		// 文字数
		if(!CsvCheker.maxLength(row[8], 15, rowPos, 8, mauprc, stErr)) {
			ret = false;
		}
		// 数値
		if(!CsvCheker.isNum(row[8], rowPos, 8, mauprc, stErr)) {
			ret = false;
		}

		// 削除の場合 支払人No(keyのみ必要)
		if(row[0] == "D") {
			continue;
		}
	}

	return ret;
}

/*
 * DBによるデータ有無チェック
 * @param csv　csv二次元配列
 * @param stErr エラーメッセージパラメータ.(OUT)
 */
function dbCheck(csv, stErr) {
	var rowLength = csv.length;
	var result;
	var ret = true;
	
	var malitm = MessageManager.getMessage('TOMS.MASTER.MAINTENANCE.SALES.DETAIL.INPUT.MALITM');
	var mauorg = MessageManager.getMessage('TOMS.MASTER.MAINTENANCE.SALES.DETAIL.INPUT.MAUORG');
	var macrcd = MessageManager.getMessage('TOMS.MASTER.MAINTENANCE.SALES.DETAIL.INPUT.MACRCD');
	var macpgp = MessageManager.getMessage('TOMS.MASTER.MAINTENANCE.SALES.DETAIL.INPUT.MACPGP');
	var maeftj = MessageManager.getMessage('TOMS.MASTER.MAINTENANCE.SALES.DETAIL.INPUT.MAEFTJ');

	
	for(var rowPos=1; rowPos<rowLength; rowPos++) {
		var row = csv[rowPos];
		var ope = row[0];

		result = getSaleByPk(row[2], row[4], row[5], row[6], row[7]);

		// 挿入の場合
		if(ope == "I") {			
			if(result.countRow > 0 ) {
//				stErr.append("<p>" + rowPos + "行目はデータが重複しています。 " + malitm + "=" + trim(row[2]) + ", " + macpgp + "=" + trim(row[4]) + ", " + mauorg + "=" + trim(row[5]) + ", " + macrcd + "=" + trim(row[6]) + ", " + maeftj + "=" + trim(row[7]) + "</p>");
				stErr.append(MessageManager.getMessage('TOMS.MASTER.MAINTENANCE.SALES.LIST.LABEL.MESSAGE.ERROR.DUPLICATE', String(rowPos),String(trim(row[2])),String(trim(row[4])),String(trim(row[5])),String(trim(row[6])),String(trim(row[7]))));
				ret = false;
			}
		// 更新、削除の場合
		} else {
			if(result.countRow < 1 ) {
//				stErr.append("<p>" + rowPos + "行目はデータが存在しません。 " + malitm + "=" + trim(row[2]) + ", " + macpgp + "=" + trim(row[4]) + ", " + mauorg + "=" + trim(row[5]) + ", " + macrcd + "=" + trim(row[6]) + ", " + maeftj + "=" + trim(row[7]) + "</p>");
				stErr.append(MessageManager.getMessage('TOMS.MASTER.MAINTENANCE.SALES.LIST.LABEL.MESSAGE.ERROR.DATANOTEXIST', String(rowPos),String(trim(row[2])),String(trim(row[4])),String(trim(row[5])),String(trim(row[6])),String(trim(row[7]))));
				ret = false;
			}
			if(result.countRow > 1 ) {
//				stErr.append("<p>" + rowPos + "行目はデータが１件以上存在しています。 " + malitm + "=" + trim(row[2]) + ", " + macpgp + "=" + trim(row[4]) + ", " + mauorg + "=" + trim(row[5]) + ", " + macrcd + "=" + trim(row[6]) + ", " + maeftj + "=" + trim(row[7]) + "</p>");
				stErr.append(MessageManager.getMessage('TOMS.MASTER.MAINTENANCE.SALES.LIST.LABEL.MESSAGE.ERROR.DATAEXIST', String(rowPos),String(trim(row[2])),String(trim(row[4])),String(trim(row[5])),String(trim(row[6])),String(trim(row[7]))));
				ret = false;
			}
		}
	}

	return ret;
}

/*
 * DB更新
 * @param csv　csv二次元配列
 * @param stErr エラーメッセージパラメータ.(OUT)
 * @param updateCount (OUT)
 */
function dbUpdate(csv, stErr, counts) {
	
	load("toms/common/master");

	var rowLength = csv.length;
	var ret = true;
	var newCount = 0;
	var updateCount = 0;
	var deleteCount = 0;
	
	Transaction.begin();
	for(var rowPos=1; rowPos<rowLength; rowPos++) {
		var row = csv[rowPos];
		var ope = row[0];
		var result;

		var entity = createEntity(row);
		var condition = "MALITM = RPAD(?, 25) " +
        		" AND MAMCU = ? " +
        		" AND MALOCN = ? " +
        		" AND MALOTN = ? " +
        		" AND MAAN8 = ? " +
        		" AND MACPGP = RPAD(?, 8) " +
        		" AND MAPRGR = ? " +
        		" AND MAUORG = ? " +
        		" AND MACRCD = ? " +
        		" AND MAEFTJ = ? ";
        var params = [
        	   DbParameter.string(entity['malitm']),
        	   DbParameter.string(entity['mamcu']),
        	   DbParameter.string(entity['malocn']),
        	   DbParameter.string(entity['malotn']),
        	   DbParameter.number(entity['maan8']),
        	   DbParameter.string(entity['macpgp']),
        	   DbParameter.string(entity['maprgr']),
        	   DbParameter.number(entity['mauorg']),
        	   DbParameter.string(entity['macrcd']),
        	   DbParameter.number(entity['maeftj'])
             ];

       
		if(ope == "I") {			//挿入
			result = TomsMaster.insertToF57A5010(entity);
			newCount++;
		} else if (ope =="U") {		//更新
			result = TomsMaster.updateToF57A5010(entity, condition, params);
			updateCount++;
		} else if  (ope =="D") {	//削除
			result = TomsMaster.removeFromF57A5010(condition, params);
			deleteCount++;
		}
		if(!result.error && result.countRow != 1) {
			Transaction.rollback();
//			stErr.append("<p>処理数が異常でした。(1件が正常):" + result.countRow);
//			stErr.append(" CSV行数:" + rowPos);
//			stErr.append("</p>");
			stErr.append(MessageManager.getMessage('TOMS.MASTER.MAINTENANCE.SALES.LIST.LABEL.MESSAGE.ERROR.ABNORMAL',String(result.countRow)));
//			stErr.append(" CSV行数:" + rowPos);
//			stErr.append("</p>");
			return false;
		}
		if (result.error) {
			Transaction.rollback();
//			stErr.append("<p>データベースエラー \n");
//			stErr.append(" エラーコード:" + result.errorCode);
//			stErr.append(" エラーメッセージ:" + result.errorMessage);
//			stErr.append(" CSV行数:" + rowPos);
//			stErr.append("</p>");
			stErr.append(MessageManager.getMessage('TOMS.MASTER.MAINTENANCE.SALES.LIST.LABEL.MESSAGE.ERROR.DB'));
//			stErr.append(MessageManager.getMessage('TOMS.MASTER.MAINTENANCE.SALES.LIST.LABEL.MESSAGE.ERRORCODE.DB',result.errorCode));
//			stErr.append(MessageManager.getMessage('TOMS.MASTER.MAINTENANCE.SALES.LIST.LABEL.MESSAGE.ERRORMSG.DB',result.errorMessage));
			stErr.append(MessageManager.getMessage('TOMS.MASTER.MAINTENANCE.SALES.LIST.LABEL.MESSAGE.CSVLINE',String(rowPos)));
			return false;
		}
	}

	counts.newCount = newCount;
	counts.updateCount = updateCount;
	counts.deleteCount = deleteCount;

	Transaction.commit();
	return true;
}

/**
 * エラー処理
 * @param response　レスポンス
 * @param stErr エラーメッセージパラメータ.
 */
function doError(response, stErr){
//		stErr.insert(0,"<p>登録に失敗しました。</p>");
		stErr.insert(0, MessageManager.getMessage('TOMS.MASTER.MAINTENANCE.SALES.LIST.LABEL.ENTRY.ERROR'));
		var st = stErr.toString();
		response.sendMessageBodyString(ImJson.toJSONString([{
	        "message":st,
	        "isError":"true"
		}]));
}

function getSaleByPk(malitm, macpgp, mauorg, macrcd, maeftj) {
    var result = TomsMaster.getSaleByPk(malitm, macpgp, mauorg, macrcd, maeftj);
	return result;
}


function createEntity(row) {
	var userContext = Contexts.getUserContext();
	
	var now = new Date();
	
	// 数字のデータ型
	var maitm = null;
	var maan8 = null;
	var mauorg = null;
	var maeftj = null;
	var may57adt1 = null;
	var may57adt2 = null;
	var may57adt3 = null;
	var may57aura1 = null;
	var may57aura2 = null;
	var may57aura3 = null;
	var may57aamt1 = null;
	var may57aamt2 = null;
	var may57aamt3 = null;
	var maurdt = null;
	var maurat = null;
	var maurab = null;
	
	var maupmj = cmnUtil.convertDateToJulia(now);
	var maupmt = cmnUtil.getTime(now);

	// 文字列のデータ型
	var malitm = null;
    var mamcu = null;
    var malocn = null;
    var malotn = null;
    var macpgp = null;
    var maprgr = null;
    var macrcd = null;
    var mauom = null;
    var mauprc = null;
    var maev01 = null;
    var maev02 = null;
    var maev03 = null;
    var may57adl01 = null;
    var may57adl02 = null;
    var may57adl03 = null;
    var maurcd = null;
    var maurrf = null;
    var mauser = userContext.userProfile.userCd;
    var mapid = MessageManager.getMessage('TOMS.COMMON.CONSTANT.PROGRAM.ID');
    var majobn = null;
    
    // 数字設定
    if (cmnUtil.getData(row[1], 1) != "")  {
    	maitm = cmnUtil.getData(row[1], 1);
    }
    if (cmnUtil.getData(row[3], 1) != "")  {
    	maan8 = cmnUtil.getData(row[3], 1);
    } else {
    	maan8 = 0;
    }
    if (cmnUtil.getData(row[5], 1) != "")  {
    	mauorg = cmnUtil.getData(row[5], 1);
    } else {
    	mauorg = Number(MessageManager.getMessage('TOMS.COMMON.CONSTANT.THRESHOLD.DEFAULT'));
    }
    var tempMaeftj = cmnUtil.getData(row[7], 0);
    if (tempMaeftj != "")  {
    	maeftj = cmnUtil.convertDateToJulia(new Date(tempMaeftj));
    } else {
    	maeftj = cmnUtil.convertDateToJulia(new Date());
    }
    if (cmnUtil.getData(row[8], 1) != "")  {
		mauprc = cmnUtil.getData(row[8], 1) * 10000;
    }
   

	if (cmnUtil.getData(row[2], 0) != "")  {
		malitm = cmnUtil.getData(row[2], 0);
    } else {
    	malitm = "                         ";
    }
	
    mamcu = "            ";
    malocn = "                    ";
    malotn = "                              ";
    maprgr = "        ";
    mauom = MessageManager.getMessage('TOMS.MASTER.MAINTENANCE.SALES.DEFAULT.MAUOM')
    
	if (cmnUtil.getData(row[4], 0) != "")  {
		macpgp = cmnUtil.getData(row[4], 0);
    } else {
    	macpgp = "        ";
    }
	if (cmnUtil.getData(row[6], 0) != "")  {
		macrcd = cmnUtil.getData(row[6], 0);
    } else {
    	macrcd = MessageManager.getMessage('TOMS.COMMON.CONSTANT.CURRENCY.CODE.DEFAULT');
    }
    
    var entity = {
                        maitm : maitm,
                        malitm : malitm,
                        mamcu : mamcu,
                        malocn : malocn,
                        malotn : malotn,
                        maan8 : maan8,
                        macpgp : macpgp,
                        maprgr : maprgr,
                        mauorg : mauorg,
                        macrcd : macrcd,
                        mauom : mauom,
                        maeftj : maeftj,
                        mauprc : mauprc,
                        maev01 : maev01,
                        maev02 : maev02,
                        maev03 : maev03,
                        may57adt1 : may57adt1,
                        may57adt2 : may57adt2,
                        may57adt3 : may57adt3,
                        may57aura1 : may57aura1,
                        may57aura2 : may57aura2,
                        may57aura3 : may57aura3,
                        may57aamt1 : may57aamt1,
                        may57aamt2 : may57aamt2,
                        may57aamt3 : may57aamt3,
                        may57adl01 : may57adl01,
                        may57adl02 : may57adl02,
                        may57adl03 : may57adl03,
                        maurcd : maurcd,
                        maurdt : maurdt,
                        maurat : maurat,
                        maurab : maurab,
                        maurrf : maurrf,
                        mauser : mauser,
                        mapid : mapid,
                        majobn : majobn,
                        maupmj : maupmj,
                        maupmt : maupmt
            };
    return entity;
}
