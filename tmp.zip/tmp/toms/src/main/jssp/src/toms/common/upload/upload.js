/**
 * バインド変数.
 */
var $bind = {};

/**
 * ファイルアップロード.
 * @param request リクエストパラメータ.
 */
function init(request) {

	load("toms/common/csv/CsvUtil");

    var response = Web.getHTTPResponse();
    response.setContentType('text/plain; charset=utf-8');
    //var csv = [];								// csv二次元配列
    var stErr = new java.lang.StringBuilder();	// エラー文言
    var fileInfo = {name: "", size: 0};	   		// ファイル情報

    // ファイル保存csv(二次元配列)作成
    if(!CsvUtil.Upload(request, stErr, fileInfo)) {
    	doError(response, stErr, fileInfo);
	    return;
	}

    // 正常値の返却
    response.sendMessageBodyString(ImJson.toJSONString([{
        "name":fileInfo.name,
        "size":fileInfo.size
    }]));
}

/**
 * エラー処理
 * @param response　レスポンス
 * @param stErr エラーメッセージパラメータ.
 * @param fileInfo ファイル情報パラメータ.
 */
function doError(response, stErr, fileInfo){

		var st = stErr.toString();
		response.sendMessageBodyString(ImJson.toJSONString([{
	        "name":fileInfo.name,
	        "size":fileInfo.size,
	        "error":st
		}]));
}

