SELECT
    COUNT(*) AS ROWCOUNT
FROM
	(
	SELECT
           MAITM
          ,MALITM
          ,MAMCU
          ,MALOCN
          ,MALOTN
          ,MAAN8
          ,MACPGP
          ,MAPRGR
          ,MAUORG
          ,MACRCD
          ,MAUOM
          ,MAEFTJ
          ,MAUPRC
          ,MAEV01
          ,MAEV02
          ,MAEV03
          ,MAY57ADT1
          ,MAY57ADT2
          ,MAY57ADT3
          ,MAY57AURA1
          ,MAY57AURA2
          ,MAY57AURA3
          ,MAY57AAMT1
          ,MAY57AAMT2
          ,MAY57AAMT3
          ,MAY57ADL01
          ,MAY57ADL02
          ,MAY57ADL03
          ,MAURCD
          ,MAURDT
          ,MAURAT
          ,MAURAB
          ,MAURRF
          ,MAUSER
          ,MAPID
          ,MAJOBN
          ,MAUPMJ
          ,MAUPMT
        FROM
          F57A5010
        /*BEGIN*/
        WHERE
            /*IF malitm != null*/
            TRIM(MALITM) LIKE /*malitm*/'%010015200102%'
            /*END*/
            /*IF maan8 != null*/
            AND MAAN8 LIKE /*maan8*/'%0%'
            /*END*/
            /*IF macpgp != null*/
            AND TRIM(MACPGP) = /*macpgp*/'31'
            /*END*/
          /*IF maeftj != null*/
            AND TO_CHAR(FC_JDI9902_TO_DATE(MAEFTJ), 'YYYY/MM/DD') = /*maeftj*/'113001'
            /*END*/
        /*END*/
        ORDER BY
            MALITM
            ,MAEFTJ
	)
