/**
 * バインド変数.
 */
var $bind = {};


/**
 * 初期表示.
 * @param request リクエストパラメータ.
 */
function init(request) {

    request.setAttribute("imui-theme-builder-module", "headwithcontainer"); 

    /* 詳細一覧検索条件 */
    var instructNo = request.instructNo;
    var denpyoType = request.denpyoType;

	/* ヘッダ情報取得処理 */
	$bind.deliveryHeaderInfo =getHeaderInfo(instructNo, denpyoType);

	/* 明細一覧取得処理 */
	var detailListInfo = getDetailList(instructNo, denpyoType);
	
	$bind.deliveryDetailList = detailListInfo;

}


/**
 * 明細ヘッダ情報取得
 * @param instructNo  出荷予定NO
 * @param denpyoType 伝票タイプ
 *  
 */
function getHeaderInfo(instructNo, denpyoType){
	load("toms/common/delivery");
	
	var result = Delivery.getHeaderInfo(instructNo, denpyoType);
	if (result.error) {
		error(result.errorMessage);
	}
	
	var tmpData = result.data[0];
	var resultObj ={
		tdaddj 		: tmpData.tdaddj,
		tdy57ashpn 	: tmpData.tdy57ashpn,
		tddoco 		: tmpData.tddoco,
		tddcto 		: tmpData.tddcto,
		tdy57asdct	: tmpData.tdy57asdct,
		tdy57cpcn	: tmpData.tdy57cpcn,
		tdalph		: tmpData.tdalph,
		tdadd		: tmpData.tdadd,
		abalph		: tmpData.abalph,
		abalp1		: tmpData.abalp1,
		aban8		: tmpData.aban8,
		tel			: tmpData.tel,
		fax			: tmpData.fax,
		drdl		: tmpData.drdl,
		tay57cokj	: tmpData.tay57cokj,
	//	tay57cokj	: isBlank(tmpData.tay57cokj) ? tmpData.tay57cokj : (tmpData.tay57cokj).replace(/\//g,' / '),
		tdy57cyk	: tmpData.tdy57cyk,
		tdy57abpsn	: tmpData.tdy57abpsn,
		tdvr01		: tmpData.tdvr01,
		wwalph		: tmpData.wwalph,
		tdy57ahrmk  : tmpData.tdy57ahrmk
	};
	


	return resultObj;
}

/* リスト表示用のメソッド */
function getDetailList(instructNo, denpyoType){
    load("toms/common/delivery");
	var result = Delivery.getDeliveryDetailList(instructNo, denpyoType);

	if (!result.error) {
		return result.data;
	} else {
		error(result.errorMessage);
	}
	return result;
}


/**
 * エラー画面へ遷移の処理.
 */
function error(message) {
  Transfer.toErrorPage({
    title: MessageManager.getMessage('TOMS.COMMON.ERROR.PAGE.TITLE'),
    message: MessageManager.getMessage('TOMS.COMMON.ERROR.MESSAGE.SYSTEM'),
    detail: [MessageManager.getMessage('TOMS.DELIVERY.LIST.LABEL.MESSAGE.ERROR'), message],
    returnUrl: 'toms/delevery/search/input', // 戻り先 URL
    returnUrlLabel: MessageManager.getMessage('TOMS.DELIVERY.LIST.LABEL.RETURN.LINK.NAME'),
    parameter: {
    }
  });
}
