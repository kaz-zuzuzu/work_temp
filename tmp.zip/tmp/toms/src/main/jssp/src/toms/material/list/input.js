/**
 * 素材マスタメンテナンス一覧
 *
 **/

 var $bind ={};
 
 var $data={};
 load("toms/common/common");
 

/**
 * 初期表示
 * @param request リクエストパラメータ
 */
function init(request){
	
	$bind.dialogMessages="";

	$data = {
		pageNum : isBlank(request.pageNum) ? '1' : request.pageNum,
		rowNum  : isBlank(request.rowNum) ? '30' : request.rowNum,
		rowList : isBlank(request.rowList) ? '30, 50, 100' : request.rowList
	};

	//検索条件設定
	$bind.mly57amtc = isBlank(request.search_mly57amtc) ? "":request.search_mly57amtc; //素材コード
	$bind.mldl01 = isBlank(request.search_mldl01) ? "":request.search_mldl01; //原材料名
	$bind.mly57acsc = isBlank(request.search_mly57acsc) ? "":request.search_mly57acsc; //商品形態コード
	$bind.mly57apcsc = isBlank(request.search_mly57apcsc) ? "":request.mly57apcsc; //親商品形態コード
	$bind.mlpct1 = isBlank(request.search_mlpct1) ? "":request.mlpct1; //パーセント
	$bind.mly57ajdc = isBlank(request.search_mly57ajdc) ? "":request.mly57ajdc; //JDEコード
	$bind.mly57amflg = isBlank(request.search_mly57amflg) ? "0":request.mly57amflg; //たたみ袋制御フラグ
	$bind.mly57adflg = isBlank(request.search_mly57adflg) ? "0":request.mly57adflg; //削除フラグ
	$bind.mly57absc = isBlank(request.search_mly57absc) ? "" :request.search_mly57absc;//たたみ袋SKUコード
	$bind.mleftj = isBlank(request.search_mleftj) ? "":request.search_mleftj;//適用開始日
	$bind.mleftj2 = isBlank(request.search_mleftj2) ? "":request.search_mleftj2;//適用開始日
	$bind.mlexdj = isBlank(request.search_mlexdj) ? "":request.search_mlexdj;//適用終了日
	
	//ダウrンロード用検索条件

	var csvObj;
	if (request.csvFlag == "1") {
		csvObj ={
			mly57amtc 	: isBlank(request.mly57amtc) ? "":request.mly57amtc, //素材コード
			mldl01 		: isBlank(request.mldl01) ? "":request.mldl01, //原材料名
			mly57acsc 	: isBlank(request.mly57acsc) ? "":request.mly57acsc, //商品形態コード
			mly57apcsc 	: isBlank(request.mly57apcsc) ? "":request.mly57apcsc, //親商品形態コード
			mlpct1 		: isBlank(request.mlpct1) ? "":request.mlpct1, //パーセント
			mly57ajdc 	: isBlank(request.mly57ajdc) ? "":request.mly57ajdc, //JDEコード
			mly57amflg 	: isBlank(request.mly57amflg) ? "":request.mly57amflg, //たたみ袋制御フラグ
			mly57adflg 	: isBlank(request.mly57adflg) ? "":request.mly57adflg, //削除フラグ
			mly57absc 	: isBlank(request.mly57absc) ? "" :request.mly57absc,//たたみ袋SKUコード
			mleftj 		: isBlank(request.mleftj) ? "":request.mleftj,//適用開始日
			mleftj2 	: isBlank(request.mleftj2) ? "":request.mleftj2,//適用開始日
			mlexdj 		: isBlank(request.mlexdj) ? "":request.mlexdj//適用終了日
		};
	

        outputCSV(csvObj);
	}
	
	$bind.checked1 = true; 	
	$bind.checked2 = false;
	$bind.checked3 	=false;

	//画面項目
	$bind.select_notdelete=MessageManager.getMessage('TOMS.COMMON.DELETE.SELECT.NOTDELETE');
	$bind.select_delete=MessageManager.getMessage('TOMS.COMMON.DELETE.SELECT.DELETE');
	$bind.select_all=MessageManager.getMessage('TOMS.COMMON.DELETE.SELECT.ALL');

	$bind.control_notcontrol=MessageManager.getMessage('TOMS.COMMON.CONTROL.SELECT.NOTCONTROL');
	$bind.control_control=MessageManager.getMessage('TOMS.COMMON.CONTROL.SELECT.CONTROL');
	$bind.control_all=MessageManager.getMessage('TOMS.COMMON.CONTROL.SELECT.ALL');


  $bind.dialogMessages = ({
    addConfirmTitle: MessageManager.getMessage('TOMS.COMMON.DIALOG.CONFIRM.TITLE'),
    addConfirmMessage: MessageManager.getMessage('TOMS.COMMON.DIALOG.CONFIRM.MESSAGE')
  }).toSource();

}

/**
 * 素材マスタメンテナンスのCSV出力処理
 * 
 * @param　リクエストパラメータ
 * 
 */
function outputCSV(param){
    load("toms/common/Material");
	var result = Material.getMaterialList(param, false, null,null);

	var outputContent = "";
	if (!result.error) {
		outputContent = outputCSVHeader();
    	for(var i = 0; i < result.countRow; i++) {
    		outputContent += outputCSVRow(result.data[i]);
    	}
    	var strDate = DateTimeFormatter.format("yyyyMMdd_HHmmss", new Date());
    	var strUserName = Contexts.getUserContext().userProfile.userName;
    	var fileName = MessageManager.getMessage('TOMS.MASTER.MAINTENANCE.MATERIAL.DETAIL.INPUT.TITLE') + '_' + strDate + '_' + strUserName + '.csv';
    	Module.download.send(Unicode.to(outputContent, 'MS932'), fileName, MessageManager.getMessage('TOMS.COMMON.MIME.CSV'));
	} else {
		error(result.errorMessage);
	}
}

/**
 * 素材マスタメンテナンスのCSVヘッダ部分出力処理。
 */
function outputCSVHeader() {
	var outputHeader = common.convert(MessageManager.getMessage('TOMS.COMMON.CSV.UPDATE.DIVIDE'), true)
	  + common.convert(MessageManager.getMessage('TOMS.MASTER.MAINTENANCE.MATERIAL.LABEL.MATERIAL_CODE'), true)
	  + common.convert(MessageManager.getMessage('TOMS.MASTER.MAINTENANCE.COMMODITYSHAPE.LABEL.PARENT_COMMODITY_SHAPE_CODE'), true)
	  + common.convert(MessageManager.getMessage('TOMS.MASTER.MAINTENANCE.COMMODITYSHAPE.LABEL.COMMODITY_SHAPE_CODE'), true)
	  + common.convert(MessageManager.getMessage('TOMS.MASTER.MAINTENANCE.MATERIAL.LABEL.MATERIAL_NAME'), true)
	  + common.convert(MessageManager.getMessage('TOMS.MASTER.MAINTENANCE.MATERIAL.LABEL.PARCENT'), true)
	  + common.convert(MessageManager.getMessage('TOMS.MASTER.MAINTENANCE.COMMODITYSHAPE.LABEL.DISPLAY_ORDER'), true)
//	  + common.convert(MessageManager.getMessage('TOMS.MASTER.MAINTENANCE.COMMODITYSHAPE.LABEL.JDE_CODE'), true)
	  + common.convert(MessageManager.getMessage('TOMS.MASTER.MAINTENANCE.MATERIAL.LABEL.MAT_CONTROL_FLG'), true)
	  + common.convert(MessageManager.getMessage('TOMS.MASTER.MAINTENANCE.MATERIAL.LABEL.BAG_SKU_CODE'), true)
	  + common.convert(MessageManager.getMessage('TOMS.MASTER.MAINTENANCE.COMMODITYSHAPE.LABEL.APPLIED_START_DATE'), true)
	  + common.convert(MessageManager.getMessage('TOMS.MASTER.MAINTENANCE.COMMODITYSHAPE.LABEL.DELETE_FLG'), false);
	  //	  + common.convert(MessageManager.getMessage('TOMS.MASTER.MAINTENANCE.COMMODITYSHAPE.LABEL.APPLIED_END_DATE'), true)
//	  + common.convert(MessageManager.getMessage('TOMS.MASTER.MAINTENANCE.LIST.INPUT.USER'), true)
//	  + common.convert(MessageManager.getMessage('TOMS.MASTER.MAINTENANCE.LIST.INPUT.PID'), true)
//	  + common.convert(MessageManager.getMessage('TOMS.MASTER.MAINTENANCE.LIST.INPUT.UPMJ'), true)
//	  + common.convert(MessageManager.getMessage('TOMS.MASTER.MAINTENANCE.LIST.INPUT.UPMT'), true)
return outputHeader;

}

/**
 * 素材マスタメンテナンスのCSVファイルの行を出力する処理
 * 
 * @param record DBから検索した行のデータ
 */
function outputCSVRow(record) {
	var result =  MessageManager.getMessage('TOMS.COMMON.CSV.SPLIT')
		    + common.convert(record["mly57amtc"], true)
			+ common.convert(record["mly57apcsc"], true)
			+ common.convert(record["mly57acsc"], true)
			+ common.convert(record["mldl01"], true)
			+ common.convert(record["mlpct1"], true)
			+ common.convert(record["mlsnn"], true)
//			+ common.convert(record["mly57ajdc"], true)
			+ common.convert(record["mly57amflg"]+"", true)
			+ common.convert(record["mly57absc"], true)
			+ common.convert(record["mleftj"], true)
			+ common.convert(record["mly57adflg"]+"", false);
//			+ common.convert(record["mlexdj"], true)
//			+ common.convert(record["mluser"], true)
//			+ common.convert(record["mlpid"], true)
//			+ common.convert(record["mlupmj"], true)
//			+ common.convert(record["mlupmt"], true)

	return result;
	
}

function error(message) {
  Transfer.toErrorPage({
    title: MessageManager.getMessage('TOMS.COMMON.ERROR.PAGE.TITLE'),
    message: MessageManager.getMessage('TOMS.COMMON.ERROR.MESSAGE.SYSTEM'),
    detail: [MessageManager.getMessage('TOMS.MASTER.MAINTENANCE.MATERIAL.LIST.LABEL.MESSAGE.ERROR'), message],
    returnUrl: 'toms/material/list/input', // 戻り先 URL
    returnUrlLabel: MessageManager.getMessage('TOMS.MASTER.MAINTENANCE.MATERIAL.LIST.LABEL.RETURN.LINK.NAME'),
    parameter: {
    }
  });
}