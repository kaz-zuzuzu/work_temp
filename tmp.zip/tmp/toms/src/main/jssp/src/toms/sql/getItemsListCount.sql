SELECT
    COUNT(*) AS ROWCOUNT
FROM
	(
	SELECT
            MGAN8
            ,MGY57ASPCD
            ,MGRNO
            ,MGDS01
            ,MGFLAG
            ,MGEV01
            ,MGEV02
            ,MGEV03
            ,MGY57ADT1
            ,MGY57ADT2
            ,MGY57ADT3
            ,MGY57AURA1
            ,MGY57AURA2
            ,MGY57AURA3
            ,MGY57AAMT1
            ,MGY57AAMT2
            ,MGY57AAMT3
            ,MGY57ADL01
            ,MGY57ADL02
            ,MGY57ADL03
            ,MGURCD
            ,MGURDT
            ,MGURAT
            ,MGURAB
            ,MGURRF
            ,MGUSER
            ,MGPID
            ,MGJOBN
            ,MGUPMJ
            ,MGUPMT

        FROM
          F57A5070
        /*BEGIN*/
        WHERE
            /*IF mgan8 != null*/
            MGAN8 = /*mgan8*/'0'
            /*END*/
        /*END*/
        ORDER BY
            MGAN8
            ,MGY57ASPCD
            ,MGRNO
	)
