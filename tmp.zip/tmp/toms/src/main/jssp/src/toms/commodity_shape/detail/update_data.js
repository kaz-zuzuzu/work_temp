/**
 * 商品形態マスタ設定更新処理群
 * 
 * toms\src\main\jssp\src\toms\commodity_shape\detail\update_data.js
 * 
 */

load('toms/common/common');
load('toms/common/cmnUtil');
var _SHARED_DB_KEY = "toms-web-dev";

 function init(request){

	var entity = createEntity(request);
	var msg;
	var result;
	
	var condition ="TRIM(mjy57acsc) = ? " + 
							" AND TRIM(mjy57apcsc) = ? "+
							" AND mjeftj = ? ";

	var params = [
					   DbParameter.string(entity['mjy57acsc']),
					   DbParameter.string(entity['mjy57apcsc']),
					   DbParameter.number(entity['mjeftj'])
					   ];
	
	//------------------------------------
	//新規登録時
	//------------------------------------
	// request.updateFlag  0： 新規登録、１：更新、２：削除
	var parentFlg ="1"; //商品形態詳細は1、商品形態は0
	if(entity['mjy57acsc']==entity['mjy57apcsc']){
		parentFlg ="0";
	}
	if(request.operateFlag=="0"){
		//新規登録時
		//重複チェック（登録済みかどうか）
    	result = _dbCheck(entity['mjy57acsc'],entity['mjy57apcsc'],entity['mjeftj']);
    	if(result.error){
            // SELECTが失敗した場合
        	msg = MessageManager.getMessage('TOMS.COMMON.MAINTENANCE.AJAX.ERROR.INSERT.MESSAGE', MessageManager.getMessage('TOMS.MASTER.MAINTENANCE.COMMODITYSHAPE.DETAIL.INPUT.TITLE'));
        	common.sendErrorResult(msg, "");
    	}
    	if(result.countRow !=0){
    		// 既に登録済みの場合
        	msg = MessageManager.getMessage('TOMS.COMMON.MAINTENANCE.AJAX.ERROR.INSERT.MESSAGE', MessageManager.getMessage('TOMS.MASTER.MAINTENANCE.COMMODITYSHAPE.DETAIL.INPUT.TITLE'));
        	common.sendErrorResult(msg, MessageManager.getMessage('TOMS.COMMON.MAINTENANCE.AJAX.ERROR.INSERT.NOTNEWDATA.MESSAGE'));
    	}
    	
    	if(parentFlg=="0"){
        //商品形態の場合（商品形態コードの存在チェック:内部コード、親商品形態コード、JDEコード：内部コードUDC）
    		//商品形態コード
        	result = checkCodeMaster("01", "01", entity['mjy57acsc']);
        	if(result.error){
                // SELECTが失敗した場合
            	msg = MessageManager.getMessage('TOMS.COMMON.MAINTENANCE.AJAX.ERROR.INSERT.MESSAGE', MessageManager.getMessage('TOMS.MASTER.MAINTENANCE.COMMODITYSHAPE.DETAIL.INPUT.TITLE'));
            	common.sendErrorResult(msg, "");
        	}
        	if(result.countRow ==0){
        		// 存在しない場合
            	msg = MessageManager.getMessage('TOMS.COMMON.MAINTENANCE.AJAX.ERROR.INSERT.MESSAGE', MessageManager.getMessage('TOMS.MASTER.MAINTENANCE.COMMODITYSHAPE.DETAIL.INPUT.TITLE'));
            	common.sendErrorResult(msg, MessageManager.getMessage('TOMS.COMMON.MAINTENANCE.AJAX.ERROR.CODEMASTER.NOTINLINE.MESSAGE',MessageManager.getMessage('TOMS.MASTER.MAINTENANCE.COMMODITYSHAPE.LABEL.COMMODITY_SHAPE_CODE')));
        	}
    	}else{
        //商品形態詳細の場合
        	//商品形態コード
        	result = checkCodeMaster("02", "01", entity['mjy57acsc']);
        	if(result.error){
                // SELECTが失敗した場合
            	msg = MessageManager.getMessage('TOMS.COMMON.MAINTENANCE.AJAX.ERROR.INSERT.MESSAGE', MessageManager.getMessage('TOMS.MASTER.MAINTENANCE.COMMODITYSHAPE.DETAIL.INPUT.TITLE'));
            	common.sendErrorResult(msg, "");
        	}
        	if(result.countRow ==0){
        		// 存在しない場合
            	msg = MessageManager.getMessage('TOMS.COMMON.MAINTENANCE.AJAX.ERROR.INSERT.MESSAGE', MessageManager.getMessage('TOMS.MASTER.MAINTENANCE.COMMODITYSHAPE.DETAIL.INPUT.TITLE'));
            	common.sendErrorResult(msg, MessageManager.getMessage('TOMS.COMMON.MAINTENANCE.AJAX.ERROR.CODEMASTER.NOTINLINE.MESSAGE',MessageManager.getMessage('TOMS.MASTER.MAINTENANCE.COMMODITYSHAPE.LABEL.COMMODITY_SHAPE_CODE')));
        	}
        	//親商品形態コード内部コードチェック
        	result = checkCodeMaster("01", "01", entity['mjy57apcsc']);
        	if(result.error){
                // SELECTが失敗した場合
            	msg = MessageManager.getMessage('TOMS.COMMON.MAINTENANCE.AJAX.ERROR.INSERT.MESSAGE', MessageManager.getMessage('TOMS.MASTER.MAINTENANCE.COMMODITYSHAPE.DETAIL.INPUT.TITLE'));
            	common.sendErrorResult(msg, "");
        	}
        	if(result.countRow ==0){
        		// 存在しない場合
            	msg = MessageManager.getMessage('TOMS.COMMON.MAINTENANCE.AJAX.ERROR.INSERT.MESSAGE', MessageManager.getMessage('TOMS.MASTER.MAINTENANCE.COMMODITYSHAPE.DETAIL.INPUT.TITLE'));
            	common.sendErrorResult(msg, MessageManager.getMessage('TOMS.COMMON.MAINTENANCE.AJAX.ERROR.CODEMASTER.NOTINLINE.MESSAGE',MessageManager.getMessage('TOMS.MASTER.MAINTENANCE.COMMODITYSHAPE.LABEL.PARENT_COMMODITY_SHAPE_CODE')));
        	}
        	//親商品形態コード存在チェック
        	result = _dbCheck(entity['mjy57apcsc'],entity['mjy57apcsc'],null);
        	if(result.error){
                // SELECTが失敗した場合
            	msg = MessageManager.getMessage('TOMS.COMMON.MAINTENANCE.AJAX.ERROR.INSERT.MESSAGE', MessageManager.getMessage('TOMS.MASTER.MAINTENANCE.COMMODITYSHAPE.DETAIL.INPUT.TITLE'));
            	common.sendErrorResult(msg, "");
        	}
        	if(result.countRow ==0){
        		// 既に登録されていない場合
            	msg = MessageManager.getMessage('TOMS.COMMON.MAINTENANCE.AJAX.ERROR.INSERT.MESSAGE', MessageManager.getMessage('TOMS.MASTER.MAINTENANCE.COMMODITYSHAPE.DETAIL.INPUT.TITLE'));
            	common.sendErrorResult(msg, MessageManager.getMessage('TOMS.COMMON.MAINTENANCE.AJAX.ERROR.CODEMASTER.NOTINLINE.MESSAGE',MessageManager.getMessage('TOMS.MASTER.MAINTENANCE.COMMODITYSHAPE.LABEL.PARRENT_COMMODITY_SHAPE_CODE')));
        	}
//        	//JDEコード
//        	result = checkCodeMaster("02", "02", entity['mjy57ajdc']);
//        	if(result.error){
//                // SELECTが失敗した場合
//            	msg = MessageManager.getMessage('TOMS.COMMON.MAINTENANCE.AJAX.ERROR.INSERT.MESSAGE', MessageManager.getMessage('TOMS.MASTER.MAINTENANCE.COMMODITYSHAPE.DETAIL.INPUT.TITLE'));
//            	common.sendErrorResult(msg, "");
//        	}
//        	if(result.countRow ==0){
//        		// 存在しない場合
//            	msg = MessageManager.getMessage('TOMS.COMMON.MAINTENANCE.AJAX.ERROR.INSERT.MESSAGE', MessageManager.getMessage('TOMS.MASTER.MAINTENANCE.COMMODITYSHAPE.DETAIL.INPUT.TITLE'));
//            	common.sendErrorResult(msg, MessageManager.getMessage('TOMS.COMMON.MAINTENANCE.AJAX.ERROR.CODEMASTER.NOTJDE.MESSAGE'));
//        	}
    	}
		//登録実行
    	result = inseartToF57A5110(entity);
        if (result.error) {
            // 処理が失敗した場合
        	msg = MessageManager.getMessage('TOMS.COMMON.MAINTENANCE.AJAX.ERROR.INSERT.MESSAGE', MessageManager.getMessage('TOMS.MASTER.MAINTENANCE.COMMODITYSHAPE.DETAIL.INPUT.TITLE'));
        	common.sendErrorResult(msg, "");
        }
        
        // 処理が成功した場合
        msg = MessageManager.getMessage('TOMS.COMMON.MAINTENANCE.AJAX.SUCCESS.INSERT.MESSAGE', MessageManager.getMessage('TOMS.MASTER.MAINTENANCE.COMMODITYSHAPE.DETAIL.INPUT.TITLE'));
        common.sendResult(msg,{organization: result.data});
	}else if(request.operateFlag=="1"){
	//------------------------------------
	//更新時
	//------------------------------------
//    	if(parentFlg=="1"){
//        	//JDEコード
//        	result = checkCodeMaster("02", "02", entity['mjy57ajdc']);
//        	if(result.error){
//                // SELECTが失敗した場合
//            	msg = MessageManager.getMessage('TOMS.COMMON.MAINTENANCE.AJAX.ERROR.INSERT.MESSAGE', MessageManager.getMessage('TOMS.MASTER.MAINTENANCE.COMMODITYSHAPE.DETAIL.INPUT.TITLE'));
//            	common.sendErrorResult(msg, "");
//        	}
//        	if(result.countRow ==0){
//        		// 存在しない場合
//            	msg = MessageManager.getMessage('TOMS.COMMON.MAINTENANCE.AJAX.ERROR.INSERT.MESSAGE', MessageManager.getMessage('TOMS.MASTER.MAINTENANCE.COMMODITYSHAPE.DETAIL.INPUT.TITLE'));
//            	common.sendErrorResult(msg, MessageManager.getMessage('TOMS.COMMON.MAINTENANCE.AJAX.ERROR.CODEMASTER.NOTJDE.MESSAGE') );
//        	}
//    	}

//        //データ期間化チェック
//        result = _priodDbCheck(entity['mjy57acsc'], entity['mjy57apcsc'], entity['mjeftj'], entity['mjexdj']);
//        if (result.error) {
//            // SELECTが失敗した場合
//            msg = MessageManager.getMessage('TOMS.COMMON.MAINTENANCE.AJAX.ERROR.INSERT.MESSAGE', MessageManager.getMessage('TOMS.MASTER.MAINTENANCE.COMMODITYSHAPE.DETAIL.INPUT.TITLE'));
//            common.sendErrorResult(msg, "");
//        }
//        if (result.countRow != 0) {
//            // 存在しない場合
//            msg = MessageManager.getMessage('TOMS.COMMON.MAINTENANCE.AJAX.ERROR.INSERT.MESSAGE', MessageManager.getMessage('TOMS.MASTER.MAINTENANCE.COMMODITYSHAPE.DETAIL.INPUT.TITLE'));
//            common.sendErrorResult(msg, MessageManager.getMessage('TOMS.COMMON.MAINTENANCE.AJAX.ERROR.PRIOD_DATA.MESSAGE'));
//        }
        //更新処理

		result = updateToF57A5110(entity, condition, params);
        if (result.error) {
            // 処理が失敗した場合
        	msg = MessageManager.getMessage('TOMS.COMMON.MAINTENANCE.AJAX.ERROR.UPDATE.MESSAGE', MessageManager.getMessage('TOMS.MASTER.MAINTENANCE.COMMODITYSHAPE.DETAIL.INPUT.TITLE'));
        	common.sendErrorResult(msg, "");
        }
        if (result.countRow != 1) {
            // 対象データが存在しない場合
        	msg = MessageManager.getMessage('TOMS.COMMON.MAINTENANCE.AJAX.ERROR.UPDATE.MESSAGE', MessageManager.getMessage('TOMS.MASTER.MAINTENANCE.COMMODITYSHAPE.DETAIL.INPUT.TITLE'));
        	common.sendErrorResult(msg, MessageManager.getMessage('TOMS.COMMON.MAINTENANCE.AJAX.ERROR.UPDATE.NODATA.MESSAGE'));
        }
        // 処理が成功した場合
        msg = MessageManager.getMessage('TOMS.COMMON.MAINTENANCE.AJAX.SUCCESS.UPDATE.MESSAGE', MessageManager.getMessage('TOMS.MASTER.MAINTENANCE.COMMODITYSHAPE.DETAIL.INPUT.TITLE'));
        common.sendResult(msg,{organization: result.data});
	}else if(request.operateFlag=="2"){
	//------------------------------------
	//削除時
	//------------------------------------
		result = removeFromF57A5110(condition, params);
	    if (result.error) {
	        // 処理が失敗した場合
        	msg = MessageManager.getMessage('TOMS.COMMON.MAINTENANCE.AJAX.ERROR.DELETE.MESSAGE', MessageManager.getMessage('TOMS.MASTER.MAINTENANCE.COMMODITYSHAPE.DETAIL.INPUT.TITLE'));
        	common.sendErrorResult(msg, "");
	    }
        if(result.countRow != 1){
	    	// 処理件数が１件でない場合
        	msg = MessageManager.getMessage('TOMS.COMMON.MAINTENANCE.AJAX.ERROR.DELETE.MESSAGE', MessageManager.getMessage('TOMS.MASTER.MAINTENANCE.COMMODITYSHAPE.DETAIL.INPUT.TITLE'));
        	common.sendErrorResult(msg, MessageManager.getMessage('TOMS.COMMON.MAINTENANCE.AJAX.ERROR.DELETE.NODATA.MESSAGE'));
	    }
	    // 処理が成功した場合
        msg = MessageManager.getMessage('TOMS.COMMON.MAINTENANCE.AJAX.SUCCESS.DELETE.MESSAGE', MessageManager.getMessage('TOMS.MASTER.MAINTENANCE.COMMODITYSHAPE.DETAIL.INPUT.TITLE'));
        common.sendResult(msg,{organization: result.data});
	}
 }
 
 
/**
 * DBへの登録オブジェクト生成処理
 */
function createEntity(request){
	
	var userContext = Contexts.getUserContext();
	var now = new Date();
	//数値型データ
	var  mjsnn = null; //表示順
	var mjeftj =null; //適用開始日
	var mjexdj= null; //適用終了日
	var mjy57adflg =0; //削除フラグ
	var mjupmj = cmnUtil.convertDateToJulia(now);  //更新日付
	var mjupmt = cmnUtil.getTime(now);  //更新時刻
	
	//文字列型データ
	var mjy57acsc = null; //商品形態コード
	var mjy57apcsc = null; //親商品形態コード
	var mjdl01 = null; //商品形態名称
	var mjy57ajdt = null; //JDE区分
	var mjy57ajdc = null; //JDEコード
    var mjuser = userContext.userProfile.userCd; //ユーザID
    var mjpid = "TOMS-WEB"; //プログラムID
    
    var mjurcd = null;
    var mjurdt = null;
    var mjurab = null;
    var mjurrf = null;
    var mjjobn = null;

    //商品形態コード
    if(!isBlank(request.mjy57acsc)){
    	mjy57acsc = request.mjy57acsc;
    }
    //親商品形態コード
    if(!isBlank(request.mjy57apcsc)){
    	mjy57apcsc = request.mjy57apcsc;
    }
    //商品形態名称
    if(!isBlank(request.mjdl01)){
    	mjdl01 = request.mjdl01;
    }
    //表示順
    if(!isBlank(request.mjsnn)){
    	mjsnn = cmnUtil.getData(request.mjsnn,1);
    }
    //JDE区分(未使用)
    //JDEコード
    if(!isBlank(request.mjy57ajdc)){
        	mjy57ajdc = request.mjy57ajdc;
    }
    //適用開始日
    if(!isBlank(request.mjeftj)){
    	mjeftj = cmnUtil.convertDateToJulia(new Date(request.mjeftj));
    }
    //適用終了日
    if(!isBlank(request.mjexdj)){
    	mjexdj = cmnUtil.convertDateToJulia(new Date(request.mjexdj));
    }
    //削除フラグ
    if(!isBlank(request.mjy57adflg)){
    	mjy57adflg = cmnUtil.getData(request.mjy57adflg,1);
    }
    //ユーザーID（処理の先頭で定義）
    //プログラムID（処理の先頭で定義）
    //更新日付（処理の先頭で定義）
    //更新時刻（処理の先頭で定義）

    
    var entity = {
    	mjy57acsc :mjy57acsc,
    	mjy57apcsc : mjy57apcsc,
    	mjdl01 : mjdl01,
    	mjsnn : mjsnn,
    	mjy57ajdt : mjy57ajdt,
//    	mjy57ajdc :mjy57ajdc,//JDEコード廃止に伴い全角スペースを固定で設定
    	mjy57ajdc :"　",
    	mjeftj : mjeftj,
    	mjexdj : mjexdj,
    	mjy57adflg : mjy57adflg,
    	
    	mjuser : mjuser,
    	mjpid : mjpid,
    	mjupmj : mjupmj,
    	mjupmt : mjupmt 
    	
    }
    return entity;
}
/**
 * データ存在チェック
 */
function _dbCheck( commodityShapCode , parentCommodityShapeCode , appliedStartDate){
	var db = new SharedDatabase(_SHARED_DB_KEY);
	var params = [];

	var sql ="";
	sql += " SELECT * FROM F57A5110 ";
	sql +="     WHERE ";
	sql +="                  TRIM(MJY57ACSC) = ? ";
	sql +="          AND TRIM(MJY57APCSC) = ? ";
	sql +="          AND MJY57ADFLG = 0 ";
	
	if(appliedStartDate != null){
		sql +="          AND  MJEFTJ = ? ";
	      params.push(DbParameter.string(commodityShapCode));
	      params.push(DbParameter.string(parentCommodityShapeCode));
	      params.push(DbParameter.string(appliedStartDate+""));
	}else{
	      params.push(DbParameter.string(commodityShapCode));
	      params.push(DbParameter.string(parentCommodityShapeCode));
	}

	var result = db.execute(sql, params);
	return result;
}

	
/**
 * 登録処理
 */
function inseartToF57A5110(entity){
	var database = new SharedDatabase(_SHARED_DB_KEY);
	var ret = Transaction.begin(function(){
		var result = database.insert('F57A5110', entity);
		if(result.error || result.countRow !=1){
			Transaction.rollback();
		}
		return result;
	})
	return ret.data;
}
function updateToF57A5110(entity, condition, params) {
	var database = new SharedDatabase(_SHARED_DB_KEY);
	var ret = Transaction.begin(function(){
		var result = database.update('F57A5110', entity, condition, params);
		if(result.error || result.countRow !=1){
			Transaction.rollback();
		}
			return result;
	})
	return ret.data;
}
function removeFromF57A5110(condition, params) {
	var database = new SharedDatabase(_SHARED_DB_KEY);
	var ret = Transaction.begin(function(){
		var entity ={
			mjy57adflg : 1
			};
		var result = database.update('F57A5110',entity,  condition, params);
		if(result.error || result.countRow !=1){
			Transaction.rollback();
		}
		return result;
	})
	return ret.data;
}

//内部コードマスタチェック
function checkCodeMaster(processType, codeType,codeValue){
	var db = new SharedDatabase(_SHARED_DB_KEY);
	var sql ="";
	sql += " SELECT * FROM F57A5190 ";
	sql +="     WHERE ";
	sql +="                  TRIM(MSY57APT) = ? ";
	sql +="          AND MSY57APMT = '  ' ";
	sql +="          AND  TRIM(MSY57ACOTY) = ? ";
	if(codeType =="01"){
		sql +="          AND  TRIM(MSY57AIC) = ? ";
	}else if(codeType=="02" ){
		sql +="          AND  TRIM(MSY57AJDC) = ? ";
	}
	
	var params = [];
	      params.push(DbParameter.string(processType));
	      params.push(DbParameter.string(codeType));
	      params.push(DbParameter.string(codeValue));

	var result = db.execute(sql, params);
	return result;

}

