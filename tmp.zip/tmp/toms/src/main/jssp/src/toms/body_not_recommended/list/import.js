/**
 * バインド変数.
 */
var $bind = {};

load("toms/common/mastermaintenance");

// 親商品形態コード
var mqy57apcsc = MessageManager.getMessage("TOMS.MASTER.MAINTENANCE.COMMODITYSHAPE.LABEL.PARENT_COMMODITY_SHAPE_CODE");
// 商品形態コード
var mqy57acsc = MessageManager.getMessage("TOMS.MASTER.MAINTENANCE.COMMODITYSHAPE.LABEL.COMMODITY_SHAPE_CODE");
// 素材コード
var mqy57amtc = MessageManager.getMessage("TOMS.MASTER.MAINTENANCE.MATERIAL.LABEL.MATERIAL_CODE");
// 加工部位コード
var mqy57appc1 = MessageManager.getMessage("TOMS.MASTER.MAINTENANCE.PROCESSPART.LABEL.PROCESSPART_CODE");
// 加工位置コード
var mqy57appc2 = MessageManager.getMessage("TOMS.MASTER.MAINTENANCE.PROCESSPART.LABEL.PROCESSPART_POSITION_CODE");
// 加工方法区分
var mqy57apmt = MessageManager.getMessage("TOMS.MASTER.MAINTENANCE.PROCESSMETHOD_HEADER.LABEL.PROCESS_METHOD_TPYE");
// 加工方法明細区分
var mqy57apmdt = MessageManager.getMessage("TOMS.MASTER.MAINTENANCE.PROCESSMETHOD_HEADER.LABEL.PROCESS_METHOD_DETAIL_TPYE");
// 加工方法明細第1階層コード
var mqy57apmd1 = MessageManager.getMessage("TOMS.MASTER.MAINTENANCE.BODY_NOT_RECOMMENDED.PROCESS_DETAIL_FIRST_HIERARCHY_CODE");
// 加工方法明細第2階層コード
var mqy57apmd2 = MessageManager.getMessage("TOMS.MASTER.MAINTENANCE.BODY_NOT_RECOMMENDED.PROCESS_DETAIL_SECOND_HIERARCHY_CODE");
// 加工方法明細第3階層コード
var mqy57apmd3 = MessageManager.getMessage("TOMS.MASTER.MAINTENANCE.BODY_NOT_RECOMMENDED.PROCESS_DETAIL_THIRD_HIERARCHY_CODE");
// 商品コード
var mqy57aitcd = MessageManager.getMessage("TOMS.MASTER.MAINTENANCE.PROCESSMETHOD_COMMODITY.LABEL.COMMODITY_CODE");
// サイズコード
var mqy57asc = MessageManager.getMessage("TOMS.MASTER.MAINTENANCE.BODY_NOT_RECOMMENDED.SIZE_CODE");
// 非推奨区分
var mqy57anrt = MessageManager.getMessage("TOMS.MASTER.MAINTENANCE.BODY_NOT_RECOMMENDED.NOT_RECOMMENDED_DIVIDE");
// 適用開始日
var mqeftj = MessageManager.getMessage("TOMS.MASTER.MAINTENANCE.COMMODITYSHAPE.LABEL.APPLIED_START_DATE");
// 削除フラグ
var mqy57adflg = MessageManager.getMessage("TOMS.MASTER.MAINTENANCE.COMMODITYSHAPE.LABEL.DELETE_FLG");

/**
 * 初期表示.
 * @param request リクエストパラメータ.
 */
function init(request) {

    load("toms/common/csv/CsvUtil");
    load("toms/common/csv/CsvCheker");
    load("toms/common/cmnUtil");
    
    var response = Web.getHTTPResponse();
    response.setContentType("text/plain; charset=utf-8");
    var csv = []; // csv二次元配列
    var stErr = new java.lang.StringBuilder(); // エラーメッセージ
    var stMsg = new java.lang.StringBuilder(); // 成功メッセージ
    var updateCount = { newCount: 0, updateCount: 0, deleteCount: 0};
    var ret = true;
    
    // ファイルロード csv二次元ファイル化
    if (!CsvUtil.load2Csv(request, csv, stErr)) {
        doError(response, stErr);
        return;
    }
    
    // CSVデータ有無チェック
    if (csv.length < 2) {
        // CSVファイルにデータ行が存在しない場合はエラー
        stErr.append(MessageManager.getMessage("TOMS.MASTER.MAINTENANCE.CSVUPLOAD.MESSAGE.ERROR.CSVNODATA"));
        doError(response, stErr);
        return;
    }
    
    // CSVデータの行数分繰り返す（先頭行はヘッダ行のため次の行から始める）
    for (var rowPos = 1; rowPos < csv.length; rowPos++) {
        // データチェック
        ret = check(csv[rowPos], rowPos, stErr);
        // DB存在チェック
        if (ret) {
            ret = dbCheck(csv[rowPos], rowPos, stErr);
        }
        // DB更新
        if (ret) {
            ret = dbUpdate(csv[rowPos], rowPos, stErr, updateCount);
        }
    }
    
    // 正常値の返却
    // 挿入件数
    stMsg.append(MessageManager.getMessage("TOMS.MASTER.MAINTENANCE.CSVUPLOAD.LIST.LABEL.ENTRYNUM", String(updateCount.newCount)));
    // 更新件数
    stMsg.append(MessageManager.getMessage("TOMS.MASTER.MAINTENANCE.CSVUPLOAD.LIST.LABEL.UPDATENUM", String(updateCount.updateCount)));
    // 削除件数
    stMsg.append(MessageManager.getMessage("TOMS.MASTER.MAINTENANCE.CSVUPLOAD.LIST.LABEL.DELETENUM", String(updateCount.deleteCount)));
    
    var stringErr = stErr.toString();
    var stringMsg = stMsg.toString();
    response.sendMessageBodyString(ImJson.toJSONString([{
        "errorMessage": stringErr,
        "successMessage": stringMsg
    }]));
}

/**
 * チェック
 * @param csvRowData csvの行データ.(IN)
 * @param rowPos 行番号.(IN)
 * @param stErr エラーメッセージパラメータ.(OUT)
 */
function check(csvRowData, rowPos, stErr) {
    var ret = true;
    var ope = csvRowData[0];
    var sRowPos = String(rowPos);
    var cellPos = null;
    
    // 列数チェック
    var columnCnt = 16;
    if (csvRowData.length != columnCnt) {
        if (csvRowData.length > columnCnt) {
            stErr.append(MessageManager.getMessage("TOMS.MASTER.MAINTENANCE.CSVUPLOAD.MESSAGE.ERROR.COLUMN1", sRowPos));
        } else if (csvRowData.length < columnCnt) {
            stErr.append(MessageManager.getMessage("TOMS.MASTER.MAINTENANCE.CSVUPLOAD.MESSAGE.ERROR.COLUMN2", sRowPos));
        }
        ret = false;
        return ret;
    }
    
    // --------------------
    //  0 更新区分
    // --------------------
    // データチェック
    if (isBlank(ope)) {
        stErr.append(MessageManager.getMessage("TOMS.MASTER.MAINTENANCE.CSVUPLOAD.LIST.LABEL.MESSAGE.ERROR.UPDATEDIVISION", sRowPos));
        ret = false;
    } else {
        if (ope != "I" && ope != "U" && ope != "D") {
            stErr.append(MessageManager.getMessage("TOMS.MASTER.MAINTENANCE.CSVUPLOAD.LIST.LABEL.MESSAGE.ERROR.UPDATEDIVISION_FORMAT", sRowPos));
            ret = false;
        }
    }
    // --------------------
    //  1 親商品形態コード
    // --------------------
    cellPos = 1;
    // 必須チェック
    if (!CsvCheker.required(csvRowData[cellPos], rowPos, cellPos, mqy57apcsc, stErr)) {
        ret = false;
    } else {
        // 挿入、更新の場合
        if (ope == "I" || ope == "U") {
            // 半角英数字チェック
            if (!CsvCheker.isAlphanumeric(csvRowData[cellPos], rowPos, cellPos, mqy57apcsc, stErr)) {
                ret = false;
            }
            // 文字数チェック
            if (!CsvCheker.maxLength(csvRowData[cellPos], 16, rowPos, cellPos, mqy57apcsc, stErr)) {
                ret = false;
            }
            // 親商品形態コードチェック
            if (!CsvCheker.isParentCommodityPrefix(csvRowData[cellPos], rowPos, cellPos, mqy57apcsc, stErr)) {
                
                ret = false;
            }
        }
    }
    // --------------------
    //  2 商品形態コード
    // --------------------
    cellPos = 2;
    // 必須チェック
    if (!CsvCheker.required(csvRowData[cellPos], rowPos, cellPos, mqy57acsc, stErr)) {
        ret = false;
    } else {
        // 挿入、更新の場合
        if (ope == "I" || ope == "U") {
            // 半角英数字チェック
            if (!CsvCheker.isAlphanumeric(csvRowData[cellPos], rowPos, cellPos, mqy57acsc, stErr)) {
                ret = false;
            }
            // 文字数チェック
            if (!CsvCheker.maxLength(csvRowData[cellPos], 16, rowPos, cellPos, mqy57acsc, stErr)) {
                ret = false;
            }
            // 商品形態コードチェック
            if (!CsvCheker.isCommodityPrefix(csvRowData[cellPos], rowPos, cellPos, mqy57acsc, stErr)) {
                ret = false;
            }
        }
    }
    // --------------------
    //  3 素材コード
    // --------------------
    cellPos = 3;
    // 必須チェック
    if (!CsvCheker.required(csvRowData[cellPos], rowPos, cellPos, mqy57amtc, stErr)) {
        ret = false;
    } else {
        // 挿入、更新の場合
        if (ope == "I" || ope == "U") {
            // 半角英数字チェック
            if (!CsvCheker.isAlphanumeric(csvRowData[cellPos], rowPos, cellPos, mqy57amtc, stErr)) {
                ret = false;
            }
            // 文字数チェック
            if (!CsvCheker.maxLength(csvRowData[cellPos], 16, rowPos, cellPos, mqy57amtc, stErr)) {
                ret = false;
            }
            // 素材コードチェック
            if (!CsvCheker.isMaterialPrefix(csvRowData[cellPos], rowPos, cellPos, mqy57amtc, stErr)) {
                ret = false;
            }
        }
    }
    // --------------------
    //  4 加工部位コード
    // --------------------
    cellPos = 4;
    // 必須チェック
    if (!CsvCheker.required(csvRowData[cellPos], rowPos, cellPos, mqy57appc1, stErr)) {
        ret = false;
    } else {
        // 挿入、更新の場合
        if (ope == "I" || ope == "U") {
            // 半角英数字チェック
            if (!CsvCheker.isAlphanumeric(csvRowData[cellPos], rowPos, cellPos, mqy57appc1, stErr)) {
                ret = false;
            }
            // 文字数チェック
            if (!CsvCheker.maxLength(csvRowData[cellPos], 16, rowPos, cellPos, mqy57appc1, stErr)) {
                ret = false;
            }
            // 加工部位コードチェック
            if (!CsvCheker.isProcessPartPrefix(csvRowData[cellPos], rowPos, cellPos, mqy57appc1, stErr)) {
                ret = false;
            }
        }
    }
    // --------------------
    //  5 加工位置コード
    // --------------------
    cellPos = 5;
    // 必須チェック
    if (!CsvCheker.required(csvRowData[cellPos], rowPos, cellPos, mqy57appc2, stErr)) {
        ret = false;
    } else {
        // 挿入、更新の場合
        if (ope == "I" || ope == "U") {
            // 半角英数字チェック
            if (!CsvCheker.isAlphanumeric(csvRowData[cellPos], rowPos, cellPos, mqy57appc2, stErr)) {
                ret = false;
            }
            // 文字数チェック
            if (!CsvCheker.maxLength(csvRowData[cellPos], 16, rowPos, cellPos, mqy57appc2, stErr)) {
                ret = false;
            }
            // 加工位置コードチェック
            if (!CsvCheker.isProcessPositionPrefix(csvRowData[cellPos], rowPos, cellPos, mqy57appc2, stErr)) {
                ret = false;
            }
        }
    }
    // --------------------
    //  6 加工方法区分
    // --------------------
    cellPos = 6;
    // 必須チェック
    if (!CsvCheker.required(csvRowData[cellPos], rowPos, cellPos, mqy57apmt, stErr)) {
        ret = false;
    } else {
        // 挿入、更新の場合
        if (ope == "I" || ope == "U") {
            // 半角英数字チェック
            if (!CsvCheker.isAlphanumeric(csvRowData[cellPos], rowPos, cellPos, mqy57apmt, stErr)) {
                ret = false;
            }
        }
    }
    // --------------------
    //  7 加工方法明細区分
    // --------------------
    cellPos = 7;
    // 必須チェック
    if (!CsvCheker.required(csvRowData[cellPos], rowPos, cellPos, mqy57apmdt, stErr)) {
        ret = false;
    } else {
        // 挿入、更新の場合
        if (ope == "I" || ope == "U") {
            // 半角英数字チェック
            if (!CsvCheker.isAlphanumeric(csvRowData[cellPos], rowPos, cellPos, mqy57apmdt, stErr)) {
                ret = false;
            }
        }
    }
    // --------------------------
    //  8 加工方法明細第1階層コード
    // --------------------------
    cellPos = 8;
    // 必須チェック
    if (!CsvCheker.required(csvRowData[cellPos], rowPos, cellPos, mqy57apmd1, stErr)) {
        ret = false;
    } else {
        // 挿入、更新の場合
        if (ope == "I" || ope == "U") {
            // 半角英数字チェック
            if (!CsvCheker.isAlphanumeric(csvRowData[cellPos], rowPos, cellPos, mqy57apmd1, stErr)) {
                ret = false;
            }
            // 文字数チェック
            if (!CsvCheker.maxLength(csvRowData[cellPos], 8, rowPos, cellPos, mqy57apmd1, stErr)) {
                ret = false;
            }
        }
    }
    // --------------------------
    //  9 加工方法明細第2階層コード
    // --------------------------
    cellPos = 9;
    // 必須チェック
    if (!CsvCheker.required(csvRowData[cellPos], rowPos, cellPos, mqy57apmd2, stErr)) {
        ret = false;
    } else {
        // 挿入、更新の場合
        if (ope == "I" || ope == "U") {
            // 半角英数字チェック
            if (!CsvCheker.isAlphanumeric(csvRowData[cellPos], rowPos, cellPos, mqy57apmd2, stErr)) {
                ret = false;
            }
            // 文字数チェック
            if (!CsvCheker.maxLength(csvRowData[cellPos], 8, rowPos, cellPos, mqy57apmd2, stErr)) {
                ret = false;
            }
        }
    }
    // --------------------------
    //  10 加工方法明細第3階層コード
    // --------------------------
    cellPos = 10;
    // 必須チェック
    if (!CsvCheker.required(csvRowData[cellPos], rowPos, cellPos, mqy57apmd3, stErr)) {
        ret = false;
    } else {
        // 挿入、更新の場合
        if (ope == "I" || ope == "U") {
            // 半角英数字チェック
            if (!CsvCheker.isAlphanumeric(csvRowData[cellPos], rowPos, cellPos, mqy57apmd3, stErr)) {
                ret = false;
            }
            // 文字数チェック
            if (!CsvCheker.maxLength(csvRowData[cellPos], 8, rowPos, cellPos, mqy57apmd3, stErr)) {
                ret = false;
            }
        }
    }
    // --------------------------
    //  11 商品コード
    // --------------------------
    cellPos = 11;
    // 必須チェック
    if (!CsvCheker.required(csvRowData[cellPos], rowPos, cellPos, mqy57aitcd, stErr)) {
        ret = false;
    } else {
        // 挿入、更新の場合
        if (ope == "I" || ope == "U") {
            // 半角英数字チェック
            if (!CsvCheker.isAlphanumeric(csvRowData[cellPos], rowPos, cellPos, mqy57aitcd, stErr)) {
                ret = false;
            }
            // 文字数チェック
            if (!CsvCheker.maxLength(csvRowData[cellPos], 16, rowPos, cellPos, mqy57aitcd, stErr)) {
                ret = false;
            }
        }
    }
    // --------------------------
    //  12 サイズコード
    // --------------------------
    cellPos = 12;
    // 必須チェック
    if (!CsvCheker.required(csvRowData[cellPos], rowPos, cellPos, mqy57asc, stErr)) {
        ret = false;
    } else {
        // 挿入、更新の場合
        if (ope == "I" || ope == "U") {
            // 半角英数字チェック
            if (!CsvCheker.isAlphanumeric(csvRowData[cellPos], rowPos, cellPos, mqy57asc, stErr)) {
                ret = false;
            }
            // 文字数チェック
            if (!CsvCheker.maxLength(csvRowData[cellPos], 20, rowPos, cellPos, mqy57asc, stErr)) {
                ret = false;
            }
        }
    }
    // --------------------------
    //  13 非推奨区分
    // --------------------------
    cellPos = 13;
    // 必須チェック
    if (!CsvCheker.required(csvRowData[cellPos], rowPos, cellPos, mqy57anrt, stErr)) {
        ret = false;
    } else {
        // 挿入、更新の場合
        if (ope == "I" || ope == "U") {
            // 半角英数字チェック
            if (!CsvCheker.isAlphanumeric(csvRowData[cellPos], rowPos, cellPos, mqy57anrt, stErr)) {
                ret = false;
            }
        }
    }
    // --------------------
    //  14 適用開始日
    // --------------------
    cellPos = 14;
    // 必須チェック
    if (!CsvCheker.required(csvRowData[cellPos], rowPos, cellPos, mqeftj, stErr)) {
        ret = false;
    } else {
        // 挿入、更新の場合
        if (ope == "I" || ope == "U") {
            // 日付チェック
            if (!CsvCheker.isDate(csvRowData[cellPos], rowPos, cellPos, mqeftj, stErr)) {
                ret = false;
            }
        }
    }
    // --------------------
    //  15 削除フラグ
    // --------------------
    cellPos = 15;
    // 必須チェック
    if (!CsvCheker.required(csvRowData[cellPos], rowPos, cellPos, mqy57adflg, stErr)) {
        ret = false;
    } else {
        // 挿入の場合
        if (ope == "I") {
            // データチェック
            if (csvRowData[cellPos] != "0") {
                stErr.append(MessageManager.getMessage("TOMS.MASTER.MAINTENANCE.CSVUPLOAD.LIST.LABEL.MESSAGE.ERROR.DEL_FLAG", sRowPos));
                ret = false;
            }
        }
        // 挿入、更新の場合
        else if (ope == "U") {
            // データチェック
            if (csvRowData[cellPos] != "0" && csvRowData[cellPos] != "1") {
                stErr.append(MessageManager.getMessage("TOMS.MASTER.MAINTENANCE.CSVUPLOAD.LIST.LABEL.MESSAGE.ERROR.DEL_FLAG_FORMAT", sRowPos));
                ret = false;
            }
        }
    }
    
    return ret;
}

/*
 * DBによるデータ有無チェック
 * @param csvRowData csvの行データ.(IN)
 * @param rowPos 行番号.(IN)
 * @param stErr エラーメッセージパラメータ.(OUT)
 */
function dbCheck(csvRowData, rowPos, stErr) {
    var ret = true;
    var ope = csvRowData[0];
    var sRowPos = String(rowPos);
    var cellPos = null;
    var resultBodyNotRecommended = null;
    var checkResult = null;
    
    // ボディ非推奨管理マスタのキー検索（商品形態コード、親商品形態コード、素材コード、加工部位コード、加工位置コード、
    //                          加工方法区分、加工方法明細区分、加工方法明細第1階層コード、加工方法明細第2階層コード、
    //                          加工方法明細第3階層コード、商品コード、サイズコード、非推奨区分、適用開始日）
    var resultBodyNotRecommended = MasterMain.getBodyNotRecommendedByPk(csvRowData[1], csvRowData[2], csvRowData[3], csvRowData[4], csvRowData[5],
                                                                        csvRowData[6], csvRowData[7], csvRowData[8], csvRowData[9], csvRowData[10],
                                                                        csvRowData[11], csvRowData[12], csvRowData[13], csvRowData[14]);
    // 登録、更新
    if (ope == "I" || ope == "U") {
        // 加工方法区分のコードチェック
        cellPos = 6;
        checkResult = MasterMain.checkProcessMethodType(csvRowData[cellPos]);
        if (!checkResult) {
            stErr.append(MessageManager.getMessage("TOMS.MASTER.MAINTENANCE.CSVUPLOAD.LIST.LABEL.MESSAGE.ERROR.PROCESSMETHODTYPE.NOTINLINE", sRowPos, String(cellPos + 1)));
            ret = false;
        }
        
        // 加工方法明細区分のコードチェック
        cellPos = 7;
        checkResult = MasterMain.checkProcessMethodDetailType(csvRowData[cellPos]);
        if (!checkResult) {
            stErr.append(MessageManager.getMessage("TOMS.MASTER.MAINTENANCE.CSVUPLOAD.LIST.LABEL.MESSAGE.ERROR.PROCESSMETHODDETAILTYPE.NOTINLINE", sRowPos, String(cellPos + 1)));
            ret = false;
        }
        
        // 商品コードの存在チェック
        cellPos = 11;
        var resultBagSku = MasterMain.getBagSku("01" + csvRowData[cellPos], "");
        if (resultBagSku.countRow == 0) {
            // 存在しない場合
            stErr.append(MessageManager.getMessage("TOMS.MASTER.MAINTENANCE.BODY_NOT_RECOMMENDED.MESSAGE.ERROR.DATANOTEXIST.SKU_CODE", sRowPos, String(cellPos + 1), csvRowData[cellPos].trim()));
            ret = false;
        }
        
        // サイズコードの存在チェック
        cellPos = 12;
        var resultSize = MasterMain.getSize(csvRowData[cellPos], "");
        if (resultSize.countRow == 0) {
            // 存在しない場合
            stErr.append(MessageManager.getMessage("TOMS.MASTER.MAINTENANCE.BODY_NOT_RECOMMENDED.MESSAGE.ERROR.DATANOTEXIST.SIZE_CODE", sRowPos, String(cellPos + 1), csvRowData[cellPos].trim()));
            ret = false;
        }
        
        // 非推奨区分のコードチェック
        cellPos = 13;
        checkResult = MasterMain.checkNotRecommendedDivide(csvRowData[cellPos]);
        if (!checkResult) {
            stErr.append(MessageManager.getMessage("TOMS.MASTER.MAINTENANCE.BODY_NOT_RECOMMENDED.MESSAGE.ERROR.NOT_RECOMMENDED_DIVIDE.NOTINLINE", sRowPos, String(cellPos + 1)));
            ret = false;
        }
    }
    if (ret) {
        // 新規登録の場合
        if (ope == "I") {
            // ボディ非推奨管理マスタの存在チェック
            if (resultBodyNotRecommended.countRow > 0) {
                // 既に存在する場合
                stErr.append(MessageManager.getMessage("TOMS.MASTER.MAINTENANCE.BODY_NOT_RECOMMENDED.MESSAGE.ERROR.DATAEXIST", sRowPos, csvRowData[1].trim(), csvRowData[2].trim(), csvRowData[3].trim(), csvRowData[4].trim(), csvRowData[5].trim(), csvRowData[6].trim(), csvRowData[7].trim(), csvRowData[8].trim(), csvRowData[9].trim(), csvRowData[10].trim(), csvRowData[11].trim(), csvRowData[12].trim(), csvRowData[13].trim(), csvRowData[14]));
                ret = false;
            }
            // 加工方法明細マスタの存在チェック
            var resultPeocessDetail = MasterMain.selectF57A5141(csvRowData[1], csvRowData[2], csvRowData[3], csvRowData[4], csvRowData[5], csvRowData[6], csvRowData[7], csvRowData[8], csvRowData[9], csvRowData[10]);
            if (resultPeocessDetail.countRow == 0) {
                // 存在しない場合
                stErr.append(MessageManager.getMessage("TOMS.MASTER.MAINTENANCE.BODY_NOT_RECOMMENDED.MESSAGE.ERROR.DATANOTEXIST.PROCESS_METHOD_DETAIL", sRowPos, csvRowData[1].trim(), csvRowData[2].trim(), csvRowData[3].trim(), csvRowData[4].trim(), csvRowData[5].trim(), csvRowData[6].trim(), csvRowData[7].trim(), csvRowData[8].trim(), csvRowData[9].trim(), csvRowData[10].trim()));
                ret = false;
            }
        }
        // 更新、削除の場合
        else if ((ope == "U") || (ope == "D")) {
            // 存在チェック
            if (resultBodyNotRecommended.countRow < 1) {
                stErr.append(MessageManager.getMessage("TOMS.MASTER.MAINTENANCE.BODY_NOT_RECOMMENDED.MESSAGE.ERROR.DATANOTEXIST", sRowPos, csvRowData[1].trim(), csvRowData[2].trim(), csvRowData[3].trim(), csvRowData[4].trim(), csvRowData[5].trim(), csvRowData[6].trim(), csvRowData[7].trim(), csvRowData[8].trim(), csvRowData[9].trim(), csvRowData[10].trim(), csvRowData[11].trim(), csvRowData[12].trim(), csvRowData[13].trim(), csvRowData[14]));
                ret = false;
            }
            // 複数存在チェック
            if (resultBodyNotRecommended.countRow > 1) {
                stErr.append(MessageManager.getMessage("TOMS.MASTER.MAINTENANCE.BODY_NOT_RECOMMENDED.MESSAGE.ERROR.DUPLICATE", sRowPos, csvRowData[1].trim(), csvRowData[2].trim(), csvRowData[3].trim(), csvRowData[4].trim(), csvRowData[5].trim(), csvRowData[6].trim(), csvRowData[7].trim(), csvRowData[8].trim(), csvRowData[9].trim(), csvRowData[10].trim(), csvRowData[11].trim(), csvRowData[12].trim(), csvRowData[13].trim(), csvRowData[14]));
                ret = false;
            }
        }
    }
    
    return ret;
}

/**
 * DB更新
 * 
 * @param csvRowData csvの行データ.(IN)
 * @param rowPos 行番号.(IN)
 * @param stErr エラーメッセージパラメータ.(OUT)
 * @param updateCount (OUT)
 */
function dbUpdate(csvRowData, rowPos, stErr, counts) {
    
    var ret = true;
    var newCount = counts.newCount;
    var updateCount = counts.updateCount;
    var deleteCount = counts.deleteCount;
    
    var ope = csvRowData[0];
    var sRowPos = String(rowPos);
    var result;
    
    // CSVの行データからDB更新用データ作成
    var entity = createEntity(csvRowData);
    var condition = " TRIM(MQY57APCSC) = ? "
                  + " AND TRIM(MQY57ACSC) = ? "
                  + " AND TRIM(MQY57AMTC) = ? "
                  + " AND TRIM(MQY57APPC1) = ? "
                  + " AND TRIM(MQY57APPC2) = ? "
                  + " AND TRIM(MQY57APMT) = ? "
                  + " AND TRIM(MQY57APMDT) = ? "
                  + " AND TRIM(MQY57APMD1) = ? "
                  + " AND TRIM(MQY57APMD2) = ? "
                  + " AND TRIM(MQY57APMD3) = ? "
                  + " AND TRIM(MQY57AITCD) = ? "
                  + " AND TRIM(MQY57ASC) = ? "
                  + " AND TRIM(MQY57ANRT) = ? "
                  + " AND MQEFTJ = ? ";
    
    var params = [
            DbParameter.string(entity["mqy57apcsc"]),
            DbParameter.string(entity["mqy57acsc"]),
            DbParameter.string(entity["mqy57amtc"]),
            DbParameter.string(entity["mqy57appc1"]),
            DbParameter.string(entity["mqy57appc2"]),
            DbParameter.string(entity["mqy57apmt"]),
            DbParameter.string(entity["mqy57apmdt"]),
            DbParameter.string(entity["mqy57apmd1"]),
            DbParameter.string(entity["mqy57apmd2"]),
            DbParameter.string(entity["mqy57apmd3"]),
            DbParameter.string(entity["mqy57aitcd"]),
            DbParameter.string(entity["mqy57asc"]),
            DbParameter.string(entity["mqy57anrt"]),
            DbParameter.number(entity["mqeftj"])
    ];
    
    Transaction.begin();
    var masterTable = 'F57A5170'
    if (ope == "I") {           //挿入
        result = MasterMain.insertToMasterTable(masterTable, entity);
        newCount++;
    } else if (ope == "U") {     //更新
        result = MasterMain.updateToMasterTable(masterTable, entity, condition, params);
        updateCount++;
    } else if  (ope == "D") {    //削除
        result = MasterMain.removeFromMasterTable(masterTable, condition, params);
        deleteCount++;
    }
    if (!result.error && result.countRow != 1) {
        Transaction.rollback();
        stErr.append(MessageManager.getMessage("TOMS.MASTER.MAINTENANCE.CSVUPLOAD.LIST.LABEL.MESSAGE.ERROR.ABNORMAL", sRowPos));
        return false;
    }
    if (result.error) {
        Transaction.rollback();
        stErr.append(MessageManager.getMessage("TOMS.MASTER.MAINTENANCE.CSVUPLOAD.LIST.LABEL.MESSAGE.ERROR.DB"));
        stErr.append(MessageManager.getMessage("TOMS.MASTER.MAINTENANCE.CSVUPLOAD.LIST.LABEL.MESSAGE.CSVLINE", sRowPos));
        return false;
    }
    Transaction.commit();
    
    counts.newCount = newCount;
    counts.updateCount = updateCount;
    counts.deleteCount = deleteCount;
    
    return true;
}

/**
 * DB更新用データ作成
 * 
 * @param csvRowData csvの行データ.
 */
function createEntity(csvRowData) {
    
    var userContext = Contexts.getUserContext();
    var now = new Date();
    
    // 変数初期化
    var mqy57apcsc = null; // 親商品形態コード
    var mqy57acsc = null;  // 商品形態コード
    var mqy57amtc = null;  // 素材コード
    var mqy57appc1 = null; // 加工部位コード
    var mqy57appc2 = null; // 加工位置コード
    var mqy57apmt = null;  // 加工方法区分
    var mqy57apmdt = null; // 加工方法明細区分
    var mqy57apmd1 = null; // 加工方法明細第1階層コード
    var mqy57apmd2 = null; // 加工方法明細第2階層コード
    var mqy57apmd3 = null; // 加工方法明細第3階層コード
    var mqy57aitcd = null; // 商品コード
    var mqy57asc = null;   // サイズコード
    var mqy57anrt = null;  // 非推奨区分
    var mqeftj = null;     // 適用開始日
    var mqexdj = cmnUtil.convertDateToJulia(new Date(MessageManager.getMessage("TOMS.COMMON.CONSTANT.ENDDATE"))); // 適用終了日
    var mqy57adflg = null; // 削除フラグ
    
    var mquser = userContext.userProfile.userCd;  // ユーザID
    var mqpid = MessageManager.getMessage("TOMS.COMMON.CONSTANT.PROGRAM.ID"); // プログラムID
    var mqupmj = cmnUtil.convertDateToJulia(now); // 更新日付
    var mqupmt = cmnUtil.getTime(now);            // 更新時刻
    
    // 親商品形態コード
    if (!isBlank(cmnUtil.getData(csvRowData[1], 0))) {
        mqy57apcsc = cmnUtil.getData(csvRowData[1], 0);
    }
    // 商品形態コード
    if (!isBlank(cmnUtil.getData(csvRowData[2], 0))) {
        mqy57acsc = cmnUtil.getData(csvRowData[2], 0);
    }
    // 素材コード
    if (!isBlank(cmnUtil.getData(csvRowData[3], 0))) {
        mqy57amtc = cmnUtil.getData(csvRowData[3], 0);
    }
    // 加工部位コード
    if (!isBlank(cmnUtil.getData(csvRowData[4], 0))) {
        mqy57appc1 = cmnUtil.getData(csvRowData[4], 0);
    }
    // 加工位置コード
    if (!isBlank(cmnUtil.getData(csvRowData[5], 0))) {
        mqy57appc2 = cmnUtil.getData(csvRowData[5], 0);
    }
    // 加工方法区分
    if (!isBlank(cmnUtil.getData(csvRowData[6], 0))) {
        mqy57apmt = cmnUtil.getData(csvRowData[6], 0);
    }
    // 加工方法明細区分
    if (!isBlank(cmnUtil.getData(csvRowData[7], 0))) {
        mqy57apmdt = cmnUtil.getData(csvRowData[7], 0);
    }
    // 加工方法明細第1階層コード
    if (!isBlank(cmnUtil.getData(csvRowData[8], 0))) {
        mqy57apmd1 = cmnUtil.getData(csvRowData[8], 0);
    }
    // 加工方法明細第2階層コード
    if (!isBlank(cmnUtil.getData(csvRowData[9], 0))) {
        mqy57apmd2 = cmnUtil.getData(csvRowData[9], 0);
    }
    // 加工方法明細第3階層コード
    if (!isBlank(cmnUtil.getData(csvRowData[10], 0))) {
        mqy57apmd3 = cmnUtil.getData(csvRowData[10], 0);
    }
    // 商品コード
    if (!isBlank(cmnUtil.getData(csvRowData[11], 0))) {
        mqy57aitcd = cmnUtil.getData(csvRowData[11], 0);
    }
    // サイズコード
    if (!isBlank(cmnUtil.getData(csvRowData[12], 0))) {
        mqy57asc = cmnUtil.getData(csvRowData[12], 0);
    }
    // 非推奨区分
    if (!isBlank(cmnUtil.getData(csvRowData[13], 0))) {
        mqy57anrt = cmnUtil.getData(csvRowData[13], 0);
    }
    // 適用開始日
    if (!isBlank(csvRowData[14])) {
        mqeftj = cmnUtil.convertDateToJulia(new Date(csvRowData[14]));
    }
    // 削除フラグ
    if (!isBlank(cmnUtil.getData(csvRowData[15], 1))) {
        mqy57adflg = cmnUtil.getData(csvRowData[15], 1);
    }
    
    var entity = {
        mqy57apcsc : mqy57apcsc,
        mqy57acsc : mqy57acsc,
        mqy57amtc : mqy57amtc,
        mqy57appc1 : mqy57appc1,
        mqy57appc2 : mqy57appc2,
        mqy57apmt : mqy57apmt,
        mqy57apmdt : mqy57apmdt,
        mqy57apmd1 : mqy57apmd1,
        mqy57apmd2 : mqy57apmd2,
        mqy57apmd3 : mqy57apmd3,
        mqy57aitcd : mqy57aitcd,
        mqy57asc : mqy57asc,
        mqy57anrt : mqy57anrt,
        mqeftj : mqeftj,
        mqexdj : mqexdj,
        mqy57adflg : mqy57adflg,
        mquser : mquser,
        mqpid : mqpid,
        mqupmj : mqupmj,
        mqupmt : mqupmt
    };
    
    return entity;
}

/**
 * エラー処理
 * 
 * @param response　レスポンス
 * @param stErr エラーメッセージパラメータ.
 */
function doError(response, stErr) {
        stErr.insert(0, MessageManager.getMessage("TOMS.MASTER.MAINTENANCE.CSVUPLOAD.LIST.LABEL.ENTRY.ERROR"));
        var stringErr = stErr.toString();
        response.sendMessageBodyString(ImJson.toJSONString([{
            "errorMessage": stringErr,
            "successMessage": ""
        }]));
}
