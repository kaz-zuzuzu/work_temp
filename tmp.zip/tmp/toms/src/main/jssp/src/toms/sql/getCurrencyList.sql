select
 a.value,
 a.value as label
from (
select
 NULL as value,
 NULL as label
from
 dual
union
 select
 CVCRCD as value,
 '(' || CVCRCD || '):' || trim(CVDL01) as label
from
 F0013
) a
order by
 a.value ASC NULLS FIRST