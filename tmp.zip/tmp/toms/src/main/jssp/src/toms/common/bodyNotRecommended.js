/**
 * staticオブジェクトの作成 
 */ 
load('toms/common/cmnUtil');
var _SHARED_DB_KEY ="toms-web-dev";
function BodyNotRecommended(){};

/**
 * ボディ非推奨管理マスタメンテナンスの一覧データ取得処理
 */
BodyNotRecommended.getBodyNotRecommendedList = function(params, countFlag ,paramStart, paramEnd ) {

    var db = new SharedDatabase(_SHARED_DB_KEY);
    // 検索条件設定
    var mqy57apcsc = isBlank(params.mqy57apcsc) ? null : DbParameter.string(params.mqy57apcsc);                                          // 親商品形態コード
    var mqy57apcscName = isBlank(params.mqy57apcscName) ? null : DbParameter.string("%" + params.mqy57apcscName + "%");                  // 親商品形態名称
    var mqy57acsc = isBlank(params.mqy57acsc) ? null : DbParameter.string(params.mqy57acsc);                                             // 商品形態コード
    var mqy57acscName = isBlank(params.mqy57acscName) ? null : DbParameter.string("%" + params.mqy57acscName + "%");                     // 商品形態名称
    var mqy57amtc = isBlank(params.mqy57amtc) ? null : DbParameter.string(params.mqy57amtc);                                             // 素材コード
    var mldl01 = isBlank(params.mldl01) ? null : DbParameter.string("%" + params.mldl01 + "%");                                          // 原材料名称
    var mqy57appc1 = isBlank(params.mqy57appc1) ? null : DbParameter.string(params.mqy57appc1);                                          // 加工部位コード
    var mkdl01 = isBlank(params.mkdl01) ? null : DbParameter.string("%" + params.mkdl01 + "%");                                          // 加工部位名称
    var mqy57appc2 = isBlank(params.mqy57appc2) ? null : DbParameter.string(params.mqy57appc2);                                          // 加工位置コード
    var mkdl02 = isBlank(params.mkdl02) ? null : DbParameter.string("%" + params.mkdl02 + "%");                                          // 加工位置名称
    // 加工方法区分
    var mqy57apmt = null;
    if (!isBlank(params.mqy57apmt)) {
        var aryData = params.mqy57apmt.split(',');
        mqy57apmt = [];
        for (var i = 0; i < aryData.length; i++) {
            mqy57apmt.push(DbParameter.string(aryData[i]));
        }
    }
    // 加工方法明細区分
    var mqy57apmdt = null;
    if (!isBlank(params.mqy57apmdt)) {
        var aryData = params.mqy57apmdt.split(',');
        mqy57apmdt = [];
        for (var i = 0; i < aryData.length; i++) {
            mqy57apmdt.push(DbParameter.string(aryData[i]));
        }
    }
    var mqy57apmd1 = isBlank(params.mqy57apmd1) ? null : DbParameter.string(params.mqy57apmd1);                                          // 加工方法明細第1階層コード
    var mny57apmn1 = isBlank(params.mny57apmn1) ? null : DbParameter.string("%" + params.mny57apmn1 + "%");                              // 加工方法明細第1階層名称
    var mqy57apmd2 = isBlank(params.mqy57apmd2) ? null : DbParameter.string(params.mqy57apmd2);                                          // 加工方法明細第2階層コード
    var mny57apmn2 = isBlank(params.mny57apmn2) ? null : DbParameter.string("%" + params.mny57apmn2 + "%");                              // 加工方法明細第2階層名称
    var mqy57apmd3 = isBlank(params.mqy57apmd3) ? null : DbParameter.string(params.mqy57apmd3);                                          // 加工方法明細第3階層コード
    var mny57apmn3 = isBlank(params.mny57apmn3) ? null : DbParameter.string("%" + params.mny57apmn3 + "%");                              // 加工方法明細第3階層名称
    var mqy57aitcd = isBlank(params.mqy57aitcd) ? null : DbParameter.string(params.mqy57aitcd);                                          // 商品コード
    var mqy57aitcdName = isBlank(params.mqy57aitcdName) ? null : DbParameter.string("%" + params.mqy57aitcdName + "%");                  // 商品名称
    var mqy57asc = isBlank(params.mqy57asc) ? null : DbParameter.string(params.mqy57asc);                                                // サイズコード
    var mqy57ascName = isBlank(params.mqy57ascName) ? null : DbParameter.string("%" + params.mqy57ascName + "%");                        // サイズ名称
    var mqy57anrt = isBlank(params.mqy57anrt) ? null : DbParameter.string(params.mqy57anrt);                                             // 非推奨区分
    var mqy57adflg = isBlank(params.mqy57adflg) ? null : DbParameter.number(Number(params.mqy57adflg));                                  // 削除フラグ
    var mqeftj_from = isBlank(params.mqeftj_from) ? null : DbParameter.number(cmnUtil.convertDateToJulia(new Date(params.mqeftj_from))); // 適用開始日From
    var mqeftj_to = isBlank(params.mqeftj_to) ? null : DbParameter.number(cmnUtil.convertDateToJulia(new Date(params.mqeftj_to)));       // 適用開始日To
    
    var result;
    if (countFlag) {
        var objParam = {
            mqy57apcsc : mqy57apcsc,
            mqy57apcscName : mqy57apcscName,
            mqy57acsc : mqy57acsc,
            mqy57acscName : mqy57acscName,
            mqy57amtc : mqy57amtc,
            mldl01 : mldl01,
            mqy57appc1 : mqy57appc1,
            mkdl01 : mkdl01,
            mqy57appc2 : mqy57appc2,
            mkdl02 : mkdl02,
            mqy57apmt : mqy57apmt,
            mqy57apmdt : mqy57apmdt,
            mqy57apmd1 : mqy57apmd1,
            mny57apmn1 : mny57apmn1,
            mqy57apmd2 : mqy57apmd2,
            mny57apmn2 : mny57apmn2,
            mqy57apmd3 : mqy57apmd3,
            mny57apmn3 : mny57apmn3,
            mqy57aitcd : mqy57aitcd,
            mqy57aitcdName : mqy57aitcdName,
            mqy57asc : mqy57asc,
            mqy57ascName : mqy57ascName,
            mqy57anrt : mqy57anrt,
            mqy57adflg : mqy57adflg,
            mqeftj_from : mqeftj_from,
            mqeftj_to : mqeftj_to
        };
        
        result = db.executeByTemplate('toms/sql/getBodyNotRecommendedListCount', objParam);
    } else {
        var start = isBlank(paramStart) ? null : DbParameter.number(paramStart);
        var end =  isBlank(paramEnd) ? null : DbParameter.number(paramEnd);
        var objParam = {
            mqy57apcsc : mqy57apcsc,
            mqy57apcscName : mqy57apcscName,
            mqy57acsc : mqy57acsc,
            mqy57acscName : mqy57acscName,
            mqy57amtc : mqy57amtc,
            mldl01 : mldl01,
            mqy57appc1 : mqy57appc1,
            mkdl01 : mkdl01,
            mqy57appc2 : mqy57appc2,
            mkdl02 : mkdl02,
            mqy57apmt : mqy57apmt,
            mqy57apmdt : mqy57apmdt,
            mqy57apmd1 : mqy57apmd1,
            mny57apmn1 : mny57apmn1,
            mqy57apmd2 : mqy57apmd2,
            mny57apmn2 : mny57apmn2,
            mqy57apmd3 : mqy57apmd3,
            mny57apmn3 : mny57apmn3,
            mqy57aitcd : mqy57aitcd,
            mqy57aitcdName : mqy57aitcdName,
            mqy57asc : mqy57asc,
            mqy57ascName : mqy57ascName,
            mqy57anrt : mqy57anrt,
            mqy57adflg : mqy57adflg,
            mqeftj_from : mqeftj_from,
            mqeftj_to : mqeftj_to,
            start : start,
            end : end
        };
        result = db.executeByTemplate('toms/sql/getBodyNotRecommendedList', objParam);
    }
    return result;
}
