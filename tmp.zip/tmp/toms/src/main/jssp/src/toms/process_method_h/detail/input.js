/**
 * 加工部位マスタメンテナンス登録・更新画面
 *
 * src /src/toms/process_part/detail/input.js
 * 
 **/
var $bind ={};


function init(request){

	$bind.flag ="0"; //新規、更新フラグ　新規：0　更新：1
	$bind.disabled = "false";
	if(!isBlank(request.updateFlag)){
		$bind.flag = request.updateFlag;
	}
	$bind.inputFlg = "false";
	var endDate=MessageManager.getMessage('TOMS.COMMON.CONSTANT.ENDDATE');

	var processMethodData = MessageManager.getMessage('TOMS.MASTER.MAINTENANCE.PROCESS_METHOD_DATA')
	var splitData = processMethodData.split(',');
	var processMethodList =[]; 
	for(var i=0; i<splitData.length;i++){
		var selectFlg = "false";
		var data = splitData[i].split(':');
		if(!isBlank(request.mmy57apmt)){
			if(request.mmy57apmt==data[0]){
				selectFlg = "true";
			}
		}
		var listObj = {
		               label:data[1],
		               value:data[0],
		               selected : selectFlg
		};
		processMethodList.push(listObj);
	}
	$bind.processMethodList = processMethodList;	
	//加工方法明細区分
	var processMethodDetailTypeList = [{label:"顔料・染料", value:"0"},{label:"ワンポイント", value:"1"}];
	if(!isBlank(request.mmy57apmdt) && request.mmy57apmdt =="1"){
		processMethodDetailTypeList = [{label:"顔料・染料", value:"0"},{label:"ワンポイント", value:"1", selected :"true"}];
	}
	$bind.processMethodDetailTypeList  = processMethodDetailTypeList;

	if($bind.flag=="1"){
		$bind.inputFlg ="true";
		//画面タイトル
		$bind.title = MessageManager.getMessage('TOMS.MASTER.MAINTENANCE.PROCESSMETHOD_HEADER.DETAIL.INPUT.UPDATE.TITLE');
		//更新時、前画面から設定値を受け取る
        
		$bind.mmy57apmc = request.mmy57apmc;//加工方法コード
		$bind.mmy57apcsc = request.mmy57apcsc;//親商品形態コード
		$bind.mmy57acsc = request.mmy57acsc;//商品形態コード
		$bind.mmy57amtc = request.mmy57amtc;//素材コード 
		$bind.mmy57appc1 = request.mmy57appc1;//加工方法部位コード
		$bind.mmy57appc2 = request.mmy57appc2;//加工方法位置コード
		$bind.mmy57ada = request.mmy57ada;//階層数
		$bind.mmy57asrt = request.mmy57asrt;//特記事項区分
		$bind.mmy57apmt = request.mmy57apmt;//加工方法区分
		$bind.mmy57apmdt = request.mmy57apmdt;//加工方法明細区分
		$bind.mmdl01 = request.mmdl01;//加工方法名称
		$bind.mmy57adflg = request.mmy57adflg;//削除フラグ
		$bind.mmeftj = request.mmeftj;//適用開始日
		$bind.disabled= "true";
	}else{
		//新規登録時
		$bind.title = MessageManager.getMessage('TOMS.MASTER.MAINTENANCE.PROCESSMETHOD_HEADER.DETAIL.INPUT.ENTRY.TITLE');
	}

	$bind.mmexdj = endDate;//適用終了日


    $bind.dialogMessages = ({
        entryTitle: MessageManager.getMessage('TOMS.COMMON.ENTRY'),
        entryMessage: MessageManager.getMessage('TOMS.MASTER.MAINTENANCE.PROCESSMETHOD_HEADER.DETAIL.INPUT.ENTRY.MESSAGE'),
        updateTitle: MessageManager.getMessage('TOMS.COMMON.UPDATE'),
        updateMessage: MessageManager.getMessage('TOMS.MASTER.MAINTENANCE.PROCESSMETHOD_HEADER.DETAIL.INPUT.UPDATE.MESSAGE'),
        deleteTitle: MessageManager.getMessage('TOMS.COMMON.DELETE'),
        deleteMessage: MessageManager.getMessage('TOMS.MASTER.MAINTENANCE.PROCESSMETHOD_HEADER.DETAIL.INPUT.DELETE.MESSAGE')
      }).toSource();

}