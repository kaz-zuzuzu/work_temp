/**
 * バインド変数.
 */
var $bind = {};

/**
 * 初期表示
 * @param request リクエストパラメータ
 */
function init(request) {
	load("toms/common/master");
	
	$bind.flag = request.updateFlag;
	$bind.searchMalitm = request.searchMalitm;
	$bind.searchMaan8 = request.searchMaan8;
	$bind.searchMacpgp = request.searchMacpgp;
	$bind.searchMaeftj = request.searchMaeftj;
	//更新時
	if ($bind.flag == "1") {
        $bind.maitm = request.maitm;
        $bind.malitm = request.malitm;
        //$bind.mamcu = request.mamcu;
        //$bind.malocn = request.malocn;
        //$bind.malotn = request.malotn;
        $bind.maan8 = request.maan8;
        $bind.macpgp = request.macpgp;
        //$bind.maprgr = request.maprgr;
        $bind.mauorg = request.mauorg;
        $bind.macrcd = request.macrcd;
        //$bind.mauom = request.mauom;
        $bind.maeftj = request.maeftj;
        $bind.mauprc = request.mauprc;
        $bind.titleMsg =MessageManager.getMessage('TOMS.MASTER.MAINTENANCE.SALES.DETAIL.INPUT.UPDATE.TITLE');
        $bind.update_maeftj =MessageManager.getMessage('TOMS.MASTER.MAINTENANCE.SALES.UPDATE.DATE.DEFAULT');

        /*
        $bind.maev01 = request.maev01;
        $bind.maev02 = request.maev02;
        $bind.maev03 = request.maev03;
        $bind.may57adt1 = request.may57adt1;
        $bind.may57adt2 = request.may57adt2;
        $bind.may57adt3 = request.may57adt3;
        $bind.may57aura1 = request.may57aura1;
        $bind.may57aura2 = request.may57aura2;
        $bind.may57aura3 = request.may57aura3;
        $bind.may57aamt1 = request.may57aamt1;
        $bind.may57aamt2 = request.may57aamt2;
        $bind.may57aamt3 = request.may57aamt3;
        $bind.may57adl01 = request.may57adl01;
        $bind.may57adl02 = request.may57adl02;
        $bind.may57adl03 = request.may57adl03;
        */
	} else {
		//新規登録時
		$bind.mauorg = MessageManager.getMessage('TOMS.COMMON.CONSTANT.THRESHOLD.DEFAULT');
		$bind.macrcd = MessageManager.getMessage('TOMS.COMMON.CONSTANT.CURRENCY.CODE.DEFAULT');
		$bind.mauom = 'PC';
        $bind.titleMsg =MessageManager.getMessage('TOMS.MASTER.MAINTENANCE.SALES.DETAIL.INPUT.ENTRY.TITLE');
        $bind.update_maeftj ="";
	}
	
  // 登録、更新、削除ボタン押下時の確認ダイアログのメッセージを初期化.
  // JavaScriptで利用するためオブジェクトの内容をそのまま渡します.
  $bind.dialogMessages = ({
	entryTitle: MessageManager.getMessage('TOMS.MASTER.MAINTENANCE.SALES.DETAIL.INPUT.ENTRY.MESSAGE.TITLE'),
    entryMessage: MessageManager.getMessage('TOMS.MASTER.MAINTENANCE.SALES.DETAIL.INPUT.ENTRY.MESSAGE'),
	updateTitle: MessageManager.getMessage('TOMS.MASTER.MAINTENANCE.SALES.DETAIL.INPUT.UPDATE.MESSAGE.TITLE'),
    updateMessage: MessageManager.getMessage('TOMS.MASTER.MAINTENANCE.SALES.DETAIL.INPUT.UPDATE.MESSAGE'),
    deleteTitle: MessageManager.getMessage('TOMS.MASTER.MAINTENANCE.SALES.DETAIL.INPUT.DELETE.MESSAGE.TITLE'),
    deleteMessage: MessageManager.getMessage('TOMS.MASTER.MAINTENANCE.SALES.DETAIL.INPUT.DELETE.MESSAGE')
  }).toSource();
}


