/**
 * バインド変数.
 */
var $bind = {};

load('toms/common/common');

// 区切り文字（カンマ）
var splitComma = MessageManager.getMessage('TOMS.COMMON.COMMA');

/**
 * 初期表示.
 * @param request リクエストパラメータ.
 */
function init(request) {
	load("toms/common/master");

    var stockPositionCode = "";
    var storePositionCode = "";
    var stockCategory = "";
    var skuCode = "";
    var skuDeskription1 = "";
    var skuDescription2 = "";
    var skuCatString = "";
    if (request.screenId == "outputCSV") {
        // 検索条件を取得
        stockPositionCode = request.csv_stockPositionCode;
        storePositionCode = request.csv_storePositionCode;
        stockCategory = request.csv_stockCategory;
        skuCode = request.csv_skuCode;
        skuCatString = request.csv_skuCatString;
    } else { 
        stockPositionCode = request.stockPositionCode;
        storePositionCode = request.storePositionCode;
        stockCategory = request.stockCategory;
        skuCode = request.skuCode;
        skuDeskription1 = request.skuDescription1;
        skuDescription2 = request.skuDescription2;
        // 検索画面から受け取ったデータをhtmlへ反映
        $bind.stockPositionName = request.stockPositionName;
        $bind.storePositionName = request.storePositionName;
        $bind.stockCategoryName = request.stockCategoryName;
        $bind.stockPositionCode = stockPositionCode;
        $bind.storePositionCode = storePositionCode;
        $bind.stockCategory = stockCategory;
        $bind.manufacturerProduct = request.manufacturerProduct;
        $bind.manufacturerFlag = request.manufacturerFlag;
        $bind.productCodes = request.productCodes;
        $bind.addtionNo = request.addtionNo;
        $bind.skuCode = skuCode;
        $bind.skuDeskription1 = skuDeskription1;
        $bind.skuDeskription2 = skuDescription2;
        $bind.skuCatString = skuDeskription1 + "  " + skuDescription2 + "（" + skuCode + "）";

        // CSV出力ボタン押下時の確認ダイアログのメッセージを初期化.
        // JavaScriptで利用するためオブジェクトの内容をそのまま渡します.
        $bind.dialogMessages = ({
            addConfirmTitle: MessageManager.getMessage('TOMS.COMMON.DIALOG.CONFIRM.TITLE'),
            addConfirmMessage: MessageManager.getMessage('TOMS.COMMON.DIALOG.CONFIRM.MESSAGE.COMMA')
        }).toSource();
    }

    if (stockPositionCode == "1000" && stockCategory == "") {
        if (request.screenId == "outputCSV") {
            // キープ一覧のCSV出力処理
            outputCSVBySku(skuCode, skuCatString);
        } else {
            // キープ一覧の画面出力処理
            getKeepListBySku(skuCode);
        }
    } else {
        // 在庫場所が1000以外の場合はキープ一覧は空白表示
        $bind.keepList = [];
    }
}

/**
 * キープ一覧の情報を取得する処理
 * 
 * @param skuCode 品目No.
 */
function getKeepListBySku(skuCode) {
    var result = TomsMaster.getKeepListBySku(skuCode);
    if (!result.error) {
        $bind.keepList = result.data;
    } else {
        error(result.errorMessage);
    }
}

/**
 * キープ一覧のCSV出力処理
 * 
 * @param skuCode 品目No.
 */
function outputCSVBySku(skuCode, skuCatString) {
    var result = TomsMaster.getKeepListBySku(skuCode);
    var outputContent = "";
    if (!result.error) {
    	//対象品番
    	outputContent = skuCatString + ",,,,,,,,,,,,,," + "\n";
    	//ヘッダー
        outputContent += outputCSVHeaderBySku();
        //明細
        for (var i = 0; i < result.countRow; i++) {
            outputContent += outputCSVRowBySku(result.data[i]);
        }
        var strDateTime = DateTimeFormatter.format("yyyyMMddHHmmss", new Date());
        //ファイル名「キープ一覧_品目No_日付時間」        
        var fileName = MessageManager.getMessage("TOMS.STOCK.KEEP.LABEL.CSV.FILE.NAME") + "（" + skuCode + "）_" + strDateTime + ".csv";
        Module.download.send(Unicode.to(outputContent, "MS932"), fileName, MessageManager.getMessage("TOMS.COMMON.MIME.CSV"));
    } else {
        errorCSV(result.errorMessage);
    }
}

/**
 * キープ一覧のCSVヘッダ部分出力処理。
 */
function outputCSVHeaderBySku() {
    var outputHeader = common.convertWithSplit(MessageManager.getMessage("TOMS.STOCK.KEEP.LABEL.LIST.KEEP.TARGET"), splitComma, true)
                       + common.convertWithSplit(MessageManager.getMessage("TOMS.STOCK.KEEP.LABEL.LIST.PURCHASE.RESERVE.DATE"), splitComma, true)
                       + common.convertWithSplit(MessageManager.getMessage("TOMS.STOCK.KEEP.LABEL.LIST.STOCK.COUNT"), splitComma, true)
                       + common.convertWithSplit(MessageManager.getMessage("TOMS.STOCK.KEEP.LABEL.LIST.KEEP.COUNT"), splitComma, true)
                       + common.convertWithSplit(MessageManager.getMessage("TOMS.STOCK.KEEP.LABEL.LIST.DELIVERY.DATE"), splitComma, true)
                       + common.convertWithSplit(MessageManager.getMessage("TOMS.STOCK.KEEP.LABEL.LIST.STATUS"), splitComma, true)
                       + common.convertWithSplit(MessageManager.getMessage("TOMS.STOCK.KEEP.LABEL.LIST.SALE.TARGET.NAME"), splitComma, true)
                       + common.convertWithSplit(MessageManager.getMessage("TOMS.STOCK.KEEP.LABEL.LIST.ORDER.NO"), splitComma, true)
                       + common.convertWithSplit(MessageManager.getMessage("TOMS.STOCK.KEEP.LABEL.LIST.ORDER.TYPE"), splitComma, true)
                       + common.convertWithSplit(MessageManager.getMessage("TOMS.STOCK.KEEP.LABEL.LIST.ORGANIZATION.NAME"), splitComma, true)
                       + common.convertWithSplit(MessageManager.getMessage("TOMS.STOCK.KEEP.LABEL.LIST.BUSINESS.CHARGE.PERSON.NAME"), splitComma, true)
                       + common.convertWithSplit(MessageManager.getMessage("TOMS.STOCK.KEEP.LABEL.LIST.ORDER.INPUT.PERSON.NAME"), splitComma, true)
                       + common.convertWithSplit(MessageManager.getMessage("TOMS.STOCK.KEEP.LABEL.LIST.BLAND.NAME"), splitComma, true)
                       + common.convertWithSplit(MessageManager.getMessage("TOMS.STOCK.KEEP.LABEL.LIST.ORDER.MEMO"), splitComma, true)
                       + common.convertWithSplit(MessageManager.getMessage("TOMS.STOCK.KEEP.LABEL.LIST.SEND.DEVERSE.STATUS.NAME"), splitComma, false);
    return outputHeader;
}

/**
 * キープ一覧のCSVファイルの行を出力する処理
 * 
 * @param record DBから検索した行のデータ
 */
function outputCSVRowBySku(record) {
    var result = common.convertWithSplit(record["stk_div"], splitComma, true)
                 + common.convertWithSplit(record["stk_date"], splitComma, true)
                 + common.convertWithSplit(record["stk_qty"], splitComma, true)
                 + common.convertWithSplit(record["tcy57akrqt"], splitComma, true)
                 + common.convertWithSplit(record["tcpddj"], splitComma, true)
                 + common.convertWithSplit(record["drdl01"], splitComma, true)
                 + common.convertWithSplit(record["abalph"], splitComma, true)
                 + common.convertWithSplit(record["tcdoco"], splitComma, true)
                 + common.convertWithSplit(record["tcdcto"], splitComma, true)
                 + common.convertWithSplit(record["mcdl01"], splitComma, true)
                 + common.convertWithSplit(record["wwalph"], splitComma, true)
                 + common.convertWithSplit(record["wwalph2"], splitComma, true)
                 + common.convertWithSplit(record["tay57ahrmk"], splitComma, true)
                 + common.convertWithSplit(record["tay57aormk"], splitComma, true)
                 + common.convertWithSplit(record["drdl02"], splitComma, false);
    return result;
}

/**
 * キープ一覧画面表示時のエラー画面へ遷移の処理.
 * 
 * @param message エラーメッセージ
 */
function error(message) {
  Transfer.toErrorPage({
    title: MessageManager.getMessage('TOMS.COMMON.ERROR.PAGE.TITLE'),
    message: MessageManager.getMessage('TOMS.COMMON.ERROR.MESSAGE.SYSTEM'),
    detail: [MessageManager.getMessage('TOMS.STOCK.KEEP.LABEL.MESSAGE.ERROR'), message],
    returnUrl: 'toms/stock/search/input', // 戻り先 URL
    returnUrlLabel: MessageManager.getMessage('TOMS.STOCK.SEARCH.LABEL.RETURN.LINK.NAME'),
    parameter: {
    }
  });
}

/**
 * キープ一覧CSV出力処理時のエラー画面へ遷移の処理.
 * 
 * @param message エラーメッセージ
 */
function errorCSV(message) {
  Transfer.toErrorPage({
    title: MessageManager.getMessage("TOMS.COMMON.ERROR.PAGE.TITLE"),
    message: MessageManager.getMessage("TOMS.COMMON.ERROR.MESSAGE.SYSTEM"),
    detail: [MessageManager.getMessage("TOMS.STOCK.KEEP.LABEL.MESSAGE.ERROR"), message],
    returnUrl: "toms/stock/detail/output", // 戻り先 URL
    returnUrlLabel: MessageManager.getMessage("TOMS.STOCK.SEARCH.LABEL.RETURN.LINK.NAME"),
    parameter: {
    }
  });
}