/**
 * 加工方法関連付けマスタメンテナンス検索画面(STEP2)用validation設定
 */

 var init ={
		 'search_mpdl01':{//加工方法名称
	 	caption:'TOMS.MASTER.MAINTENANCE.PROCESSMETHOD_HEADER.LABEL.PROCESS_METHOD_NAME',
	 	maxlength: 30
 		},
 
		 'search_mpy57apcsc':{//親商品形態コード
	 	caption:'TOMS.MASTER.MAINTENANCE.COMMODITYSHAPE.LABEL.PARENT_COMMODITY_SHAPE_CODE',
		alphanumeric: true,
	 	maxlength: 16
 		},
		 'search_mpy57apcscName':{//親商品形態名称
		 	caption:'TOMS.MASTER.MAINTENANCE.COMMODITYSHAPE.LABEL.PARENT_COMMODITY_SHAPE_NAME',
		 	maxlength: 30
 		},
		 'search_mpy57acsc':{//商品形態コード
		 	caption:'TOMS.MASTER.MAINTENANCE.COMMODITYSHAPE.LABEL.COMMODITY_SHAPE_CODE',
			alphanumeric: true,
		 	maxlength: 16
	 		},
		 'search_mpy57acscName':{//商品形態名称
		 	caption:'TOMS.MASTER.MAINTENANCE.COMMODITYSHAPE.LABEL.COMMODITY_SHAPE_NAME',
		 	maxlength: 30
 		},
 		'search_mpy57amtc':{//素材コード
	 	caption:'TOMS.MASTER.MAINTENANCE.MATERIAL.LABEL.MATERIAL_CODE',
	 	alphanumeric: true,
		maxlength: 16
 		},
 		'search_mpy57amtcName':{//原材料名
 		caption:'TOMS.MASTER.MAINTENANCE.MATERIAL.LABEL.MATERIAL_NAME',
		maxlength: 30
 		},

 		'search_mpy57appc1':{//加工部位コード
	 	caption:'TOMS.MASTER.MAINTENANCE.PROCESSPART.LABEL.PROCESSPART_CODE',
		 alphanumeric: true,
		 maxlength: 16
 		},
 		'search_mpy57appc1Name':{//加工部位名称
 		caption:'TOMS.MASTER.MAINTENANCE.PROCESSPART.LABEL.PROCESSPART_NAME',
		maxlength: 30
 		},


 		'search_mpy57appc2':{//加工位置コード
	 	caption:'TOMS.MASTER.MAINTENANCE.PROCESSPART.LABEL.PROCESSPART_POSITION_CODE',
		 alphanumeric: true,
		 maxlength: 16
 		},
 		'search_mpy57appc2Name':{//加工位置名称
 		caption:'TOMS.MASTER.MAINTENANCE.PROCESSPART.LABEL.PROCESSPART_POSITION_NAME',
		maxlength: 30
 		},
		'search_mpy57acc':{//商品コード
	 	caption:'TOMS.MASTER.MAINTENANCE.PROCESSMETHOD_COMMODITY.LABEL.COMMODITY_CODE',
		alphanumeric: true,
		maxlength: 5
 		},	

 		//有効開始日 
	 	'search_mpeftj':{
	 	caption:'TOMS.MASTER.MAINTENANCE.COMMODITYSHAPE.LABEL.APPLIED_START_DATE',
		date: true,
	    maxlength: 10
	 	}, 
 		//有効開始日2 
	 	'search_mpeftj2':{
	 	caption:'TOMS.MASTER.MAINTENANCE.COMMODITYSHAPE.LABEL.APPLIED_START_DATE',
		date: true,
	    maxlength: 10
	 	}, 
	 	//有効終了日 
	 	'search_mpexdj':{
	 	caption:'TOMS.MASTER.MAINTENANCE.COMMODITYSHAPE.LABEL.APPLIED_END_DATE',
		date: true,
	    maxlength: 10
	 	}
 }