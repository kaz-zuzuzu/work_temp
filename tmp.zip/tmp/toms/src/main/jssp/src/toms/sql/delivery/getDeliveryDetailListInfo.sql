/*
　出庫詳細一覧情報取得
*/
select 
 TE.TEY57ASHPN --  出荷予定No
 ,TE.TEY57ASDCT -- 伝票タイプ
 ,TE.TELNIC/1000 as TELNIC -- 枝番（出荷予定行No）
 ,TRIM(TE.TELITM) as TELITM --商品コード（第2品目）
 ,TRIM(TE.TEDSC1) as TEDSC1 --商品名（記述1）
 ,substr(TE.TEDSC2,0,instr(TE.TEDSC2,'／')-1) as TEDSC2_color --カラー
 ,TRIM(substr(TE.TEDSC2,instr(TE.TEDSC2,'／')+1)) as TEDSC2_size --サイズ
 ,TRIM(TO_CHAR(TE.TESOQS, '999,999,999,999')) as TESOQS --実績数（出荷数量）
 ,TRIM(TO_CHAR((TE.TEUPRC/10000), '999,999,999,999')) as TEUPRC--単価（単位価格）
 ,TRIM(TE.TEY57ADHRM) as TEY57ADHRM --柄名
 ,TRIM(TE.TEY57ASODN) as TEY57ASODN --販売先発注番号（お客様注文No）

from 
 F57A0071 TE 
 
 LEFT JOIN F4101 IM
  ON TE.TELITM = IM.IMLITM
  
WHERE
    /*BEGIN*/
    /*IF denpyoType != null*/
    TE.TEY57ASDCT = /*denpyoType*/'XF'                       --伝票タイプ
    /*END*/
    /*IF instructNo != null*/
    AND
    TE.TEY57ASHPN = /*instructNo*/15160520    --出荷予定番号
    /*END*/
    /*END*/
    AND IM.IMLNTY ='S'
order by TE.TELNIC
