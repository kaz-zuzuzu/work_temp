/**
 *	共通関数群（ユーティリティ）
 *
 *  toms/common/cmnUtil.js
 *
 */

var cmnUtil = function(){};

/**===================================================
 * 関数一覧
 * 　cmnUtil.trim
 * 　cmnUtil.getData
 * 　cmnUtil.getTime
 * 　cmnUtil.convertDateToJulia
 * 
 * 
 * ===================================================
 */

/**
 * trim関数
 * 　前後に含まれている半角スペースを取り除く
 * 
 * @param string　
 * 
 */
	
cmnUtil.trim = function(string){
		if (string != null) {
			return string.replace(/^\s+|\s+$/g,'');
		} else {
			return "";
		}
	 
};

	/**
 * getData関数
 * 　DbParameterへ設定用の変換関数
 * 
 * @param string　
 * @param type
 * 　　　0：文字列
 * 　　　1:数値
 * 
 */
cmnUtil.getData=function(string, type) {
	if (type == 0) {
		return cmnUtil.trim(string);
	} else if(type == 1) {
		var data = cmnUtil.trim(string);
		if (data != "") {
			return Number(data);
		} else {
			return data;
		}
	} else {
		return cmnUtil.trim(string);
	}
}

/**
 * getTime関数
 * 　0埋めで時間を文字列へ変換する
 * 
 * @param date　日付型
 * 
 */
cmnUtil.getTime = function(date) {
	return  Number(('0' + date.getHours()).slice(-2)
	        + ('0' + date.getMinutes()).slice(-2)
	        + ('0' + date.getSeconds()).slice(-2));
}

/**
 * convertDateToJulia関数
 * 　ジュリアン日付変換関数
 * 
 * @param date　日付型
 * 
 */
cmnUtil.convertDateToJulia = function(date) {
	var year = Number(date.getFullYear());
	var upperData = (year - 1900) * 1000;
	var firstDay = new Date(date.getFullYear() + '/01/01');
	var days = Math.floor((date - firstDay)/(1000 * 60 * 60 * 24)) + 1;
    return upperData + days;
}

