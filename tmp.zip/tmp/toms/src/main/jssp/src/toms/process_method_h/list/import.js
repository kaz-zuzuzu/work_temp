/**
 * 加工方法見積ヘッダアップロード処理
 */
var $bind ={};
load("toms/common/mastermaintenance");

//1 加工方法コード
var processMethodCd = MessageManager.getMessage('TOMS.MASTER.MAINTENANCE.PROCESSMETHOD_HEADER.LABEL.PROCESS_METHOD_CODE');
//2 親商品形態コード
var parentCommodityCd = MessageManager.getMessage('TOMS.MASTER.MAINTENANCE.COMMODITYSHAPE.LABEL.PARENT_COMMODITY_SHAPE_CODE');
//3 商品形態コード
var commodityCd = MessageManager.getMessage('TOMS.MASTER.MAINTENANCE.COMMODITYSHAPE.LABEL.COMMODITY_SHAPE_CODE');
//4 素材コード
var materialCd = MessageManager.getMessage('TOMS.MASTER.MAINTENANCE.MATERIAL.LABEL.MATERIAL_CODE');
//5 加工部位コード
var partCd = MessageManager.getMessage('TOMS.MASTER.MAINTENANCE.PROCESSPART.LABEL.PROCESSPART_CODE');
//6 加工位置コード
var positionCd = MessageManager.getMessage('TOMS.MASTER.MAINTENANCE.PROCESSPART.LABEL.PROCESSPART_POSITION_CODE');
//7 階層数
var deptAmount = MessageManager.getMessage('TOMS.MASTER.MAINTENANCE.PROCESSMETHOD_HEADER.LABEL.DEPTH_AMOUNT');
//8 特記事項区分
var reportType = MessageManager.getMessage('TOMS.MASTER.MAINTENANCE.PROCESSMETHOD_HEADER.LABEL.SPECIAL_REPORT_TYPE');
//9 加工方法区分
var processMethodType =MessageManager.getMessage('TOMS.MASTER.MAINTENANCE.PROCESSMETHOD_HEADER.LABEL.PROCESS_METHOD_TPYE');
//10 加工方法明細区分
var processMethodDetailType =MessageManager.getMessage('TOMS.MASTER.MAINTENANCE.PROCESSMETHOD_HEADER.LABEL.PROCESS_METHOD_DETAIL_TPYE');
//11 加工方法名称
var processMethodName = MessageManager.getMessage('TOMS.MASTER.MAINTENANCE.PROCESSMETHOD_HEADER.LABEL.PROCESS_METHOD_NAME');
//12 適用開始日
var startDate = MessageManager.getMessage('TOMS.MASTER.MAINTENANCE.COMMODITYSHAPE.LABEL.APPLIED_START_DATE');
//13 削除フラグ
var delFlg = MessageManager.getMessage('TOMS.MASTER.MAINTENANCE.COMMODITYSHAPE.LABEL.DELETE_FLG');


/**
 * CSVアップロード初期処理.
 * @param request リクエストパラメータ.
 */
function init(request) {

    load("toms/common/csv/CsvUtil");
    load("toms/common/csv/CsvCheker");
    load("toms/common/cmnUtil");

    var response = Web.getHTTPResponse();
    response.setContentType("text/plain; charset=utf-8");
    var csv = []; // csv二次元配列
    var stErr = new java.lang.StringBuilder(); // エラーメッセージ
    var stMsg = new java.lang.StringBuilder(); // 成功メッセージ
    var updateCount = { newCount: 0, updateCount: 0, deleteCount: 0};
    var ret = true;

    // ファイルロード csv二次元ファイル化
    if (!CsvUtil.load2Csv(request, csv, stErr)) {
        doError(response, stErr);
        return;
    }
    // CSVデータ有無チェック
    if (csv.length < 2) {
        // CSVファイルにデータ行が存在しない場合はエラー
        stErr.append(MessageManager.getMessage("TOMS.MASTER.MAINTENANCE.CSVUPLOAD.MESSAGE.ERROR.CSVNODATA"));
        doError(response, stErr);
        return;
    }
    // CSVデータの行数分繰り返す（先頭行はヘッダ行のため次の行から始める）
    for (var rowPos = 1; rowPos < csv.length; rowPos++) {
        // データチェック
        ret = check(csv[rowPos], rowPos, stErr);
        // DB存在チェック
        if (ret) {
            ret = dbCheck(csv[rowPos], rowPos, stErr);
        }
        // DB更新
        if (ret) {
            ret = dbUpdate(csv[rowPos], rowPos, stErr, updateCount);
        }
    }

    // 正常値の返却
    // 登録件数
    stMsg.append(MessageManager.getMessage("TOMS.MASTER.MAINTENANCE.CSVUPLOAD.LIST.LABEL.ENTRYNUM", String(updateCount.newCount)));
    // 更新件数
    stMsg.append(MessageManager.getMessage("TOMS.MASTER.MAINTENANCE.CSVUPLOAD.LIST.LABEL.UPDATENUM", String(updateCount.updateCount)));
    // 削除件数
    stMsg.append(MessageManager.getMessage("TOMS.MASTER.MAINTENANCE.CSVUPLOAD.LIST.LABEL.DELETENUM", String(updateCount.deleteCount)));

    var stringErr = stErr.toString();
    var stringMsg = stMsg.toString();
    response.sendMessageBodyString(ImJson.toJSONString([{
        "errorMessage": stringErr,
        "successMessage": stringMsg
    }]));
}

/**
 * バリデーションチェック
 * @param csvRowData csvの行データ.(IN)
 * @param rowPos 行番号.(IN)
 * @param stErr エラーメッセージパラメータ.(OUT)
 */
function check(csvRowData, rowPos, stErr){
    var ret = true;
    var ope = csvRowData[0];//更新区分
    var sRowPos = String(rowPos);
    var cellPos = null;

     // 列数チェック
    var columnCnt = 14;
    if (csvRowData.length != columnCnt) {
        if (csvRowData.length > columnCnt) {
            stErr.append(MessageManager.getMessage("TOMS.MASTER.MAINTENANCE.CSVUPLOAD.MESSAGE.ERROR.COLUMN1",sRowPos));
        } else if (csvRowData.length < columnCnt) {
            stErr.append(MessageManager.getMessage("TOMS.MASTER.MAINTENANCE.CSVUPLOAD.MESSAGE.ERROR.COLUMN2",sRowPos));
        }
        ret = false;
        return ret;
    }
    
    // --------------------
    //  0 更新区分
    // --------------------
    // データチェック
    if (isBlank(ope)) {
        stErr.append(MessageManager.getMessage("TOMS.MASTER.MAINTENANCE.CSVUPLOAD.LIST.LABEL.MESSAGE.ERROR.UPDATEDIVISION", sRowPos));
        ret = false;
    }    
    if (ope != "I" && ope != "U" && ope != "D") {
        stErr.append(MessageManager.getMessage("TOMS.MASTER.MAINTENANCE.CSVUPLOAD.LIST.LABEL.MESSAGE.ERROR.UPDATEDIVISION_FORMAT", sRowPos));
        ret = false;
    }


    // --------------------
    // 1 加工方法コード
    // --------------------
    cellPos = 1;
    // 必須チェック
    //更新と削除の場合
    if(ope == "U" || ope == "D"){
        if (!CsvCheker.required(csvRowData[cellPos], rowPos, cellPos, processMethodCd, stErr)) {
            ret = false;
        } else {
            // 半角英数字チェック
            if (!CsvCheker.isAlphanumeric(csvRowData[cellPos], rowPos, cellPos, processMethodCd, stErr)) {
                ret = false;
            }
            // 桁数チェック
            if (!CsvCheker.maxLength(csvRowData[cellPos], 16, rowPos, cellPos, processMethodCd, stErr)) {
                ret = false;
            }
        }
    }
    // --------------------
    // 2 親商品形態コード
    // --------------------	
    cellPos = 2;
    // 登録、更新の場合
    if (ope == "I" || ope == "U") {    // 必須チェック
	    if (!CsvCheker.required(csvRowData[cellPos], rowPos, cellPos, parentCommodityCd, stErr)) {
	        ret = false;
	    } else {
            // 半角英数字チェック
            if (!CsvCheker.isAlphanumeric(csvRowData[cellPos], rowPos, cellPos, parentCommodityCd, stErr)) {
                ret = false;
            }
            // 桁数チェック
            if (!CsvCheker.maxLength(csvRowData[cellPos], 16, rowPos, cellPos, parentCommodityCd, stErr)) {
                ret = false;
            }
            // 親商品形態コードチェック
            if (!CsvCheker.isParentCommodityPrefix(csvRowData[cellPos],rowPos, cellPos, parentCommodityCd, stErr)) {
                ret = false;
            }
	    }
    }
    // --------------------
    // 3 商品形態コード
    // --------------------
	cellPos = 3;
    // 登録、更新の場合
	if (ope == "I" || ope == "U") {
	    // 必須チェック
	    if (!CsvCheker.required(csvRowData[cellPos], rowPos, cellPos, commodityCd, stErr)) {
	        ret = false;
	    } else {
            // 半角英数字チェック
            if (!CsvCheker.isAlphanumeric(csvRowData[cellPos], rowPos, cellPos, commodityCd, stErr)) {
                ret = false;
            }
            // 桁数チェック
            if (!CsvCheker.maxLength(csvRowData[cellPos], 16, rowPos, cellPos, commodityCd, stErr)) {
                ret = false;
            }
            // 商品形態コードチェック
            if (!CsvCheker.isCommodityPrefix(csvRowData[cellPos], rowPos, cellPos, commodityCd, stErr)) {
                ret = false;
            }
        }
    }
    // --------------------
    // 4 素材コード
    // --------------------
	cellPos = 4;
    // 登録、更新の場合
    if (ope == "I" || ope == "U") {
    	// 必須チェック
	    if (!CsvCheker.required(csvRowData[cellPos], rowPos, cellPos, materialCd, stErr)) {
	        ret = false;
	    } else {
            // 半角英数字チェック
            if (!CsvCheker.isAlphanumeric(csvRowData[cellPos], rowPos, cellPos, materialCd, stErr)) {
                ret = false;
            }
            // 桁数チェック
            if (!CsvCheker.maxLength(csvRowData[cellPos], 16, rowPos, cellPos, materialCd, stErr)) {
                ret = false;
            }
        }
    }
    // --------------------
    // 5 加工部位コード
    // --------------------
    cellPos = 5;
    // 登録、更新の場合
    if (ope == "I" || ope == "U") {
    	// 必須チェック
	    if (!CsvCheker.required(csvRowData[cellPos], rowPos, cellPos, partCd, stErr)) {
	        ret = false;
	    } else {
            // 半角英数字チェック
            if (!CsvCheker.isAlphanumeric(csvRowData[cellPos], rowPos, cellPos, partCd, stErr)) {
                ret = false;
            }
            // 桁数チェック
            if (!CsvCheker.maxLength(csvRowData[cellPos], 16, rowPos, cellPos, partCd, stErr)) {
                ret = false;
            }
        }
    }
    // --------------------
    // 6 加工位置コード
    // --------------------
    cellPos = 6;
    // 登録、更新の場合
    if (ope == "I" || ope == "U") {
    	// 必須チェック
	    if (!CsvCheker.required(csvRowData[cellPos], rowPos, cellPos, positionCd, stErr)) {
	        ret = false;
	    } else {
            // 半角英数字チェック
            if (!CsvCheker.isAlphanumeric(csvRowData[cellPos], rowPos, cellPos, positionCd, stErr)) {
                ret = false;
            }
            // 桁数チェック
            if (!CsvCheker.maxLength(csvRowData[cellPos], 16, rowPos, cellPos, positionCd, stErr)) {
                ret = false;
            }
        }
    }
    // --------------------
    // 7 階層数
    // --------------------
    cellPos = 7;
    // 登録、更新の場合
    if (ope == "I" || ope == "U") {
        // 必須チェック
        if (!CsvCheker.required(csvRowData[cellPos], rowPos, cellPos, deptAmount, stErr)) {
            ret = false;
        } else {
        	// 半角数値チェック
            if (!CsvCheker.isNum(csvRowData[cellPos], rowPos, cellPos, deptAmount, stErr)) {
                ret = false;
            }
            // 文字数チェック
            if (!CsvCheker.maxLength(csvRowData[cellPos], 2, rowPos, cellPos, deptAmount, stErr)) {
                ret = false;
            }
        }
    }
    // --------------------
    // 8 特記事項区分
    // --------------------
    cellPos = 8;
    // 登録、更新の場合
    if (ope == "I" || ope == "U") {
        // 半角数値チェック
        if (!CsvCheker.isNum(csvRowData[cellPos], rowPos, cellPos, reportType, stErr)) {
            ret = false;
        }
        // 桁数チェック
        if (!CsvCheker.maxLength(csvRowData[cellPos], 8, rowPos, cellPos, reportType, stErr)) {
            ret = false;
        }
    }
    // --------------------
    // 9 加工方法区分
    // --------------------
    cellPos = 9;
    // 登録、更新の場合
    if (ope == "I" || ope == "U") {
    	// 必須チェック
	    if (!CsvCheker.required(csvRowData[cellPos], rowPos, cellPos, processMethodType, stErr)) {
	        ret = false;
	    } else {
            // 半角英数字チェック
            if (!CsvCheker.isAlphanumeric(csvRowData[cellPos], rowPos, cellPos, processMethodType, stErr)) {
                ret = false;
            }
            // 桁数チェック
            if (!CsvCheker.maxLength(csvRowData[cellPos], 2, rowPos, cellPos, processMethodType, stErr)) {
                ret = false;
            }
        }
    }

    // --------------------
    // 10 加工方法明細区分
    // --------------------
    cellPos = 10;
    // 登録、更新の場合
    if (ope == "I" || ope == "U") {
    	// 必須チェック
	    if (!CsvCheker.required(csvRowData[cellPos], rowPos, cellPos, processMethodDetailType, stErr)) {
	        ret = false;
	    } else {
            // 半角英数字チェック
            if (!CsvCheker.isAlphanumeric(csvRowData[cellPos], rowPos, cellPos, processMethodDetailType, stErr)) {
                ret = false;
            }
            // 桁数チェック
            if (!CsvCheker.maxLength(csvRowData[cellPos], 2, rowPos, cellPos, processMethodDetailType, stErr)) {
                ret = false;
            }
        }
    }

    // --------------------
    // 11 加工方法名称
    // --------------------
	cellPos = 11;
    // 必須チェック
    if (!CsvCheker.required(csvRowData[cellPos], rowPos, cellPos, processMethodName, stErr)) {
        ret = false;
    } else {
        // 登録、更新の場合
        if (ope == "I" || ope == "U") {

            // 文字数チェック
            if (!CsvCheker.maxLength(csvRowData[cellPos], 30, rowPos, cellPos, processMethodName, stErr)) {
                ret = false;
            }
        }
    }
    // --------------------
    // 12 適用開始日
    // --------------------
    cellPos = 12;
    // 必須チェック
    if (!CsvCheker.required(csvRowData[cellPos], rowPos, cellPos, startDate, stErr)) {
        ret = false;
    } else {
        // 登録、更新の場合
        if (ope == "I" || ope == "U") {
            // 日付チェック
            if (!CsvCheker.isDate(csvRowData[cellPos], rowPos, cellPos, startDate, stErr)) {
                ret = false;
            }
        }
    }
    // --------------------
    // 13 削除フラグ
    // --------------------
    cellPos = 13;
    // 登録の場合
    if (ope == "I") {
        // データチェック
        if (csvRowData[cellPos] != "0") {
            stErr.append(MessageManager.getMessage("TOMS.MASTER.MAINTENANCE.CSVUPLOAD.LIST.LABEL.MESSAGE.ERROR.DEL_FLAG", sRowPos));
            ret = false;
        }
    }
    // 登録、更新の場合
    else if (ope == "I" || ope == "U") {
        // データチェック
        if (csvRowData[cellPos] != "0" && csvRowData[cellPos] != "1") {
            stErr.append(MessageManager.getMessage("TOMS.MASTER.MAINTENANCE.CSVUPLOAD.LIST.LABEL.MESSAGE.ERROR.DEL_FLAG_FORMAT", sRowPos));
            ret = false;
        }
    }

    return ret;
	
}

/*
 * DBによるデータ有無チェック
 * @param csvRowData csvの行データ.(IN)
 * @param rowPos 行番号.(IN)
 * @param stErr エラーメッセージパラメータ.(OUT)
 */
function dbCheck(csvRowData, rowPos, stErr) {
    var ret = true;
    var ope = csvRowData[0];
    var sRowPos = String(rowPos);
    var cellPos = null;
    var result =null;
    //加工方法ヘッダマスタのキー検索（加工方法コード、親商品形態コード、商品形態コード、素材コード、加工部位コード、加工位置コード、加工方法区分、適用開始日）
    if (ope == "I" ) {
	    //新規登録時の重複チェック
	    var uniqResult = MasterMain.getProcessMethodHeaderByKey("",csvRowData[2], csvRowData[3],csvRowData[4],csvRowData[5],csvRowData[6],csvRowData[9],csvRowData[12]);
    }else{
	    //更新・削除時の存在チェック
	    var uniqResult = MasterMain.getProcessMethodHeaderByKey(csvRowData[1],"", "","","","","",csvRowData[12]);
    }
    if (ope == "I" || ope == "U") {
		//親商品形態コードの内部コードチェック
	    cellPos = 2;
	    result = MasterMain.checkCodeMaster("01", "01", csvRowData[cellPos]);
	    if (result.countRow == 0) {
	        // 存在しない場合
	        stErr.append(MessageManager.getMessage("TOMS.MASTER.MAINTENANCE.CSVUPLOAD.LIST.LABEL.MESSAGE.ERROR.CODEMASTER.NOTINLINE", sRowPos, String(cellPos + 1), parentCommodityCd));
	        ret = false;
	    }
	    //商品形態コードの内部コードチェック
	    cellPos = 3;
	    result = MasterMain.checkCodeMaster("02", "01", csvRowData[cellPos]);
	    if (result.countRow == 0) {
	        // 存在しない場合
	        stErr.append(MessageManager.getMessage("TOMS.MASTER.MAINTENANCE.CSVUPLOAD.LIST.LABEL.MESSAGE.ERROR.CODEMASTER.NOTINLINE", sRowPos, String(cellPos + 1), commodityCd));
	        ret = false;
	    }
	    //素材コードの内部コードチェック
	    cellPos = 4;
	    result = MasterMain.checkCodeMaster("03", "01", csvRowData[cellPos]);
	    if (result.countRow == 0) {
	        // 存在しない場合
	        stErr.append(MessageManager.getMessage("TOMS.MASTER.MAINTENANCE.CSVUPLOAD.LIST.LABEL.MESSAGE.ERROR.CODEMASTER.NOTINLINE", sRowPos, String(cellPos + 1), materialCd));
	        ret = false;
	    }
	    //加工部位コードの内部コードチェック
	     cellPos = 5;
	    result = MasterMain.checkCodeMaster("04", "01", csvRowData[cellPos]);
	    if (result.countRow == 0) {
	        // 存在しない場合
	        stErr.append(MessageManager.getMessage("TOMS.MASTER.MAINTENANCE.CSVUPLOAD.LIST.LABEL.MESSAGE.ERROR.CODEMASTER.NOTINLINE", sRowPos, String(cellPos + 1), partCd));
	        ret = false;
	    }
	   	//加工位置コードの内部コードチェック
	     cellPos = 6;
	    result = MasterMain.checkCodeMaster("05", "01", csvRowData[cellPos]);
	    if (result.countRow == 0) {
	        // 存在しない場合
	        stErr.append(MessageManager.getMessage("TOMS.MASTER.MAINTENANCE.CSVUPLOAD.LIST.LABEL.MESSAGE.ERROR.CODEMASTER.NOTINLINE", sRowPos, String(cellPos + 1), positionCd));
	        ret = false;
	    }

	    //加工方法区分のコードチェック
	    cellPos = 9
	    var checkResult = MasterMain.checkProcessMethodType(csvRowData[cellPos]);
	    if(!checkResult){
	        stErr.append(MessageManager.getMessage("TOMS.MASTER.MAINTENANCE.CSVUPLOAD.LIST.LABEL.MESSAGE.ERROR.PROCESSMETHODTYPE.NOTINLINE", sRowPos, String(cellPos + 1)));
	    	ret = false;
	    	
	    };

	    //加工方法明細区分のコードチェック
	    cellPos = 10
	    checkResult = MasterMain.checkProcessMethodDetailType(csvRowData[cellPos]);
	    if(!checkResult){
	        stErr.append(MessageManager.getMessage("TOMS.MASTER.MAINTENANCE.CSVUPLOAD.LIST.LABEL.MESSAGE.ERROR.PROCESSMETHODDETAILTYPE.NOTINLINE", sRowPos, String(cellPos + 1)));
	    	ret = false;
	    	
	    };

//	    //加工方法区分の内部コードチェック
//	     cellPos = 9;
//	    result = MasterMain.checkCodeMaster("06", "01", csvRowData[cellPos]);
//	    if (result.countRow == 0) {
//	        // 存在しない場合
//	        stErr.append(MessageManager.getMessage("TOMS.MASTER.MAINTENANCE.CSVUPLOAD.LIST.LABEL.MESSAGE.ERROR.CODEMASTER.NOTINLINE", sRowPos, String(cellPos + 1), processMethodType));
//	        ret = false;
//	    }
//	    //加工方法明細区分の内部コードチェック
//	     cellPos = 10;
//	    //result = MasterMain.checkCodeMaster("07", "01", csvRowData[cellPos]);
//	    result = MasterMain.checkCodeMasterMethodDetail("07", "01", csvRowData[cellPos],csvRowData[7]);
//	    if (result.countRow == 0) {
//	        // 存在しない場合
//	        stErr.append(MessageManager.getMessage("TOMS.MASTER.MAINTENANCE.CSVUPLOAD.LIST.LABEL.MESSAGE.ERROR.CODEMASTER.NOTINLINE", sRowPos, String(cellPos + 1), processMethodDetailType));
//	        ret = false;
//	    }
    }


    if(ope=="I"){
	    //加工部位存在チェック
	    result = MasterMain.getProcessPartByPk(csvRowData[5],csvRowData[6],csvRowData[2],csvRowData[3],csvRowData[4],"");
        if (result.countRow == 0) {
            // 存在しない場合
            stErr.append(MessageManager.getMessage("TOMS.MASTER.MAINTENANCE.CSVUPLOAD.MESSAGE.ERROR.DATANOTEXIST.PROCESSPART", sRowPos, csvRowData[5].trim(),csvRowData[6].trim(),csvRowData[2].trim(),csvRowData[3].trim(),csvRowData[4].trim()));
            ret = false;
        }
        //加工方法ヘッダ重複チェック
        if(uniqResult.countRow !=0){
            stErr.append(MessageManager.getMessage("TOMS.MASTER.MAINTENANCE.CSVUPLOAD.MESSAGE.ERROR.PROCESSMETHODHEADER.DATAEXIST.INSERT", sRowPos, csvRowData[2].trim(), csvRowData[3].trim(),csvRowData[4].trim(),csvRowData[5].trim(),csvRowData[6].trim(),csvRowData[9].trim(),csvRowData[12].trim()));
            ret = false;
        }
        
    }else{
        // 更新、削除の場合
        // 存在チェック
        if (uniqResult.countRow < 1) {
            stErr.append(MessageManager.getMessage("TOMS.MASTER.MAINTENANCE.CSVUPLOAD.MESSAGE.ERROR.PROCESSMETHODHEADER.DATANOTEXIST", sRowPos, csvRowData[1].trim(),csvRowData[12].trim()));
            ret = false;
        }
//        // 複数存在チェック
//        if (uniqResult.countRow > 1) {
//            stErr.append(MessageManager.getMessage("TOMS.MASTER.MAINTENANCE.PROCESSPART.LIST.LABEL.MESSAGE.ERROR.DUPLICATE", sRowPos, csvRowData[1].trim(), csvRowData[2].trim(), csvRowData[3].trim(), csvRowData[4].trim(), csvRowData[5].trim(), csvRowData[12].trim()));
//            ret = false;
//        }
    }
    return ret;
}

/**
 * DB更新
 * 
 * @param csvRowData csvの行データ.(IN)
 * @param rowPos 行番号.(IN)
 * @param stErr エラーメッセージパラメータ.(OUT)
 * @param updateCount (OUT)
 */
function dbUpdate(csvRowData, rowPos, stErr, counts) {

    var ret = true;
    var newCount = counts.newCount;
    var updateCount = counts.updateCount;
    var deleteCount = counts.deleteCount;

    var ope = csvRowData[0];
    var sRowPos = String(rowPos);
    var result;

    // CSVの行データからDB更新用データ作成
    var entity = createEntity(csvRowData);
    var condition = "TRIM(mmy57apmc) = ? "
                  + " AND mmeftj = ? ";
    var params = [
            DbParameter.string(entity["mmy57apmc"]),
            DbParameter.number(entity["mmeftj"])
    ];

    Transaction.begin();
    var masterTable = 'F57A5140';
    if (ope == "I") {           //登録
    	//加工方法コード取得
    	result = MasterMain.getSequence();
        if (result.error) {
            Transaction.rollback();
            stErr.append(MessageManager.getMessage("TOMS.MASTER.MAINTENANCE.CSVUPLOAD.LIST.LABEL.MESSAGE.ERROR.DB"));
            stErr.append(MessageManager.getMessage("TOMS.MASTER.MAINTENANCE.CSVUPLOAD.LIST.LABEL.MESSAGE.CSVLINE", sRowPos));
            return false;
        }
        //加工方法コード設定
    	entity.mmy57apmc = result.data[0].nextval+"";
    	result = MasterMain.insertToMasterTable(masterTable, entity);
        newCount++;
    } else if (ope =="U") {     //更新
        result = MasterMain.updateToMasterTable(masterTable, entity, condition, params);
        updateCount++;
    } else if  (ope =="D") {    //削除
        result = MasterMain.removeFromMasterTable(masterTable, condition, params);
        deleteCount++;
    }
    if (!result.error && result.countRow != 1) {
        Transaction.rollback();
        Debug.console("処理異常",sRowPos,entity, condition, params);
        stErr.append(MessageManager.getMessage("TOMS.MASTER.MAINTENANCE.CSVUPLOAD.LIST.LABEL.MESSAGE.ERROR.ABNORMAL", sRowPos));
        return false;
    }
    if (result.error) {
        Transaction.rollback();
        stErr.append(MessageManager.getMessage("TOMS.MASTER.MAINTENANCE.CSVUPLOAD.LIST.LABEL.MESSAGE.ERROR.DB"));
        stErr.append(MessageManager.getMessage("TOMS.MASTER.MAINTENANCE.CSVUPLOAD.LIST.LABEL.MESSAGE.CSVLINE", sRowPos));
        return false;
    }
    Transaction.commit();

    counts.newCount = newCount;
    counts.updateCount = updateCount;
    counts.deleteCount = deleteCount;

    return true;
}
/**
 * DB更新用データ作成
 * 
 * @param csvRowData csvの行データ.
 */
function createEntity(csvRowData) {

    var userContext = Contexts.getUserContext();
    var now = new Date();

 	var mmy57apmc = null; //加工方法コード1
	var mmy57apcsc =null;//親商品形態コード2
	var mmy57acsc = null;//商品形態コード3
	var mmy57amtc = null; //素材コード4
	var mmy57appc1 = null; //加工部位コード5
	var mmy57appc2 = null; //加工位置コード6
	var mmy57ada =null;//階層数7
	var mmy57asrt =null;//特記事項8
	var mmy57apmt =null;//加工方法区分9
	var mmy57apmdt =null;//加工方法明細区分10
	var mmdl01 = null; //加工方法名称11
	var mmeftj =null;//適用開始日12
	var mmy57adflg = null //削除フラグ
	var mmexdj = cmnUtil.convertDateToJulia(new Date(MessageManager.getMessage("TOMS.COMMON.CONSTANT.ENDDATE")));    // 適用終了日
	var mmuser = userContext.userProfile.userCd; //ユーザID
    var mmpid = MessageManager.getMessage("TOMS.COMMON.CONSTANT.PROGRAM.ID");    // プログラムID
	var mmupmj = cmnUtil.convertDateToJulia(now);  //更新日付
	var mmupmt = cmnUtil.getTime(now);  //更新時刻
	
	//加工方法コード1
    if(!isBlank(cmnUtil.getData(csvRowData[1], 0))){
    	mmy57apmc = cmnUtil.getData(csvRowData[1], 0);
    }
	//親商品形態コード2
    if(!isBlank(cmnUtil.getData(csvRowData[2], 0))){
    	mmy57apcsc = cmnUtil.getData(csvRowData[2], 0);
    }
	//商品形態コード3
    if(!isBlank(cmnUtil.getData(csvRowData[3], 0))){
    	mmy57acsc = cmnUtil.getData(csvRowData[3], 0);
    }
    //素材コード4
    if(!isBlank(cmnUtil.getData(csvRowData[4], 0))){
    	mmy57amtc = cmnUtil.getData(csvRowData[4], 0);
    }
	//加工部位コード5
    if(!isBlank(cmnUtil.getData(csvRowData[5], 0))){
    	mmy57appc1 = cmnUtil.getData(csvRowData[5], 0);
    }
	//加工位置コード6
    if(!isBlank(cmnUtil.getData(csvRowData[6], 0))){
    	mmy57appc2 = cmnUtil.getData(csvRowData[6], 0);
    }

	//階層数7
    if(!isBlank(cmnUtil.getData(csvRowData[7], 1))){
    	mmy57ada = cmnUtil.getData(csvRowData[7], 1);
    }
	//特記事項8
    if(!isBlank(cmnUtil.getData(csvRowData[8], 0))){
    	mmy57asrt = cmnUtil.getData(csvRowData[8], 0);
    }
	//加工方法区分9
    if(!isBlank(cmnUtil.getData(csvRowData[9], 0))){
    	mmy57apmt = cmnUtil.getData(csvRowData[9], 0);
    }
	//加工方法明細区分10
    if(!isBlank(cmnUtil.getData(csvRowData[10], 0))){
    	mmy57apmdt = cmnUtil.getData(csvRowData[10], 0);
    }
    //加工方法名称11
    if(!isBlank(cmnUtil.getData(csvRowData[11], 0))){
    	mmdl01 = cmnUtil.getData(csvRowData[11], 0);
    }

	//適用開始日12
    if(!isBlank(csvRowData[12])){

    	mmeftj = cmnUtil.convertDateToJulia(new Date(csvRowData[12]));
    }

    //削除フラグ13
    if(!isBlank(cmnUtil.getData(csvRowData[13], 1))){
    	mmy57adflg = cmnUtil.getData(csvRowData[13], 1);
    }

    var entity ={
    	mmy57apmc : mmy57apmc,
	    mmy57apcsc : mmy57apcsc,
	    mmy57acsc : mmy57acsc,
	    mmy57amtc : mmy57amtc,
	    mmy57appc1 : mmy57appc1,
	    mmy57appc2 : mmy57appc2,
	    mmy57ada : mmy57ada,
	    mmy57asrt : mmy57asrt,
	    mmy57apmt : mmy57apmt,
	    mmy57apmdt : mmy57apmdt,
	    mmdl01 : mmdl01,
	    mmy57adflg : mmy57adflg,
	    mmeftj : mmeftj,
	    mmexdj : mmexdj,
    	mmuser : mmuser,
    	mmpid : mmpid,
    	mmupmj : mmupmj,
    	mmupmt : mmupmt 
    };
    return entity;
}
/**
 * エラー処理
 * 
 * @param response　レスポンス
 * @param stErr エラーメッセージパラメータ.
 */
function doError(response, stErr) {
        stErr.insert(0, MessageManager.getMessage("TOMS.MASTER.MAINTENANCE.CSVUPLOAD.LIST.LABEL.ENTRY.ERROR"));
        var stringErr = stErr.toString();
        response.sendMessageBodyString(ImJson.toJSONString([{
            "errorMessage": stringErr,
            "successMessage": ""
        }]));
}
