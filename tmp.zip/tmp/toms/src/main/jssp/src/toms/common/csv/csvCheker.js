
/**
* staticオブジェクトの作成 
 */ 
function CsvCheker(){}

/**
 * 必須チェック
 * @param v 値(対象文字列)
 * @param rowPos 行位置
 * @param cellPos 列位置
 * @param cellName 列名
 * @param stErr エラーメッセージパラメータ.(OUT)
 * @return エラー時 false
 */
CsvCheker.required = function(v, rowPos, cellPos, cellName, stErr ) {
	
	if(v == null || v == "") {
//		stErr.append("<p>" + rowPos + "行目 " + (cellPos+1) + "列　" + cellName + 
//			"には値を設定して下さい。</p>");
		stErr.append(MessageManager.getMessage('TOMS.COMMON.MAINTENANCE.CSV.ERROR.REQUIRED.MESSAGE',String(rowPos), String(cellPos+1),String(cellName)));
			return false;
	}
	return true;
}

/**
 * 最大長チェック
 * @param v 値(対象文字列)
 * @param maxLen 最大長
 * @param rowPos 行位置
 * @param cellPos 列位置
 * @param cellName 列名
 * @param stErr エラーメッセージパラメータ.(OUT)
 * @return エラー時 false
 */
CsvCheker.maxLength = function (v, maxLen, rowPos, cellPos, cellName, stErr ) {
	
	if(v == null || v == "") {
		return true;
	}
	
	if(v.length<=maxLen) {
		return true
	}

//	stErr.append("<p>" + rowPos + "行目 " + (cellPos+1) + "列　" + cellName + 
//		"は" + maxLen + "文字を超えています。</p>");
	stErr.append(MessageManager.getMessage('TOMS.COMMON.MAINTENANCE.CSV.ERROR.LENGTH.MESSAGE', String(rowPos), String(cellPos+1), cellName, String(maxLen)));

		return false;
}

/**
 * 整数部長　少数部長　チェック
 * @param v 値(対象文字列)
 * @param integralMaxLen 整数部　最大長
 * @paramf fractionalMaxLen 少数部　最大長
 * @param rowPos 行位置
 * @param cellPos 列位置
 * @param cellName 列名
 * @param stErr エラーメッセージパラメータ.(OUT)
 * @return エラー時 false
 */
CsvCheker.isDigits = function (v, integralMaxLen, fractionalMaxLen, rowPos, cellPos, cellName, stErr ) {

	// TODO 作成中
	var ret = true;

	if(v == null || v == "") {
		return ret;
	}

	// 整数部　最大長に分ける
	var tmpDigitsArray =v.split(".");

	if(tmpDigitsArray.length > 2) {
		if(tmpDigitsArray[0].length > integralMaxLen) {
//			stErr.append("<p>" + rowPos + "行目 " + (cellPos+1) + "列　" + cellName + 
//			"には小数点が2つ以上有ります。</p>");
			stErr.append(MessageManager.getMessage('TOMS.COMMON.MAINTENANCE.CSV.ERROR.DIGITS.MESSAGE', String(rowPos), String(cellPos+1), String(cellName)));
			return false;
		}
	}

	// 整数部
	if(tmpDigitsArray.length > 0) {
		if(tmpDigitsArray[0].length > integralMaxLen) {
//			stErr.append("<p>" + rowPos + "行目 " + (cellPos+1) + "列　" + cellName + 
//			"の整数部は" + integralMaxLen + "桁を超えています。</p>");
			stErr.append(MessageManager.getMessage('TOMS.COMMON.MAINTENANCE.CSV.ERROR.DIGITS.INT.LENGTH.MESSAGE', String(rowPos), String(cellPos+1), String(cellName), String(integralMaxLen)));
			ret = false;
		}
	}

	// 少数部
	if(tmpDigitsArray.length > 1) {
		if(tmpDigitsArray[1].length > fractionalMaxLen) {
//			stErr.append("<p>" + rowPos + "行目 " + (cellPos+1) + "列　" + cellName + 
//			"の少数部は" + fractionalMaxLen + "桁を超えています。</p>");
			stErr.append(MessageManager.getMessage('TOMS.COMMON.MAINTENANCE.CSV.ERROR.DIGITS.FRCT.LENGTH.MESSAGE', String(rowPos), String(cellPos+1), String(cellName), String(fractionalMaxLen)));
			ret = false;
		}
	}

	return ret;
}

/**
 * 数値チェック
 * @param v 値(対象文字列)
 * @param rowPos 行位置
 * @param cellPos 列位置
 * @param cellName 列名
 * @param stErr エラーメッセージパラメータ.(OUT)
 * @return エラー時 false
 */
CsvCheker.isNum = function (v, rowPos, cellPos, cellName, stErr ) {

	if(v == null || v == "") {
		return true;
	}

	var tmp = Number(v);
	if(isNaN(tmp)) {
//		stErr.append("<p>" + rowPos + "行目 " + (cellPos+1) + "列　" + cellName + 
//			"には数値を設定して下さい。<\p>");
		stErr.append(MessageManager.getMessage('TOMS.COMMON.MAINTENANCE.CSV.ERROR.NUMBER.MESSAGE', String(rowPos), String(cellPos+1), String(cellName)));
		return false;
	}
	return true;
}

/**
 * 半角英数字チェック
 * @param v 値(対象文字列)
 * @param rowPos 行位置
 * @param cellPos 列位置
 * @param cellName 列名
 * @param stErr エラーメッセージパラメータ.(OUT)
 * @return エラー時 false
 */
CsvCheker.isAlphanumeric = function (v, rowPos, cellPos, cellName, stErr) {

	if (v == null || v == "") {
		return true;
	}

	// 正規表現による英数字チェック（半角英数字以外の文字が存在する場合はエラー）
	if (v.match(/[^A-Za-z0-9]+/)) {
		stErr.append(MessageManager.getMessage('TOMS.COMMON.MAINTENANCE.CSV.ERROR.ALPHANUMERIC.MESSAGE', String(rowPos), String(cellPos+1), String(cellName)));
		return false;
	}
	return true;
}

/**
 * 日付チェック
 * @param v 値(対象文字列)
 * @param rowPos 行位置
 * @param cellPos 列位置
 * @param cellName 列名
 * @param stErr エラーメッセージパラメータ.(OUT)
 * @return エラー時 false
 */
CsvCheker.isDate = function isDate(v, rowPos, cellPos, cellName, stErr ) {

	if(v == null || v == "") {
		return true;
	}

    // 正規表現による書式チェック
    if(!v.match(/^\d{4}\/\d{1,2}\/\d{1,2}$/)){
//    	stErr.append("<p>" + rowPos + "行目 " + (cellPos+1) + "列　" + cellName + 
//		"はyyyy/mm/dd形式で設定して下さい。</p>");
    	stErr.append(MessageManager.getMessage('TOMS.COMMON.MAINTENANCE.CSV.ERROR.DATE.FORMAT.MESSAGE', String(rowPos), String(cellPos+1), String(cellName)));
        return false;
    }

    // エラー文言
//  var est = "<p>" + rowPos + "行目 " + (cellPos+1) + "列　" + cellName + "は正しい日付の値を設定して下さい。</p>";
    var est = MessageManager.getMessage('TOMS.COMMON.MAINTENANCE.CSV.ERROR.DATE.MESSAGE', String(rowPos), String(cellPos+1), String(cellName));

    var ymd = v.split("/");
    var vYear = ymd[0] - 0;
    var vMonth = ymd[1]  - 1; // Javascriptは、0-11で表現
    var vDay = ymd[2] - 0;
    // 月,日の妥当性チェック
    if(vMonth >= 0 && vMonth <= 11 && vDay >= 1 && vDay <= 31){
        var vDt = new Date(vYear, vMonth, vDay);
        if(isNaN(vDt)){
        	stErr.append(est);
            return false;
        }else if(vDt.getFullYear() == vYear && vDt.getMonth() == vMonth && vDt.getDate() == vDay){
            return true;
        }else{
        	stErr.append(est);
            return false;
        }
    }else{
    	stErr.append(est);
        return false;
    }
}

/**
 * 時刻チェック
 * @param v 値(対象文字列)
 * @param rowPos 行位置
 * @param cellPos 列位置
 * @param cellName 列名
 * @param stErr エラーメッセージパラメータ.(OUT)
 * @return エラー時 false
 */
CsvCheker.isTime = function (v, rowPos, cellPos, cellName, stErr ) {

	if(v == null || v == "") {
		return true;
	}
	
	// TODO 要仕様
	return true;

//			    // 正規表現による書式チェック
//			    if(!v.match(/^\d{4}\/\d{1,2}\/\d{1,2}$/)){
//			    	stErr.append(rowPos + "行目 " + cellPos + "列　" + cellName + 
//					"はyyyy/mm/dd形式で設定して下さい。\n");
//			        return false;
//			    }
//
//			    // エラー文言
//			    var est = rowPos + "行目 " + cellPos + "列　" + cellName + "は正しい日付の値を設定して下さい。\n"
//
//			    var ymd = v.split("/");
//			    var vYear = ymd[0] - 0;
//			    var vMonth = ymd[1]  - 1; // Javascriptは、0-11で表現
//			    var vDay = ymd[2] - 0;
//			    // 月,日の妥当性チェック
//			    if(vMonth >= 0 && vMonth <= 11 && vDay >= 1 && vDay <= 31){
//			        var vDt = new Date(vYear, vMonth, vDay);
//			        if(isNaN(vDt)){
//			        	stErr.append(est);
//			            return false;
//			        }else if(vDt.getFullYear() == vYear && vDt.getMonth() == vMonth && vDt.getDate() == vDay){
//			            return true;
//			        }else{
//			        	stErr.append(est);
//			            return false;
//			        }
//			    }else{
//			    	stErr.append(est);
//			        return false;
//			    }
}

//----加工見積　素材マスタメンテナンスで使用

/**
 * 親商品形態コードチェック
 * @param v 値(対象文字列)
 * @param rowPos 行位置
 * @param cellPos 列位置
 * @param cellName 列名
 * @param stErr エラーメッセージパラメータ.(OUT)
 * @return エラー時 false
 * 暗黙のルールとして、親商品形態コードは「PA」始まりとし
 * チェックを行う
 */
CsvCheker.isParentCommodityPrefix = function (v, rowPos, cellPos, cellName, stErr) {

	if (v == null || v == "") {
		return true;
	}

	// 正規表現による英数字チェック（半角英数字以外の文字が存在する場合はエラー）
	if (!v.match(/^PA/)) {
		stErr.append(MessageManager.getMessage('TOMS.COMMON.MAINTENANCE.CSV.ERROR.PARENT_COMMODITY.FORMAT.MESSAGE', String(rowPos), String(cellPos+1), String(cellName)));
		return false;
	}
	return true;
}

/**
 * 商品形態コードチェック
 * @param v 値(対象文字列)
 * @param rowPos 行位置
 * @param cellPos 列位置
 * @param cellName 列名
 * @param stErr エラーメッセージパラメータ.(OUT)
 * @return エラー時 false
 * 暗黙のルールとして、商品形態コードは「CH」始まりとし
 * チェックを行う
 */
CsvCheker.isCommodityPrefix = function (v, rowPos, cellPos, cellName, stErr) {

	if (v == null || v == "") {
		return true;
	}

	// 正規表現による英数字チェック（半角英数字以外の文字が存在する場合はエラー）
	if (!v.match(/^CH/)) {
		stErr.append(MessageManager.getMessage('TOMS.COMMON.MAINTENANCE.CSV.ERROR.COMMODITY.FORMAT.MESSAGE', String(rowPos), String(cellPos+1), String(cellName)));
		return false;
	}
	return true;
}

/**
 * 素材コードチェック
 * @param v 値(対象文字列)
 * @param rowPos 行位置
 * @param cellPos 列位置
 * @param cellName 列名
 * @param stErr エラーメッセージパラメータ.(OUT)
 * @return エラー時 false
 * 暗黙のルールとして、素材コードは「MA」始まりとし
 * チェックを行う
 */
CsvCheker.isMaterialPrefix = function (v, rowPos, cellPos, cellName, stErr) {

	if (v == null || v == "") {
		return true;
	}

	// 正規表現による英数字チェック（半角英数字以外の文字が存在する場合はエラー）
	if (!v.match(/^MA/)) {
		stErr.append(MessageManager.getMessage('TOMS.COMMON.MAINTENANCE.CSV.ERROR.MATERIAL.FORMAT.MESSAGE', String(rowPos), String(cellPos+1), String(cellName)));
		return false;
	}
	return true;
}

/**
 * 加工部位コードチェック
 * @param v 値(対象文字列)
 * @param rowPos 行位置
 * @param cellPos 列位置
 * @param cellName 列名
 * @param stErr エラーメッセージパラメータ.(OUT)
 * @return エラー時 false
 * 暗黙のルールとして、加工部位コードは「P1」始まりとし
 * チェックを行う
 */
CsvCheker.isProcessPartPrefix = function (v, rowPos, cellPos, cellName, stErr) {

	if (v == null || v == "") {
		return true;
	}

	// 正規表現による英数字チェック（半角英数字以外の文字が存在する場合はエラー）
	if (!v.match(/^P1/)) {
		stErr.append(MessageManager.getMessage('TOMS.COMMON.MAINTENANCE.CSV.ERROR.PROCESS_PART.FORMAT.MESSAGE', String(rowPos), String(cellPos+1), String(cellName)));
		return false;
	}
	return true;
}

/**
 * 加工位置コードチェック
 * @param v 値(対象文字列)
 * @param rowPos 行位置
 * @param cellPos 列位置
 * @param cellName 列名
 * @param stErr エラーメッセージパラメータ.(OUT)
 * @return エラー時 false
 * 暗黙のルールとして、加工位置コードは「P2」始まりとし
 * チェックを行う
 */
CsvCheker.isProcessPositionPrefix = function (v, rowPos, cellPos, cellName, stErr) {

	if (v == null || v == "") {
		return true;
	}

	// 正規表現による英数字チェック（半角英数字以外の文字が存在する場合はエラー）
	if (!v.match(/^P2/)) {
		stErr.append(MessageManager.getMessage('TOMS.COMMON.MAINTENANCE.CSV.ERROR.PROCESS_POSITION.FORMAT.MESSAGE', String(rowPos), String(cellPos+1), String(cellName)));
		return false;
	}
	return true;
}
