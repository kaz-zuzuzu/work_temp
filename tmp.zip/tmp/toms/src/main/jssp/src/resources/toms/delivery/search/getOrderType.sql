/*
 * オーダータイププルダウン生成SQL
 * 
 */
	select 
	 TRIM(DRKY) AS value,
   TRIM(DRKY) AS label
	from F0005
	where DRSY = '57A'
     and TRIM(DRRT) = '02'
     order by value desc 