select AB.ABAN8                                                 as torihikisakicd                -- 取引先コード
     ,TRIM(AB.ABALPH                                          ) as torihikisakimei               -- 取引先名
     ,TRIM(AB.ABALP1                                          ) as torihikisakikana              -- 取引先カナ
     ,TRIM(MC.MCRP03                                          ) as jigyosyocd                    -- 上位組織コード
     ,TRIM(DR_RP03.DRDL01                                     ) as jigyosyomei                   -- 上位組織名
     ,TRIM(AB.ABMCU                                           ) as sosikicd                      -- 組織コード
     ,TRIM(MC.MCDL01                                          ) as sosikimei                     -- 組織名
     ,TRIM(AL.ALADD1                                          ) as jyusyo1                       -- 住所１
     ,TRIM(AL.ALADD2                                          ) as jyusyo2                       -- 住所２
     ,TRIM(AL.ALADD3                                          ) as jyusyo3                       -- 住所３
     ,TRIM(AL.ALADD4                                          ) as jyusyo4                       -- 住所４
     ,TRIM(AL.ALADDZ                                          ) as yuubinbangou                  -- 郵便番号
     ,TRIM(AI.AICPGP                                          ) as kakakurankcd                  -- 価格ランクコード
     ,TRIM(DR_AICPGP.DRDL01                                   ) as kakakurankmei                 -- 価格ランク
     ,AB.ABAN84                                          	    as eigyoutantousyacd             -- 営業担当者CD
     ,TRIM(WW_ABAN84.WWALPH                                   ) as eigyoutantousyamei            -- 営業担当者
     ,TRIM(AB.ABAC29                                          ) as bunrui1cd                     -- 分類１コード
     ,TRIM(DR_ABAC29.DRDL01                                   ) as bunrui1mei                    -- 分類１名
     ,TRIM(AB.ABAC30                                          ) as bunrui2cd                     -- 分類２コード
     ,TRIM(DR_ABAC30.DRDL01                                   ) as bunrui2mei                    -- 分類２
     ,TRIM(AB.ABAC23                                          ) as bunrui3cd                     -- 分類３
     ,TRIM(DR_ABAC23.DRDL01                                   ) as bunrui3mei                    -- 分類３コード
     ,TRIM(AB.ABAC10                                          ) as shimebicd                     -- 締日コード
     ,TRIM(DR_ABAC10.DRDL01                                   ) as shimebimei                    -- 締日
     ,TRIM(WPT1.WPPH1                                         ) as phone                         -- 電話番号代表
     ,TRIM(WPF1.WPPH1                                         ) as fax                           -- FAX番号代表
     ,TRIM(AI.AITRAR                                          ) as shiharaijyokencd              -- 支払条件コード
     ,TRIM(PN.PNPTD                                           ) as torihikijyouken                 -- 取引条件
     ,CASE WHEN TRIM(AB.ABTAX) IS NULL THEN '無' ELSE '有' END 	as factoringumu					 --ファクタリング有無
	 ,TRIM(MA.MAURRF 										  )	as shiharaijouken            	　--支払条件
     ,TRIM(TO_CHAR(AI.AIACL,  '999G999G999G999'              )) as yoshingendogaku               -- 与信限度額
     ,TRIM(AB.ABAT1                                           ) as searchtypecd                  -- 検索タイプCD
     ,TRIM(DR_ABAT1.DRDL01                                    ) as searchtypemei                 -- 検索タイプ名
     ,CASE WHEN TK.CNT IS NULL THEN 'なし' ELSE '有り' END			as tokukaumu-- 特価有無
     ,CASE WHEN TKI.CNT IS NULL THEN 'なし' ELSE '有り' END		as tokukijikou-- 特記事項
     ,'送付先一覧' as sendlist             -- 送付先

FROM -- 【マスタテーブル】 -------------------------------
     F0101 AB -- 住所録
     INNER JOIN F0111 WW -- 住所録（人名録） 
        ON AB.ABAN8  = WW.WWAN8
       AND WW.WWIDLN = 0
     LEFT OUTER JOIN F0116 AL -- 住所録（住所）
        ON AB.ABAN8  = AL.ALAN8
     LEFT OUTER JOIN F03012 AI -- 顧客マスタ
        ON AB.ABAN8  = AI.AIAN8
       AND AI.AICO   = '00000'
     -------- 住所録（代表電話） ---------------------------------
     LEFT OUTER JOIN F0115 WPT1
        ON AB.ABAN8  = WPT1.WPAN8
       AND WW.WWIDLN = WPT1.WPIDLN
       AND WPT1.WPCNLN = 0
       AND TRIM(WPT1.WPPHTP) = 'TEL1'
     -------- 住所録（代表FAX） ---------------------------------
     LEFT OUTER JOIN F0115 WPF1
        ON AB.ABAN8  = WPF1.WPAN8
       AND WW.WWIDLN = WPF1.WPIDLN
       AND WPF1.WPCNLN = 0
       AND TRIM(WPF1.WPPHTP) = 'FAX1'
     -------- 検索タイプ ---------------------------------
     LEFT OUTER JOIN F0005 DR_ABAT1
        ON TRIM(AB.ABAT1) = TRIM(DR_ABAT1.DRKY)
       AND DR_ABAT1.DRSY          = '01  '
       AND DR_ABAT1.DRRT          = 'ST'
     -------- 販売部門、上位組織 -------------------------
     LEFT OUTER JOIN F0006 MC
        ON TRIM(AB.ABMCU) = TRIM(MC.MCMCU)
     LEFT OUTER JOIN F0005 DR_RP03
        ON TRIM(MC.MCRP03) = TRIM(DR_RP03.DRKY)
       AND DR_RP03.DRSY            = '00  '
       AND DR_RP03.DRRT            = '03'
     -------- 営業担当者 ---------------------------------
     LEFT OUTER JOIN F0111 WW_ABAN84
        ON AB.ABAN84 = WW_ABAN84.WWAN8
       AND WW_ABAN84.WWIDLN        = 0
     -------- 顧客分類コード1 ----------------------------
     LEFT OUTER JOIN F0005 DR_ABAC29
        ON TRIM(AB.ABAC29) = TRIM(DR_ABAC29.DRKY)
       AND DR_ABAC29.DRSY          = '01  '
       AND DR_ABAC29.DRRT          = '29'
     -------- 顧客分類コード2 ----------------------------
     LEFT OUTER JOIN F0005 DR_ABAC30
        ON TRIM(AB.ABAC30) = TRIM(DR_ABAC30.DRKY)
       AND DR_ABAC30.DRSY          = '01  '
       AND DR_ABAC30.DRRT          = '30'
     -------- 顧客分類コード3 ----------------------------
     LEFT OUTER JOIN F0005 DR_ABAC23
        ON TRIM(AB.ABAC23) = TRIM(DR_ABAC23.DRKY)
       AND DR_ABAC23.DRSY          = '01  '
       AND DR_ABAC23.DRRT          = '23'
     -------- 顧客価格グループランク ---------------------
     LEFT OUTER JOIN F0005 DR_AICPGP
        ON TRIM(AI.AICPGP) = TRIM(DR_AICPGP.DRKY)
       AND DR_AICPGP.DRSY          = '40  '
       AND DR_AICPGP.DRRT          = 'PC'
     -------- 販売先締め日 -------------------------------
     LEFT OUTER JOIN F0005 DR_ABAC10
        ON TRIM(AB.ABAC10) = TRIM(DR_ABAC10.DRKY)
       AND DR_ABAC10.DRSY          = '01  '
       AND DR_ABAC10.DRRT          = '10'
     -------- 取引条件 -----------------------------------
     LEFT OUTER JOIN F0014 PN
        ON TRIM(AI.AITRAR) = TRIM(PN.PNPTC)
     -------- 支払条件 -----------------------------------
     LEFT OUTER JOIN F56C1030 MA
     	ON AB.ABAN8 = MA.MAPYR
     -------- 特価有無 -----------------------------------
     LEFT OUTER JOIN (SELECT COUNT(1) CNT
                            ,TKT.MAAN8
                      FROM (SELECT MAAN8
                                  ,MA.MAEFTJ
--                                  ,DENSE_RANK() OVER (PARTITION BY MA.MAAN8,MA.MALITM ORDER BY MA.MAEFTJ DESC) RNK
                            FROM F57A5010 MA
--                            WHERE MA.MAAN8 <> 0 ) TKT
                            WHERE MA.MAAN8 <> 0
                            AND   MA.MAEFTJ <= FC_JDI9902_TO_JULIAN(SYSDATE) ) TKT
--                      WHERE FC_JDI9902_TO_DATE(TKT.MAEFTJ) <= SYSDATE
--                      AND   TKT.RNK = 1
                      GROUP BY TKT.MAAN8) TK 
        ON TK.MAAN8 = AB.ABAN8
     -------- 特記事項 -----------------------------------
	 LEFT OUTER JOIN (SELECT COUNT(1) CNT
	 						,TKK.MGAN8
  					  FROM (SELECT MGAN8
                			FROM F57A5070 MG) TKK
                   	  GROUP BY TKK.MGAN8) TKI
        ON AB.ABAN8 = TKI.MGAN8 
WHERE TRIM(AB.ABAT1) IN /*exchangeCategoryCd*/('1A','1B')            --取引種別
/*IF exchangeTargetId != null*/
AND AB.ABAN8 = /*exchangeTargetId*/'11002230'                        --取引先コード
/*END*/
/*IF organizationCd != null*/
AND TRIM(AB.ABMCU) IN /*organizationCd*/('101', '102')               --組織
/*END*/
/*IF bunrui1Cd != null*/
AND AB.ABAC29 = /*bunrui1Cd*/'010'                             --分類１
/*END*/
/*IF notinBunrui1Cd != null*/
AND AB.ABAC29 NOT IN /*notinBunrui1Cd*/('070', '080')          --除外の分類1
/*END*/
/*IF bunrui2Cd != null*/
AND TRIM(AB.ABAC30)  IN /*bunrui2Cd*/('008', '700', '800')           --分類２
/*END*/
/*IF chargePersonCd != null*/
AND AB.ABAN84 = /*chargePersonCd*/'90037500'                         --担当者コード
/*END*/
/*IF chargePersonNm != null*/
AND TRIM(WW_ABAN84.WWALP1) LIKE /*chargePersonNm*/'%ﾄﾐｵｶ%'           --担当者
/*END*/
/*IF todoufukenCd != null*/
AND TRIM(AL.ALADDS) = /*todoufukenCd*/'27'                           --都道府県コード
/*END*/
/*IF exchangeTargetKn != null*/
AND TRIM(AB.ABALP1) LIKE /*exchangeTargetKn*/'%ｼｮｳｺｳ%'               -- 取引先カナ
/*END*/
/*IF telNo != null*/
AND TRIM(REPLACE(TRIM(WPT1.WPPH1), '-', '')) = /*telNo*/'0662311171' -- 電話番号
/*END*/
/*IF faxNo != null*/
AND TRIM(REPLACE(TRIM(WPF1.WPPH1), '-', '')) = /*faxNo*/'0662311172' -- FAX番号
/*END*/
ORDER BY torihikisakicd



