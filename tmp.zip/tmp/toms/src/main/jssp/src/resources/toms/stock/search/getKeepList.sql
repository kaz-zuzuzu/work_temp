SELECT DISTINCT
  CASE WHEN TRUNC(fc_jdi9902_to_date(F57A0030.TCPDDJ)) <= TRUNC(NY.MIN_DD1) THEN '実在庫' ELSE '入荷予定' END AS KEEPTYPE --キープ対象
  ,TRIM(F57A0030.TCMCU)                                      AS TAMCU                                 --事業所
  ,sub_tbl.TAY57AOSTS                                        AS TAY57AOSTS                         --オーダーステータス
  ,sub_tbl.DRDL01                                            AS OSTS_DRDL01                        --オーダーステータス名
  ,NVL(sub_tbl2.TEY57ASOQS, F57A0030.TCY57AKRQT)             AS TCY57AKRQT                       --キープ残数量
  ,sub_tbl.TADOCO                                            AS TCDOCO                               --オーダーNo
  ,F57A0030.TCY57AKPNO                                       AS TCY57AKPNO                       --キープNo
  ,DECODE(sub_tbl.TAY57ATRDJ, NULL, NULL,  TO_CHAR(sub_tbl.TAY57ATRDJ, 'FMYYYY/MM/DD'))   AS TAY57ATRDJ                   --受注(予定)日  
  ,DECODE(F57A0030.TCPDDJ, NULL, NULL,  TO_CHAR(FC_JDI9902_TO_DATE(F57A0030.TCPDDJ), 'FMYYYY/MM/DD'))   AS TAY57APDDJ                    --ボディ出庫日(受注)
  ,DECODE(F57A0030.TCPDDJ, NULL, NULL,  TO_CHAR(FC_JDI9902_TO_DATE(F57A0030.TCPDDJ), 'YYYY/MM/DD'))   AS TAY57APDDJ_SORT                    --ボディ出庫日(受注)ソート用
  ,DECODE(sub_tbl2.TEDRQJ, NULL, NULL,  TO_CHAR(sub_tbl2.TEDRQJ, 'FMYYYY/MM/DD'))         AS TEDRQJ                       --納期
  ,sub_tbl2.TDY57ASHPN                   AS TDY57ASHPN                    --出荷予定No
  ,DECODE(sub_tbl2.PDDJ, NULL, NULL,  TO_CHAR(sub_tbl2.PDDJ, 'FMYYYY/MM/DD'))             AS TDY57APDDJ                    -- ボディ出庫日（出荷）
  ,sub_tbl2.STSN                       AS ESTS_DRDL01                     --出荷予定ステータス
  ,sub_tbl.ABALPH2                     AS ABALPH_AN8                      -- 販売先名
  ,sub_tbl.MCDL01                      AS MCDL01_EMCU                     --販売部門
  ,F0101_eigyo.ABALPH                  AS ABALPH_S                        --営業担当者名
  ,sub_tbl.ABALPH3                     AS ABALPH_O                        -- オーダー入力者名
  ,sub_tbl.TAY57AHRMK                  AS TAY57AHRMK                      --柄名
  ,sub_tbl.TBY57ADORM                  AS TBY57ADORM                      --受注メモ
  ,sub_tbl.TADCTO                      AS TADCTO                          -- オーダータイプ
  ,sub_tbl.TBY57ABODY                  AS TBY57ABODY                          -- ボディ区分
FROM 
    F57A0030   -- キープ明細
    ,(SELECT IM.IMLITM
       FROM F41021 LI --品目保管場所
           ,F4100 LM --ロケーションマスタ
           ,F4101 IM   -------- 別注品購買業者、商品名、商品略名、商品分類1・2
      WHERE LI.LIMCU   = LM.LMMCU
        AND LI.LILOCN  = LM.LMLOCN
        AND LI.LIITM   = IM.IMITM
        /*IF stockPositionCode != null*/
        AND LI.LIMCU = LPAD(/*stockPositionCode*/'1000', 12)
        /*END*/
        /*IF stockCode == "3000" */
        AND  SUBSTR(IM.IMLITM,11,2) <> '  '
        /*END*/
        /*IF storePositionCode != null*/
        AND DECODE(LENGTH(TRIM(LI.LILOCN)), 15,SUBSTR(LI.LILOCN,1,3),TRIM(LI.LILOCN)) = /*storePositionCode*/'001'
        /*END*/
        /*IF stockCode == "1000" && storePositionCode == null*/
        AND (DECODE(LENGTH(TRIM(LI.LILOCN)), 15, SUBSTR(TRIM(LI.LILOCN),1,3), TRIM(LI.LILOCN)) <> '200'
          OR DECODE(LENGTH(TRIM(LI.LILOCN)), 15, SUBSTR(TRIM(LI.LILOCN),1,3), TRIM(LI.LILOCN)) <> '201'
          OR DECODE(LENGTH(TRIM(LI.LILOCN)), 15, SUBSTR(TRIM(LI.LILOCN),1,3), TRIM(LI.LILOCN)) <> '202')
        /*END*/
        /*IF stockCode != "1000" && storePositionCode == null && stockCategory != null*/
        AND LM.LMBIN = RPAD(/*stockCategory*/'900', 8)
        /*END*/
        /*IF stockCode == "1000" && storePositionCode == null && stockCategory == null*/
        AND LM.LMKZON = RPAD('1', 6)
        /*END*/
        /*IF stockCode == "1000" && storePositionCode == null && stockCategory != null*/
        AND LM.LMKZON <> RPAD('1', 6)
        AND LM.LMBIN = RPAD(/*stockCategory*/'900', 8)
        /*END*/
     ) IM
   ,(SELECT
          TQ.TQY57BLITM  LITM          -- 第2品目番号 
         ,TP.TPY57BRMCU  MCU           -- 事業所 
         ,MIN(TO_DATE(TP.TPY57BRDD1))  MIN_DD1  -- 入荷予定日1 
      FROM 
          F57B0010 TP    -- 入荷予定見出し 
         ,F57B0020 TQ    -- 入荷予定明細 
      WHERE 
          TP.TPY57BRCNO       = TQ.TQY57BRCNO 
      AND TRIM(TP.TPY57BRMCU) = '1000'
      AND (TRIM(TP.TPY57BRLCN) <> '216'
      OR TRIM(TP.TPY57BRLCN) IS NULL)
      AND TP.TPY57BOSTS < '499' 
      AND TP.TPY57BRDD1 >= TRUNC(SYSDATE)
--見せ数に変更↓
      AND TQ.TQY57BUREC > 0
--品番
    /*IF skuCode != null*/
      AND TRIM(TQ.TQY57BLITM) = /*skuCode*/'010016900502'
    /*END*/
      GROUP BY 
          TQ.TQY57BLITM           -- 第2品目番号 
         ,TP.TPY57BRMCU           -- 事業所 
    ) NY 
   ,(SELECT
         TAY57AOSTS                 -- オーダーステータス
        ,FC_JDI9902_TO_DATE(TAY57ATRDJ) AS   TAY57ATRDJ               --受注(予定)日
        ,FC_JDI9902_TO_DATE(TAY57APDDJ)  AS  TAY57APDDJ                    --ボディ出庫日(受注)
        ,UDC2.DRDL01    AS  TBY57ABODY                    --ボディ区分
        ,UDC1.DRDL01                -- オーダーステータス名 
        ,TAAN8                      -- 販売先コード
        ,F0101_hanbai.ABALPH AS ABALPH2  -- 販売先名
        ,TAEMCU                          -- 販売部門コード
        ,MC.MCDL01                   AS MCDL01        -- 販売部門名
        ,TAY57AOPPN                      -- オーダー入力者コード
        ,F0101_order.ABALPH AS ABALPH3   -- オーダー入力者名
        ,TAY57AORMK                 -- 受注内容
        ,TBY57ADORM                 -- 受注メモ
        ,TAY57AHRMK                 -- 柄名
        ,TBUPRC                     -- 受注単価
        ,TBAEXP                     -- 受注金額
        ,TAKCOO                     -- オーダー会社
        ,TADOCO                     -- オーダー№
        ,TADCTO                     -- オーダータイプ
        ,CASE
           WHEN TRIM(TADCTO) = 'SW' THEN '1'       -- Web Shopping
           WHEN TRIM(TADCTO) = 'SE' THEN '2'       -- EDI
           WHEN TRIM(TADCTO) = 'SF' THEN '3'       -- 無地受注
           WHEN TRIM(TADCTO) = 'SP' THEN '4'       -- 加工受注
           WHEN TRIM(TADCTO) IS NULL THEN '5'      -- 譲渡
           ELSE ''
         END OTSK                   -- オーダータイプソートキー
        ,TBLNID                     -- 明細行番号
     FROM
        F57A0010         -- 受注ヘッダ
       ,F57A0011         -- 受注明細
       ,F0101    F0101_hanbai -- 住所録(販売先コード)
       ,F0101    F0101_order -- 住所録(オーダー入力者コード)
       ,F0006    MC
       ,(SELECT DRKY, DRDL01 FROM F0005 WHERE  DRSY = '57A' AND DRRT = '01') UDC1 --UDC(オーダーステータス)
       ,(SELECT DRKY, DRDL01 FROM F0005 WHERE  DRSY = '57A' AND DRRT = '03') UDC2 --UDC(ボディ区分)
     WHERE
         F57A0010.TAAN8        = F0101_hanbai.ABAN8(+)   -- [外部結合]受注ヘッダ←住所録(販売先コード)
     AND F57A0010.TAY57AOPPN   = F0101_order.ABAN8(+)    -- [外部結合]受注ヘッダ←住所録(オーダー入力者コード)
     AND F57A0010.TAKCOO       = F57A0011.TBKCOO(+)      -- [外部結合]受注ヘッダ←受注明細
     AND F57A0010.TADOCO       = F57A0011.TBDOCO(+)      -- [外部結合]受注ヘッダ←受注明細
     AND F57A0010.TADCTO       = F57A0011.TBDCTO(+)      -- [外部結合]受注ヘッダ←受注明細
     AND F57A0010.TAEMCU       = MC.MCMCU(+)      -- [外部結合]受注ヘッダ←販売部門
     AND TRIM(F57A0010.TAY57AOSTS)   = TRIM(UDC1.DRKY(+))    -- [外部結合]受注ヘッダ←UDC1(オーダーステータス)
     AND TRIM(F57A0011.TBY57ABODY)   = TRIM(UDC2.DRKY(+))    -- [外部結合]受注ヘッダ←UDC1(オーダーステータス)
--品番
    /*IF skuCode != null*/
      AND TRIM(F57A0011.TBLITM) = /*skuCode*/'010016900502'
    /*END*/
   ) sub_tbl
    ,(SELECT
          TDY57ASHPN                 -- 出荷予定No
         ,TDY57ASHPS                 -- 出荷予定ステータス
         ,UDC3.DRDL01 AS STSN        -- オーダーステータス名 
         ,fc_jdi9902_to_date(F57A0071.TEY57APDDJ) AS PDDJ  -- ボディ出庫日
         ,fc_jdi9902_to_date(TEDRQJ) AS TEDRQJ             -- 納期
         ,TEY57ASOQS    AS TEY57ASOQS                     -- 出荷数量
         ,TRIM(TEMCU) TEMCU          -- 事業所
         ,TDY57ASHPF                 -- 出荷予定区分
         ,TEKCOO                     -- 受注会社ｺｰﾄﾞ
         ,TEDOCO                     -- 受注NO
         ,TEDCTO                     -- 受注タイプ
         ,TELNID                     -- 受注行No
      FROM
         F57A0070         -- 出荷予定ヘッダ
        ,F57A0071         -- 出荷予定明細
        ,(SELECT DRKY, DRDL01 FROM F0005 WHERE  DRSY = '57A' AND DRRT = '05') UDC3 --UDC(オーダーステータス)
      WHERE
          F57A0070.TDY57ASHPN   = F57A0071.TEY57ASHPN(+)      -- [外部結合]出荷予定ヘッダ←出荷予定明細
      AND F57A0070.TDY57ASDCT   = F57A0071.TEY57ASDCT(+)      -- [外部結合]出荷予定ヘッダ←出荷予定明細
      AND TRIM(F57A0070.TDY57ASHPS)   = TRIM(UDC3.DRKY(+))            -- [外部結合]出荷予定ヘッダ←UDC1(オーダーステータス)
--品番
    /*IF skuCode != null*/
      AND TRIM(F57A0071.TELITM) = /*skuCode*/'010016900502'
    /*END*/
      AND F57A0070.TDY57ASHPS <> '999'
      AND TRIM(F57A0071.TEMCU) = '1000'
      AND F57A0071.TEY57ASDCT <> 'XP'
    ) sub_tbl2
   ,F0101    F0101_eigyo -- 住所録(営業担当者コード)
   ,(SELECT DRKY, DRDL01 FROM F0005 WHERE  DRSY = '00' AND DRRT = 'DT') UDC2 -- UDC(伝票タイプ※オーダータイプ)
  WHERE
      TRIM(TCY57AKPST) IS NULL
  AND TRIM(TCY57ASTKF) IS NULL
--品番
    /*IF skuCode != null*/
      AND TRIM(F57A0030.TCLITM) = /*skuCode*/'010016900502'
    /*END*/
  AND F57A0030.TCLITM     = IM.IMLITM(+)
  AND F57A0030.TCLITM     = NY.LITM(+)
  AND F57A0030.TCDOCO     = sub_tbl.TADOCO(+)       -- [外部結合]キープ明細←受注sub_tbl
  AND F57A0030.TCDCTO     = sub_tbl.TADCTO(+)       -- [外部結合]キープ明細←受注sub_tbl
  AND F57A0030.TCKCOO     = sub_tbl.TAKCOO(+)       -- [外部結合]キープ明細←受注sub_tbl
  AND F57A0030.TCLNID     = sub_tbl.TBLNID(+)       -- [外部結合]キープ明細←受注sub_tbl
  AND F57A0030.TCDOCO     = sub_tbl2.TEDOCO(+)       -- [外部結合]キープ明細←出荷予定sub_tbl
  AND F57A0030.TCDCTO     = sub_tbl2.TEDCTO(+)       -- [外部結合]キープ明細←出荷予定sub_tbl
  AND F57A0030.TCKCOO     = sub_tbl2.TEKCOO(+)       -- [外部結合]キープ明細←出荷予定sub_tbl
  AND F57A0030.TCLNID     = sub_tbl2.TELNID(+)       -- [外部結合]キープ明細←出荷予定sub_tbl
  AND TRIM(F57A0030.TCDCTO)     = TRIM(UDC2.DRKY(+))   -- [外部結合]キープ明細←UDC2(伝票タイプ※オーダータイプ)
  AND F57A0030.TCY57ABPSN = F0101_eigyo.ABAN8(+)    -- [外部結合]キープ明細←住所録(営業担当者コード)
ORDER BY
    KEEPTYPE
--    ,TAY57APDDJ
    ,TAY57APDDJ_SORT
    ,TAY57AOSTS
    ,TCDOCO