SELECT
 NVL(TRIM(mc.mcmcu), ' ') AS value,
 DECODE(TRIM(mc.mcmcu), NULL, '（全組織）', TRIM(mc.mcdc)) AS label
FROM
 f0005 dr_rp03,
 f0006 mc
WHERE
 dr_rp03.drsy = '00  '
AND
 dr_rp03.drrt = '03'
AND
 TRIM(mc.mcrp03) = TRIM(dr_rp03.drky)
ORDER  BY value ASC NULLS FIRST