SELECT DISTINCT
       AL.NAME
      ,AL.CAPTION
      ,AL.DRSPHD 
  FROM (/********************************
         **  実在庫からの商品リスト 
         ********************************/
        SELECT        'c1' || SUBSTR(TRIM(IM.IMLITM),11,2)          AS NAME --サイズコード
                      ,TRIM(DR_SZ.DRDL01)                           AS CAPTION --サイズ
                      ,NVL(TRIM(DR_SZ.DRSPHD), '0')                 AS DRSPHD --順番
                  FROM -- 【トランザクションテーブル】 ---------------------
                       F41021 LI --品目保管場所
                       INNER JOIN F4100 LM --ロケーションマスタ
                          ON LI.LIMCU   = LM.LMMCU
                         AND LI.LILOCN  = LM.LMLOCN
                       -------- 別注品購買業者、商品名、商品略名、商品分類1・2
                       INNER JOIN F4101 IM
                          ON LI.LIITM = IM.IMITM
                       -------- サイズ名 -----------------------------
                       INNER JOIN F0005 DR_SZ
                          ON SUBSTR(TRIM(IM.IMLITM),11,2) = TRIM(DR_SZ.DRKY)
                         AND DR_SZ.DRSY                              = '41F '
                         AND DR_SZ.DRRT                              = DECODE(SUBSTR(TRIM(IM.IMLITM),1,2),'01','1S','2S')
        WHERE
        --SUBSTR(TRIM(IM.IMLITM),11,2) IS NOT NULL
        /*BEGIN*/
        /*IF stockPositionCode != null*/
        --AND
          TRIM(LI.LIMCU) = /*stockPositionCode*/'1000'
        /*END*/
        /*IF stockCode == "3000" */
          AND  
          SUBSTR(IM.IMLITM,11,2) <> '  '
        /*END*/
        /*IF storePositionCode != null*/
        AND
          DECODE(LENGTH(TRIM(LI.LILOCN)), 15,SUBSTR(TRIM(LI.LILOCN),1,3),TRIM(LI.LILOCN)) = /*storePositionCode*/'001'
        /*END*/
        /*IF stockCode == "1000" && storePositionCode == null*/
        AND
          (DECODE(LENGTH(TRIM(LI.LILOCN)), 15, SUBSTR(TRIM(LI.LILOCN),1,3), TRIM(LI.LILOCN)) <> '200'
          OR DECODE(LENGTH(TRIM(LI.LILOCN)), 15, SUBSTR(TRIM(LI.LILOCN),1,3), TRIM(LI.LILOCN)) <> '201'
          OR DECODE(LENGTH(TRIM(LI.LILOCN)), 15, SUBSTR(TRIM(LI.LILOCN),1,3), TRIM(LI.LILOCN)) <> '202')
        /*END*/
        /*IF stockCode != "1000" && storePositionCode == null && stockCategory != null*/
        AND
          LM.LMBIN = RPAD(/*stockCategory*/'900', 8)
        /*END*/
        /*IF stockCode == "1000" && storePositionCode == null && stockCategory == null*/
        AND
          LM.LMKZON = '1'
        /*END*/
        /*IF stockCode == "1000" && storePositionCode == null && stockCategory != null*/
        AND
          LM.LMKZON <> '1'
        AND
          LM.LMBIN = RPAD(/*stockCategory*/'900', 8)
        /*END*/
        /*IF manufacturerCode != null*/
        AND
          SUBSTR(TRIM(IM.IMLITM),1,2) = /*manufacturerCode*/'01'
        /*END*/
        /*IF productCodes != null*/
        AND
          SUBSTR(TRIM(IM.IMLITM),3,5) IN /*productCodes*/('00001', '00002')
        /*END*/
        /*IF addtionNo != null*/
        AND
          TRIM(SUBSTR(TRIM(IM.IMLITM),13,2)) IS NOT NULL
        /*END*/
        /*IF addtionNo == null*/
        AND
          TRIM(SUBSTR(TRIM(IM.IMLITM),13,2)) IS NULL
        /*END*/

        UNION ALL ----------------------------------------------------------------

        /********************************
         **  入荷予定からの商品リスト 
         ********************************/
        SELECT 'c1' || SUBSTR(TRIM(IM.IMLITM),11,2)          AS NAME --サイズコード
              ,TRIM(DR_SZ.DRDL01)                           AS CAPTION --サイズ
              ,NVL(TRIM(DR_SZ.DRSPHD), '0')                 AS DRSPHD --順番
        FROM F57B0020 TQ
             INNER JOIN F57B0010 TP
                ON TQ.TQY57BRCNO = TP.TPY57BRCNO
               AND TP.TPY57BOSTS  < '499'
               AND TQ.TQY57BUREC > 0
               /*IF stockPositionCode != null*/
               AND TP.TPY57BRMCU = LPAD(/*stockPositionCode*/'1000', 12)
               /*END*/
               -- 画面引数：在庫場所が必要
               -- 216は在庫場所＝1000の時のみ設定可能
               /*IF stockCode == "1000" */
               AND (TP.TPY57BRLCN <> RPAD('216', 20)
                    OR TP.TPY57BRLCN = RPAD(' ', 20))
               /*END*/
               /*IF stockCode != "1000" */
               AND TP.TPY57BRLCN = RPAD(' ', 20)
               /*END*/
             -------- 別注品購買業者、商品名、商品略名、商品分類1・2
             INNER JOIN F4101 IM
                ON TQ.TQY57BLITM = IM.IMLITM
             -------- サイズ名 -----------------------------
             INNER JOIN F0005 DR_SZ
                ON SUBSTR(TRIM(IM.IMLITM),11,2) = TRIM(DR_SZ.DRKY)
               AND DR_SZ.DRSY                              = '41F '
               AND DR_SZ.DRRT                              = DECODE(SUBSTR(TRIM(IM.IMLITM),1,2),'01','1S','2S')
         WHERE
             SUBSTR(IM.IMLITM,11,2) IS NOT NULL
         /*IF stockCode != "1000" || (stockCode == "1000" && stockCategory != null) */
           AND 1=2
         /*END*/
         /*IF stockCode == "3000" */
           AND  
           SUBSTR(IM.IMLITM,11,2) <> '  '
         /*END*/
         /*IF manufacturerCode != null*/
         AND
           SUBSTR(IM.IMLITM,1,2) = /*manufacturerCode*/'01'
         /*END*/
         /*IF productCodes != null*/
         AND
           SUBSTR(IM.IMLITM,3,5) in /*productCodes*/('00001', '00169')
         /*END*/
         /*IF addtionNo != null*/
         AND
           TRIM(SUBSTR(IM.IMLITM,13,2)) IS NOT NULL
         /*END*/
         /*IF addtionNo == null*/
         AND
           TRIM(SUBSTR(IM.IMLITM,13,2)) IS NULL
         /*END*/
        /*END*/
       ) AL
ORDER BY
TO_NUMBER(AL.DRSPHD)
,AL.NAME