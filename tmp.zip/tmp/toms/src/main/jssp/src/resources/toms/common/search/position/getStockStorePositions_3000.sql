SELECT 
  TRIM(DRKY) AS value,
  TRIM(DRDL01) AS label
FROM
  F0005
WHERE
  DRSY = '57C '
AND
  DRRT = '06'
/*IF stockPositionCode != null*/
AND
  TRIM(DRDL02) = /*stockPositionCode*/'3000'
/*END*/
ORDER BY
value