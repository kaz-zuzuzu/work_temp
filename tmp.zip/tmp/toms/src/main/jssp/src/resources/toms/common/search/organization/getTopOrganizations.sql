SELECT 
  NVL(TRIM(drky), ' ') AS value, 
  DECODE(TRIM(drky), NULL, '（全上位組織）', TRIM(drdl01)) AS label 
FROM 
  f0005 
WHERE 
  drsy = '00  ' 
AND 
  drrt = '03' 
ORDER  BY value ASC NULLS FIRST