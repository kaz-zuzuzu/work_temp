select AL.DIV
      ,AL.DIV1
      ,AL.DIV2
      ,AL.DIV3
      ,AL.DIV4
      ,AL.DIV5
      ,AL.DIV6
      ,AL.DIV7
      ,AL.DIV8
      ,AL.DIV9
      ,AL.DIV10
      ,AL.DIV11
  from (SELECT 1             as DIV
              ,'締日'        as DIV1
              ,'販売先'      as DIV2
              ,'営業担当者'  as DIV3
              ,'前回請求額'  as DIV4
              ,'今回入金額'  as DIV5
              ,'値引類'      as DIV6
              ,'繰越残高'    as DIV7
              ,'今回買上'    as DIV8
              ,'消費税額'    as DIV9
              ,'今回請求額'  as DIV10
              ,1             as DIV11
          FROM DUAL
        UNION ALL --------------------------------------------------
        SELECT DISTINCT
            2 DIV
           ,to_char(FC_JDI9902_TO_DATE(TQY56CDDJ),'DD') --締日
           ,to_char(trim(AB.ABALPH))                    --販売先名
           ,to_char(trim(WW.WWALPH))                    --営業担当者
           ,to_char(TQY56CPBL)                          --前回請求額
           ,to_char(TQY56CCDA)                          --今回入金額
           ,to_char(TQY56CDIA)                          --値引き額
           ,to_char(TQY56CBBF)                          --繰越残高
           ,to_char(TQY56CCBA)                          --今回買入額
           ,to_char(TQY56CTA)                           --消費税額
           ,to_char(TQY56CCBI)                          --今回請求額
           ,1
        FROM F56C1013 TQ
             LEFT OUTER JOIN F0101 AB
               ON TQ.TQPYR = AB.ABAN8
             LEFT OUTER JOIN F0111 WW
               ON AB.ABAN84 = WW.WWAN8
              AND WW.WWIDLN = 0
        WHERE
          /*IF exchangeTargetCode != null*/
          TQ.TQPYR = /*exchangeTargetCode*/'11000400'
          /*END*/
          /*IF requestNo != null*/
          AND TQ.TQY56CRQN = /*requestNo*/'1509423'
          /*END*/
          /*IF searchCloseDate != null*/
          AND TQ.TQY56CDDJ = /*searchCloseDate*/'20151020'
          /*END*/
          AND EXISTS(
             SELECT 'X'
               FROM F56C1011 TD
              WHERE TQ.TQPYR = TD.TDPYR
                AND TQ.TQY56CDDJ = TD.TDY56CDDJ
                AND TQ.TQY56CRQN = TD.TDY56CRQN
                AND TQ.TQY56DNTRN = TD.TDY56DNTRN
                /*IF exchangeTargetCode != null*/
                AND TDPYR = /*exchangeTargetCode*/'11000400'
                /*END*/
                /*IF requestNo != null*/
                AND TDY56CRQN = /*requestNo*/'1509423'
                /*END*/
                /*IF searchCloseDate != null*/
                AND TDY56CDDJ = /*searchCloseDate*/'20151020'
                /*END*/
                    ) 
        UNION ALL --------------------------------------------------
        SELECT 3 DIV
              ,''
              ,''
              ,''
              ,''
              ,''
              ,''
              ,''
              ,''
              ,''
              ,''
              ,1
          FROM DUAL
        UNION ALL --------------------------------------------------
        SELECT 4 DIV
              ,'日付'
              ,'伝票No'
              ,'区分'
              ,'商品名'
              ,'数量'
              ,'単価'
              ,'金額'
              ,'備考'
              ,''
              ,'メモ'
              ,1
          FROM DUAL
        UNION ALL --------------------------------------------------
        SELECT 5 div
              ,to_char(TQ.TQA701) AS TQA701                                                             -- 日付
              ,to_char(DECODE(TQ.TQNETTCID, 0, NULL, TQ.TQNETTCID)) AS TQNETTCID                        -- 伝票No
              ,to_char(TQ.TQR004) AS TQR004                                                             -- 区分
              ,TRIM(to_char(TQ.TQDSC1)) AS TQDSC1                                                       -- 商品名
              ,to_char(TQ.TQUORG) AS TQUORG                                                             -- 数量
              ,to_char(TRUNC(TQ.TQUPRC/10000)) AS TQUPRC                                                -- 単価
              ,to_char(TQ.TQATXA) AS TQATXA                                                             -- 金額
              ,to_char(TRIM(TQ.TQRMK) || ' ' || TRIM(TQ.TQRMK2) || ' ' || TRIM(TQ.TQY57AHRMK)) AS TQRMK -- 備考
              ,to_char(CASE TQ.TQY56CBLD
                          WHEN N'0' THEN N'●'
                          WHEN N'1' THEN N' '
                       END) AS TQY56CBLD                                                                -- 帳端区分
              ,to_char(trim(TE.TELGL1)) AS TQLGL1                                                       -- メモ
              ,TQ.TQUKRECN
          FROM F56C1013 TQ
               LEFT OUTER JOIN F56C1012 TE
                 ON TQ.TQPYR = TE.TEPYR
                AND TQ.TQY56CDDJ = TE.TEY56CDDJ
                AND TQ.TQY56CRSD = TE.TEY56CRSD
                AND TQ.TQNETTCID = TE.TEDOC
                AND TQ.TQR004 = TE.TESDCT
         WHERE
           /*IF exchangeTargetCode != null*/
           TQ.TQPYR = /*exchangeTargetCode*/'11000400'
           /*END*/
           /*IF requestNo != null*/
           AND TQ.TQY56CRQN = /*requestNo*/'1509423'
           /*END*/
           /*IF searchCloseDate != null*/
           AND TQ.TQY56CDDJ = /*searchCloseDate*/'20151020'
           /*END*/
           AND EXISTS(
             SELECT 'X'
               FROM F56C1011 TD
              WHERE TQ.TQPYR = TD.TDPYR
                AND TQ.TQY56CDDJ = TD.TDY56CDDJ
                AND TQ.TQY56CRQN = TD.TDY56CRQN
                AND TQ.TQY56DNTRN = TD.TDY56DNTRN
               /*IF exchangeTargetCode != null*/
               AND TDPYR = /*exchangeTargetCode*/'11000400'
               /*END*/
               /*IF requestNo != null*/
               AND TDY56CRQN = /*requestNo*/'1509423'
               /*END*/
               /*IF searchCloseDate != null*/
               AND TDY56CDDJ = /*searchCloseDate*/'20151020'
               /*END*/
               )

       ) AL
 ORDER BY AL.DIV
        ,AL.DIV11
