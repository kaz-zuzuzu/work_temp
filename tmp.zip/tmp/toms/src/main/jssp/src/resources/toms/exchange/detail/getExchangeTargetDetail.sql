select AB.ABAN8                                                                   as torihikisakicd                -- 取引先コード
      ,TRIM(AB.ABALPH                                          )                  as torihikisakimei               -- 取引先名
      ,TRIM(AB.ABALP1                                          )                  as torihikisakikana              -- 取引先カナ
      ,TRIM(AB.ABAT1                                           )                  as searchtypecd                  -- 検索タイプCD
      ,TRIM(DR_ABAT1.DRDL01                                    )                  as searchtypemei                 -- 検索タイプ名
      ,TRIM(AL.ALADDZ                                          )                  as yuubinbangou                  -- 郵便番号
      ,TRIM(AL.ALADD1                                          )                  as jyusyo1                       -- 住所１
      ,TRIM(AL.ALADD2                                          )                  as jyusyo2                       -- 住所２
      ,TRIM(AL.ALADD3                                          )                  as jyusyo3                       -- 住所３
      ,TRIM(AL.ALADD4                                          )                  as jyusyo4                       -- 住所４
      ,TRIM(WPT1.WPPH1                                         )                  as phonedaihyo                   -- 電話番号代表
      ,TRIM(WPF1.WPPH1                                         )                  as faxdaihyo                     -- FAX番号代表
      ,TRIM(MC.MCRP03                                          )                  as jigyosyocd                    -- 上位組織コード
      ,TRIM(DR_RP03.DRDL01                                     )                  as jigyosyomei                   -- 上位組織名
      ,TRIM(AB.ABMCU                                           )                  as sosikicd                      -- 組織コード
      ,TRIM(MC.MCDL01                                          )                  as sosikimei                     -- 組織名
      ,AB.ABAN84                                                                  as eigyoutantousyacd             -- 営業担当者CD
      ,TRIM(WW_ABAN84.WWALPH                                   )                  as eigyoutantousyamei            -- 営業担当者
      ,TRIM(AB.ABAC29                                          )                  as bunrui1cd                     -- 分類1コード
      ,TRIM(DR_ABAC29.DRDL01                                   )                  as bunrui1mei                    -- 分類1
      ,TRIM(AB.ABAC30                                          )                  as bunrui2cd                     -- 分類2コード
      ,TRIM(DR_ABAC30.DRDL01                                   )                  as bunrui2mei                    -- 分類2
      ,TRIM(AB.ABAC23                                          )                  as bunrui3cd                     -- 分類3コード
      ,TRIM(DR_ABAC23.DRDL01                                   )                  as bunrui3mei                    -- 分類3
      ,TRIM(AB.ABAC19                                          )                  as bunrui6cd                     -- 分類6コード
      ,TRIM(DR_ABAC19.DRDL01                                   )                  as bunrui6mei                    -- 分類6
      ,TRIM(AB.ABAC20                                          )                  as bunrui7cd                     -- 分類7コード
      ,TRIM(DR_ABAC20.DRDL01                                   )                  as bunrui7mei                    -- 分類7
      ,TRIM(AB.ABAC21                                          )                  as bunrui8cd                     -- 分類8コード
      ,TRIM(DR_ABAC21.DRDL01                                   )                  as bunrui8mei                    -- 分類8
      ,TRIM(DR_AICPGP.DRDL01                                   )                  as kakakurankmei                 -- 価格ランク
      ,CASE WHEN TK.CNT IS NULL THEN 'なし' ELSE '有り' END                       as tokukaumu                     -- 特価有無
      ,CASE WHEN TKJ.CNT IS NULL THEN 'なし' ELSE '有り' END                      as tokkijiko                     -- 特記事項有無
      ,CASE WHEN TRIM(AB.ABTAX) IS NOT NULL THEN '有' ELSE '無' END as factoringumu                  -- ファクタリング有無
--      ,TRIM(AB.ABAC05                                          )                  as factoringcd                   -- ファクタリング識別
--      ,TRIM(DR_ABAC05.DRDL01                                   )                  as factoringmei                  -- ファクタリング識別名
      ,TRIM(AB2.ABALPH) || '(' || TRIM(AI.AIARPY) || ')'                          as daitaishiharainin             -- 支払人
      ,CASE WHEN TRIM(AB.ABAC12) IS NOT NULL THEN 'する' ELSE 'しない' END        as gassanseikyukbn               -- 合算請求区分
      ,TRIM(AB.ABAC09                                          )                  as sumrequestcd                  -- 合計請求書出力区分
      ,TRIM(DR_ABAC09.DRDL01                                   )                  as sumrequestmei                 -- 合計請求書出力区分名
      ,TRIM(AB.ABAC10                                          )                  as shimebicd                     -- 締日コード
      ,TRIM(DR_ABAC10.DRDL01                                   )                  as shimebimei                    -- 締日
--      ,TRIM(AB.ABAC12                                          )                  as sumrequesttargetcd            -- 合計請求書出力先区分
--      ,TRIM(DR_ABAC12.DRDL01                                   )                  as sumrequesttargetmei           -- 合計請求書出力先区分名
      ,TRIM(AB.ABAC13                                          )                  as requestsendcd                 -- 請求書郵送区分
      ,TRIM(DR_ABAC13.DRDL01                                   )                  as requestsendmei                -- 請求書郵送区分名
      ,TRIM(WL_seikyusho.WLADDZ                                )                  as seikyu_yuubinbangou           -- 郵便番号（請求書送付先）
      ,TRIM(WL_seikyusho.WLADD1                                )                  as seikyu_jyusyo1                -- 住所１（請求書送付先）
      ,TRIM(WL_seikyusho.WLADD2                                )                  as seikyu_jyusyo2                -- 住所２（請求書送付先）
      ,TRIM(WL_seikyusho.WLADD3                                )                  as seikyu_jyusyo3                -- 住所３（請求書送付先）
      ,TRIM(WL_seikyusho.WLADD4                                )                  as seikyu_jyusyo4                -- 住所４（請求書送付先）
      ,TRIM(WPT1_seikyusho.WPPH1                               )                  as seikyu_phonedaihyo            -- 電話番号代表（請求書送付先）
      ,TRIM(WPF1_seikyusho.WPPH1                               )                  as seikyu_faxdaihyo              -- FAX番号代表（請求書送付先）
      ,TRIM(WW_seikyusho.WWGNNM                                  )                  as seikyu_tantousya              -- 担当者（請求書送付先）
      ,TRIM(AB.ABAC14                                          )                  as nouhinyusoucd                 -- 納品書郵送区分
      ,TRIM(DR_ABAC14.DRDL01                                   )                  as nouhinyusoumei                -- 納品書郵送区分名      
      ,TRIM(WL_nouhinsho.WLADDZ                                )                  as nouhin_yuubinbangou           -- 郵便番号（納品書送付先）
      ,TRIM(WL_nouhinsho.WLADD1                                )                  as nouhin_jyusyo1                -- 住所１（納品書送付先）
      ,TRIM(WL_nouhinsho.WLADD2                                )                  as nouhin_jyusyo2                -- 住所２（納品書送付先）
      ,TRIM(WL_nouhinsho.WLADD3                                )                  as nouhin_jyusyo3                -- 住所３（納品書送付先）
      ,TRIM(WL_nouhinsho.WLADD4                                )                  as nouhin_jyusyo4                -- 住所４（納品書送付先）
      ,TRIM(WPT1_nouhinsho.WPPH1                               )                  as nouhin_phonedaihyo            -- 電話番号代表（納品書送付先）
      ,TRIM(WPF1_nouhinsho.WPPH1                               )                  as nouhin_faxdaihyo              -- FAX番号代表（納品書送付先）
      ,TRIM(WW_nouhinsho.WWGNNM                                )                  as nouhin_tantousya              -- 担当者（納品書送付先）
      ,TRIM(AB.ABAC17                                          )                  as jidoufaxcd                    -- 自動FAX対象
      ,TRIM(DR_ABAC17.DRDL01                                   )                  as jidoufaxmei                   -- 自動FAX対象名
      ,TRIM(AB.ABAC27                                          )                  as kakeuricd                     -- 掛売フラグ
      ,TRIM(DR_ABAC27.DRDL01                                   )                  as kakeurimei                    -- 掛売フラグ名
      ,TRIM(AI.AITRAR                                          )                  as shiharaijyokencd              -- 取引条件コード
      ,TRIM(PN.PNPTD                                           )                  as torihikijyouken               -- 取引条件
	  ,TRIM(MA.MAURRF										   )				  as shiharaijouken               --支払条件
      ,TRIM(AI.AIRYIN                                          )                  as shiharaisyudancd              -- 取引区分コード
      ,TRIM(DR_AIRYIN.DRDL01                                   )                  as torihikikubun             	   -- 取引区分
      ,TO_CHAR(AI.AIACL,  '999G999G999G999'                    )                  as yoshingendogaku               -- 与信限度額
      ,TRIM(AI.AIDR03                                          )                  as bukkengotoseikyucd            -- 物件毎請求フラグ
      ,TRIM(DR_AIDR03.DRDL01                                   )                  as bukkengotoseikyumei           -- 物件毎請求フラグ名
      ,TRIM(AI.AIDR04                                          )                  as senyounouhinsyoaricd          -- 専用納品書有
      ,TRIM(DR_AIDR04.DRDL01                                   )                  as senyounouhinsyoarimei         -- 専用納品書有名
      ,TRIM(AI.AIDR08                                          )                  as senyouseikyusyoaricd          -- 専用請求書有
      ,TRIM(DR_AIDR08.DRDL01                                   )                  as senyouseikyusyoarimei         -- 専用請求書有名
      ,TRIM(AI.AIDR09                                          )                  as souhumaefaxaricd              -- 送付前FAX有
      ,TRIM(DR_AIDR09.DRDL01                                   )                  as souhumaefaxarimei             -- 送付前FAX有名
      ,TRIM(AI.AICUSTS                                         )                  as stopflg                       -- 停止フラグ
      ,TRIM(AY.AYTNST                                          )                  as ginkoushitencd                -- 銀行・支店コード
      ,TRIM(AYG.J0ALPH                                         )                  as ginkoumei                     -- 銀行名
      ,TRIM(AYS.J0ALPH                                         )                  as shitenmei                     -- 支店名
      ,TRIM(SUBSTR(AY.AYCBNK,4,20)                             )                  as kouzabangou                   -- 口座番号
      ,TRIM(AY.AYDL01                                          )                  as meiginin                      -- 名義人
      ,TRIM(DR_AYCKSV.DRDL01)                                                     as yokinsyubetu                  -- 預金種別：預金種別名
  FROM -- 【マスタテーブル】 -------------------------------
       F0101 AB -- 住所録
       -------- 本社住所 ---------------------------------------------
       INNER JOIN F0111 WW -- 住所録（人名録） 
          ON AB.ABAN8  = WW.WWAN8
         AND WW.WWIDLN = 0
       -------- 納品先 ---------------------------------------------
       LEFT OUTER JOIN F0111 WW_nouhinsho -- 住所録（人名録） 
          ON AB.ABAN8  = WW_nouhinsho.WWAN8
         AND WW_nouhinsho.WWIDLN = 1
       LEFT OUTER JOIN F01161 WL_nouhinsho -- 代替住所
          ON AB.ABAN8  = WL_nouhinsho.WLAN8
         AND WW_nouhinsho.WWIDLN = WL_nouhinsho.WLIDLN
       LEFT OUTER JOIN F0115 WPT1_nouhinsho -- 住所録 電話番号
          ON AB.ABAN8            = WPT1_nouhinsho.WPAN8
         AND WW_nouhinsho.WWIDLN = WPT1_nouhinsho.WPIDLN
         AND WPT1_nouhinsho.WPCNLN = 0
         AND TRIM(WPT1_nouhinsho.WPPHTP) = 'TEL1'
       LEFT OUTER JOIN F0115 WPF1_nouhinsho -- 住所録 電話番号
          ON AB.ABAN8            = WPF1_nouhinsho.WPAN8
         AND WW_nouhinsho.WWIDLN = WPF1_nouhinsho.WPIDLN
         AND WPF1_nouhinsho.WPCNLN = 0
         AND TRIM(WPF1_nouhinsho.WPPHTP) = 'FAX1'
       -------- 請求先 ---------------------------------------------
       LEFT OUTER JOIN F0111 WW_seikyusho -- 住所録（人名録） 
          ON AB.ABAN8  = WW_seikyusho.WWAN8
         AND WW_seikyusho.WWIDLN = 2
       LEFT OUTER JOIN F01161 WL_seikyusho -- 代替住所
          ON AB.ABAN8  = WL_seikyusho.WLAN8
         AND WW_seikyusho.WWIDLN = WL_seikyusho.WLIDLN
       LEFT OUTER JOIN F0115 WPT1_seikyusho -- 住所録 電話番号
          ON AB.ABAN8            = WPT1_seikyusho.WPAN8
         AND WW_seikyusho.WWIDLN = WPT1_seikyusho.WPIDLN
         AND WPT1_seikyusho.WPCNLN = 0
         AND TRIM(WPT1_seikyusho.WPPHTP) = 'TEL1'
       LEFT OUTER JOIN F0115 WPF1_seikyusho -- 住所録 電話番号
          ON AB.ABAN8            = WPF1_seikyusho.WPAN8
         AND WW_seikyusho.WWIDLN = WPF1_seikyusho.WPIDLN
         AND WPF1_seikyusho.WPCNLN = 0
         AND TRIM(WPF1_seikyusho.WPPHTP) = 'FAX1'
       LEFT OUTER JOIN F0116 AL -- 住所録（住所）
          ON AB.ABAN8  = AL.ALAN8
--           AND AL.ALEFTB = CONVERT(Date,'1753/01/01')
       LEFT OUTER JOIN F03012 AI -- 顧客マスタ
          ON AB.ABAN8  = AI.AIAN8
         AND AI.AICO   = '00000'
       LEFT OUTER JOIN F0101 AB2 -- 住所録マスタ
          ON AB2.ABAN8  = AI.AIARPY
         AND AI.AICO   = '00000'
       LEFT OUTER JOIN F0030 AY -- 住所別銀行口座
          ON AI.AIARPY  = AY.AYAN8
         AND AY.AYBKTP = 'P'  -- トムス入金口座
       -------- 銀行名 ---------------------------------------------
       LEFT OUTER JOIN F75010 AYG
          ON AYG.J0JPBK = SUBSTR(TRIM(AY.AYTNST), 1, 4)
         AND AYG.J0JPBH = ' '
       -------- 支店名 ---------------------------------------------
       LEFT OUTER JOIN F75010 AYS
          ON AYS.J0JPBK = SUBSTR(TRIM(AY.AYTNST), 1, 4)
         AND AYS.J0JPBH = SUBSTR(TRIM(AY.AYTNST), 5, 3)
       -------- 住所録（代表電話） ---------------------------------
       LEFT OUTER JOIN F0115 WPT1
          ON AB.ABAN8  = WPT1.WPAN8
         AND WW.WWIDLN = WPT1.WPIDLN
         AND WPT1.WPCNLN = 0
         AND TRIM(WPT1.WPPHTP) = 'TEL1'
       -------- 住所録（代表FAX） ---------------------------------
       LEFT OUTER JOIN F0115 WPF1
          ON AB.ABAN8  = WPF1.WPAN8
         AND WW.WWIDLN = WPF1.WPIDLN
         AND WPF1.WPCNLN = 0
         AND TRIM(WPF1.WPPHTP) = 'FAX1'
       -------- 検索タイプ ---------------------------------
       LEFT OUTER JOIN F0005 DR_ABAT1
          ON TRIM(AB.ABAT1) = TRIM(DR_ABAT1.DRKY)
         AND DR_ABAT1.DRSY          = '01  '
         AND DR_ABAT1.DRRT          = 'ST'
       -------- 販売部門、上位組織 -------------------------
       LEFT OUTER JOIN F0006 MC
          ON TRIM(AB.ABMCU) = TRIM(MC.MCMCU)
       LEFT OUTER JOIN F0005 DR_RP03
          ON TRIM(MC.MCRP03) = TRIM(DR_RP03.DRKY)
         AND DR_RP03.DRSY            = '00  '
         AND DR_RP03.DRRT            = '03'
       -------- 営業担当者 ---------------------------------
       LEFT OUTER JOIN F0111 WW_ABAN84
          ON AB.ABAN84 = WW_ABAN84.WWAN8
         AND WW_ABAN84.WWIDLN        = 0
       -------- 顧客分類コード1 ----------------------------
       LEFT OUTER JOIN F0005 DR_ABAC29
          ON TRIM(AB.ABAC29) = TRIM(DR_ABAC29.DRKY)
         AND DR_ABAC29.DRSY          = '01  '
         AND DR_ABAC29.DRRT          = '29'
       -------- 顧客分類コード2 ----------------------------
       LEFT OUTER JOIN F0005 DR_ABAC30
          ON TRIM(AB.ABAC30) = TRIM(DR_ABAC30.DRKY)
         AND DR_ABAC30.DRSY          = '01  '
         AND DR_ABAC30.DRRT          = '30'
       -------- 顧客分類コード3 ----------------------------
       LEFT OUTER JOIN F0005 DR_ABAC23
          ON TRIM(AB.ABAC23) = TRIM(DR_ABAC23.DRKY)
         AND DR_ABAC23.DRSY          = '01  '
         AND DR_ABAC23.DRRT          = '23'
       -------- 顧客分類コード6 ----------------------------
       LEFT OUTER JOIN F0005 DR_ABAC19
          ON TRIM(AB.ABAC19) = TRIM(DR_ABAC19.DRKY)
         AND DR_ABAC19.DRSY          = '01  '
         AND DR_ABAC19.DRRT          = '19'
       -------- 顧客分類コード7 ----------------------------
       LEFT OUTER JOIN F0005 DR_ABAC20
          ON TRIM(AB.ABAC20) = TRIM(DR_ABAC20.DRKY)
         AND DR_ABAC20.DRSY          = '01  '
         AND DR_ABAC20.DRRT          = '20'
       -------- 顧客分類コード8 ----------------------------
       LEFT OUTER JOIN F0005 DR_ABAC21
          ON TRIM(AB.ABAC21) = TRIM(DR_ABAC21.DRKY)
         AND DR_ABAC21.DRSY          = '01  '
         AND DR_ABAC21.DRRT          = '21'
       -------- 顧客価格グループランク ---------------------
       LEFT OUTER JOIN F0005 DR_AICPGP
          ON TRIM(AI.AICPGP) = TRIM(DR_AICPGP.DRKY)
         AND DR_AICPGP.DRSY          = '40  '
         AND DR_AICPGP.DRRT          = 'PC'
--       -------- ファクタリング識別 -------------------------
--       LEFT OUTER JOIN F0005 DR_ABAC05
--          ON TRIM(AB.ABAC05) = TRIM(DR_ABAC05.DRKY)
--         AND DR_ABAC05.DRSY          = '01  '
--         AND DR_ABAC05.DRRT          = '05'
       -------- 合計請求書出力区分 -------------------------
       LEFT OUTER JOIN F0005 DR_ABAC09
          ON TRIM(AB.ABAC09) = TRIM(DR_ABAC09.DRKY)
         AND DR_ABAC09.DRSY          = '01  '
         AND DR_ABAC09.DRRT          = '09'
       -------- 販売先締め日 -------------------------------
       LEFT OUTER JOIN F0005 DR_ABAC10
          ON TRIM(AB.ABAC10) = TRIM(DR_ABAC10.DRKY)
         AND DR_ABAC10.DRSY          = '01  '
         AND DR_ABAC10.DRRT          = '10'
       -------- 合計請求書出力先区分 -----------------------
       LEFT OUTER JOIN F0005 DR_ABAC12
          ON TRIM(AB.ABAC12) = TRIM(DR_ABAC12.DRKY)
         AND DR_ABAC12.DRSY          = '01  '
         AND DR_ABAC12.DRRT          = '12'
       -------- 請求書郵送区分 -----------------------------
       LEFT OUTER JOIN F0005 DR_ABAC13
          ON AB.ABAC13 = SUBSTR(DR_ABAC13.DRKY, 8, 3)
         AND DR_ABAC13.DRSY          = '01  '
         AND DR_ABAC13.DRRT          = '13'
       -------- 納品書郵送区分 -----------------------------
       LEFT OUTER JOIN F0005 DR_ABAC14
          ON AB.ABAC14 = SUBSTR(DR_ABAC14.DRKY, 8, 3)
         AND DR_ABAC14.DRSY          = '01  '
         AND DR_ABAC14.DRRT          = '14'
       -------- 自動FAX対象 --------------------------------
       LEFT OUTER JOIN F0005 DR_ABAC17
          ON TRIM(AB.ABAC17) = TRIM(DR_ABAC17.DRKY)
         AND DR_ABAC17.DRSY          = '01  '
         AND DR_ABAC17.DRRT          = '17'
       -------- 掛売フラグ ---------------------------------
       LEFT OUTER JOIN F0005 DR_ABAC27
          ON TRIM(AB.ABAC27) = TRIM(DR_ABAC27.DRKY)
         AND DR_ABAC27.DRSY          = '01  '
         AND DR_ABAC27.DRRT          = '27'
       -------- 取引条件 -----------------------------------
       LEFT OUTER JOIN F0014 PN
          ON TRIM(AI.AITRAR) = TRIM(PN.PNPTC)
       -------- 支払条件 -----------------------------------
       LEFT OUTER JOIN F56C1030 MA
     	  ON AB.ABAN8 = MA.MAPYR
       -------- 取引区分 -----------------------------------
       LEFT OUTER JOIN F0005 DR_AIRYIN
          ON TRIM(AI.AIRYIN) = TRIM(DR_AIRYIN.DRKY)
         AND DR_AIRYIN.DRSY          = '00  '
         AND DR_AIRYIN.DRRT          = 'PY'
       -------- 預金種別 -----------------------------------
       LEFT OUTER JOIN F0005 DR_AYCKSV
          ON TRIM(AY.AYCKSV) = TRIM(DR_AYCKSV.DRKY)
         AND DR_AYCKSV.DRSY          = 'H00 '
         AND DR_AYCKSV.DRRT          = 'CK'
       -------- 物件毎請求フラグ ---------------------------
       LEFT OUTER JOIN F0005 DR_AIDR03
          ON TRIM(AI.AIDR03) = TRIM(DR_AIDR03.DRKY)
         AND DR_AIDR03.DRSY          = '41  '
         AND DR_AIDR03.DRRT          = 'X3'
       -------- 専用納品書有 -------------------------------
       LEFT OUTER JOIN F0005 DR_AIDR04
          ON TRIM(AI.AIDR04) = TRIM(DR_AIDR04.DRKY)
         AND DR_AIDR04.DRSY          = '41  '
         AND DR_AIDR04.DRRT          = 'X3'
       -------- 専用請求書有 -------------------------------
       LEFT OUTER JOIN F0005 DR_AIDR08
          ON TRIM(AI.AIDR08) = TRIM(DR_AIDR08.DRKY)
         AND DR_AIDR08.DRSY          = '41  '
         AND DR_AIDR08.DRRT          = 'X6'
       -------- 送付前FAX有 --------------------------------
       LEFT OUTER JOIN F0005 DR_AIDR09
          ON TRIM(AI.AIDR09) = TRIM(DR_AIDR09.DRKY)
         AND DR_AIDR09.DRSY          = '41  '
         AND DR_AIDR09.DRRT          = 'X6'
      -------- 特価有無 -----------------------------------
      LEFT OUTER JOIN (SELECT COUNT(1) CNT
                             ,TKT.MAAN8
                         FROM (SELECT MAAN8
                                     ,MA.MAEFTJ
                                     ,DENSE_RANK() OVER (PARTITION BY MA.MAAN8,MA.MALITM ORDER BY MA.MAEFTJ DESC) RNK
                                 FROM F57A5010 MA
--                                WHERE MA.MAAN8 <> 0 ) TKT
                                 WHERE MA.MAAN8 <> 0
                                 AND   MA.MAEFTJ <= FC_JDI9902_TO_JULIAN(SYSDATE) ) TKT
--                        WHERE FC_JDI9902_TO_DATE(TKT.MAEFTJ) <= SYSDATE
--                          AND TKT.RNK = 1 
                        GROUP BY TKT.MAAN8) TK 
         ON TK.MAAN8 = AB.ABAN8
       -------- 特記事項有無 --------------------------------
       LEFT OUTER JOIN (SELECT MGAN8, 
                               COUNT(MGAN8) CNT
                        FROM F57A5070
                        GROUP BY MGAN8 ) TKJ
          ON TKJ.MGAN8 =  AB.ABAN8
     WHERE AB.ABAN8 = /*exchangeTargetId*/'11000840'               --取引先コード
