SELECT 
  TRIM(DRKY) AS value,
  TRIM(DRDL01) AS label
FROM
  F0005
WHERE
  DRSY = '57C '
AND
  DRRT = '06'
AND
LENGTH(TRIM(DRKY)) = 3
AND
TRIM(DRKY) NOT IN ('200', '201', '202')
/*IF stockPositionCode != null*/
AND
  TRIM(DRDL02) = /*stockPositionCode*/'1000'
/*END*/
ORDER BY
value