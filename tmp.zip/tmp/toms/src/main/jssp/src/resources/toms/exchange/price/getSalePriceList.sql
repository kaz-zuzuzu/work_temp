select sm.MAAN8              as torihikisakicd      --販売先
      ,sm.ABALPH             as torihikisakimei     --販売先名
      ,sm.MALITM             as hinmokunumber       --品目No
      ,sm.IMDSC1             as shohinmei1          --商品名1
      ,sm.IMDSC2             as shohinmei2          --商品名2
      ,sm.MAEFTJ             as yukokaishibi        --有効開始日
      ,NVL(TO_CHAR(sm.MAUPRC), ' ')   as tokka      --特価
 from (select MA.MAAN8                                 --販売先
             ,trim(AB.ABALPH) ABALPH                   --販売先名
             ,trim(MA.MALITM) MALITM                   --品目No
             ,trim(IM.IMDSC1) IMDSC1                   --商品名
             ,trim(IM.IMDSC2) IMDSC2                   --商品名
             ,TO_CHAR(FC_JDI9902_TO_DATE(MA.MAEFTJ),'YYYY/MM/DD') MAEFTJ    --有効開始日付
             ,MA.MAUPRC /power(10,4)  MAUPRC           --特価
             ,dense_rank() over (partition by MA.MAAN8,MA.MALITM order by MA.MAEFTJ desc) rnk
         from F57A5010 MA
              -------- 商品名 -------------------------------
              left outer join F4101 IM
                on MA.MAITM  = IM.IMITM
              -------- 住所録 -------------------------------
              left outer join F0101 AB
                on MA.MAAN8 = AB.ABAN8
        where MA.MAEFTJ <= FC_JDI9902_TO_JULIAN(sysdate)
          and MA.MAAN8 = /*exchangeTargetId*/11000210   --取引先コード
      ) sm
 where sm.rnk = 1
 order by sm.MALITM;
