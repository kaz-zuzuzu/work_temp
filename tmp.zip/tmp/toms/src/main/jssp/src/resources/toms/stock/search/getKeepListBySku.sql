select STK_DIV        as STK_DIV    -- キープ対象
      ,TO_CHAR(STK_DATE, 'yyyy/MM/dd') as STK_DATE -- 入荷予定日
      ,STK_QTY        as STK_QTY    -- 在庫数
      ,TCY57AKRQT     as TCY57AKRQT -- キープ数
      ,TO_CHAR(TCPDDJ, 'yyyy/MM/dd') as TCPDDJ -- 出荷予定日
      ,DRDL01         as DRDL01     -- ステータス名（オーダーステータス名）
      ,ABALPH         as ABALPH     -- 販売先名
      ,TCDOCO         as TCDOCO     -- オーダーNo
      ,TCDCTO         as TCDCTO     -- オーダータイプ
      ,MCDL01         as MCDL01     -- 組織名
      ,WWALPH         as WWALPH     -- 営業担当者名
      ,WWALPH2        as WWALPH2    -- オーダー入力者名
      ,TAY57AHRMK     as TAY57AHRMK -- 柄名
      ,TAY57AORMK     as TAY57AORMK -- 受注メモ
      ,DRDL02         as DRDL02     -- 出荷予定ステータス名
  from TABLE(PKG_TWEB_KEEP.GET_KEEPLIST(/*skuCode*/'010008500101'))
 order by SORT_DATE        -- ソート日付
         ,DIV              -- 区分
         ,DEVOLVE_PRIORITY -- 優先順位
         ,TCPDDJ           -- 出荷予定日
         ,TAY57AOSTS       -- オーダーステータス
