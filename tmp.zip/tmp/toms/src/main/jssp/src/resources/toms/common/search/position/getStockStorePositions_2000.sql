SELECT DISTINCT
  TRIM(SUBSTR(TRIM(DRKY), 0, 3)) AS value,
  CASE 
    WHEN INSTR(DRDL01, '(') > 0 THEN
      TRIM(SUBSTR(TRIM(DRDL01), 0, INSTR(DRDL01, '(') -1 ))
    ELSE
      TRIM(DRDL01)
  END AS label
  --TRIM(SUBSTR(TRIM(DRDL01), 0, INSTR(DRDL01, '(') -1 )) AS label
FROM
  F0005
WHERE
  DRSY = '57C '
AND
  DRRT = '06'
/*IF stockPositionCode != null*/
AND
  TRIM(DRDL02) = /*stockPositionCode*/'2000'
/*END*/
ORDER BY
value
