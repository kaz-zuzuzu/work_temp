select
 DECODE(TD.TDADDJ, NULL, NULL, (select TO_CHAR(
      TO_DATE(CONCAT(((CASE WHEN LENGTH(TD.TDADDJ)=6 THEN 2 ELSE 1 END)*1000
      +SUBSTR(TD.TDADDJ,2,2)),'/01/01'))
      +TO_NUMBER(SUBSTR(TD.TDADDJ,4,3)-1), 'FMYYYY/MM/DD') from dual)) AS TDADDJ --出荷確定日
,MC.MCRP03 --上位組織コード
,TRIM(DR_RP03.DRDL01) as DRDL01 --上位組織名
,AB.ABMCU --組織コード
,MC.MCDC　--組織名
,AB.ABALPH --取引先名
,AB.ABALP1 --取引先カナ
,TD.TDDOCO --受注番号
,TD.TDDCTO --加工/無地区分
,TD.TDY57AOTYP --オーダータイプ
,RTRIM(TD.TDY57ASHPN) as TDY57ASHPN --出荷予定ナンバー
,TRIM(TD.TDALPH) as TDALPH--送付先名称
,TD.TDADD1 --住所1
,TD.TDADD2 --住所2
,DR_Y57CUBC.DRDL01 as DRDL --運送会社
,TD.TDY57AIINN --枝番
,SUBSTR(TF.TFLITM,3,5) as TFLITM--商品コード
,IM.IMDSC1 --商品名
,DR_CL.DRDL01 as DRCL--カラー
,DR_SZ.DRDL01 as DRSZ--サイズ
,TD.TDY57CYK --個口数
,TF.TFSOQS --総数
,TD.TDVR01 --販売先発注No
,TD.TDY57CSBP --ピッキングステータス（バラ）
,AB.ABAN84 --営業担当者コード
,TRIM(WW_ABAN84.WWALPH) --営業担当者名
,TF.TFY57CLC01 --出荷倉庫
,F.MCDC --出荷倉庫名
,DR_TFY57CLC01.DRDL01 --出荷倉庫名
FROM
 F57A0070 TD
INNER JOIN F57A0153 TF
 ON TD.TDY57CPCN = TF.TFY57CPCN --ピッキング明細
 -------- 商品名、商品略名、商品分類1・2
LEFT OUTER JOIN F4101 IM
   ON RTRIM(LTRIM(TF.TFITM))  = RTRIM(LTRIM(IM.IMITM))
LEFT OUTER JOIN F0005 DR_IMTYPE1
   ON RTRIM(LTRIM(IM.IMPRP2)) = RTRIM(LTRIM(DR_IMTYPE1.DRKY))
  AND DR_IMTYPE1.DRSY         = '41'
  AND DR_IMTYPE1.DRRT         = 'P2'
LEFT OUTER JOIN F0005 DR_IMTYPE2
   ON RTRIM(LTRIM(IM.IMSRP9)) = RTRIM(LTRIM(DR_IMTYPE2.DRKY))
  AND DR_IMTYPE2.DRSY         = '41'
  AND DR_IMTYPE2.DRRT         = '09'
-------- カラー名 -----------------------------------
LEFT OUTER JOIN F0005 DR_CL
   ON RTRIM(LTRIM(SUBSTR(TF.TFLITM,8,3))) = RTRIM(LTRIM(DR_CL.DRKY))
  AND DR_CL.DRSY                             = '41F'
  AND DR_CL.DRRT                             = DECODE(TRIM(SUBSTR(IM.IMLITM,1,2)),'01','1C','2C')
-------- サイズ名 -----------------------------------
LEFT OUTER JOIN F0005 DR_SZ
   ON RTRIM(LTRIM(SUBSTR(TF.TFLITM,11,2))) = RTRIM(LTRIM(DR_SZ.DRKY))
  AND DR_SZ.DRSY                              = '41F'
  AND DR_SZ.DRRT                              = DECODE(TRIM(SUBSTR(IM.IMLITM,1,2)),'01','1S','2S')
-------- 便種 ---------------------------------
LEFT OUTER JOIN F0005 DR_Y57CUBC
  ON RTRIM(LTRIM(TD.TDY57CUBC))  = RTRIM(LTRIM(DR_Y57CUBC.DRKY))
 AND DR_Y57CUBC.DRSY             = '01'
 AND DR_Y57CUBC.DRRT             = '06'
-------- 営業担当者 ---------------------------------
LEFT OUTER JOIN F0101 AB
   ON RTRIM(LTRIM(TD.TDAN8))=RTRIM(LTRIM(AB.ABAN8))
LEFT OUTER JOIN F0111 WW_ABAN84
   ON AB.ABAN84 = WW_ABAN84.WWAN8
   AND WW_ABAN84.WWIDLN = 0 
--------出荷倉庫-------------------------------------
LEFT OUTER JOIN F0005 DR_TFY57CLC01
   ON RTRIM(LTRIM(TF.TFY57CLC01)) = RTRIM(LTRIM(DR_TFY57CLC01.DRKY))
  AND DR_TFY57CLC01.DRSY          = '57C'
  AND DR_TFY57CLC01.DRRT          = '06' 
LEFT OUTER JOIN F0006 F
   ON RTRIM(LTRIM(DR_TFY57CLC01.DRDL02)) = RTRIM(LTRIM(F.MCMCU))
  AND DR_TFY57CLC01.DRDL02 IN ('1000','2000','3000')
-------- 販売部門、上位組織 -------------------------
LEFT OUTER JOIN F0006 MC
   ON TRIM(AB.ABMCU) = TRIM(MC.MCMCU)
LEFT OUTER JOIN F0005 DR_RP03
   ON TRIM(MC.MCRP03) = TRIM(DR_RP03.DRKY)
  AND DR_RP03.DRSY            = '00'
  AND DR_RP03.DRRT            = '03'
-------- 便種 ---------------------------------
LEFT OUTER JOIN F0005 DR_Y57CUBC
  ON RTRIM(LTRIM(TD.TDY57CUBC))  = RTRIM(LTRIM(DR_Y57CUBC.DRKY))
 AND DR_Y57CUBC.DRSY             = '01'
 AND DR_Y57CUBC.DRRT             = '06'

/*BEGIN*/
/*IF receiveOrderNo != null*/
WHERE
/*IF receiveOrderNo != null*/
TD.TDDOCO=/*receiveOrderNo*/'14000089'
/*END*/
/*IF instructNo != null*/
AND
TD.TDY57ASHPN=/*instructNo*/'15002524'
/*END*/
/*IF destination != null*/
AND
TRIM(TD.TDALPH)=/*destination*/'玉川屋ユニホームセンター'
/*END*/
AND
TD.TDY57ASHPS IN('590','600','999')
/*END*/
