select 
   trim(f03b13.rycknu) as billno, -- 手形番号,
   DECODE(f03b13.rydmtj, NULL, NULL, (select TO_CHAR(
              TO_DATE(
              CONCAT(((CASE WHEN LENGTH(f03b13.rydmtj)=6 THEN 2 ELSE 1 END)*1000
              +SUBSTR(f03b13.rydmtj,2,2)),'/01/01'))
              +TO_NUMBER(SUBSTR(f03b13.rydmtj,4,3)-1), 'FMYYYY/MM/DD') from dual)) AS rydmtj, -- 手形振出日
   trim(f0005d.drky) || ':' || trim(f0005d.drdl01) as billstatus,-- 手形状況,
   DECODE(f03b13.ryvldt, NULL, NULL, (select TO_CHAR(
              TO_DATE(
              CONCAT(((CASE WHEN LENGTH(f03b13.ryvldt)=6 THEN 2 ELSE 1 END)*1000
              +SUBSTR(f03b13.ryvldt,2,2)),'/01/01'))
              +TO_NUMBER(SUBSTR(f03b13.ryvldt,4,3)-1), 'FMYYYY/MM/DD') from dual)) AS ryvldt, -- 手形満期日
   f03b13.ryckam       -- 手形金額
from  f03b11, f03b13,f0005d
where
/*IF customerCode != null*/
f03b11.rpan8 = /*customerCode*/'11000500'
/*END*/
  and f03b11.rpicut =  'DB' --受取手形
  and f03b11.rpdct <> 'RU'
  and f03b11.rppst <> 'P' --未決済
  and f03b11.rppyid = f03b13.rypyid
  and f0005d.drsy = '03B'
  and f0005d.drrt = 'DS'
  and trim(f0005d.drky) = trim(f03b13.ryddst)
order by rydmtj desc
