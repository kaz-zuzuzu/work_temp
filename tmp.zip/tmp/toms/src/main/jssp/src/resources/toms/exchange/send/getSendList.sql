select
	trim(AB.aban8)					 	 as torihikisakicd		　　--取引先コード
   ,trim(AB.abalph)						 as torihikisakimei		  --取引先
   ,trim(f0101.aban8)                    as soufusakibangou       --送付先番号
   ,trim(f0101.abalph)                   as soufusakimei          --送付先名称
   ,trim(f0101.abalp1)                   as soufusakikana         --送付先カナ名
   ,trim(f0116.aladd1)                   as soufusakijyusyo1      --送付先住所１
   ,trim(f0116.aladd2)                   as soufusakijyusyo2      --送付先住所２
   ,trim(f0116.aladd3)                   as soufusakijyusyo3      --送付先住所３
   ,trim(f0116.aladd4)                   as soufusakijyusyo4      --送付先住所４
   ,trim(f0116.aladdz)                   as zipcode               --郵便番号
   ,trim(f0005b.drdl01)                  as untinseikyuuflg       --運賃請求フラグ
   ,trim(f0005c.drdl01)                  as tameutitime           --貯め打時間
   ,case f0101.abac02
      when to_nchar('   ') then '無'
      when to_nchar('1  ') then '有'
      else ''
    end                                  as asootoset             --アソート設定
   ,trim(f0005d.drdl01)                  as unsoubin              --運送便
   ,trim(f0111.wwgnnm)                   as tantousya             --担当者
   ,trim(f0115a.wpph1)                   as daihyoutel            --代表電話番号
   ,trim(f0115b.wpph1)                   as daihyoufax            --代表FAX番号
   ,trim(f0115c.wpph1)                   as tyokutuutel           --直通電話番号
   ,trim(f0115d.wpph1)                   as tyokutuufax           --直通FAX番号
from f0101
  left join f0111
    on  f0101.aban8 = f0111.wwan8
  left join f0116
  on  f0101.aban8 = f0116.alan8
  left outer join (select 
                       f0115.wpan8,
                       f0115.wpidln,
                       f0115.wprck7,
                       f0115.wpcnln,
                       f0115.wpphtp,
                       f0115.wpar1,
                       f0115.wpph1
                   from f0115
                   where f0115.wpphtp = 'TEL1') f0115a
    on  f0111.wwan8 = f0115a.wpan8
    and f0111.wwidln = f0115a.wpidln
  left outer join (select 
                       f0115.wpan8,
                       f0115.wpidln,
                       f0115.wprck7,
                       f0115.wpcnln,
                       f0115.wpphtp,
                       f0115.wpar1,
                       f0115.wpph1
                   from f0115
                   where f0115.wpphtp = 'FAX1') f0115b
    on  f0111.wwan8 = f0115b.wpan8
    and f0111.wwidln = f0115b.wpidln
  left outer join (select 
                       f0115.wpan8,
                       f0115.wpidln,
                       f0115.wprck7,
                       f0115.wpcnln,
                       f0115.wpphtp,
                       f0115.wpar1,
                       f0115.wpph1
                   from f0115
                   where f0115.wpphtp = 'TEL2') f0115c
    on  f0111.wwan8 = f0115c.wpan8
    and f0111.wwidln = f0115c.wpidln
  left outer join (select 
                       f0115.wpan8,
                       f0115.wpidln,
                       f0115.wprck7,
                       f0115.wpcnln,
                       f0115.wpphtp,
                       f0115.wpar1,
                       f0115.wpph1
                   from f0115
                   where f0115.wpphtp = 'FAX2') f0115d
    on  f0111.wwan8 = f0115d.wpan8
    and f0111.wwidln = f0115d.wpidln
  left join f0005 f0005a
    on nvl(trim(f0101.abclass01), 'a') = nvl(trim(f0005a.drky), 'a')
  left join f0005 f0005b
    on nvl(trim(f0101.abclass03), 'a') = nvl(trim(f0005b.drky), 'a')
  left join f0005 f0005c
    on nvl(trim(f0101.abac01), 'a')    = nvl(trim(f0005c.drky), 'a')
  left join f0005 f0005d
    on nvl(trim(f0101.abac06), 'a')    = nvl(trim(f0005d.drky), 'a')
  left outer join f0101 AB
    on f0101.ABAN81 = AB.ABAN8
where
f0111.wwidln = '0' --商品の送付先は0のみ
and   f0116.aleftb = '0' --商品の送付先は0のみ
and   f0005a.drsy = '01'
and   f0005a.drrt = 'CA'
and   substrb(f0005a.drdl02,1,2) <> '2'
and   f0005b.drsy = '01'
and   f0005b.drrt = 'CC'
and   f0005c.drsy = '01'
and   f0005c.drrt = '01'
and   f0005d.drsy = '01'
and   f0005d.drrt = '06'
/*IF exchangeTargetId != null*/
and f0101.aban81 = /*exchangeTargetId*/'11000210'   --取引先コード
/*END*/
order by f0101.aban81,f0101.aban8
