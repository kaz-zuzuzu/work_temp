select
    b.abmcu,                --組織コード
    c.mcdc,                 --組織名
    b.aban84,               --営業担当者コード
    d.abalph,               --営業担当者名
    a.aian8,                --請求先コード
    b.abalph as customer,   --請求先名
    a.airyin,               --取引区分
    substr(e.drdl01, 1, 1) as airyindisp,   --取引区分名
    a.aitrar,                               --取引手段
    case when trim(b.abtax) is null then '無' else '有' end as factoringumu, --ファクタリング有無
    TRIM(MA.maurrf) as shiharaijouken,            --支払条件
    a.aiasty,               --未払金
    a.aiabam,               --受注残額
    a.aiacl,                --与信限度額
    a.aiacl - a.aiasty - a.aiabam as creditbalance, --与信残高
    '入金履歴一覧' as col1,
    '受取手形未決済一覧' as col2
  from F03012 a
    inner join F0101 b
       on a.aian8 = b.aban8
    inner join F0006 c
       on b.abmcu = c.mcmcu
    inner join f0101 d
       on b.aban84 = d.aban8
     left outer join f0005 e
       on trim(a.airyin) = trim(e.drky)
       and e.drsy = '00  '
       and e.drrt = 'PY'
     left outer join F56C1030 MA
       on a.aian8 = MA.mapyr
where b.abat1 in (
'1A',
'1B',
'1C',
'1D',
'1E',
'1F',
'1G',
'1H',
'1I',
'1J',
'1K',
'1L',
'1X'
)
/*IF organization != null*/
  and trim(b.abmcu) IN/*organization*/('101', '102')
/*END*/
/*IF searchExchangeTargetType != null*/
  and trim(a.airyin) = /*searchExchangeTargetType*/'Y'
/*END*/
/*IF searchExchangeTargetId != null*/
  and trim(a.aian8) = /*searchExchangeTargetId*/'11226090'
/*END*/
/*IF exchangeTargetKn != null*/
  and trim(b.abalp1)  LIKE /*exchangeTargetKn*/'%ｱｯﾄﾌﾟﾘﾝﾄ%'
/*END*/
/*IF chargePerson != null*/
  and trim(b.aban84) = /*chargePerson*/'90037400'
/*END*/
/*IF chargePersonText != null*/
  and trim(d.abalp1) like /*chargePersonText*/'%ﾀｼﾛ ｷﾝﾔ%'
/*END*/
/*IF creditAmountOver_0001_flag*/
  and (a.aiacl - a.aiasty - a.aiabam) < 0
/*END*/

order by 
     b.abmcu,
     b.aban84,
     a.aian8
