select 
   DECODE(rydgj, NULL, NULL, (select TO_CHAR(
              TO_DATE(
              CONCAT(((CASE WHEN LENGTH(rydgj)=6 THEN 2 ELSE 1 END)*1000
              +SUBSTR(rydgj,2,2)),'/01/01'))
              +TO_NUMBER(SUBSTR(rydgj,4,3)-1), 'FMYYYY/MM/DD') from dual)) AS rydgj, -- 入金日
   b.ryckam, -- 入金額,
   b.ryaap  -- 未消込額
from (select 
         f56c0071.tpan8  as tpan8,            -- 顧客番号
         f56c0071.tppyid as tppyid            -- 入金ID
      from f56c0070
        left join f56c0071
        on f56c0070.toy56cponm = f56c0071.tpy56cponm
      where
      f56c0070.toco       = '10000'     -- 会社番号
      and f56c0070.toy56cud06 = '0'         -- FBデータ
      and   f56c0070.toy56cud07 in ('1', '2') -- 1:一部処理済、2:処理済
      and   f56c0071.tpy56cud06 = '0'         -- FBデータ
      and   f56c0071.tpy56cud09 = '1'         -- 1:処理済
      ) a
  left join f03b13 b
  on a.tppyid = b.rypyid
where
  /*IF customerCode != null*/
  ryan8 = /*customerCode*/'11002230'
  /*END*/
  and   b.ryicut = 'RB'    -- 入金の伝票タイプ
  and   b.ryco   = '10000' -- 会社
  and   b.rynfvd = ' '     -- 無効ではないもの
order by b.rydgj desc