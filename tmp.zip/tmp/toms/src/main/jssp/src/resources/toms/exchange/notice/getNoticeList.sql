select MG.MGAN8           as torihikisaki
      ,trim(AB.ABALPH)    as torihikisakimei
      ,MG.MGY57ASPCD      as tokkijikoucodeno
      ,TRIM(DR.DRDL01)    as tokkijikoucode
      ,MG.MGRNO           as tokkijikouno
      ,trim(MG.MGDS01)    as tokkijikou
  from f57A5070 MG
       -------- 住所録 -------------------------------
       left outer join F0101 AB
         on MG.MGAN8 = AB.ABAN8
       -------- 特記事項内容 --------------------------
       left outer join F0005 DR
         on trim(MG.MGY57ASPCD) = trim(DR.DRKY)
        and DR.DRSY = '57A '
        and DR.DRRT = '22'
 where MG.MGAN8 = /*exchangeTargetId*/11002490   --取引先コード
 order by MG.MGAN8
         ,MG.MGY57ASPCD
         ,MG.MGRNO
