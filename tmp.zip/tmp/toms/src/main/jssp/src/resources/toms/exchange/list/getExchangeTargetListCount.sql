select COUNT(AB.ABAN8) cnt
FROM -- 【マスタテーブル】 -------------------------------
     F0101 AB -- 住所録
     INNER JOIN F0111 WW -- 住所録（人名録） 
        ON AB.ABAN8  = WW.WWAN8
       AND WW.WWIDLN = 0
     LEFT OUTER JOIN F0116 AL -- 住所録（住所）
        ON AB.ABAN8  = AL.ALAN8
     LEFT OUTER JOIN F03012 AI -- 顧客マスタ
        ON AB.ABAN8  = AI.AIAN8
       AND AI.AICO   = '00000'
     -------- 住所録（代表電話） ---------------------------------
     LEFT OUTER JOIN F0115 WPT1
        ON AB.ABAN8  = WPT1.WPAN8
       AND WW.WWIDLN = WPT1.WPIDLN
       AND WPT1.WPCNLN = 0
       AND TRIM(WPT1.WPPHTP) = 'TEL1'
     -------- 住所録（代表FAX） ---------------------------------
     LEFT OUTER JOIN F0115 WPF1
        ON AB.ABAN8  = WPF1.WPAN8
       AND WW.WWIDLN = WPF1.WPIDLN
       AND WPF1.WPCNLN = 0
       AND TRIM(WPF1.WPPHTP) = 'FAX1'
     -------- 検索タイプ ---------------------------------
     LEFT OUTER JOIN F0005 DR_ABAT1
        ON TRIM(AB.ABAT1) = TRIM(DR_ABAT1.DRKY)
       AND DR_ABAT1.DRSY          = '01  '
       AND DR_ABAT1.DRRT          = 'ST'
     -------- 販売部門、上位組織 -------------------------
     LEFT OUTER JOIN F0006 MC
        ON TRIM(AB.ABMCU) = TRIM(MC.MCMCU)
     LEFT OUTER JOIN F0005 DR_RP03
        ON TRIM(MC.MCRP03) = TRIM(DR_RP03.DRKY)
       AND DR_RP03.DRSY            = '00  '
       AND DR_RP03.DRRT            = '03'
     -------- 営業担当者 ---------------------------------
     LEFT OUTER JOIN F0111 WW_ABAN84
        ON AB.ABAN84 = WW_ABAN84.WWAN8
       AND WW_ABAN84.WWIDLN        = 0
     -------- 顧客分類コード1 ----------------------------
     LEFT OUTER JOIN F0005 DR_ABAC29
        ON TRIM(AB.ABAC29) = TRIM(DR_ABAC29.DRKY)
       AND DR_ABAC29.DRSY          = '01  '
       AND DR_ABAC29.DRRT          = '29'
     -------- 顧客分類コード2 ----------------------------
     LEFT OUTER JOIN F0005 DR_ABAC30
        ON TRIM(AB.ABAC30) = TRIM(DR_ABAC30.DRKY)
       AND DR_ABAC30.DRSY          = '01  '
       AND DR_ABAC30.DRRT          = '30'
WHERE TRIM(AB.ABAT1) IN /*exchangeCategoryCd*/('1A','1B')       --取引種別
/*IF exchangeTargetId != null*/
AND AB.ABAN8 = /*exchangeTargetId*/'11000170'         --取引先コード
/*END*/
/*IF organizationCd != null*/
AND TRIM(AB.ABMCU) IN /*organizationCd*/('101', '102')      --組織
/*END*/
/*IF bunrui1Cd != null*/
AND AB.ABAC29 = /*bunrui1Cd*/'010'                     --分類１
/*END*/
/*IF notinBunrui1Cd != null*/
AND AB.ABAC29 NOT IN /*notinBunrui1Cd*/('070', '080')  --除外の分類1
/*END*/
/*IF bunrui2Cd != null*/
AND TRIM(AB.ABAC30)  IN /*bunrui2Cd*/('008', '700', '800')    --分類２
/*END*/
/*IF chargePersonCd != null*/
AND AB.ABAN84 = /*chargePersonCd*/'90037500'            --担当者コード
/*END*/
/*IF chargePersonNm != null*/
AND TRIM(WW_ABAN84.WWALP1) LIKE /*chargePersonNm*/'%ﾄﾐｵｶ%'    --担当者
/*END*/
/*IF todoufukenCd != null*/
AND TRIM(AL.ALADDS) = /*todoufukenCd*/'27'                    --都道府県コード
/*END*/
/*IF exchangeTargetKn != null*/
AND TRIM(AB.ABALP1) LIKE /*exchangeTargetKn*/'%ｼｮｳｺｳ%'   -- 取引先カナ
/*END*/
/*IF telNo != null*/
AND TRIM(REPLACE(TRIM(WPT1.WPPH1), '-', '')) = /*telNo*/'0662311171' -- 電話番号
/*END*/
/*IF faxNo != null*/
AND TRIM(REPLACE(TRIM(WPF1.WPPH1), '-', '')) = /*faxNo*/'0662311172' -- FAX番号
/*END*/
