SELECT
    COUNT(*) AS ROWCOUNT
FROM
(
	select TRIM(AB.ABAN8) AS ABAN8                                            -- 顧客コード
	       ,TRIM(AB.ABALPH) AS ABALPH                                         -- 販売先名略称
	       ,TRIM(AB.ABDC) AS ABDC                                             -- 販売先カナ
	       ,TRIM(AB.ABAN84) AS ABAN84                                         -- 営業担当者コード
	       ,TRIM(WW.WWALPH) AS WWALPH                                         -- 営業担当者
	       ,TRIM(WW.WWDC) AS WWDC                                            -- 営業担当者カナ
	FROM
	    F0101 AB -- 住所録
	LEFT JOIN
	    F0111 WW -- 住所録2
	ON
	    TRIM(AB.ABAN84) = TRIM(WW.WWAN8)
	AND
	    WW.WWIDLN = 0
	WHERE
	    -- 検索タイプ：顧客(1A)／顧客・仕入先(1D)／顧客・加工先(1E)／顧客・加工先・仕入先(1L)
	    (TRIM(AB.ABAT1) = '1A'
	    OR
	     TRIM(AB.ABAT1) = '1D'
	    OR
	     TRIM(AB.ABAT1) = '1E'
	    OR
	     TRIM(AB.ABAT1) = '1L')
	/*IF exchangeTargetName != null*/
	AND TRIM(AB.ABALPH) like /*exchangeTargetName*/'%name%'
	/*END*/
	/*IF exchangeTargetKana != null*/
	AND TRIM(AB.ABDC) like /*exchangeTargetKana*/'%kana%'
	/*END*/
	/*IF chargePersonKana != null*/
	AND TRIM(WW.WWDC) like /*chargePersonKana*/'%kana%'
	/*END*/
)
