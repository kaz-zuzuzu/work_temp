WITH BASE_QR AS
(
SELECT        
      IMBASE.IMLITM                                       AS IMLITM --品目No
      ,IMBASE.IMDSC1                                      AS IMDSC1 --記述１
      ,IMBASE.IMDSC2                                      AS IMDSC2 --記述２
      ,IMBASE.LIPQOH                                      AS LIPQOH --在庫数量
      ,FC_JDI9902_TO_JULIAN(MIN(TQP.TPY57BRDD1))           AS TPY57BRDD1 --直近入荷予定日
FROM 
    (
        SELECT        
              IM.IMLITM                                       AS IMLITM --品目No
              ,TRIM(IM.IMDSC1)                                      AS IMDSC1 --記述１
              ,TRIM(IM.IMDSC2)                                      AS IMDSC2 --記述２
              ,SUM(LI.LIPQOH)                                       AS LIPQOH --在庫数量
        FROM -- 【トランザクションテーブル】 ---------------------
               F41021 LI --品目保管場所
               INNER JOIN F4100 LM --ロケーションマスタ
                  ON LI.LIMCU   = LM.LMMCU
                 AND LI.LILOCN  = LM.LMLOCN
               -------- 別注品購買業者、商品名、商品略名、商品分類1・2
               INNER JOIN F4101 IM
                  ON LI.LIITM = IM.IMITM
        WHERE
            SUBSTR(IM.IMLITM,11,2) IS NOT NULL
        /*IF stockPositionCode != null*/
        AND
          LI.LIMCU = LPAD(/*stockPositionCode*/'1000', 12)
        /*END*/
        /*IF stockCode == "3000" */
          AND  
          SUBSTR(IM.IMLITM,11,2) <> '  '
        /*END*/
        /*IF storePositionCode != null*/
        AND
          DECODE(LENGTH(TRIM(LI.LILOCN)), 15,SUBSTR(LI.LILOCN,1,3),TRIM(LI.LILOCN)) = /*storePositionCode*/'001'
        /*END*/
        /*IF stockCode == "1000" && storePositionCode == null*/
        AND
          (DECODE(LENGTH(TRIM(LI.LILOCN)), 15, SUBSTR(TRIM(LI.LILOCN),1,3), TRIM(LI.LILOCN)) <> '200'
          OR DECODE(LENGTH(TRIM(LI.LILOCN)), 15, SUBSTR(TRIM(LI.LILOCN),1,3), TRIM(LI.LILOCN)) <> '201'
          OR DECODE(LENGTH(TRIM(LI.LILOCN)), 15, SUBSTR(TRIM(LI.LILOCN),1,3), TRIM(LI.LILOCN)) <> '202')
        /*END*/
        /*IF stockCode != "1000" && storePositionCode == null && stockCategory != null*/
        AND
          LM.LMBIN = RPAD(/*stockCategory*/'900', 8)
        /*END*/
        /*IF stockCode == "1000" && storePositionCode == null && stockCategory == null*/
        AND
          LM.LMKZON = RPAD('1', 6)
        /*END*/
        /*IF stockCode == "1000" && storePositionCode == null && stockCategory != null*/
        AND
          LM.LMKZON <> RPAD('1', 6)
        AND
          LM.LMBIN = RPAD(/*stockCategory*/'900', 8)
        /*END*/
        /*IF manufacturerCode != null*/
        AND
          SUBSTR(IM.IMLITM,1,2) = /*manufacturerCode*/'01'
        /*END*/
        /*IF productCodes != null*/
        AND
          SUBSTR(IM.IMLITM,3,5) in /*productCodes*/('00001', '00169')
        /*END*/
        /*IF addtionNo != null*/
        AND
          TRIM(SUBSTR(IM.IMLITM,13,2)) IS NOT NULL
        /*END*/
        /*IF addtionNo == null*/
        AND
          TRIM(SUBSTR(IM.IMLITM,13,2)) IS NULL
        /*END*/
        
        GROUP BY
        IM.IMLITM --品目No
        ,IM.IMDSC1 --記述１
        ,IM.IMDSC2 --記述２
    ) IMBASE
   -------- 入荷予定明細、 入荷予定見出し-----------------------------
   LEFT OUTER JOIN 
     ( SELECT 
          TQ.TQY57BLITM    AS TQY57BLITM --品番
          ,TQ.TQY57BQTYA   AS TQY57BQTYA --入荷予定数
          ,TP.TPY57BRDD1   AS TPY57BRDD1 --入荷予定日
       FROM
          F57B0020 TQ
   INNER JOIN F57B0010 TP
      ON TQ.TQY57BRCNO = TP.TPY57BRCNO
     AND TP.TPY57BOSTS  < '499'
--     AND TP.TPY57BRDD1 >= TRUNC(SYSDATE)
     AND TQ.TQY57BUREC > 0
     /*IF stockPositionCode != null*/
     AND TP.TPY57BRMCU = LPAD(/*stockPositionCode*/'1000', 12)
     /*END*/
-- 画面引数：在庫場所が必要
-- 216は在庫場所＝1000の時のみ設定可能
    /*IF stockCode == "1000" */
    AND (TP.TPY57BRLCN <> RPAD('216', 20)
            OR   TP.TPY57BRLCN = RPAD(' ', 20))
    /*END*/
    /*IF stockCode != "1000" */
    AND TP.TPY57BRLCN = RPAD(' ', 20)
    /*END*/
   ) TQP
   ON IMBASE.IMLITM = TQP.TQY57BLITM
GROUP BY
IMBASE.IMLITM 
,IMBASE.IMDSC1 
,IMBASE.IMDSC2
,IMBASE.LIPQOH
)

SELECT
    COUNT(*) AS ROWCOUNT
FROM
    (

	SELECT
        TRIM(BALL_QR.IMLITM)                               AS IMLITM --品目No
        ,BALL_QR.IMDSC1                              AS IMDSC1 --記述１
        ,BALL_QR.IMDSC2                              AS IMDSC2 --記述２
        ,CASE WHEN BALL_QR.LIPQOH - DECODE(BALL_QR.TCY57AKRQT_R, NULL, 0, BALL_QR.TCY57AKRQT_R) >= 0 THEN BALL_QR.LIPQOH - DECODE(BALL_QR.TCY57AKRQT_R, NULL, 0, BALL_QR.TCY57AKRQT_R)
                      ELSE 0 END AS LIPQOH --在庫数量
        ,BALL_QR.TCY57AKRQT_R                        AS TCY57AKRQT_R --実在庫キープ
        ,BALL_QR.TCY57AKRQT_F                        AS TCY57AKRQT_F --予定在庫キープ
        ,SUM(BALL_QR.TQY57BQTYA)                     AS TQY57BQTYA --入荷予定数
        ,MIN(DECODE(SEQ, 1, BALL_QR.TPY57BRDD1, NULL))          AS TPY57BRDD1_1 --入荷予定日１
        ,MIN(DECODE(SEQ, 1, BALL_QR.TQY57BQTYA, NULL))          AS TQY57BQTYA_1 --入荷予定数１
        ,MIN(DECODE(SEQ, 2, BALL_QR.TPY57BRDD1, NULL))          AS TPY57BRDD1_2 --入荷予定日２
        ,MIN(DECODE(SEQ, 2, BALL_QR.TQY57BQTYA, NULL))          AS TQY57BQTYA_2 --入荷予定数２
        ,MIN(DECODE(SEQ, 3, BALL_QR.TPY57BRDD1, NULL))          AS TPY57BRDD1_3 --入荷予定日３
        ,MIN(DECODE(SEQ, 3, BALL_QR.TQY57BQTYA, NULL))          AS TQY57BQTYA_3 --入荷予定数３
        ,MIN(DECODE(SEQ, 4, BALL_QR.TPY57BRDD1, NULL))          AS TPY57BRDD1_4 --入荷予定日４
        ,MIN(DECODE(SEQ, 4, BALL_QR.TQY57BQTYA, NULL))          AS TQY57BQTYA_4 --入荷予定数４
        ,MIN(DECODE(SEQ, 5, BALL_QR.TPY57BRDD1, NULL))          AS TPY57BRDD1_5 --入荷予定日５
        ,MIN(DECODE(SEQ, 5, BALL_QR.TQY57BQTYA, NULL))          AS TQY57BQTYA_5 --入荷予定数５
        ,MIN(DECODE(SEQ, 6, BALL_QR.TPY57BRDD1, NULL))          AS TPY57BRDD1_6 --入荷予定日６
        ,MIN(DECODE(SEQ, 6, BALL_QR.TQY57BQTYA, NULL))          AS TQY57BQTYA_6 --入荷予定数６
        ,MIN(DECODE(SEQ, 7, BALL_QR.TPY57BRDD1, NULL))          AS TPY57BRDD1_7 --入荷予定日７
        ,MIN(DECODE(SEQ, 7, BALL_QR.TQY57BQTYA, NULL))          AS TQY57BQTYA_7 --入荷予定数７
        ,MIN(DECODE(SEQ, 8, BALL_QR.TPY57BRDD1, NULL))          AS TPY57BRDD1_8 --入荷予定日８
        ,MIN(DECODE(SEQ, 8, BALL_QR.TQY57BQTYA, NULL))          AS TQY57BQTYA_8 --入荷予定数８
        ,MIN(DECODE(SEQ, 9, BALL_QR.TPY57BRDD1, NULL))          AS TPY57BRDD1_9 --入荷予定日９
        ,MIN(DECODE(SEQ, 9, BALL_QR.TQY57BQTYA, NULL))          AS TQY57BQTYA_9 --入荷予定数９
        ,MIN(DECODE(SEQ, 10, BALL_QR.TPY57BRDD1, NULL))          AS TPY57BRDD1_10 --入荷予定日１０
        ,MIN(DECODE(SEQ, 10, BALL_QR.TQY57BQTYA, NULL))          AS TQY57BQTYA_10 --入荷予定数１０
        FROM
          (
            SELECT
            BKEEP_QR.IMLITM                               AS IMLITM --品目No
            ,BKEEP_QR.IMDSC1                              AS IMDSC1 --記述１
            ,BKEEP_QR.IMDSC2                              AS IMDSC2 --記述２
            ,BKEEP_QR.LIPQOH                              AS LIPQOH --在庫数量
            ,BKEEP_QR.TCY57AKRQT_R                        AS TCY57AKRQT_R --実在庫キープ
            ,BKEEP_QR.TCY57AKRQT_F                        AS TCY57AKRQT_F --予定在庫キープ
            ,SUM(TQP.TQY57BQTYA)                           AS TQY57BQTYA --入荷予定数
            ,DECODE(TQP.TPY57BRDD1, NULL, NULL,  TO_CHAR(TO_DATE(TQP.TPY57BRDD1, 'FMYYYY/MM/DD'), 'FMYYYY/MM/DD'))   AS TPY57BRDD1 --入荷予定日
            ,RANK() OVER(PARTITION BY BKEEP_QR.IMLITM --品目No
                          ORDER BY TQP.TPY57BRDD1)  AS SEQ
            FROM
              (
                SELECT
                BASE_QR.IMLITM                               AS IMLITM --品目No
                ,BASE_QR.IMDSC1                              AS IMDSC1 --記述１
                ,BASE_QR.IMDSC2                              AS IMDSC2 --記述２
                ,BASE_QR.LIPQOH                              AS LIPQOH --在庫数量
                ,SUM(CASE WHEN TC.TCPDDJ <= BASE_QR.TPY57BRDD1 THEN TC.TCY57AKRQT
                    WHEN BASE_QR.TPY57BRDD1 IS NULL THEN TC.TCY57AKRQT 
                    ELSE NULL END)  AS TCY57AKRQT_R --実在庫キープ
                ,SUM(CASE WHEN TC.TCPDDJ > BASE_QR.TPY57BRDD1 THEN TC.TCY57AKRQT ELSE NULL END)  AS TCY57AKRQT_F --予定在庫キープ
                FROM
                  BASE_QR
                LEFT OUTER JOIN F57A0030 TC
                   ON BASE_QR.IMLITM = TC.TCLITM
                   /*IF stockPositionCode != null*/
                    AND
                      TC.TCMCU = LPAD(/*stockPositionCode*/'1000', 12)
                  /*END*/
                WHERE
                     TRIM(TCY57AKPST) IS NULL
                      AND TRIM(TCY57ASTKF) IS NULL
                GROUP BY
                BASE_QR.IMLITM --品目No
                ,BASE_QR.IMDSC1 --記述１
                ,BASE_QR.IMDSC2 --記述２
                ,BASE_QR.LIPQOH 
              ) BKEEP_QR
             -------- 入荷予定明細、 入荷予定見出し-----------------------------
             LEFT OUTER JOIN 
             ( SELECT 
                  TQ.TQY57BLITM    AS TQY57BLITM --品番
                  ,TQ.TQY57BQTYA   AS TQY57BQTYA --入荷予定数
                  ,TP.TPY57BRDD1   AS TPY57BRDD1 --入荷予定日
               FROM
                  F57B0020 TQ
             INNER JOIN F57B0010 TP
                ON TQ.TQY57BRCNO = TP.TPY57BRCNO
               AND TP.TPY57BOSTS  < '499'
--               AND TP.TPY57BRDD1 >= TRUNC(SYSDATE)
               --実入荷予定数量→見せ入荷予定数量に変更
               AND TQ.TQY57BQTYA > 0
        /*IF stockPositionCode != null*/
          AND TP.TPY57BRMCU = LPAD(/*stockPositionCode*/'1000', 12)
        /*END*/
-- 画面引数：在庫場所が必要
-- 216は在庫場所＝1000の時のみ設定可能
        /*IF stockCode == "1000" */
        AND (TP.TPY57BRLCN <> RPAD('216', 20)
                OR   TP.TPY57BRLCN = RPAD(' ', 20))
        /*END*/
        /*IF stockCode != "1000" */
        AND TP.TPY57BRLCN = RPAD(' ', 20)
        /*END*/
    ) TQP
    ON BKEEP_QR.IMLITM = TQP.TQY57BLITM
            GROUP BY
              BKEEP_QR.IMLITM --品目No
              ,BKEEP_QR.IMDSC1 --記述１
              ,BKEEP_QR.IMDSC2 --記述２
              ,BKEEP_QR.LIPQOH 
              ,BKEEP_QR.TCY57AKRQT_R
              ,BKEEP_QR.TCY57AKRQT_F
              ,TQP.TPY57BRDD1
          ) BALL_QR
        GROUP BY
          BALL_QR.IMLITM --品目No
          ,BALL_QR.IMDSC1 --記述１
          ,BALL_QR.IMDSC2 --記述２
          ,BALL_QR.LIPQOH 
          ,BALL_QR.TCY57AKRQT_R
          ,BALL_QR.TCY57AKRQT_F
)