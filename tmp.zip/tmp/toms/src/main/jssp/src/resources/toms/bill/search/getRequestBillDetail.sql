SELECT
    *
FROM
(
  SELECT
        base.*
    , ROWNUM AS RN
  FROM
  (
SELECT
    TQ.TQA701 AS TQA701                                                             -- 日付
   ,DECODE(TQ.TQNETTCID, 0, NULL, TQ.TQNETTCID) AS TQNETTCID                        -- 伝票No
   ,TQ.TQR004 AS TQR004                                                             -- 区分
   ,TQ.TQDSC1 AS TQDSC1                                                             -- 商品名
   ,TQ.TQUORG AS TQUORG                                                             -- 数量
   ,TRUNC(TQ.TQUPRC/10000) AS TQUPRC                                                -- 単価
   ,TQ.TQATXA AS TQATXA                                                             -- 金額
   ,TRIM(TQ.TQRMK) || ' ' || TRIM(TQ.TQRMK2) || ' ' || TRIM(TQ.TQY57AHRMK) AS TQRMK -- 備考
   ,CASE TQ.TQY56CBLD
      WHEN N'0' THEN N'●'
      WHEN N'1' THEN N' '
    END AS TQY56CBLD                                                                -- 帳端区分
   ,TE.TELGL1 AS TQLGL1                                                             -- メモ
   ,DECODE(TRIM(TQ.TQDSC1), '計', '1', '0') AS TOTALFLAG
FROM 
    F56C1013 TQ
    INNER JOIN (
         SELECT 
             TDPYR
            ,TDY56CDDJ
            ,TDY56CRQN
            ,MAX(TDY56DNTRN) AS TDY56DNTRN
         FROM 
             F56C1011
         WHERE 
         /*BEGIN*/
             /*IF exchangeTargetCode != null*/
             TDPYR = /*exchangeTargetCode*/'11000300'
             /*END*/
             /*IF requestNo != null*/
             AND TDY56CRQN = /*requestNo*/'1509423'
             /*END*/
             /*IF searchCloseDate != null*/
             AND TDY56CDDJ = /*searchCloseDate*/'115090'
             /*END*/
         GROUP BY
             TDPYR
            ,TDY56CDDJ
            ,TDY56CRQN
        ) TD
        ON  TQ.TQPYR = TD.TDPYR
        AND TQ.TQY56CDDJ = TD.TDY56CDDJ
        AND TQ.TQY56CRQN = TD.TDY56CRQN
        AND TQ.TQY56DNTRN = TD.TDY56DNTRN
    LEFT OUTER JOIN
        F56C1012 TE
        ON  TQ.TQPYR = TE.TEPYR
        AND TQ.TQY56CDDJ = TE.TEY56CDDJ
        AND TQ.TQY56CRSD = TE.TEY56CRSD
        AND TQ.TQNETTCID = TE.TEDOC
        AND TQ.TQR004 = TE.TESDCT

WHERE
    /*IF exchangeTargetCode != null*/
    TQ.TQPYR = /*exchangeTargetCode*/'11000300'
    /*END*/
    /*IF requestNo != null*/
    AND TQ.TQY56CRQN = /*requestNo*/'1509423'
    /*END*/
    /*IF searchCloseDate != null*/
    AND TQ.TQY56CDDJ = /*searchCloseDate*/'115090'
    /*END*/

ORDER BY
TQ.TQPYR
,TQ.TQY56CDDJ
,TQ.TQY56CRQN
,TQ.TQY56DNTRN
,TQ.TQUKRECN
  ) base
   /*IF end != null*/
      WHERE ROWNUM <= /*end*/'1500' 
   /*END*/
)
/*IF start != null*/
WHERE RN >= /*start*/'1' 
/*END*/
/*END*/