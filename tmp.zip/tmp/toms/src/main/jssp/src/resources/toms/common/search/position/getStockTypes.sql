SELECT 
  TRIM(VALUE2) AS value,
  TRIM(VALUE1) AS label
FROM
  TW_TCMN019001
WHERE
  SYSTEM_ID = 'TOMS-WEB'
/*IF key1 != null*/
AND
  TRIM(KEY1) = /*key1*/'zik'
/*END*/
  /*IF key2 != null*/
AND
  TRIM(KEY2) = /*key2*/'001'
/*END*/
ORDER BY
KEY3