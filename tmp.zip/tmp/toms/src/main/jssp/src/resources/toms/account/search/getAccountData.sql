WITH BASE_QR AS
(
--当月--

SELECT
RPAN8, --顧客コード
RPAAP, --未入金額
'0' AS DATA_TYPE --データ種類：当月
FROM F03B11 --債権テーブル
WHERE RPICUT = 'IB' --バッチタイプ「IB:請求」
--AND RPRYIN IN ('F','E') --支払手段「F：ファクタリング」「E：現金」
AND RPPST <> 'P' --支払状況「P:支払済み」
--AND RPAAP >= 1 --未入金額
AND RPDCT IN ('U8','U9','RM') --伝票タイプ
AND RPDDJ >= (SELECT FC_JDI9902_TO_JULIAN(TRUNC(SYSDATE,'MONTH'))  FROM DUAL) --月初から
AND RPDDJ < FC_JDI9902_TO_JULIAN(SYSDATE) --システム日付の前日までの支払期日

UNION ALL--------

-- 一ヶ月前 --
SELECT
RPAN8, --顧客コード
RPAAP, --未入金額
'1' AS DATA_TYPE --データ種類：一ヶ月前
FROM F03B11 --債権テーブル
WHERE RPICUT = 'IB' --バッチタイプ「IB:請求」
--AND RPRYIN IN ('F','E') --支払手段「F：ファクタリング」「E：現金」
AND RPPST <> 'P' --支払状況「P:支払済み」
--AND RPAAP >= 1 --未入金額
AND RPDCT IN ('U8','U9','RM') --伝票タイプ
AND RPDDJ >= (SELECT FC_JDI9902_TO_JULIAN(ADD_MONTHS(TRUNC(SYSDATE,'MONTH'),-1))  FROM DUAL) --先月初
AND RPDDJ <= (SELECT FC_JDI9902_TO_JULIAN(ADD_MONTHS(LAST_DAY(SYSDATE),-1)) FROM DUAL) --先月末

UNION ALL--------

-- 二ヶ月前 --
SELECT
RPAN8, --顧客コード
RPAAP, --未入金額
'2' AS DATA_TYPE --データ種類：二ヶ月前
FROM F03B11 --債権テーブル
WHERE RPICUT = 'IB' --バッチタイプ「IB:請求」
--AND RPRYIN IN ('F','E') --支払手段「F：ファクタリング」「E：現金」
AND RPPST <> 'P' --支払状況「P:支払済み」
--AND RPAAP >= 1 --未入金額
AND RPDCT IN ('U8','U9','RM') --伝票タイプ
AND RPDDJ >= (SELECT FC_JDI9902_TO_JULIAN(ADD_MONTHS(TRUNC(SYSDATE,'MONTH'),-2))  FROM DUAL) --二ヶ月前の月初
AND RPDDJ <= (SELECT FC_JDI9902_TO_JULIAN(ADD_MONTHS(LAST_DAY(SYSDATE),-2)) FROM DUAL) --二ヶ月前の先月末

UNION ALL--------

-- 三ヶ月前 --
SELECT
RPAN8, --顧客コード
RPAAP, --未入金額
'3' AS DATA_TYPE --データ種類：三ヶ月前
FROM F03B11 --債権テーブル
WHERE RPICUT = 'IB' --バッチタイプ「IB:請求」
--AND RPRYIN IN ('F','E') --支払手段「F：ファクタリング」「E：現金」
AND RPPST <> 'P' --支払状況「P:支払済み」
--AND RPAAP >= 1 --未入金額
AND RPDCT IN ('U8','U9','RM') --伝票タイプ
AND RPDDJ >= (SELECT FC_JDI9902_TO_JULIAN(ADD_MONTHS(TRUNC(SYSDATE,'MONTH'),-3))  FROM DUAL) --三ヶ月前の月初
AND RPDDJ <= (SELECT FC_JDI9902_TO_JULIAN(ADD_MONTHS(LAST_DAY(SYSDATE),-3)) FROM DUAL) --三ヶ月前の先月末

UNION ALL--------

-- 四ヶ月前 --
SELECT
RPAN8, --顧客コード
RPAAP, --未入金額
'4' AS DATA_TYPE --データ種類：四ヶ月前
FROM F03B11 --債権テーブル
WHERE RPICUT = 'IB' --バッチタイプ「IB:請求」
--AND RPRYIN IN ('F','E') --支払手段「F：ファクタリング」「E：現金」
AND RPPST <> 'P' --支払状況「P:支払済み」
--AND RPAAP >= 1 --未入金額
AND RPDCT IN ('U8','U9','RM') --伝票タイプ
AND RPDDJ >= (SELECT FC_JDI9902_TO_JULIAN(ADD_MONTHS(TRUNC(SYSDATE,'MONTH'),-4))  FROM DUAL) --四ヶ月前の月初
AND RPDDJ <= (SELECT FC_JDI9902_TO_JULIAN(ADD_MONTHS(LAST_DAY(SYSDATE),-4)) FROM DUAL) --四ヶ月前の先月末

UNION ALL--------

-- 五ヶ月前 --
SELECT
RPAN8, --顧客コード
RPAAP, --未入金額
'5' AS DATA_TYPE --データ種類：五ヶ月前
FROM F03B11 --債権テーブル
WHERE RPICUT = 'IB' --バッチタイプ「IB:請求」
--AND RPRYIN IN ('F','E') --支払手段「F：ファクタリング」「E：現金」
AND RPPST <> 'P' --支払状況「P:支払済み」
--AND RPAAP >= 1 --未入金額
AND RPDCT IN ('U8','U9','RM') --伝票タイプ
--AND RPDDJ >= (SELECT FC_JDI9902_TO_JULIAN(ADD_MONTHS(TRUNC(SYSDATE,'MONTH'),-5))  FROM DUAL) --五ヶ月前の月初
AND RPDDJ <= (SELECT FC_JDI9902_TO_JULIAN(ADD_MONTHS(LAST_DAY(SYSDATE),-5)) FROM DUAL) --五ヶ月前の先月末

UNION ALL--------

-- 仮受入金未充当情報の取得 --

SELECT
RPAN8, --顧客コード
RPAAP, --仮受金額
'99' AS DATA_TYPE --データ種類：仮受入金未充当情報
FROM F03B11 --債権テーブル
LEFT JOIN F0101 A01 ON  --住所録テーブル（顧客情報を取得）
  RPAN8 = A01.ABAN8
LEFT JOIN F0101 B01 ON --住所録テーブル（営業者情報を取得）
  A01.ABAN84 = B01.ABAN8
LEFT JOIN F03012 ON --顧客テーブル
  RPAN8 = AIAN8
LEFT JOIN F0006 ON --BUテーブル
  A01.ABMCU = MCMCU
LEFT JOIN F00141 ON --支払条件
  TRIM(AITRAR) = TRIM(L3PTC)
LEFT JOIN F00143 ON --日付範囲
  TRIM(AITRAR) = TRIM(L5DDRL) AND
  L5FMDY = 1
WHERE RPICUT IN ('RB', 'DB') --バッチタイプ「IB:請求」
AND RPPST <> 'P' --支払状況「P:支払済み」
AND RPAAP < 0 --未入金額
--AND RPDCT <> 'RB'
AND RPDCT = 'RU' --伝票タイプ
)

SELECT
  TRIM(A01.ABMCU) AS ABMCU, --組織コード
  TRIM(MCDC) AS MCDC, --組織名称
  TRIM(A01.ABAN84) AS ABAN84, --営業者コード
  TRIM(B01.ABALPH) AS ABAN84_NM, --営業者名称
  TRIM(RPAN8) AS RPAN8, --顧客コード
  TRIM(A01.ABALPH) AS RPAN8_NM, --顧客名称
  DECODE(TRIM(A01.ABAC10), '99', '末日', TRIM(A01.ABAC10)) AS ABAC10,  --締日
  TRIM(AITRAR) AS AITRAR, --支払条件
  TRIM(L3PTD) AS L3PTD, --支払条件記述
  SUM(DECODE(BASE_QR.DATA_TYPE, '0', BASE_QR.RPAAP, 0)) AS RPAAP_0, --未入金額:当月
  SUM(DECODE(BASE_QR.DATA_TYPE, '1', BASE_QR.RPAAP, 0)) AS RPAAP_1, --未入金額:前月
  SUM(DECODE(BASE_QR.DATA_TYPE, '2', BASE_QR.RPAAP, 0)) AS RPAAP_2, --未入金額:二ヶ月前
  SUM(DECODE(BASE_QR.DATA_TYPE, '3', BASE_QR.RPAAP, 0)) AS RPAAP_3, --未入金額:三ヶ月前
  SUM(DECODE(BASE_QR.DATA_TYPE, '4', BASE_QR.RPAAP, 0)) AS RPAAP_4, --未入金額:四ヶ月前
  SUM(DECODE(BASE_QR.DATA_TYPE, '5', BASE_QR.RPAAP, 0)) AS RPAAP_5, --未入金額:五ヶ月前
  SUM(DECODE(BASE_QR.DATA_TYPE, '99', BASE_QR.RPAAP, 0)) AS RPAAP_99 --未入金額:未充当
FROM
  BASE_QR
LEFT JOIN F0101 A01 ON  --住所録テーブル（顧客情報を取得）
  RPAN8 = A01.ABAN8
LEFT JOIN F0101 B01 ON --住所録テーブル（営業者情報を取得）
  A01.ABAN84 = B01.ABAN8
LEFT JOIN F03012 ON --顧客テーブル
  RPAN8 = AIAN8
LEFT JOIN F0006 ON --BUテーブル
  A01.ABMCU = MCMCU
LEFT JOIN F00141 ON --支払条件
  TRIM(AITRAR) = TRIM(L3PTC)
LEFT JOIN F00143 ON --日付範囲
  TRIM(AITRAR) = TRIM(L5DDRL) AND
  L5FMDY = 1

/*BEGIN*/
WHERE
	/*IF organizationCode != null*/
	TRIM(A01.ABMCU) IN /*organizationCode*/('101', '102')
	/*END*/
	/*IF paymentDayFrom != null*/
	AND L5DYFX >= /*paymentDayFrom*/'1'
	/*END*/
	/*IF paymentDayTo != null*/
	AND L5DYFX <= /*paymentDayTo*/'31'
	/*END*/
/*END*/


GROUP BY
  A01.ABMCU, --組織コード
  MCDC, --組織名称
  A01.ABAN84, --営業者コード
  B01.ABALPH, --営業者名称
  RPAN8, --顧客コード
  A01.ABALPH, --顧客名称
  A01.ABAC10,  --締日
  AITRAR, --支払条件
  L3PTD --支払条件記述
order by 
ABMCU, --組織コード
ABAN84, --営業者コード
RPAN8, --顧客コード
ABAC10 --締日

