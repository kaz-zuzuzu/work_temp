SELECT value
      ,label
FROM (
      SELECT TO_CHAR(' ')       as value
            ,TO_NCHAR('全て')    as label
      FROM DUAL
      UNION ALL
      SELECT DISTINCT(TRIM(a.aban84))                       as value
            ,TRIM(d.wwalph) || ' ('|| TRIM(a.aban84) || ')' as label
      FROM   F0101 a
        INNER JOIN (select aban8 from F0101 where TRIM(abat1) like '8%') b
          ON   a.aban84 = b.aban8
        LEFT OUTER JOIN F0006 c
          ON   a.ABMCU = c.MCMCU
        LEFT OUTER JOIN F0111 d
          ON   a.ABAN84 = d.WWAN8
          AND  d.WWIDLN = 0
      WHERE TRIM(a.ABAT1) IN  /*exchangeCategoryCd*/('1C','1D')      --取引種別
      /*IF organizationCd != null*/
        AND TRIM(a.ABMCU) IN /*organizationCd*/('101', '102', '109') --組織
      /*END*/
     )
GROUP BY value
        ,label
ORDER BY value