SELECT value
      ,label
FROM (
      SELECT TO_CHAR(' ')       as value
            ,TO_NCHAR('全て')    as label
      FROM DUAL
      UNION ALL
      SELECT TRIM(a.aban84)                                 as value
            ,TRIM(c.wwalph) || ' ('|| TRIM(a.aban84) || ')' as label
      FROM   f0101 a
      LEFT OUTER JOIN F0006 b
        ON   a.ABMCU = b.MCMCU
      LEFT OUTER JOIN F0111 c
        ON   a.ABAN84 = c.WWAN8
       AND   c.WWIDLN = 0
      WHERE  a.abat1 in ('1A ', '1D ', '1E ', '1L ')
      /*IF organizationCd != null*/
        AND  TRIM(a.ABMCU) IN /*organizationCd*/('101', '102', '109') --組織
      /*END*/
     )
GROUP BY value
        ,label
ORDER BY value