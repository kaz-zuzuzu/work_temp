SELECT
  NVL(TRIM(mcmcu), ' ') AS value,
  DECODE(TRIM(mcmcu), NULL, '（全組織）', TRIM(mcdc)) AS label
FROM
  f0006
/*BEGIN*/
WHERE
	/*IF superOrganizationCodeParam != null*/
	 TRIM(mcrp03) = /*superOrganizationCodeParam*/'001'
	/*END*/
/*END*/
ORDER  BY value ASC NULLS FIRST