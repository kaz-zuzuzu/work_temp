SELECT
    *
FROM
(
    SELECT
        base.* 
        ,ROWNUM AS RN
    FROM
    ( 
        select 
         distinct
          TO_CHAR(FC_JDI9902_TO_DATE(TD.TDADDJ),'fmYYYY/MM/DD') AS TDADDJ    --出庫日付
          -----加工無地区分----------------------------------------
          , CASE 
            WHEN TA.TADCTO IN ('CP', 'SP') 
            THEN '加工' 
            ELSE '無地' 
            END as TADCTO2                        --加工無地区分
          , TD.TDY57ASDCT        as TDY57ASDCT    --伝票タイプ
          , RTRIM(TD.TDY57ASHPN) as TDY57ASHPN    --出荷予定番号
          , TD.TDDOCO            as TDDOCO        --オーダーNo.
          , TRIM(TD.TDDCTO)      as TDDCTO        --オーダータイプ
          , TRIM(TD.TDY57CPCN)   as TDY57CPCN     --ピッキングNO
          , TRIM(AB.ABALPH)      as ABALPH        --取引先
          , AB.ABALP1            as ABALP1        --取引先ｶﾅ
          , AB.ABAN8             as ABAN8         --取引先コード
          , TRIM(DR_Y57CUBC.DRDL01)    as DRDL          --運送会社
--               , DR_Y57CUBC.DRDL01    as DRDL          --運送会社
--          , TD.TDY57ASENO as TDY57ASENO         --送り状No
--          , (select
--                  wk_0150.tay57cokj 
--                from
--                  ( 
--                    SELECT
--                      ta1.tay57cpcn
--                      , TO_CHAR(wmsys.wm_concat(ta1.tay57cokj)) as tay57cokj 
--                    FROM
--                      f57a0150 ta1
--                      , f57a0070 td1 
--                    WHERE
--                      ta1.tay57cpcn = td1.tdy57cpcn 
--                    GROUP BY
--                      ta1.tay57cpcn
--                     order by  ta1.tay57cpcn
--                  ) wk_0150
--                
--                WHERE wk_0150.tay57cpcn = TD.TDY57CPCN
--                ) as  TAY57COKJ                 --送り状No
          ,('') as TAY57COKJ                      --送り状No
            -----総数----------------------------------------
         ,(SELECT sum(detail.TESOQS) from F57A0071 detail
             LEFT JOIN F4101 IM
                ON detail.TELITM = IM.IMLITM
             WHERE detail.TEY57ASHPN = TD.TDY57ASHPN
             AND detail.TEY57ASDCT = TD.TDY57ASDCT
             AND IM.IMLNTY = 'S'
          ) as TFSOQS                             --総数
--        , TD.TDY57CYK as TDY57CYK               --個口数
         ,( SELECT sum(send.tay57cboxn) FROM  F57A0070 td1 
             INNER JOIN F57A0150 send
              ON td1.tdy57CPCN = send.tay57CPCN
              WHERE td1.tdy57ASHPN = TD.TDY57ASHPN
                  AND td1.tdy57asdct = TD.TDY57ASDCT
         ) as TDY57CYK                            --個口数
         , TRIM(TD.TDY57AHRMK) as TDY57AHRMK      --柄名
         , TRIM(TD.TDVR01) as TDVR01              --販売先発注番号
          , DECODE( 
            TD.TDY57ASHPS
            , '550'
            , 'ピッキング完了'
            , '580'
            , '出荷登録'
            , '590'
            , '出荷確定'
            , '600'
            , '返品売上取り消し'
            , '999'
            , '売上済'
          ) as TDY57ASHPS                         --状況
        
        FROM
          F57A0070 TD             --出荷予定見出し
          INNER JOIN F57A0010 TA  --受注見出し
            ON TD.TDKCOO = TA.TAKCOO 
            AND TD.TDDOCO = TA.TADOCO 
            AND TD.TDDCTO = TA.TADCTO             -- 商品名、商品略名、商品分類1・2
        ----------出荷予定明細---------------------------
        --    INNER JOIN F57A0071 TE
        --      ON TD.TDY57ASHPN = TE.TEY57ASHPN
        --      AND TD.TDY57ASDCT = TE.TEY57ASDCT
        --      AND TD.TDY57CPCN = TE.TEY57CPCN
        ----------販売先---------------------------
          INNER JOIN F0101 AB
           ON TD.TDAN8 = AB.ABAN8
            INNER JOIN F0111 WW -- 住所録（人名録）
                ON AB.ABAN8  = WW.WWAN8
               AND WW.WWIDLN = 0
            INNER JOIN F03012 AI -- 顧客マスタ
                ON WW.WWAN8  = AI.AIAN8
               AND AI.AICO   = '00000'
             -------- 営業担当者 ---------------------------------
             LEFT OUTER JOIN F0111 WW_ABAN84
                ON AB.ABAN84 = WW_ABAN84.WWAN8
               AND WW_ABAN84.WWIDLN        = 0
        -------- 便種 ---------------------------------
          LEFT OUTER JOIN F0005 DR_Y57CUBC 
            ON RTRIM(LTRIM(TD.TDY57CUBC)) = RTRIM(LTRIM(DR_Y57CUBC.DRKY)) 
            AND DR_Y57CUBC.DRSY = '01' 
            AND DR_Y57CUBC.DRRT = '06'
        
        /*BEGIN*/
        WHERE
          /*IF stockPositionList != null*/
          TD.TDMCU = LPAD(/*stockPositionList*/'1000', 12)              --在庫場所
          /*END*/
          /*IF organization != null*/
          AND TRIM(TD.TDEMCU) IN /*organization*/('101','102','350')    --組織コード
          /*END*/
          /*IF receiveOrderNo != null*/
          AND TD.TDDOCO = /*receiveOrderNo*/15007374                    --オーダーNo
          /*END*/
          /*IF orderTypeList != null*/
          AND TD.TDDCTO IN /*orderTypeList*/('SP','SE')                 --オーダータイプ
          /*END*/
          /*IF instructNo != null*/
          AND TD.TDY57ASHPN = /*instructNo*/15004035                    --出荷予定番号
          /*END*/
          /*IF destination != null*/
          AND TD.TDALPH LIKE /*destination*/'%クロス%'                  --納入先
          /*END*/
          /*IF exchangeTarget != null*/
          AND AB.ABALP1 LIKE /*exchangeTarget*/'%ｸﾛｽ%'                  --取引先カナ
          /*END*/
          /*IF deliveryDateFrom != null*/
          AND
          TO_CHAR(FC_JDI9902_TO_DATE(TD.TDADDJ), 'YYYY/MM/DD') >=/*deliveryDateFrom*/'2015/08/01' --出庫日付FROM
          /*END*/
          /*IF deliveryDateTo != null*/
          AND
          TO_CHAR(FC_JDI9902_TO_DATE(TD.TDADDJ), 'YYYY/MM/DD') <=/*deliveryDateTo*/'2015/08/31'   --出庫日付TO
          /*END*/
          AND TD.TDY57ASHPS >= '550'    -- 出荷予定ステータス
          /*END*/
          
        ORDER BY 
            TDADDJ
           ,TADCTO2
           ,TDDOCO
    ) base
     /*IF end != null*/
        WHERE ROWNUM <= /*end*/'15' 
     /*END*/
)
/*IF start != null*/
WHERE RN >= /*start*/'1' 
/*END*/