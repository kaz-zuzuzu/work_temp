SELECT
    *
FROM
(
	SELECT
        base.*
	  , ROWNUM AS RN
	FROM
	(
		SELECT DISTINCT
		  TRIM(BREC.TDPYR) AS TDPYR                                -- 販売先C
		  ,TRIM(AB.ABALPH) AS ABALPH                             -- 販売先
		  ,TRIM(AB.ABDC) AS ABDC                                 -- 販売先カナ
		  ,TRIM(AI.AIARPY) AS AIARPY                             -- 支払人C
		  ,TRIM(AB2.ABALPH) AS ABALPH_P                            -- 支払人
		  ,TRIM(AI2.AITRAR) AS AITRAR                            -- 支払条件
		  ,TRIM(PN.PNPTD) AS PNPTD                               -- 支払条件名
		  ,TRIM(TD.TDY56CDDJ) AS TDY56CDDJ                            -- 締日(PK)
		  ,TRIM(AB2.ABAC10) AS ABAC10                            -- 締日
		 -- ,TO_CHAR(ADD_MONTHS(TO_DATE(CONCAT(BREC.YEARMONTH, '01'), 'YYYYMMDD'), - 2), 'YYYY') AS TYEAR   -- 年度
		 -- ,SUBSTR(BREC.YEARMONTH, 5, 2) AS MONTH               -- 月  
		  ,BREC.YEARMONTH AS TDY56CCYM                        -- 締年月
		  ,TRIM(TD.TDY56CRSD) AS HTDY56CRSD                       -- 債権状況区分
		  ,DECODE(TRIM(TD.TDY56CRSD), 1, '○', null) AS  TDY56CRSD -- 債権状況区分
		  ,TRIM(TD.TDY56CFAC) AS TDY56CFAC                        -- ファクタリング
		  ,TRIM(AB.ABMCU) AS ABMCU                                -- 部門C
		  ,TRIM(MC.MCDL01) AS MCDL01                              -- 部門
		  ,TRIM(TD.TDMCU) AS TDMCU                                -- 部門_トラン
		  ,TRIM(AB.ABAN84) AS ABAN84                              -- 営業担当者C
		  ,TRIM(WW.WWALPH) AS WWALPH                              -- 営業担当者名
		  ,TD.TDY56CPBL AS TDY56CPBL                        -- 前回請求額
		  ,TD.TDY56CCDA AS TDY56CCDA                        -- 今回入金額
		  ,DECODE(TD.TDY56CPBL, NULL, '', 0, '100%', TO_CHAR(ROUND((TD.TDY56CCDA/TD.TDY56CPBL)*100,1)) || '%') AS RATE   -- 回収率
		  ,TD.TDY56CDIA AS TDY56CDIA                        -- 値引き額
		  ,TD.TDY56CBBF AS TDY56CBBF                        -- 繰越残高
		  ,TD.TDY56CCBA AS TDY56CCBA                        -- 今回買入額
		  ,TD.TDY56CTA AS TDY56CTA                          -- 消費税額
		  ,(TD.TDY56CCBA + TD.TDY56CTA) AS SUMCBATA          -- 今回買入額合計
		  ,TD.TDY56CCBI AS TDY56CCBI                          -- 今回請求額
		  ,TD.TDY56CFEA AS TDY56CFEA                          -- ファクタリング債権超過額
		  ,TD.TDY56CRQN AS TDY56CRQN                          -- 請求書番号
		  ,TD.TDLGL1 AS TDLGL1                                -- メモ
		FROM -- 【トランザクションテーブル】 ---------------------
		(
				SELECT
				     DNX.TDPYR AS TDPYR
	                 ,DNX.MINCCYM AS MINCCYM
	                 ,DNX.MAXCCYM AS MAXCCYM
	                 ,MAXROWS.YEARMONTH AS YEARMONTH
				FROM 
				(
	              SELECT
	                  TD.TDPYR AS TDPYR
	                  ,MIN(TD.TDY56CCYM) AS MINCCYM
	                  ,MAX(TD.TDY56CCYM) AS MAXCCYM
	                  FROM -- 【トランザクションテーブル】 ---------------------
	                     F56C1011 TD
	                     -- 販売先名 -------------------------------
	                  LEFT OUTER JOIN F0101 AB
	                       ON TD.TDPYR = AB.ABAN8
	                  LEFT OUTER JOIN F03012 AI
	                        ON AB.ABAN8 = AI.AIAN8
	                       AND AI.AICO  = '00000'
	                     -- 支払人名 -------------------------------
	                  LEFT OUTER JOIN F0101 AB2
	                       ON AI.AIARPY = AB2.ABAN8
	                  WHERE
	                      1 = 1
	                      /*IF exchangeTargetCode != null*/
	                      AND TD.TDPYR = /*exchangeTargetCode*/'11160860'
	                      /*END*/
	                      /*IF exchangeTargetKana != null*/
	                      AND AB.ABDC like /*exchangeTargetKana*/'%ｶ%'
	                      /*END*/
	                       /*IF paymentPersonCode != null*/
	                      AND AI.AIARPY = /*paymentPersonCode*/'11160860'
	                      /*END*/
	                      /*IF paymentPersonKana != null*/
	                      AND AB2.ABDC like /*paymentPersonKana*/'%ｶ%'
	                      /*END*/
	                  GROUP BY
	                      TD.TDPYR
	            ) DNX
				CROSS JOIN 
				(
				    SELECT 
				        TO_CHAR(ADD_MONTHS(
				        (
				        SELECT DISTINCT
				              TO_DATE(CONCAT(MIN(TD.TDY56CCYM),'01'), 'YYYYMMDD') AS MINDATE                      -- 最小日付
				            FROM -- 【トランザクションテーブル】 ---------------------
				               F56C1011 TD
				               -- 販売先名 -------------------------------
				            LEFT OUTER JOIN F0101 AB
				                 ON TD.TDPYR = AB.ABAN8
				            LEFT OUTER JOIN F03012 AI
				                  ON AB.ABAN8 = AI.AIAN8
				                 AND AI.AICO  = '00000'
				               -- 支払人名 -------------------------------
				            LEFT OUTER JOIN F0101 AB2
				                 ON AI.AIARPY = AB2.ABAN8
				            WHERE
				                1 = 1
				                /*IF exchangeTargetCode != null*/
				                AND TD.TDPYR = /*exchangeTargetCode*/'11160860'
				                /*END*/
				                /*IF exchangeTargetKana != null*/
				                AND AB.ABDC like /*exchangeTargetKana*/'%ｶ%'
				                /*END*/
				                 /*IF paymentPersonCode != null*/
				                AND AI.AIARPY = /*paymentPersonCode*/'11160860'
				                /*END*/
				                /*IF paymentPersonKana != null*/
				                AND AB2.ABDC like /*paymentPersonKana*/'%ｶ%'
				                /*END*/
				        )
				      , Rownum - 1), 'YYYYMM') AS YEARMONTH
				      FROM dual
				      CONNECT BY Rownum <= (
				      SELECT DISTINCT
				                MAX(TD.TDY56CCYM) - MIN(TD.TDY56CCYM) + 1 AS MAXROWCOUNT                      -- 最大レコード数
				              FROM -- 【トランザクションテーブル】 ---------------------
				                 F56C1011 TD
				                 -- 販売先名 -------------------------------
				              LEFT OUTER JOIN F0101 AB
				                   ON TD.TDPYR = AB.ABAN8
				              LEFT OUTER JOIN F03012 AI
				                    ON AB.ABAN8 = AI.AIAN8
				                   AND AI.AICO  = '00000'
				                 -- 支払人名 -------------------------------
				              LEFT OUTER JOIN F0101 AB2
				                   ON AI.AIARPY = AB2.ABAN8
				              WHERE
				                  1 = 1
				                  /*IF exchangeTargetCode != null*/
				                  AND TD.TDPYR = /*exchangeTargetCode*/'11160860'
				                  /*END*/
				                  /*IF exchangeTargetKana != null*/
				                  AND AB.ABDC like /*exchangeTargetKana*/'%ｶ%'
				                  /*END*/
				                   /*IF paymentPersonCode != null*/
				                  AND AI.AIARPY = /*paymentPersonCode*/'11160860'
				                  /*END*/
				                  /*IF paymentPersonKana != null*/
				                  AND AB2.ABDC like /*paymentPersonKana*/'%ｶ%'
				                  /*END*/
				      )
				) MAXROWS
			 WHERE
                 MAXROWS.YEARMONTH >= DNX.MINCCYM
                 AND
                 MAXROWS.YEARMONTH <= DNX.MAXCCYM
			GROUP BY
                DNX.TDPYR
                ,DNX.MINCCYM
                ,DNX.MAXCCYM
                ,MAXROWS.YEARMONTH
		) BREC
		LEFT OUTER JOIN F56C1011 TD
		  ON BREC.TDPYR = TD.TDPYR
		  AND BREC.YEARMONTH = TD.TDY56CCYM
		   -- 販売先名 -------------------------------
		LEFT OUTER JOIN F0101 AB
		     ON BREC.TDPYR = AB.ABAN8
		LEFT OUTER JOIN F03012 AI
		      ON AB.ABAN8 = AI.AIAN8
		     AND AI.AICO  = '00000'
		   -- 支払人名 -------------------------------
		LEFT OUTER JOIN F0101 AB2
		     ON AI.AIARPY = AB2.ABAN8
		LEFT OUTER JOIN F03012 AI2
		      ON AB2.ABAN8 = AI2.AIAN8
		     AND AI2.AICO  = '00000'
		   -------- 支払条件 -----------------------------------
		LEFT OUTER JOIN F0014 PN
		     ON TRIM(AI2.AITRAR) = TRIM(PN.PNPTC)
		   -------- 販売部門、上位組織 -------------------------
		LEFT OUTER JOIN F0006 MC
		     ON TRIM(AB.ABMCU) = TRIM(MC.MCMCU)
		   -------- 営業担当者 ---------------------------------
		LEFT OUTER JOIN F0111 WW
		      ON TRIM(AB.ABAN84) = TRIM(WW.WWAN8)
		     AND WW.WWIDLN        = 0
		WHERE
		    1 = 1
		    /*IF exchangeTargetCode != null*/
		    AND BREC.TDPYR = /*exchangeTargetCode*/'11160860'
		    /*END*/
		    /*IF exchangeTargetKana != null*/
		    AND AB.ABDC like /*exchangeTargetKana*/'%ｶ%'
		    /*END*/
		     /*IF paymentPersonCode != null*/
		    AND AI.AIARPY = /*paymentPersonCode*/'11160860'
		    /*END*/
		    /*IF paymentPersonKana != null*/
		    AND AB2.ABDC like /*paymentPersonKana*/'%ｶ%'
		    /*END*/
		ORDER BY
		    TDPYR
		    ,AIARPY
		    ,ABMCU
		    ,ABAN84
		    ,TDY56CCYM DESC
		    ,ABAC10
	) base
	 /*IF end != null*/
	    WHERE ROWNUM <= /*end*/'15' 
	 /*END*/
)
/*IF start != null*/
WHERE RN >= /*start*/'1' 
/*END*/