SELECT DISTINCT
       AL.PCODE
      ,AL.PNAME
      ,AL.STATUS
  FROM (/*********************
         ** 実在庫からの商品リスト 
         *********************/
        SELECT SUBSTR(TRIM(IM.IMLITM),3,5)                    AS PCODE --商品コード
              ,TRIM(IM.IMDSC1)                                AS PNAME --商品名
              ,'未選択'                                       AS STATUS --ステータス 
        FROM -- 【トランザクションテーブル】 ---------------------
             F41021 LI --品目保管場所
             INNER JOIN F4100 LM --ロケーションマスタ
                ON LI.LIMCU   = LM.LMMCU
               AND LI.LILOCN  = LM.LMLOCN
             -------- 事業所名 -----------------------------------
             LEFT OUTER JOIN F0006 MC
               ON LI.LIMCU = MC.MCMCU
             -------- 保管場所名 ---------------------------------
             LEFT OUTER JOIN F0005 DR_LILOCN
                ON DECODE(LENGTH(TRIM(LI.LILOCN)), 15, SUBSTR(TRIM(LI.LILOCN),1,3), TRIM(LI.LILOCN)) = TRIM(DR_LILOCN.DRKY)
               AND DR_LILOCN.DRSY          = '57C '
               AND DR_LILOCN.DRRT          = '06'
             -------- 別注品購買業者、商品名、商品略名、商品分類1・2
             INNER JOIN F4101 IM
                ON LI.LIITM = IM.IMITM
        /*BEGIN*/
        WHERE
        /*IF stockPositionCode != null*/
          TRIM(LI.LIMCU) = /*stockPositionCode*/'1000'
        /*END*/
        /*IF stockCode == "3000" */
          AND  
          SUBSTR(IM.IMLITM,11,2) <> '  '
        /*END*/
        /*IF storePositionCode != null*/
        AND
          DECODE(LENGTH(TRIM(LI.LILOCN)), 15, SUBSTR(TRIM(LI.LILOCN),1,3), TRIM(LI.LILOCN)) = /*storePositionCode*/'001'
        /*END*/
        /*IF stockCode == "1000" && storePositionCode == null*/
        AND
          (DECODE(LENGTH(TRIM(LI.LILOCN)), 15, SUBSTR(TRIM(LI.LILOCN),1,3), TRIM(LI.LILOCN)) <> '200'
          OR DECODE(LENGTH(TRIM(LI.LILOCN)), 15, SUBSTR(TRIM(LI.LILOCN),1,3), TRIM(LI.LILOCN)) <> '201'
          OR DECODE(LENGTH(TRIM(LI.LILOCN)), 15, SUBSTR(TRIM(LI.LILOCN),1,3), TRIM(LI.LILOCN)) <> '202')
        /*END*/
        /*IF stockCode != "1000" && storePositionCode == null && stockCategory != null*/
        AND
          LM.LMBIN = RPAD(/*stockCategory*/'900', 8)
        /*END*/
        /*IF stockCode == "1000" && storePositionCode == null && stockCategory == null*/
        AND
          LM.LMKZON = '1'
        /*END*/
        /*IF stockCode == "1000" && storePositionCode == null && stockCategory != null*/
        AND
          LM.LMKZON <> '1'
        AND
          LM.LMBIN = RPAD(/*stockCategory*/'900', 8)
        /*END*/
        /*IF manufacturerCode != null*/
        AND
          SUBSTR(TRIM(IM.IMLITM),1,2) = /*manufacturerCode*/'01'
        /*END*/
        /*IF productCode != null*/
        AND
          SUBSTR(TRIM(IM.IMLITM),3,5) = /*productCode*/'00085'
        /*END*/
        /*IF addtionNo != null*/
        AND
          TRIM(SUBSTR(TRIM(IM.IMLITM),13,2)) IS NOT NULL
        /*END*/
        /*IF addtionNo == null*/
        AND
          TRIM(SUBSTR(TRIM(IM.IMLITM),13,2)) IS NULL
        /*END*/
        UNION ALL ----------------------------------------------------------------
        /**********************
         ** 入荷予定からの商品リスト 
         **********************/
        SELECT SUBSTR(TRIM(IM.IMLITM),3,5)  AS PCODE --商品コード
              ,TRIM(IM.IMDSC1)              AS PNAME --商品名
              ,'未選択'                     AS STATUS --ステータス 
        FROM F57B0020 TQ
             INNER JOIN F57B0010 TP
                ON TQ.TQY57BRCNO = TP.TPY57BRCNO
               AND TP.TPY57BOSTS  < '499'
               AND TQ.TQY57BUREC > 0
               /*IF stockPositionCode != null*/
               AND TP.TPY57BRMCU = LPAD(/*stockPositionCode*/'1000', 12)
               /*END*/
               -- 画面引数：在庫場所が必要
               -- 216は在庫場所＝1000の時のみ設定可能
               /*IF stockCode == "1000" */
               AND (TP.TPY57BRLCN <> RPAD('216', 20)
                    OR TP.TPY57BRLCN = RPAD(' ', 20))
               /*END*/
               /*IF stockCode != "1000" */
               AND TP.TPY57BRLCN = RPAD(' ', 20)
               /*END*/
             -------- 別注品購買業者、商品名、商品略名、商品分類1・2
             INNER JOIN F4101 IM
                ON TQ.TQY57BLITM = IM.IMLITM
         WHERE
             SUBSTR(IM.IMLITM,11,2) IS NOT NULL
         /*IF stockCode != "1000" || (stockCode == "1000" && stockCategory != null) */
           AND 1=2
         /*END*/
         /*IF stockCode == "3000" */
           AND  
           SUBSTR(IM.IMLITM,11,2) <> '  '
         /*END*/
         /*IF manufacturerCode != null*/
         AND
           SUBSTR(IM.IMLITM,1,2) = /*manufacturerCode*/'01'
         /*END*/
         /*IF productCode != null*/
         AND
           SUBSTR(IM.IMLITM,3,5) = /*productCode*/'00085'
         /*END*/
         /*IF addtionNo != null*/
         AND
           TRIM(SUBSTR(IM.IMLITM,13,2)) IS NOT NULL
         /*END*/
         /*IF addtionNo == null*/
         AND
           TRIM(SUBSTR(IM.IMLITM,13,2)) IS NULL
         /*END*/
        /*END*/
       ) AL
ORDER BY AL.PCODE
