SELECT KEY2   as key
      ,VALUE1 as label
      ,VALUE2 as value
FROM   TW_TCMN019001
WHERE  SYSTEM_ID = 'TOMS-WEB'
AND    KEY1='001'
ORDER BY KEY2
        ,VALUE2
