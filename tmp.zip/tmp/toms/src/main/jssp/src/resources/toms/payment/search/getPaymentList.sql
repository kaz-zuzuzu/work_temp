select
  mapyr,
  trim(macrcd) as macrcd,
  may56cathr,
  may56crper,
  may56carec,
  trim(may56cryi1) as may56cryi1,
  trim(may56ctra1) as may56ctra1,
  trim(may56cryi2) as may56cryi2,
  trim(may56ctra2) as may56ctra2,
  may56cerpe,
  may56ceare,
  trim(may56cery1) as may56cery1,
  trim(may56cetr1) as may56cetr1,
  trim(may56cery2) as may56cery2,
  trim(may56cetr2) as may56cetr2,
  trim(maurrf)     as maurrf,
  trim(maurcd)     as maurcd,
  maurab,
  maurat,
  maurdt,
  trim(mauser) as mauser,
  trim(mapid) as mapid,
  trim(majobn) as mapid,
  DECODE(F56C1030.maupmj, NULL, NULL, (select TO_CHAR(
              TO_DATE(
              CONCAT(((CASE WHEN LENGTH(F56C1030.maupmj)=6 THEN 2 ELSE 1 END)*1000
              +SUBSTR(F56C1030.maupmj,2,2)),'/01/01'))
              +TO_NUMBER(SUBSTR(F56C1030.maupmj,4,3)-1), 'FMYYYY/MM/DD') from dual)) AS maupmj,
  to_char(maupmt) as maupmt -- TODO 更新時刻
from
  F56C1030
where
 1=1
  /*IF mapyrFrom != null*/
  and F56C1030.mapyr >= /*mapyrFrom*/91000170
  /*END*/
  /*IF mapyrTo != null*/
  and F56C1030.mapyr <= /*mapyrTo*/91000200
  /*END*/
ORDER BY
  mapyr
