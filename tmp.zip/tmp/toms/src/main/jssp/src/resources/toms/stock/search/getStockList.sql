WITH BASE_QR AS
(
SELECT        
      IMBASE.IMLITM                                       AS IMLITM --品目No
      ,IMBASE.IMDSC1                                      AS IMDSC1 --記述１
      ,IMBASE.DRDL01_CL                                   AS DRDL01_CL --カラー名
      ,IMBASE.IMLITM_S                                    AS IMLITM_S --サイズコード
      ,IMBASE.LIPQOH                                      AS LIPQOH --在庫数量
      ,FC_JDI9902_TO_JULIAN(MIN(TQP.TPY57BRDD1))          AS TPY57BRDD1 --直近入荷予定日
FROM 
    (
        SELECT        
              IM.IMLITM                                       AS IMLITM --品目No
              ,TRIM(IM.IMDSC1)                                      AS IMDSC1 --記述１
              ,TRIM(DR_CL.DRDL01)                            AS DRDL01_CL --カラー名
              ,SUBSTR(IM.IMLITM,11,2)                        AS IMLITM_S --サイズコード
              ,SUM(LI.LIPQOH)                                       AS LIPQOH --在庫数量
        FROM -- 【トランザクションテーブル】 ---------------------
               F41021 LI --品目保管場所
               INNER JOIN F4100 LM --ロケーションマスタ
                  ON LI.LIMCU   = LM.LMMCU
                 AND LI.LILOCN  = LM.LMLOCN
               -------- 別注品購買業者、商品名、商品略名、商品分類1・2
               INNER JOIN F4101 IM
                  ON LI.LIITM = IM.IMITM
                        -------- カラー名 -----------------------------
         LEFT OUTER JOIN F0005 DR_CL
            ON TRIM(SUBSTR(IM.IMLITM,8,3)) = TRIM(DR_CL.DRKY)
           AND DR_CL.DRSY                             = '41F '
           AND DR_CL.DRRT                             = DECODE(TRIM(SUBSTR(IM.IMLITM,1,2)),'01','1C','2C')
        WHERE
            SUBSTR(IM.IMLITM,11,2) IS NOT NULL
        /*IF stockPositionCode != null*/
        AND
          LI.LIMCU = LPAD(/*stockPositionCode*/'1000', 12)
        /*END*/
        /*IF stockCode == "3000" */
          AND  
          SUBSTR(IM.IMLITM,11,2) <> '  '
        /*END*/
        /*IF storePositionCode != null*/
        AND
          DECODE(LENGTH(TRIM(LI.LILOCN)), 15,SUBSTR(LI.LILOCN,1,3),TRIM(LI.LILOCN)) = /*storePositionCode*/'001'
        /*END*/
        /*IF stockCode != "1000" && storePositionCode == null && stockCategory != null*/
        AND
          LM.LMBIN = RPAD(/*stockCategory*/'900', 8)
        /*END*/
        /*IF stockCode == "1000" && storePositionCode == null*/
        AND
          (DECODE(LENGTH(TRIM(LI.LILOCN)), 15, SUBSTR(TRIM(LI.LILOCN),1,3), TRIM(LI.LILOCN)) <> '200'
          OR DECODE(LENGTH(TRIM(LI.LILOCN)), 15, SUBSTR(TRIM(LI.LILOCN),1,3), TRIM(LI.LILOCN)) <> '201'
          OR DECODE(LENGTH(TRIM(LI.LILOCN)), 15, SUBSTR(TRIM(LI.LILOCN),1,3), TRIM(LI.LILOCN)) <> '202')
        /*END*/
        /*IF stockCode != "1000" && storePositionCode == null && stockCategory != null*/
        AND
          LM.LMBIN = RPAD(/*stockCategory*/'900', 8)
        /*END*/
        /*IF stockCode == "1000" && storePositionCode == null && stockCategory == null*/
        AND
          LM.LMKZON = RPAD('1', 6)
        /*END*/
        /*IF stockCode == "1000" && storePositionCode == null && stockCategory != null*/
        AND
          LM.LMKZON <> RPAD('1', 6)
        AND
          LM.LMBIN = RPAD(/*stockCategory*/'900', 8)
        /*END*/
        /*IF manufacturerCode != null*/
        AND
          SUBSTR(IM.IMLITM,1,2) = /*manufacturerCode*/'01'
        /*END*/
        /*IF productCodes != null*/
        AND
          SUBSTR(IM.IMLITM,3,5) in /*productCodes*/('00001', '00169')
        /*END*/
        /*IF addtionNo != null*/
        AND
          TRIM(SUBSTR(IM.IMLITM,13,2)) IS NOT NULL
        /*END*/
        /*IF addtionNo == null*/
        AND
          TRIM(SUBSTR(IM.IMLITM,13,2)) IS NULL
        /*END*/
        
        GROUP BY
        IM.IMLITM --品目No
        ,IM.IMDSC1 --記述１
        ,TRIM(DR_CL.DRDL01) 
        ,SUBSTR(IM.IMLITM,11,2) 
    ) IMBASE
   -------- 入荷予定明細、 入荷予定見出し-----------------------------
   LEFT OUTER JOIN 
     ( SELECT 
          TQ.TQY57BLITM    AS TQY57BLITM --品番
          ,TQ.TQY57BQTYA   AS TQY57BQTYA --入荷予定数
          ,TP.TPY57BRDD1   AS TPY57BRDD1 --入荷予定日
       FROM
          F57B0020 TQ
   INNER JOIN F57B0010 TP
      ON TQ.TQY57BRCNO = TP.TPY57BRCNO
     AND TP.TPY57BOSTS  < '499'
--     AND TP.TPY57BRDD1 >= TRUNC(SYSDATE)
     AND TQ.TQY57BUREC > 0
     /*IF stockPositionCode != null*/
     AND TP.TPY57BRMCU = LPAD(/*stockPositionCode*/'1000', 12)
     /*END*/
-- 画面引数：在庫場所が必要
-- 216は在庫場所＝1000の時のみ設定可能
    /*IF stockCode == "1000" */
    AND (TP.TPY57BRLCN <> RPAD('216', 20)
            OR   TP.TPY57BRLCN = RPAD(' ', 20))
    /*END*/
    /*IF stockCode != "1000" */
    AND TP.TPY57BRLCN = RPAD(' ', 20)
    /*END*/
   ) TQP
   ON IMBASE.IMLITM = TQP.TQY57BLITM
GROUP BY
IMBASE.IMLITM 
,IMBASE.IMDSC1 
,IMBASE.DRDL01_CL
,IMBASE.IMLITM_S
,IMBASE.LIPQOH
)



SELECT DISTINCT
    BKEEP_QR.IMLITM                               AS IMLITM --品目No
    ,BKEEP_QR.IMDSC1                              AS IMDSC1 --記述１
    ,BKEEP_QR.DRDL01_CL                           AS DRDL01_CL --カラー名
    ,BKEEP_QR.IMLITM_S                            AS IMLITM_S --サイズコード
    /*IF stockCode == "1000" && stockCategory == null*/
    ,CASE WHEN BKEEP_QR.LIPQOH - DECODE(BKEEP_QR.TCY57AKRQT_R, NULL, 0, BKEEP_QR.TCY57AKRQT_R) >= 0 THEN BKEEP_QR.LIPQOH - DECODE(BKEEP_QR.TCY57AKRQT_R, NULL, 0, BKEEP_QR.TCY57AKRQT_R)
                      ELSE 0 END AS LIPQOH --在庫数量
    /*END*/
    /*IF !(stockCode == "1000" && stockCategory == null)*/
    ,BKEEP_QR.LIPQOH      AS LIPQOH --在庫数量
    /*END*/
FROM
      (
        SELECT
        BASE_QR.IMLITM                               AS IMLITM --品目No
        ,BASE_QR.IMDSC1                              AS IMDSC1 --記述１
        ,BASE_QR.DRDL01_CL                                   AS DRDL01_CL --カラー名
        ,BASE_QR.IMLITM_S                                    AS IMLITM_S --サイズコード
        ,BASE_QR.LIPQOH                              AS LIPQOH --在庫数量
        ,SUM(CASE WHEN TC.TCPDDJ <= BASE_QR.TPY57BRDD1 THEN TC.TCY57AKRQT 
              WHEN BASE_QR.TPY57BRDD1 IS NULL THEN TC.TCY57AKRQT 
              ELSE NULL END)  AS TCY57AKRQT_R --実在庫キープ
        FROM
          BASE_QR
        LEFT OUTER JOIN F57A0030 TC
           ON BASE_QR.IMLITM = TC.TCLITM
           /*IF stockPositionCode != null*/
            AND
              TC.TCMCU = LPAD(/*stockPositionCode*/'1000', 12)
          /*END*/
          WHERE
                  TRIM(TCY57AKPST) IS NULL
              AND TRIM(TCY57ASTKF) IS NULL
        GROUP BY
        BASE_QR.IMLITM --品目No
        ,BASE_QR.IMDSC1 --記述１
        ,BASE_QR.DRDL01_CL
        ,BASE_QR.IMLITM_S
        ,BASE_QR.LIPQOH 
      ) BKEEP_QR
ORDER BY
IMLITM